(function runPopup(global) {
  "use strict";

  const extensionApi = global.browser || global.chrome;
  const defaultRules = global.BYEBYEFISHING_DEFAULT_RULES || [];
  const rulesetVersion = global.BYEBYEFISHING_RULESET_VERSION || "0";
  const detector = global.ByeByeFishingDetector;

  function storageGet(defaults) {
    const result = extensionApi.storage.sync.get(defaults);
    if (result && typeof result.then === "function") {
      return result;
    }
    return new Promise((resolve) => extensionApi.storage.sync.get(defaults, resolve));
  }

  function storageSet(values) {
    const result = extensionApi.storage.sync.set(values);
    if (result && typeof result.then === "function") {
      return result;
    }
    return new Promise((resolve) => extensionApi.storage.sync.set(values, resolve));
  }

  function mergeSavedRules(rules) {
    const merged = detector.mergeDefaultRuleUpdates
      ? detector.mergeDefaultRuleUpdates(rules, defaultRules)
      : rules;
    return detector.validateRules(merged).ok ? merged : defaultRules;
  }

  async function init() {
    const checkbox = document.getElementById("trustedBadges");
    const ruleCount = document.getElementById("ruleCount");
    const openOptions = document.getElementById("openOptions");
    const saved = await storageGet({
      byebyefishingRules: defaultRules,
      byebyefishingRulesCustom: false,
      byebyefishingRulesVersion: "",
      byebyefishingShowTrustedBadges: true
    });

    const validation = detector.validateRules(saved.byebyefishingRules);
    const shouldUseSavedRules =
      validation.ok && (saved.byebyefishingRulesCustom || saved.byebyefishingRulesVersion === rulesetVersion);
    const rules = shouldUseSavedRules ? mergeSavedRules(saved.byebyefishingRules) : defaultRules;

    checkbox.checked = saved.byebyefishingShowTrustedBadges !== false;
    ruleCount.textContent = `${rules.length} watched brands`;

    checkbox.addEventListener("change", () => {
      storageSet({ byebyefishingShowTrustedBadges: checkbox.checked });
    });

    openOptions.addEventListener("click", () => {
      if (extensionApi.runtime.openOptionsPage) {
        extensionApi.runtime.openOptionsPage();
      }
    });
  }

  init();
})(typeof globalThis !== "undefined" ? globalThis : this);
