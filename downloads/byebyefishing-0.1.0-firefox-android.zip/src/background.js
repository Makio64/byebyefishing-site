(function runBackground(global) {
  "use strict";

  const extensionApi = global.browser || global.chrome;
  if (!extensionApi?.runtime?.onInstalled || !extensionApi?.runtime?.getURL) {
    return;
  }

  extensionApi.runtime.onInstalled.addListener((details) => {
    if (details.reason !== "install") {
      return;
    }

    const onboardingUrl = extensionApi.runtime.getURL("onboarding.html");
    const opened = extensionApi.tabs?.create?.({ url: onboardingUrl });
    if (opened?.catch) {
      opened.catch(() => {});
    }
  });
})(typeof globalThis !== "undefined" ? globalThis : this);
