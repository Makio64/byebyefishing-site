(function runOnboarding(global) {
  "use strict";

  const extensionApi = global.browser || global.chrome;
  const CONSENT_VERSION = 1;
  const enableButton = document.getElementById("enableProtection");
  const notNowButton = document.getElementById("notNow");
  const status = document.getElementById("setupStatus");

  if (!extensionApi?.storage?.local) {
    enableButton.disabled = true;
    status.textContent = "Browser extension storage is unavailable. Reinstall the extension and try again.";
    status.classList.add("error");
    return;
  }

  function storageGet(defaults) {
    if (global.browser) {
      return extensionApi.storage.local.get(defaults);
    }
    return new Promise((resolve, reject) => {
      extensionApi.storage.local.get(defaults, (values) => {
        const error = extensionApi.runtime?.lastError;
        error ? reject(new Error(error.message)) : resolve(values);
      });
    });
  }

  function storageSet(values) {
    if (global.browser) {
      return extensionApi.storage.local.set(values);
    }
    return new Promise((resolve, reject) => {
      extensionApi.storage.local.set(values, () => {
        const error = extensionApi.runtime?.lastError;
        error ? reject(new Error(error.message)) : resolve();
      });
    });
  }

  function showEnabled() {
    enableButton.textContent = "Protection enabled";
    enableButton.disabled = true;
    notNowButton.hidden = true;
    status.textContent = "Done. Open or reload a supported webmail page to start local checks.";
    status.classList.remove("error");
  }

  enableButton.addEventListener("click", async () => {
    enableButton.disabled = true;
    status.textContent = "Saving your choice…";
    try {
      await storageSet({ byebyefishingPrivacyConsentVersion: CONSENT_VERSION });
      showEnabled();
    } catch (error) {
      enableButton.disabled = false;
      status.textContent = "That choice could not be saved. Please try again.";
      status.classList.add("error");
    }
  });

  notNowButton.addEventListener("click", () => {
    status.textContent = "Protection remains paused. Reopen this setup from the extension popup when you are ready.";
    global.close();
  });

  storageGet({ byebyefishingPrivacyConsentVersion: 0 })
    .then((saved) => {
      if (saved.byebyefishingPrivacyConsentVersion >= CONSENT_VERSION) {
        showEnabled();
      }
    })
    .catch(() => {
      status.textContent = "Your current setup choice could not be read. You can try enabling protection again.";
      status.classList.add("error");
    });
})(typeof globalThis !== "undefined" ? globalThis : this);
