(function exposeDefaultRules(global) {
  "use strict";

  const RULESET_VERSION = "2026-07-31.0";

  function rule(category, id, name, aliases, allowedDomains, options = {}) {
    return {
      category,
      id,
      name,
      aliases,
      allowedDomains,
      ...(category === "forms" ? { userContentPlatform: true } : {}),
      ...options
    };
  }

  const rules = [
    rule("developer", "stripe", "Stripe", ["stripe"], [
      "stripe.com",
      "stripe.dev",
      "stripe.events",
      "stripe.global",
      "link.com"
    ]),
    rule("developer", "github", "GitHub", ["github"], [
      "github.com",
      "githubstatus.com"
    ]),
    rule("developer", "gitlab", "GitLab", ["gitlab"], ["gitlab.com"]),
    rule("developer", "bitbucket", "Bitbucket", ["bitbucket"], ["bitbucket.org"]),
    rule("developer", "atlassian", "Atlassian", ["atlassian", "jira", "confluence"], [
      "atlassian.com",
      "jira.com",
      "statuspage.io"
    ]),
    rule("developer", "npm", "npm", ["npm", "npmjs"], ["npmjs.com"]),
    rule("developer", "pypi", "Python Package Index", ["pypi", "python package index"], [
      "pypi.org",
      "python.org"
    ]),
    rule("developer", "docker", "Docker", ["docker", "docker hub"], [
      "docker.com",
      "docker.io"
    ]),
    rule("developer", "cloudflare", "Cloudflare", ["cloudflare"], [
      "cloudflare.com",
      "cloudflarestatus.com"
    ]),
    rule("developer", "vercel", "Vercel", ["vercel"], ["vercel.com"]),
    rule("developer", "netlify", "Netlify", ["netlify"], ["netlify.com"]),
    rule("developer", "aws", "Amazon Web Services", ["aws", "amazon web services"], [
      "aws.amazon.com",
      "amazonaws.com"
    ]),
    rule("developer", "google-cloud", "Google Cloud", ["google cloud", "gcp", "firebase"], [
      "cloud.google.com",
      "console.cloud.google.com",
      "firebase.google.com",
      "firebaseapp.com"
    ], {
      senderDomains: ["google.com"],
      senderMatchSubdomains: false
    }),
    rule("developer", "azure", "Microsoft Azure", ["azure", "microsoft azure"], [
      "azure.com"
    ]),
    rule("developer", "digitalocean", "DigitalOcean", ["digitalocean"], ["digitalocean.com"]),
    rule("developer", "heroku", "Heroku", ["heroku"], ["heroku.com"]),
    rule("developer", "supabase", "Supabase", ["supabase"], ["supabase.com"]),
    rule("developer", "mongodb", "MongoDB", ["mongodb", "mongo db"], ["mongodb.com"]),
    rule("developer", "planetscale", "PlanetScale", ["planetscale"], ["planetscale.com"]),
    rule("developer", "neon", "Neon", ["neon database", "neon postgres", "neon.tech"], [
      "neon.com",
      "neon.tech",
      "neonstatus.com"
    ]),
    rule("developer", "railway", "Railway", ["railway.app", "railway hosting"], [
      "railway.com",
      "railway.app"
    ]),
    rule("developer", "render", "Render", ["render.com", "render hosting"], ["render.com"]),
    rule("developer", "fly-io", "Fly.io", ["fly.io", "fly app"], ["fly.io"]),
    rule("developer", "twilio", "Twilio", ["twilio"], ["twilio.com", "segment.com"]),
    rule("developer", "sendgrid", "SendGrid", ["sendgrid"], ["sendgrid.com", "twilio.com"]),
    rule("developer", "mailgun", "Mailgun", ["mailgun"], ["mailgun.com"]),
    rule("developer", "postmark", "Postmark", ["postmark"], ["postmarkapp.com"]),
    rule("developer", "resend", "Resend", ["resend.com", "resend email"], ["resend.com"]),
    rule("developer", "mailchimp", "Mailchimp", ["mailchimp"], [
      "mailchimp.com"
    ]),
    rule("developer", "linear", "Linear", ["linear.app", "linear issue"], ["linear.app"]),
    rule("developer", "sentry", "Sentry", ["sentry"], ["sentry.io"]),
    rule("developer", "datadog", "Datadog", ["datadog"], ["datadoghq.com", "datadog.com"]),
    rule("developer", "new-relic", "New Relic", ["new relic", "newrelic"], ["newrelic.com"]),
    rule("developer", "circleci", "CircleCI", ["circleci", "circle ci"], ["circleci.com"]),
    rule("developer", "travis-ci", "Travis CI", ["travis ci", "travis-ci"], ["travis-ci.com"]),
    rule("developer", "buildkite", "Buildkite", ["buildkite"], ["buildkite.com"]),
    rule("developer", "jetbrains", "JetBrains", ["jetbrains"], ["jetbrains.com"]),
    rule("developer", "hashicorp", "HashiCorp", ["hashicorp", "terraform cloud"], [
      "hashicorp.com"
    ]),
    rule("developer", "openai", "OpenAI", ["openai", "chatgpt"], [
      "openai.com",
      "chatgpt.com"
    ]),
    rule("developer", "anthropic", "Anthropic", ["anthropic", "claude"], [
      "anthropic.com",
      "claude.ai"
    ]),

    rule("payments", "paypal", "PayPal", ["paypal"], ["paypal.com", "paypal.fr"]),
    rule("payments", "adyen", "Adyen", ["adyen"], ["adyen.com"]),
    rule("payments", "mollie", "Mollie", ["mollie"], ["mollie.com"]),
    rule("payments", "checkout", "Checkout.com", ["checkout.com", "checkout payments"], [
      "checkout.com"
    ]),
    rule("payments", "paddle", "Paddle", ["paddle payments", "paddle.com"], [
      "paddle.com",
      "paddle.net",
      "paddle.io"
    ]),
    rule("payments", "lemonsqueezy", "Lemon Squeezy", ["lemon squeezy", "lemonsqueezy"], [
      "lemonsqueezy.com"
    ]),
    rule("payments", "square", "Square", ["square payments", "squareup"], [
      "square.com",
      "squareup.com",
      "block.xyz"
    ]),
    rule("payments", "cash-app", "Cash App", ["cash app", "cash.app"], ["cash.app"]),
    rule("payments", "venmo", "Venmo", ["venmo"], ["venmo.com"]),
    rule("payments", "wise", "Wise", ["wise.com", "wise payments", "transferwise"], [
      "wise.com",
      "transferwise.com"
    ]),
    rule("payments", "revolut", "Revolut", ["revolut"], ["revolut.com"]),
    rule("payments", "lydia-sumeria", "Lydia / Sumeria", ["lydia", "sumeria"], [
      "lydia-app.com",
      "lydia.me",
      "sumeria.eu"
    ], {
      senderDomains: ["lydia-app.com", "lydia.me", "sumeria.eu", "isbs.eu"],
      senderMatchSubdomains: true
    }),
    rule("payments", "klarna", "Klarna", ["klarna"], [
      "klarna.com",
      "klarna.fr",
      "app.klarna.com",
      "portal.klarna.com",
      "merchants.klarna.com",
      "investors.klarna.com"
    ], {
      senderDomains: ["klarna.com", "klarna.fr"],
      senderMatchSubdomains: true
    }),
    rule("payments", "afterpay", "Afterpay", ["afterpay"], ["afterpay.com"]),
    rule("payments", "affirm", "Affirm", ["affirm"], ["affirm.com"]),
    rule("payments", "worldline", "Worldline", ["worldline"], ["worldline.com"]),
    rule("payments", "visa", "Visa", ["visa", "visa card", "visa.com"], ["visa.com", "visa.fr"], {
      senderAliases: ["visa card", "visa.com"]
    }),
    rule("payments", "mastercard", "Mastercard", ["mastercard"], [
      "mastercard.com",
      "mastercard.fr"
    ]),
    rule("payments", "western-union", "Western Union", ["western union"], [
      "westernunion.com"
    ]),
    rule("payments", "moneygram", "MoneyGram", ["moneygram"], ["moneygram.com"]),
    rule("payments", "zelle", "Zelle", ["zelle"], ["zelle.com", "zellepay.com"]),
    rule("payments", "braintree", "PayPal Braintree", ["braintree", "braintree payments"], [
      "braintreepayments.com",
      "braintreegateway.com"
    ]),
    rule("payments", "sumup", "SumUp", ["sumup"], ["sumup.com"]),
    rule("payments", "payoneer", "Payoneer", ["payoneer"], ["payoneer.com"]),
    rule("payments", "airwallex", "Airwallex", ["airwallex"], ["airwallex.com"]),
    rule("payments", "lemonway", "Lemonway", ["lemonway"], ["lemonway.com"]),
    rule("payments", "ideal", "iDEAL", ["ideal payment", "ideal payments"], [
      "ideal.nl"
    ]),
    rule("payments", "wero", "Wero", ["wero", "wero wallet", "ideal wero"], [
      "wero-wallet.eu",
      "epicompany.eu",
      "weropay.eu"
    ]),

    rule("banks-fr", "la-banque-postale", "La Banque Postale", [
      "la banque postale",
      "banque postale"
    ], ["labanquepostale.fr"]),
    rule("banks-fr", "societe-generale", "Societe Generale", [
      "societe generale",
      "socgen",
      "particuliers sg"
    ], ["societegenerale.fr", "particuliers.sg.fr", "sg.fr"]),
    rule("banks-fr", "bnp-paribas", "BNP Paribas", ["bnp paribas", "bnpparibas"], [
      "bnpparibas.net",
      "mabanque.bnpparibas",
      "bnpparibas.com"
    ]),
    rule("banks-fr", "credit-agricole", "Credit Agricole", ["credit agricole"], [
      "credit-agricole.fr"
    ]),
    rule("banks-fr", "lcl", "LCL", ["lcl"], ["lcl.fr"]),
    rule("banks-fr", "credit-mutuel", "Credit Mutuel", ["credit mutuel"], [
      "creditmutuel.fr",
      "creditmutuel.com"
    ]),
    rule("banks-fr", "cic", "CIC", ["cic banque", "cic.fr"], ["cic.fr", "cic.com"]),
    rule("banks-fr", "caisse-epargne", "Caisse d'Epargne", [
      "caisse epargne",
      "caisse d epargne"
    ], ["caisse-epargne.fr"]),
    rule("banks-fr", "banque-populaire", "Banque Populaire", ["banque populaire"], [
      "banquepopulaire.fr"
    ]),
    rule("banks-fr", "bred", "BRED", ["bred banque", "bred.fr"], ["bred.fr"]),
    rule("banks-fr", "bourso-bank", "BoursoBank", [
      "boursobank",
      "boursorama",
      "boursorama banque"
    ], ["boursobank.com", "boursorama.com", "boursorama-banque.com"]),
    rule("banks-fr", "fortuneo", "Fortuneo", ["fortuneo"], ["fortuneo.fr"]),
    rule("banks-fr", "hello-bank", "Hello bank!", ["hello bank", "hellobank"], [
      "hellobank.fr"
    ]),
    rule("banks-fr", "bforbank", "BforBank", ["bforbank"], ["bforbank.com"]),
    rule("banks-fr", "monabanq", "Monabanq", ["monabanq"], ["monabanq.com"]),
    rule("banks-fr", "axa-banque", "AXA Banque", ["axa banque", "axabanque"], [
      "axa.fr",
      "axa.com",
      "axabanque.fr"
    ]),
    rule("banks-fr", "nickel", "Nickel", ["compte nickel", "nickel.eu"], [
      "nickel.eu",
      "nickel.fr"
    ]),
    rule("banks-fr", "qonto", "Qonto", ["qonto"], ["qonto.com"]),
    rule("banks-fr", "shine", "Shine", ["shine banque", "shine.fr"], ["shine.fr"]),
    rule("banks-fr", "blank", "Blank", ["blank.app", "blank banking"], ["blank.app"]),
    rule("banks-fr", "memo-bank", "Memo Bank", ["memo bank", "memo.bank"], ["memo.bank"]),
    rule("banks-fr", "manager-one", "Manager.one", ["manager.one", "manager one"], [
      "manager.one"
    ]),

    rule("consumer-credit-fr", "cetelem", "Cetelem", ["cetelem"], ["cetelem.fr"]),
    rule("consumer-credit-fr", "cofidis", "Cofidis", ["cofidis"], ["cofidis.fr"]),
    rule("consumer-credit-fr", "floa-bank", "Floa (FLOA Bank)", ["floa", "floa bank", "floabank"], [
      "floabank.fr",
      "floa.com",
      "floapay.fr",
      "moncoupdepouce.com"
    ]),
    rule("consumer-credit-fr", "oney", "Oney", ["oney"], ["oney.fr", "oney.com"]),
    rule("consumer-credit-fr", "sofinco", "Sofinco", ["sofinco"], ["sofinco.fr"]),
    rule("consumer-credit-fr", "younited-credit", "Younited Credit", [
      "younited",
      "younited credit"
    ], ["younited-credit.com", "younited.com"]),
    rule("consumer-credit-fr", "franfinance", "Franfinance", ["franfinance"], [
      "franfinance.fr"
    ]),
    rule("consumer-credit-fr", "carrefour-banque", "Carrefour Banque", [
      "carrefour banque"
    ], ["carrefour-banque.fr"]),

    rule("banks-global", "american-express", "American Express", [
      "american express",
      "amex"
    ], ["americanexpress.com", "aexp.com"]),
    rule("banks-global", "jpmorgan-chase", "JPMorgan Chase", [
      "jpmorgan",
      "jpmorgan chase",
      "chase bank"
    ], ["jpmorgan.com", "jpmorganchase.com", "chase.com"]),
    rule("banks-global", "bank-of-america", "Bank of America", [
      "bank of america",
      "bofa"
    ], ["bankofamerica.com", "bofa.com"]),
    rule("banks-global", "citi", "Citi", ["citi bank", "citibank"], [
      "citi.com",
      "citibank.com"
    ]),
    rule("banks-global", "wells-fargo", "Wells Fargo", ["wells fargo"], [
      "wellsfargo.com"
    ]),
    rule("banks-global", "capital-one", "Capital One", ["capital one"], [
      "capitalone.com"
    ]),
    rule("banks-global", "discover", "Discover", ["discover card", "discover bank"], [
      "discover.com"
    ]),
    rule("banks-global", "us-bank", "U.S. Bank", ["us bank", "u s bank"], ["usbank.com"]),
    rule("banks-global", "pnc", "PNC Bank", ["pnc bank"], ["pnc.com"]),
    rule("banks-global", "td-bank", "TD Bank", ["td bank"], ["td.com", "tdbank.com"]),
    rule("banks-global", "hsbc", "HSBC", ["hsbc"], ["hsbc.com", "hsbc.fr", "hsbc.co.uk"]),
    rule("banks-global", "barclays", "Barclays", ["barclays"], [
      "barclays.com",
      "barclays.co.uk",
      "home.barclays"
    ]),
    rule("banks-global", "santander", "Santander", ["santander"], [
      "santander.com",
      "santander.co.uk"
    ]),
    rule("banks-global", "ing", "ING", ["ing bank", "ing direct"], [
      "ing.com",
      "ing.fr",
      "ing.nl",
      "ingwb.com"
    ]),
    rule("banks-global", "deutsche-bank", "Deutsche Bank", ["deutsche bank"], [
      "db.com",
      "deutsche-bank.de",
      "deutschebank.com"
    ]),
    rule("banks-global", "ubs", "UBS", ["ubs bank", "ubs.com"], ["ubs.com"]),
    rule("banks-global", "natwest", "NatWest", ["natwest"], ["natwest.com"]),
    rule("banks-global", "lloyds", "Lloyds Bank", ["lloyds bank"], ["lloydsbank.com"]),
    rule("banks-global", "halifax", "Halifax", ["halifax bank"], ["halifax.co.uk"]),
    rule("banks-global", "monzo", "Monzo", ["monzo"], ["monzo.com"]),
    rule("banks-global", "starling", "Starling Bank", ["starling bank"], [
      "starlingbank.com"
    ]),
    rule("banks-global", "n26", "N26", ["n26"], ["n26.com"]),
    rule("banks-global", "bunq", "Bunq", ["bunq"], ["bunq.com"]),
    rule("banks-global", "trade-republic", "Trade Republic", ["trade republic"], [
      "traderepublic.com"
    ]),
    rule("banks-global", "robinhood", "Robinhood", ["robinhood"], ["robinhood.com"]),
    rule("banks-global", "vanguard", "Vanguard", ["vanguard"], ["vanguard.com"]),
    rule("banks-global", "fidelity", "Fidelity", ["fidelity investments"], [
      "fidelity.com"
    ]),
    rule("banks-global", "charles-schwab", "Charles Schwab", ["charles schwab", "schwab"], [
      "schwab.com"
    ]),
    rule("banks-global", "etrade", "E*TRADE", ["etrade", "e trade"], ["etrade.com"]),

    rule("crypto", "coinbase", "Coinbase", ["coinbase"], ["coinbase.com"]),
    rule("crypto", "binance", "Binance", ["binance"], ["binance.com"]),
    rule("crypto", "kraken", "Kraken", ["kraken"], ["kraken.com"]),
    rule("crypto", "crypto-com", "Crypto.com", ["crypto.com", "crypto com"], [
      "crypto.com"
    ]),
    rule("crypto", "ledger", "Ledger", ["ledger wallet", "ledger.com"], ["ledger.com"]),
    rule("crypto", "metamask", "MetaMask", ["metamask"], ["metamask.io"]),
    rule("crypto", "phantom", "Phantom", ["phantom wallet"], [
      "phantom.com",
      "phantom.app"
    ]),
    rule("crypto", "trust-wallet", "Trust Wallet", ["trust wallet"], [
      "trustwallet.com"
    ]),
    rule("crypto", "exodus", "Exodus", ["exodus wallet"], ["exodus.com"]),
    rule("crypto", "trezor", "Trezor", ["trezor"], ["trezor.io"]),
    rule("crypto", "okx", "OKX", ["okx"], ["okx.com"]),
    rule("crypto", "bybit", "Bybit", ["bybit"], ["bybit.com"]),
    rule("crypto", "kucoin", "KuCoin", ["kucoin"], ["kucoin.com"]),
    rule("crypto", "opensea", "OpenSea", ["opensea", "open sea"], ["opensea.io"]),
    rule("crypto", "uniswap", "Uniswap", ["uniswap"], ["uniswap.org"]),

    rule("government-fr", "impots", "Impots.gouv.fr", [
      "impots",
      "impots.gouv",
      "finances publiques",
      "dgfip"
    ], ["impots.gouv.fr", "dgfip.finances.gouv.fr"]),
    rule("government-fr", "franceconnect", "FranceConnect", ["franceconnect"], [
      "franceconnect.gouv.fr"
    ]),
    rule("government-fr", "service-public", "Service Public", ["service public"], [
      "service-public.gouv.fr",
      "service-public.fr"
    ]),
    rule("government-fr", "france-identite", "France Identité", [
      "france identité",
      "france identite",
      "identité numérique",
      "identite numerique"
    ], ["france-identite.gouv.fr"]),
    rule("government-fr", "ameli", "Ameli", ["ameli", "assurance maladie"], [
      "ameli.fr",
      "assurance-maladie.fr"
    ]),
    rule("government-fr", "caf", "CAF", ["caf", "allocations familiales"], ["caf.fr"]),
    rule("government-fr", "ants", "France Titres (ANTS)", [
      "ants",
      "france titres",
      "agence nationale des titres"
    ], [
      "ants.gouv.fr"
    ]),
    rule("government-fr", "france-travail", "France Travail", [
      "france travail",
      "pole emploi"
    ], ["francetravail.fr", "pole-emploi.fr"]),
    rule("government-fr", "urssaf", "Urssaf", ["urssaf"], ["urssaf.fr"]),
    rule("government-fr", "msa", "MSA", ["msa securite sociale", "msa.fr"], ["msa.fr"]),
    rule("government-fr", "cesu", "Cesu", ["cesu"], ["cesu.urssaf.fr"]),
    rule("government-fr", "pajemploi", "Pajemploi", ["pajemploi"], ["pajemploi.urssaf.fr"]),
    rule("government-fr", "mon-compte-formation", "Mon Compte Formation", [
      "mon compte formation"
    ], ["moncompteformation.gouv.fr"]),
    rule("government-fr", "antai-amendes", "ANTAI / Amendes.gouv.fr", [
      "antai",
      "amendes.gouv",
      "amendes"
    ], ["antai.gouv.fr", "amendes.gouv.fr"]),
    rule("government-fr", "info-retraite", "Info Retraite", ["info retraite"], [
      "info-retraite.fr",
      "lassuranceretraite.fr",
      "agirc-arrco.fr"
    ]),
    rule("government-fr", "demarches-simplifiees", "Demarches Simplifiees", [
      "demarches simplifiees"
    ], ["demarches-simplifiees.fr"]),
    rule("government-fr", "diplomatie", "France Diplomatie", ["france diplomatie"], [
      "diplomatie.gouv.fr"
    ]),
    rule("government-fr", "gouvernement", "Gouvernement / info.gouv.fr", ["gouvernement"], [
      "gouvernement.fr",
      "info.gouv.fr"
    ]),
    rule("government-fr", "critair", "Crit'Air", [
      "crit'air",
      "critair",
      "crit air",
      "certificat qualite de l'air",
      "certificat-air"
    ], ["certificat-air.gouv.fr"]),
    rule("government-fr", "cheque-energie", "Cheque energie", [
      "cheque energie",
      "chequeenergie",
      "cheque-energie"
    ], ["chequeenergie.gouv.fr"]),
    rule("government-fr", "maprimerenov", "MaPrimeRenov'", [
      "maprimerenov",
      "ma prime renov",
      "maprimerénov",
      "ma prime renov'"
    ], ["maprimerenov.gouv.fr"]),

    rule("government-global", "irs", "IRS", ["irs", "internal revenue service"], [
      "irs.gov"
    ]),
    rule("government-global", "ssa", "Social Security Administration", [
      "social security administration",
      "ssa.gov"
    ], ["ssa.gov"]),
    rule("government-global", "gov-uk", "GOV.UK", ["gov.uk", "government uk"], [
      "gov.uk"
    ]),
    rule("government-global", "hmrc", "HMRC", ["hmrc", "hm revenue"], [
      "hmrc.gov.uk",
      "gov.uk"
    ]),
    rule("government-global", "canada-ca", "Government of Canada", [
      "government of canada",
      "canada.ca"
    ], ["canada.ca", "gc.ca"]),
    rule("government-global", "ato", "Australian Taxation Office", [
      "australian taxation office",
      "ato"
    ], ["ato.gov.au"]),
    rule("government-global", "mygov-au", "myGov Australia", ["mygov australia", "mygov"], [
      "my.gov.au"
    ]),
    rule("government-global", "europa", "European Union", ["europa.eu", "european union"], [
      "europa.eu"
    ]),
    rule("government-global", "agenzia-entrate", "Agenzia delle Entrate", [
      "agenzia delle entrate",
      "agenzia entrate"
    ], ["agenziaentrate.gov.it", "agenziaentrate.it"]),
    rule("government-global", "inps", "INPS", ["inps"], ["inps.it"]),
    rule("government-global", "agencia-tributaria", "Agencia Tributaria", [
      "agencia tributaria",
      "agenciatributaria"
    ], ["agenciatributaria.gob.es", "agenciatributaria.es"]),
    rule("government-global", "digid", "DigiD", ["digid"], ["digid.nl"]),
    rule("government-global", "belastingdienst", "Belastingdienst", [
      "belastingdienst"
    ], ["belastingdienst.nl"]),
    rule("government-global", "elster", "ELSTER", ["elster", "elster online"], [
      "elster.de"
    ]),
    rule("government-global", "belgium-be", "Belgium.be", [
      "belgium.be",
      "belgique.be"
    ], ["belgium.be"]),

    rule("toll-roads-fr", "sanef", "Sanef", [
      "sanef",
      "sanef autoroutes"
    ], ["sanef.com", "sanef.fr", "sapn.fr"]),
    rule("toll-roads-fr", "bipandgo", "Bip&Go", [
      "bip&go",
      "bip and go",
      "bipandgo"
    ], ["bipandgo.com"]),
    rule("toll-roads-fr", "vinci-autoroutes", "VINCI Autoroutes", [
      "vinci autoroutes",
      "vinci-autoroutes"
    ], ["vinci-autoroutes.com", "asf.fr", "cofiroute.fr", "escota.fr"]),
    rule("toll-roads-fr", "ulys", "Ulys", [
      "ulys",
      "ulys vinci"
    ], ["ulys.com", "ulys.vinci-autoroutes.com", "vinci-autoroutes.com"]),
    rule("toll-roads-fr", "aprr", "APRR / AREA", [
      "aprr",
      "area autoroutes"
    ], ["aprr.fr", "aprr.com"]),
    rule("toll-roads-fr", "fulli", "Fulli", ["fulli"], ["fulli.com"]),
    rule("toll-roads-fr", "eurotoll", "Eurotoll / Lumesia", ["eurotoll", "lumesia"], [
      "eurotoll.eu"
    ]),
    rule("toll-roads-fr", "atmb", "ATMB", [
      "atmb",
      "tunnel du mont blanc"
    ], ["atmb.com"]),
    rule("toll-roads-fr", "sftrf", "SFTRF", [
      "sftrf",
      "tunnel du frejus"
    ], ["sftrf.fr"]),

    rule("telecom-utilities-fr", "orange", "Orange", ["orange"], [
      "orange.fr",
      "orange.com"
    ], {
      exactSenderAliases: ["Orange"],
      senderAliases: ["orange telecom", "orange mobile", "orange internet"]
    }),
    rule("telecom-utilities-fr", "free", "Free Mobile / Freebox", [
      "free mobile",
      "freebox"
    ], [
      "free.fr",
      "www.free.fr",
      "mobile.free.fr",
      "subscribe.free.fr",
      "assistance.free.fr",
      "zimbra.free.fr",
      "webmail.free.fr",
      "imp.free.fr",
      "freebox.fr",
      "www.freebox.fr"
    ], {
      matchSubdomains: false,
      senderDomains: [
        "free-mobile.fr",
        "freetelecom.fr",
        "assistance.free.fr",
        "proxad.net"
      ]
    }),
    rule("telecom-utilities-fr", "sfr", "SFR", ["sfr", "red by sfr"], [
      "sfr.fr",
      "red-by-sfr.fr"
    ]),
    rule("telecom-utilities-fr", "bouygues", "Bouygues Telecom", [
      "bouygues telecom",
      "bbox"
    ], ["bouyguestelecom.fr"]),
    rule("telecom-utilities-fr", "edf", "EDF", ["edf"], ["edf.fr"]),
    rule("telecom-utilities-fr", "engie", "Engie", ["engie"], ["engie.fr", "engie.com"]),
    rule("telecom-utilities-fr", "totalenergies", "TotalEnergies", ["totalenergies"], [
      "totalenergies.fr",
      "totalenergies.com"
    ]),
    rule("telecom-utilities-fr", "enedis", "Enedis", ["enedis"], ["enedis.fr"]),
    rule("telecom-utilities-fr", "grdf", "GRDF", ["grdf"], ["grdf.fr"]),
    rule("telecom-utilities-fr", "veolia", "Veolia", ["veolia"], ["veolia.fr", "veolia.com"]),
    rule("telecom-utilities-fr", "suez", "Suez", ["suez"], [
      "suez.com",
      "suez.fr",
      "toutsurmoneau.fr",
      "monservicedechets.com"
    ]),

    rule("telecom-utilities-global", "verizon", "Verizon", ["verizon"], [
      "verizon.com"
    ]),
    rule("telecom-utilities-global", "att", "AT&T", ["at&t", "att.com"], [
      "att.com"
    ]),
    rule("telecom-utilities-global", "t-mobile", "T-Mobile", ["t-mobile", "tmobile"], [
      "t-mobile.com"
    ]),
    rule("telecom-utilities-global", "vodafone", "Vodafone", ["vodafone"], [
      "vodafone.com"
    ]),
    rule("telecom-utilities-global", "ee", "EE", ["ee mobile", "ee.co.uk"], [
      "ee.co.uk"
    ]),
    rule("telecom-utilities-global", "o2", "O2", ["o2 mobile", "o2.co.uk"], [
      "o2.co.uk"
    ]),
    rule("telecom-utilities-global", "xfinity", "Xfinity", ["xfinity"], [
      "xfinity.com",
      "comcast.com"
    ]),
    rule("telecom-utilities-global", "comcast", "Comcast", ["comcast"], [
      "comcast.com"
    ]),
    rule("telecom-utilities-global", "british-gas", "British Gas", ["british gas"], [
      "britishgas.co.uk"
    ]),
    rule("telecom-utilities-global", "eon", "E.ON", ["eon energy", "e.on"], [
      "eon.com",
      "eonenergy.com"
    ]),

    rule("insurance-fr", "axa", "AXA", ["axa assurance", "axa assurances"], [
      "axa.fr",
      "axa.com"
    ]),
    rule("insurance-fr", "maif", "MAIF", ["maif"], ["maif.fr"]),
    rule("insurance-fr", "macif", "Macif", ["macif"], ["macif.fr"]),
    rule("insurance-fr", "maaf", "MAAF", ["maaf"], ["maaf.fr"]),
    rule("insurance-fr", "matmut", "Matmut", ["matmut"], ["matmut.fr"]),
    rule("insurance-fr", "allianz", "Allianz", ["allianz"], ["allianz.fr", "allianz.com"]),
    rule("insurance-fr", "april", "April", ["april assurance", "april mutuelle"], [
      "april.fr"
    ]),
    rule("insurance-fr", "harmonie-mutuelle", "Harmonie Mutuelle", ["harmonie mutuelle"], [
      "harmonie-mutuelle.fr"
    ]),

    rule("delivery", "laposte", "La Poste", ["la poste", "laposte"], [
      "laposte.fr",
      "laposte.net",
      "labanquepostale.fr"
    ]),
    rule("delivery", "colissimo", "Colissimo", ["colissimo"], [
      "laposte.fr",
      "colissimo.fr"
    ]),
    rule("delivery", "chronopost", "Chronopost", ["chronopost"], ["chronopost.fr"]),
    // ccTLD coverage: when a brand uses per-country registrable domains, list them here
    // (see the deliveroo / amazon rules). Brands with path-based locales on one domain need none.
    rule("delivery", "dhl", "DHL", ["dhl"], [
      "dhl.com",
      "dhl.com.mx",
      "dhl.fr",
      "dhl.de",
      "dhl.co.uk"
    ]),
    rule("delivery", "ups", "UPS", ["ups"], ["ups.com"]),
    rule("delivery", "fedex", "FedEx", ["fedex"], ["fedex.com"]),
    rule("delivery", "mondial-relay", "Mondial Relay", ["mondial relay"], [
      "mondialrelay.fr"
    ]),
    rule("delivery", "relais-colis", "Relais Colis", ["relais colis"], ["relaiscolis.com"]),
    rule("delivery", "dpd", "DPD", ["dpd"], [
      "dpd.com",
      "dpdgroup.com",
      "geopost.com",
      "dpd.fr",
      "dpd.co.uk",
      "dpd.de",
      "dpd.ie",
      "dpd.nl",
      "dpd.be",
      "dpd.pl",
      "dpd.pt",
      "dpd.at",
      "dpd.ch"
    ]),
    rule("delivery", "gls", "GLS", ["gls delivery", "gls colis", "gls france"], [
      "gls-group.com",
      "gls-group.eu",
      "gls-france.com"
    ]),
    rule("delivery", "colis-prive", "Colis Privé", ["colis prive", "colis privé"], [
      "colisprive.com",
      "colisprive.fr",
      "colisprive-store.com",
      "colisprive.be",
      "colisprive.nl"
    ]),
    rule("delivery", "usps", "USPS", ["usps", "usps government"], ["usps.com"]),
    rule("delivery", "royal-mail", "Royal Mail", ["royal mail"], ["royalmail.com"]),
    rule("delivery", "canada-post", "Canada Post", ["canada post", "postes canada"], [
      "canadapost-postescanada.ca"
    ]),
    rule("delivery", "correos", "Correos", ["correos"], ["correos.es"]),
    rule("delivery", "bpost", "bpost", ["bpost"], ["bpost.be"]),
    rule("delivery", "postnl", "PostNL", ["postnl", "post nl"], ["postnl.nl"]),
    rule("delivery", "evri", "Evri", ["evri"], ["evri.com"]),
    rule("delivery", "poste-italiane", "Poste Italiane", [
      "poste italiane",
      "posteitaliane"
    ], ["poste.it", "posteitaliane.it"]),
    rule("delivery", "deutsche-post", "Deutsche Post", ["deutsche post"], [
      "deutschepost.de"
    ]),
    rule("delivery", "postnord", "PostNord", ["postnord"], [
      "postnord.com",
      "postnord.se",
      "postnord.dk"
    ]),
    rule("delivery", "an-post", "An Post", ["an post", "anpost"], [
      "anpost.com",
      "anpost.ie"
    ]),
    rule("delivery", "posti", "Posti", ["posti"], ["posti.fi"]),
    rule("delivery", "swiss-post", "Swiss Post / Die Post", [
      "swiss post",
      "die post"
    ], ["post.ch"]),
    rule("delivery", "oesterreichische-post", "Osterreichische Post", [
      "österreichische post",
      "osterreichische post"
    ], ["post.at"]),
    rule("delivery", "ctt", "CTT (Correios de Portugal)", [
      "ctt correios",
      "correios ctt"
    ], ["ctt.pt"]),
    rule("delivery", "deliveroo", "Deliveroo", ["deliveroo"], [
      "deliveroo.com",
      "deliveroo.co.uk",
      "deliveroo.ie",
      "deliveroo.fr",
      "deliveroo.be",
      "deliveroo.it",
      "deliveroo.ae",
      "deliveroo.com.kw",
      "deliveroo.com.sg"
    ]),
    rule("delivery", "just-eat", "Just Eat", ["just eat", "justeat"], [
      "just-eat.fr",
      "justeat.com",
      "just-eat.co.uk",
      "just-eat.ie",
      "justeattakeaway.com",
      "takeaway.com"
    ]),
    rule("delivery", "uber-eats", "Uber Eats", ["uber eats", "ubereats"], [
      "ubereats.com",
      "uber.com"
    ]),
    rule("delivery", "doordash", "DoorDash", ["doordash", "door dash"], [
      "doordash.com",
      "doordash.ca",
      "doordash.com.au"
    ]),
    rule("delivery", "instacart", "Instacart", ["instacart"], ["instacart.com"]),
    rule("delivery", "glovo", "Glovo", ["glovo"], ["glovoapp.com"]),
    rule("delivery", "wolt", "Wolt", ["wolt delivery", "wolt.com"], ["wolt.com"]),

    rule("commerce", "amazon", "Amazon", ["amazon", "amzn"], [
      "amazon.com",
      "amazon.fr",
      "amazon.co.uk",
      "amazon.de",
      "amazon.es",
      "amazon.it",
      "amazon.nl",
      "amazon.ca",
      "amazon.com.mx",
      "amazon.com.be",
      "amazon.com.au",
      "amazon.co.jp",
      "amazonpay.com"
    ], {
      brandLinkDomains: ["media-amazon.com"]
    }),
    rule("commerce", "ebay", "eBay", ["ebay"], [
      "ebay.com",
      "ebay.fr",
      "ebay.co.uk",
      "ebay.de",
      "ebay.it",
      "ebay.es",
      "ebay.nl",
      "ebay.be",
      "ebay.at",
      "ebay.ch",
      "ebay.ie",
      "ebay.pl",
      "ebay.ca",
      "ebay.com.au",
      "ebay.in",
      "ebay.ph",
      "ebay.com.hk",
      "ebay.com.sg"
    ]),
    rule("commerce", "leboncoin", "Leboncoin", ["leboncoin", "le bon coin"], [
      "leboncoin.fr"
    ]),
    rule("commerce", "vinted", "Vinted", ["vinted"], [
      "vinted.com",
      "vinted.fr",
      "vinted.co.uk",
      "vinted.de",
      "vinted.it",
      "vinted.es",
      "vinted.nl",
      "vinted.be",
      "vinted.at",
      "vinted.pl",
      "vinted.cz",
      "vinted.sk",
      "vinted.lt",
      "vinted.lu",
      "vinted.pt",
      "vinted.se",
      "vinted.dk",
      "vinted.fi",
      "vinted.ie",
      "vinted.gr",
      "vinted.hu",
      "vinted.ro",
      "vinted.hr"
    ]),
    rule("commerce", "cdiscount", "Cdiscount", ["cdiscount"], ["cdiscount.com"]),
    rule("commerce", "fnac", "Fnac", ["fnac"], ["fnac.com"]),
    rule("commerce", "darty", "Darty", ["darty"], ["darty.com"]),
    rule("commerce", "rakuten", "Rakuten", ["rakuten"], [
      "rakuten.com",
      "rakuten.fr",
      "rakuten.co.jp"
    ]),
    rule("commerce", "aliexpress", "AliExpress", ["aliexpress", "ali express"], [
      "aliexpress.com"
    ]),
    rule("commerce", "alibaba", "Alibaba", ["alibaba"], ["alibaba.com"]),
    rule("commerce", "temu", "Temu", ["temu"], ["temu.com"]),
    rule("commerce", "shein", "SHEIN", ["shein"], ["shein.com"], {
      brandLinkDomains: ["ltwebstatic.com"]
    }),
    rule("commerce", "etsy", "Etsy", ["etsy"], ["etsy.com"]),
    rule("commerce", "shopify", "Shopify", ["shopify"], ["shopify.com"]),
    rule("site-builders", "squarespace", "Squarespace", ["squarespace"], [
      "squarespace.com",
      "www.squarespace.com",
      "support.squarespace.com",
      "account.squarespace.com",
      "login.squarespace.com",
      "domains.squarespace.com",
      "squarespace-security.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["squarespace.com", "mail.squarespace.com", "squarespace-security.com"],
      senderMatchSubdomains: false
    }),
    rule("site-builders", "wix", "Wix", ["wix", "wix.com"], [
      "wix.com",
      "www.wix.com",
      "support.wix.com",
      "manage.wix.com",
      "users.wix.com",
      "editor.wix.com",
      "wixanswers.com",
      "wixsiteverifications.com",
      "wixinvoices.com",
      "wix-domains.com",
      "crm.wix.com",
      "forms.wix.com",
      "wixforms.com",
      "wixsite.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: [
        "wix.com",
        "wixanswers.com",
        "wixsiteverifications.com",
        "wixinvoices.com",
        "wix-domains.com",
        "crm.wix.com",
        "forms.wix.com",
        "wixforms.com",
        "wixemails.com"
      ],
      senderMatchSubdomains: true
    }),
    rule("site-builders", "webflow", "Webflow", ["webflow"], [
      "webflow.com",
      "www.webflow.com",
      "help.webflow.com",
      "support.webflow.com",
      "status.webflow.com",
      "webflow.io"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["webflow.com"]
    }),
    rule("site-builders", "wordpress-com", "WordPress.com", ["wordpress.com", "wordpress"], [
      "wordpress.com",
      "www.wordpress.com",
      "wordpress.org",
      "wp.com",
      "automattic.com",
      "gravatar.com",
      "akismet.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["wordpress.com", "automattic.com"]
    }),
    rule("site-builders", "weebly", "Weebly", ["weebly"], [
      "weebly.com",
      "www.weebly.com",
      "editor.weebly.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["weebly.com"]
    }),
    rule("site-builders", "framer", "Framer", ["framer"], [
      "framer.com",
      "www.framer.com",
      "help.framer.com",
      "framer.app",
      "framer.website"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["framer.com"]
    }),
    rule("site-builders", "carrd", "Carrd", ["carrd"], [
      "carrd.co",
      "www.carrd.co"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["carrd.co"]
    }),
    rule("site-builders", "tilda", "Tilda", ["tilda"], [
      "tilda.cc",
      "tilda.ws",
      "tildacdn.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["tilda.cc"]
    }),
    rule("site-builders", "strikingly", "Strikingly", ["strikingly"], [
      "strikingly.com",
      "www.strikingly.com",
      "mystrikingly.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["strikingly.com"]
    }),
    rule("site-builders", "jimdo", "Jimdo", ["jimdo"], [
      "jimdo.com",
      "www.jimdo.com",
      "jimdofree.com",
      "jimdosite.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["jimdo.com"]
    }),
    rule("site-builders", "duda", "Duda", ["duda"], [
      "duda.co",
      "www.duda.co",
      "support.duda.co",
      "my.duda.co",
      "multiscreensite.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["duda.co"]
    }),
    rule("commerce", "zalando", "Zalando", ["zalando"], [
      "zalando.fr",
      "zalando.com",
      "zalando.co.uk",
      "zalando.de",
      "zalando.it",
      "zalando.es",
      "zalando.nl",
      "zalando.be",
      "zalando.at",
      "zalando.pl",
      "zalando.ch",
      "zalando.se",
      "zalando.dk",
      "zalando.fi",
      "zalando.ie",
      "zalando.cz",
      "zalando.sk",
      "zalando.hu",
      "zalando.ro",
      "zalando.pt"
    ]),
    rule("commerce", "carrefour", "Carrefour", ["carrefour"], ["carrefour.fr"]),
    rule("commerce", "auchan", "Auchan", ["auchan"], ["auchan.fr"]),
    rule("commerce", "leclerc", "E.Leclerc", ["e leclerc", "leclerc"], [
      "e.leclerc",
      "e-leclerc.com",
      "leclercdrive.fr"
    ]),
    rule("commerce", "intermarche", "Intermarche", ["intermarche"], [
      "intermarche.com"
    ]),
    rule("commerce", "lidl", "Lidl", ["lidl"], ["lidl.fr", "lidl.com"]),
    rule("commerce", "decathlon", "Decathlon", ["decathlon"], [
      "decathlon.fr",
      "decathlon.com"
    ]),
    rule("commerce", "ikea", "IKEA", ["ikea"], ["ikea.com"]),
    rule("commerce", "leroy-merlin", "Leroy Merlin", ["leroy merlin"], [
      "leroymerlin.fr"
    ]),
    rule("commerce", "castorama", "Castorama", ["castorama"], ["castorama.fr"]),
    rule("commerce", "boulanger", "Boulanger", ["boulanger"], ["boulanger.com"]),
    rule("commerce", "walmart", "Walmart", ["walmart"], [
      "walmart.com",
      "walmart.com.mx"
    ]),
    rule("commerce", "target", "Target", ["target store", "target.com"], ["target.com"]),
    rule("commerce", "best-buy", "Best Buy / Geek Squad", [
      "best buy",
      "bestbuy",
      "geek squad",
      "geeksquad"
    ], ["bestbuy.com", "geeksquad.com"]),
    rule("commerce", "costco", "Costco", ["costco"], [
      "costco.com",
      "costco.com.mx"
    ]),
    rule("commerce", "home-depot", "The Home Depot", ["home depot"], [
      "homedepot.com"
    ]),
    rule("commerce", "lowes", "Lowe's", ["lowes", "lowe s"], ["lowes.com"]),
    rule("commerce", "wayfair", "Wayfair", ["wayfair"], ["wayfair.com"]),
    rule("commerce", "macys", "Macy's", ["macys", "macy s"], ["macys.com"]),
    rule("commerce", "nordstrom", "Nordstrom", ["nordstrom"], ["nordstrom.com"]),
    rule("commerce", "kohls", "Kohl's", ["kohls", "kohl s"], ["kohls.com"]),
    rule("commerce", "chewy", "Chewy", ["chewy.com", "chewy pet"], ["chewy.com"]),
    rule("commerce", "back-market", "Back Market", ["back market"], [
      "backmarket.com",
      "backmarket.fr"
    ]),
    rule("commerce", "manomano", "ManoMano", ["manomano", "mano mano"], [
      "manomano.fr",
      "manomano.com"
    ]),
    rule("commerce", "la-redoute", "La Redoute", ["la redoute"], ["laredoute.fr"]),
    rule("commerce", "veepee", "Veepee", ["veepee", "vente privee"], [
      "veepee.fr",
      "veepee.com"
    ]),
    rule("commerce", "showroomprive", "Showroomprive", ["showroomprive"], [
      "showroomprive.com"
    ]),
    rule("commerce", "sephora", "Sephora", ["sephora"], ["sephora.fr", "sephora.com"]),
    rule("commerce", "nocibe", "Nocibe", ["nocibe"], ["nocibe.fr"]),
    rule("commerce", "hm", "H&M", ["h&m", "h and m", "hm.com"], ["hm.com"]),
    rule("commerce", "zara", "Zara", ["zara"], ["zara.com"]),
    rule("commerce", "nike", "Nike", ["nike"], ["nike.com"]),
    rule("commerce", "adidas", "Adidas", ["adidas"], ["adidas.com"]),
    rule("commerce", "asos", "ASOS", ["asos"], ["asos.com"]),
    rule("commerce", "uniqlo", "UNIQLO", ["uniqlo"], ["uniqlo.com"]),
    rule("commerce", "ldlc", "LDLC", ["ldlc"], ["ldlc.com"]),
    rule("commerce", "materiel-net", "Materiel.net", ["materiel.net", "materiel net"], [
      "materiel.net"
    ]),
    rule("commerce", "rueducommerce", "Rue du Commerce", ["rue du commerce"], [
      "rueducommerce.fr"
    ]),
    rule("commerce", "topachat", "TopAchat", ["topachat", "top achat"], [
      "topachat.com"
    ]),
    rule("commerce", "monoprix", "Monoprix", ["monoprix"], ["monoprix.fr"]),
    rule("commerce", "franprix", "Franprix", ["franprix"], ["franprix.fr"]),
    rule("commerce", "picard", "Picard", ["picard surgeles", "picard surgele"], [
      "picard.fr"
    ]),
    rule("commerce", "mercari", "Mercari", ["mercari"], ["mercari.com"]),
    rule("commerce", "poshmark", "Poshmark", ["poshmark"], ["poshmark.com"]),
    rule("commerce", "depop", "Depop", ["depop"], ["depop.com"]),
    rule("commerce", "wallapop", "Wallapop", ["wallapop"], ["wallapop.com"]),
    rule("commerce", "olx", "OLX", ["olx"], ["olx.com"]),
    rule("commerce", "allegro", "Allegro", ["allegro"], ["allegro.pl"]),
    rule("commerce", "mercado-libre", "Mercado Libre", ["mercado libre", "mercadolibre"], [
      "mercadolibre.com",
      "mercadolibre.com.mx"
    ]),
    rule("commerce", "shopee", "Shopee", ["shopee"], ["shopee.com"]),
    rule("commerce", "lazada", "Lazada", ["lazada"], ["lazada.com"]),
    rule("commerce", "flipkart", "Flipkart", ["flipkart"], ["flipkart.com"]),
    rule("commerce", "myntra", "Myntra", ["myntra"], ["myntra.com"]),
    rule("commerce", "newegg", "Newegg", ["newegg"], ["newegg.com"]),
    rule("commerce", "groupon", "Groupon", ["groupon"], ["groupon.com"]),
    rule("commerce", "groupon-fr", "Groupon France", ["groupon france"], [
      "groupon.fr"
    ]),
    rule("commerce", "qvc", "QVC", ["qvc"], ["qvc.com"]),
    rule("commerce", "publishers-clearing-house", "Publishers Clearing House", [
      "publishers clearing house",
      "pch",
      "pch prize patrol"
    ], ["pch.com"]),
    rule("commerce", "wish", "Wish", ["wish.com", "wish shopping"], ["wish.com"]),

    rule("events", "eventbrite", "Eventbrite", ["eventbrite", "event brite"], [
      "eventbrite.com",
      "eventbrite.com.mx"
    ]),
    rule("events", "ticketmaster", "Ticketmaster", ["ticketmaster"], [
      "ticketmaster.com",
      "ticketmaster.fr"
    ]),
    rule("events", "live-nation", "Live Nation", ["live nation", "livenation"], [
      "livenation.com",
      "livenation.fr",
      "livenationhip.co.jp"
    ]),
    rule("events", "weezevent", "Weezevent", ["weezevent"], ["weezevent.com"]),
    rule("events", "billetweb", "Billetweb", ["billetweb"], ["billetweb.fr"]),
    rule("events", "helloasso", "HelloAsso", ["helloasso", "hello asso"], [
      "helloasso.com"
    ]),
    rule("events", "shotgun", "Shotgun", ["shotgun.live", "shotgun tickets"], [
      "shotgun.live"
    ]),
    rule("events", "dice", "DICE", ["dice.fm", "dice tickets"], ["dice.fm"]),
    rule("events", "fever", "Fever", ["feverup", "fever tickets"], [
      "feverup.com"
    ]),
    rule("events", "meetup", "Meetup", ["meetup"], ["meetup.com"]),
    rule("events", "luma", "Luma", ["lu.ma", "luma", "luma event"], [
      "luma.com",
      "lu.ma"
    ], {
      userContentPlatform: true,
      senderDomains: ["luma.com", "luma-mail.com"],
      brandLinkDomains: ["luma.link", "o.lu.ma"]
    }),
    rule("events", "eventim", "Eventim", ["eventim"], [
      "eventim.com",
      "eventim.fr",
      "eventim.de",
      "eventim.us",
      "seetickets.us"
    ]),
    rule("events", "see-tickets", "See Tickets", ["see tickets", "seetickets"], [
      "seetickets.com",
      "seetickets.fr"
    ]),
    rule("events", "fnac-spectacles", "Fnac Spectacles", [
      "fnac spectacles",
      "france billet"
    ], ["fnacspectacles.com", "francebillet.com"]),
    rule("events", "ticketac", "Ticketac", ["ticketac"], ["ticketac.com"]),
    rule("events", "yurplan", "Yurplan", ["yurplan"], ["yurplan.com"]),
    rule("events", "placeminute", "Placeminute", ["placeminute", "place minute"], [
      "placeminute.com"
    ]),
    rule("events", "assoconnect", "AssoConnect", ["assoconnect", "asso connect"], [
      "assoconnect.com"
    ]),
    rule("events", "resident-advisor", "Resident Advisor", [
      "resident advisor",
      "ra.co"
    ], ["ra.co"]),
    rule("events", "eventzilla", "Eventzilla", ["eventzilla"], ["eventzilla.net"]),
    rule("events", "universe", "Universe", ["universe tickets", "universe.com"], [
      "universe.com"
    ]),
    rule("events", "splash", "Splash", ["splashthat", "splash event"], [
      "splashthat.com"
    ]),
    rule("events", "partiful", "Partiful", ["partiful"], ["partiful.com"]),
    rule("events", "pretix", "Pretix", ["pretix"], ["pretix.eu"]),

    rule("forms", "typeform", "Typeform", ["typeform"], ["typeform.com"]),
    rule("forms", "jotform", "Jotform", ["jotform"], ["jotform.com"]),
    rule("forms", "surveymonkey", "SurveyMonkey", ["surveymonkey", "survey monkey"], [
      "surveymonkey.com"
    ]),
    rule("forms", "qualtrics", "Qualtrics", ["qualtrics"], [
      "qualtrics.com",
      "qualtrics.eu"
    ], {
      // Google Help explicitly identifies this tenant as its legitimate survey
      // host; other Qualtrics tenants remain user-content links.
      controlPlaneDomains: ["google.qualtrics.com"]
    }),
    rule("forms", "calendly", "Calendly", ["calendly"], ["calendly.com"]),
    rule("forms", "doodle", "Doodle", ["doodle meeting", "doodle.com"], [
      "doodle.com"
    ]),
    rule("forms", "youcanbookme", "YouCanBookMe", ["youcanbook.me", "you can book me"], [
      "youcanbook.me"
    ]),
    rule("forms", "tally", "Tally", ["tally.so", "tally forms"], ["tally.so"]),
    rule("forms", "fillout", "Fillout", ["fillout.com", "fillout forms"], [
      "fillout.com"
    ]),
    rule("forms", "paperform", "Paperform", ["paperform"], ["paperform.co"]),
    rule("forms", "formstack", "Formstack", ["formstack"], ["formstack.com"]),
    rule("forms", "wufoo", "Wufoo", ["wufoo"], ["wufoo.com"]),
    rule("forms", "cognito-forms", "Cognito Forms", ["cognito forms"], [
      "cognitoforms.com"
    ]),
    rule("forms", "slido", "Slido", ["slido"], ["slido.com", "sli.do"]),
    rule("forms", "mentimeter", "Mentimeter", ["mentimeter", "menti.com"], [
      "mentimeter.com",
      "menti.com"
    ]),
    rule("forms", "gofundme", "GoFundMe", ["gofundme", "go fund me"], [
      "gofundme.com"
    ]),
    rule("forms", "donorbox", "Donorbox", ["donorbox"], ["donorbox.org"]),
    rule("forms", "kickstarter", "Kickstarter", ["kickstarter"], ["kickstarter.com"]),
    rule("forms", "indiegogo", "Indiegogo", ["indiegogo"], ["indiegogo.com"]),
    rule("forms", "patreon", "Patreon", ["patreon"], ["patreon.com"]),

    rule("accounting", "indy", "Indy", ["indy", "indy.fr", "indy comptabilite"], [
      "indy.fr"
    ], {
      senderAliases: ["indy.fr", "indy comptabilite"]
    }),
    rule("accounting", "pennylane", "Pennylane", [
      "pennylane",
      "pennylane comptabilite"
    ], [
      "pennylane.com"
    ]),
    rule("accounting", "dougs", "Dougs", ["dougs", "dougs expert comptable"], [
      "dougs.fr"
    ]),
    rule("accounting", "tiime", "Tiime", ["tiime", "tiime comptabilite"], [
      "tiime.fr"
    ]),
    rule("accounting", "abby", "Abby", ["abby", "abby facturation"], ["abby.fr"], {
      senderAliases: ["abby facturation", "abby.fr"]
    }),
    rule("accounting", "freebe", "Freebe", ["freebe", "freebe.me"], ["freebe.me"]),
    rule("accounting", "sinao", "Sinao", ["sinao", "sinao comptabilite"], [
      "sinao.fr"
    ]),
    rule("accounting", "dext", "Dext", ["dext", "dext prepare", "receipt bank"], [
      "dext.com"
    ]),
    rule("accounting", "myunisoft", "MyUnisoft / MyU", ["myunisoft", "my unisoft", "myu"], [
      "myunisoft.fr",
      "myu.fr",
      "dayboard.fr",
      "limpyd.fr"
    ]),
    rule("accounting", "fulll", "fulll", ["fulll", "fulll compta"], ["fulll.fr"]),
    rule("accounting", "kanta", "Kanta", ["kanta", "kanta expert comptable"], [
      "kanta.fr"
    ]),
    rule("accounting", "regate-qonto", "Regate by Qonto", [
      "regate",
      "regate by qonto"
    ], [
      "regate.io",
      "web.regate.io",
      "qonto.com",
      "support-regate-fr.qonto.com"
    ]),
    rule("accounting", "xero", "Xero", ["xero accounting", "xero.com"], ["xero.com"]),
    rule("accounting", "quickbooks", "QuickBooks", [
      "quickbooks",
      "intuit quickbooks"
    ], [
      "quickbooks.intuit.com"
    ]),
    rule("accounting", "intuit", "Intuit", ["intuit"], ["intuit.com"]),

    rule("hr-finance-ops", "payfit", "PayFit", ["payfit", "payfit payroll"], [
      "payfit.com"
    ]),
    rule("hr-finance-ops", "spendesk", "Spendesk", ["spendesk"], [
      "spendesk.com"
    ]),
    rule("hr-finance-ops", "libeo", "Libeo", ["libeo"], ["libeo.io"]),
    rule("hr-finance-ops", "lucca", "Lucca", ["lucca", "lucca sirh"], [
      "lucca.fr",
      "ilucca.net"
    ]),
    rule("hr-finance-ops", "swile", "Swile", ["swile"], ["swile.co"]),
    rule("hr-finance-ops", "adp", "ADP", ["adp", "adp payroll"], ["adp.com"]),
    rule("hr-finance-ops", "paychex", "Paychex", ["paychex"], ["paychex.com"]),
    rule("hr-finance-ops", "ukg", "UKG", ["ukg", "ukg pro"], ["ukg.com"]),
    rule("hr-finance-ops", "bamboohr", "BambooHR", ["bamboohr", "bamboo hr"], [
      "bamboohr.com"
    ]),
    rule("hr-finance-ops", "greenhouse", "Greenhouse", ["greenhouse recruiting"], [
      "greenhouse.io"
    ]),
    rule("hr-finance-ops", "lever", "Lever", ["lever recruiting"], ["lever.co"]),
    rule("hr-finance-ops", "workable", "Workable", ["workable recruiting"], [
      "workable.com"
    ]),
    rule("hr-finance-ops", "ashby", "Ashby", ["ashby recruiting", "ashbyhq"], [
      "ashbyhq.com"
    ]),
    rule("hr-finance-ops", "personio", "Personio", ["personio"], ["personio.com"]),
    rule("hr-finance-ops", "hibob", "HiBob", ["hibob", "bob hr"], ["hibob.com"]),
    rule("hr-finance-ops", "remote", "Remote", ["remote.com", "remote payroll"], [
      "remote.com"
    ]),
    rule("hr-finance-ops", "ramp", "Ramp", ["ramp card", "ramp.com"], ["ramp.com"]),
    rule("hr-finance-ops", "brex", "Brex", ["brex"], ["brex.com"]),
    rule("hr-finance-ops", "bill-com", "BILL", ["bill.com", "bill payments"], [
      "bill.com"
    ]),
    rule("hr-finance-ops", "expensify", "Expensify", ["expensify"], [
      "expensify.com"
    ]),
    rule("hr-finance-ops", "navan", "Navan", ["navan", "tripactions"], [
      "navan.com",
      "tripactions.com"
    ]),
    rule("hr-finance-ops", "sap-concur", "SAP Concur", ["sap concur", "concur"], [
      "concur.com",
      "concursolutions.com"
    ]),

    rule("health-fr", "doctolib", "Doctolib", ["doctolib"], [
      "doctolib.fr",
      "doctolib.de",
      "doctolib.com"
    ]),
    rule("health-fr", "alan", "Alan", ["alan assurance", "alan health", "alan.com"], [
      "alan.com"
    ]),
    rule("health-fr", "mon-espace-sante", "Mon espace santé", [
      "mon espace santé",
      "mon espace sante"
    ], ["monespacesante.fr"]),

    rule("travel", "booking", "Booking.com", ["booking.com", "booking"], ["booking.com"], {
      exactSenderAliases: ["Booking.com"],
      senderAliases: ["booking.com"]
    }),
    rule("travel", "airbnb", "Airbnb", ["airbnb"], [
      "airbnb.com",
      "airbnb.co.uk",
      "airbnb.fr",
      "airbnb.de",
      "airbnb.es",
      "airbnb.it",
      "airbnb.ca",
      "airbnb.mx",
      "airbnb.com.au"
    ], {
      // airbnb.mx is a current country link surface, but Airbnb's published
      // sender guidance does not list it as a mail-authentication domain.
      senderDomains: [
        "airbnb.com",
        "airbnb.co.uk",
        "airbnb.fr",
        "airbnb.de",
        "airbnb.es",
        "airbnb.it",
        "airbnb.ca",
        "airbnb.com.au"
      ]
    }),
    rule("travel", "thefork", "TheFork", ["thefork", "la fourchette", "lafourchette"], [
      "thefork.com",
      "thefork.fr",
      "lafourchette.com"
    ], {
      senderDomains: ["thefork.com", "thefork.fr", "email.thefork.com"],
      senderMatchSubdomains: false
    }),
    rule("travel", "opentable", "OpenTable", ["opentable", "open table"], [
      "opentable.com",
      "opentable.co.uk",
      "opentable.fr",
      "opentable.de",
      "opentable.es",
      "opentable.it",
      "opentable.nl",
      "opentable.ca",
      "opentable.com.au",
      "opentable.jp",
      "opentable.ie",
      "opentable.sg",
      "opentable.hk",
      "opentable.com.mx",
      "opentable.ae",
      "opentable.co.th",
      "opentable.com.tw"
    ]),
    rule("travel", "resy", "Resy", ["resy"], ["resy.com"]),
    rule("travel", "tock", "Tock", ["tock", "exploretock"], ["exploretock.com"]),
    rule("travel", "sevenrooms", "SevenRooms", ["sevenrooms", "seven rooms"], [
      "sevenrooms.com"
    ]),
    rule("travel", "zenchef", "Zenchef", ["zenchef", "zenchef app"], ["zenchef.com"]),
    rule("travel", "uber", "Uber", ["uber"], ["uber.com"]),
    rule("travel", "bolt", "Bolt", ["bolt ride", "bolt.eu"], ["bolt.eu"]),
    rule("travel", "sncf", "SNCF", ["sncf", "sncf connect", "tgv inoui", "tgvinoui"], [
      "sncf.com",
      "sncf.fr",
      "sncf-connect.com",
      "sncfconnect.com",
      "tgvinoui.sncf",
      "sncf-voyageurs.com"
    ], {
      senderDomains: [
        "mail.sncfconnect.com",
        "mail.sncf-connect.com",
        "info.sncf.com",
        "connect.sncf"
      ],
      senderMatchSubdomains: false
    }),
    rule("travel", "trainline", "Trainline", ["trainline"], ["thetrainline.com"]),
    rule("travel", "air-france", "Air France", ["air france"], [
      "airfrance.fr",
      "airfrance.com",
      "airfrance-klm.com",
      "airfranceklm.com",
      "flyingblue.com"
    ], {
      senderDomains: [
        "airfrance.com",
        "airfrance.fr",
        "account-airfrance.com",
        "connect-passengers.com",
        "email.airfrance.fr",
        "enews-airfrance.com",
        "info-airfrance.com",
        "info-flyingblue.com",
        "infos-airfrance.com",
        "service.airfrance.com",
        "service-airfrance.com",
        "ticket-airfrance.com",
        "websupportairfrance.com",
        "xmedia.airfrance.fr"
      ],
      senderMatchSubdomains: false
    }),
    rule("travel", "transavia", "Transavia", ["transavia"], ["transavia.com"]),
    rule("travel", "accor", "Accor", ["accor", "all accor"], ["accor.com", "all.com"]),
    rule("travel", "ratp", "RATP", ["ratp"], ["ratp.fr"]),
    rule("travel", "navigo", "Ile-de-France Mobilites", [
      "ile de france mobilites",
      "navigo"
    ], ["iledefrance-mobilites.fr"]),
    rule("travel", "telepass", "Telepass", ["telepass"], ["telepass.com", "telepass.it"]),
    rule("travel", "asfinag", "ASFINAG", ["asfinag"], ["asfinag.at"]),
    rule("travel", "via-verde", "Via Verde", ["via verde", "viaverde"], ["viaverde.pt"]),
    rule("travel", "toll-collect", "Toll Collect", [
      "toll collect",
      "toll-collect"
    ], ["toll-collect.de"]),
    rule("travel", "expedia", "Expedia", ["expedia"], ["expedia.com", "expedia.fr"]),
    rule("travel", "hotels-com", "Hotels.com", ["hotels.com"], ["hotels.com"]),
    rule("travel", "agoda", "Agoda", ["agoda"], ["agoda.com"]),
    rule("travel", "trip-com", "Trip.com", ["trip.com", "trip travel"], ["trip.com"]),
    rule("travel", "kayak", "Kayak", ["kayak travel", "kayak.com"], ["kayak.com"]),
    rule("travel", "skyscanner", "Skyscanner", ["skyscanner"], ["skyscanner.com"]),
    rule("travel", "vrbo", "Vrbo", ["vrbo"], ["vrbo.com"]),
    rule("travel", "hertz", "Hertz", ["hertz rental", "hertz.com"], ["hertz.com"]),
    rule("travel", "avis", "Avis", ["avis rental", "avis.com"], ["avis.com"]),
    rule("travel", "enterprise", "Enterprise Rent-A-Car", [
      "enterprise rent",
      "enterprise.com"
    ], ["enterprise.com"]),
    rule("travel", "ryanair", "Ryanair", ["ryanair"], ["ryanair.com"]),
    rule("travel", "easyjet", "easyJet", ["easyjet", "easy jet"], ["easyjet.com"]),
    rule("travel", "lufthansa", "Lufthansa", ["lufthansa"], ["lufthansa.com"]),
    rule("travel", "klm", "KLM", ["klm"], ["klm.com"]),
    rule("travel", "british-airways", "British Airways", ["british airways"], [
      "britishairways.com"
    ]),
    rule("travel", "delta", "Delta Air Lines", ["delta air lines", "delta.com"], [
      "delta.com"
    ]),
    rule("travel", "united-airlines", "United Airlines", ["united airlines"], [
      "united.com"
    ]),
    rule("travel", "american-airlines", "American Airlines", ["american airlines"], [
      "aa.com",
      "americanairlines.com"
    ]),
    rule("travel", "southwest-airlines", "Southwest Airlines", ["southwest airlines"], [
      "southwest.com"
    ]),
    rule("travel", "china-eastern", "China Eastern Airlines", [
      "china eastern",
      "china eastern airlines"
    ], ["ceair.com"]),
    rule("travel", "indigo", "IndiGo", ["indigo", "goindigo"], [
      "goindigo.in"
    ]),
    rule("travel", "china-southern-airlines", "China Southern Airlines", [
      "china southern",
      "china southern airlines"
    ], [
      "csair.com",
      "csair.cn"
    ]),
    rule("travel", "air-china", "Air China", ["air china"], [
      "airchina.com.cn"
    ]),
    rule("travel", "alaska-airlines", "Alaska Airlines", ["alaska airlines"], [
      "alaskaair.com"
    ]),
    rule("travel", "ana", "ANA", ["ana", "all nippon airways"], [
      "ana.co.jp"
    ], {
      exactSenderAliases: ["ANA"],
      senderAliases: ["all nippon airways", "ana airlines", "ana.co.jp"]
    }),
    rule("travel", "latam-airlines", "LATAM Airlines", ["latam", "latam airlines"], [
      "latam.com",
      "latamairlines.com"
    ]),
    rule("travel", "turkish-airlines", "Turkish Airlines", ["turkish airlines"], [
      "thy.com",
      "turkishairlines.com"
    ]),
    rule("travel", "japan-airlines", "Japan Airlines", ["jal", "japan airlines"], [
      "jal.co.jp",
      "jal.com"
    ]),
    rule("travel", "air-canada", "Air Canada", ["air canada"], [
      "aircanada.com"
    ]),
    rule("travel", "hainan-airlines", "Hainan Airlines", ["hainan airlines"], [
      "hainanairlines.com"
    ]),
    rule("travel", "qantas", "Qantas", ["qantas"], [
      "qantas.com",
      "qantas.com.au"
    ]),
    rule("travel", "shenzhen-airlines", "Shenzhen Airlines", ["shenzhen airlines"], [
      "shenzhenair.com"
    ]),
    rule("travel", "avianca", "Avianca", ["avianca"], [
      "avianca.com"
    ]),
    rule("travel", "aeroflot", "Aeroflot", ["aeroflot"], [
      "aeroflot.ru"
    ]),
    rule("travel", "air-india", "Air India", ["air india"], [
      "airindia.com",
      "airindia.in"
    ]),
    rule("travel", "jetblue", "JetBlue", ["jetblue", "jetblue airways"], [
      "jetblue.com"
    ]),
    rule("travel", "xiamen-airlines", "Xiamen Airlines", [
      "xiamen airlines",
      "xiamenair"
    ], [
      "xiamenair.com",
      "xiamenair.com.cn"
    ]),
    rule("travel", "sichuan-airlines", "Sichuan Airlines", ["sichuan airlines"], [
      "sichuanair.com"
    ]),
    rule("travel", "azul", "Azul", ["azul", "azul airlines", "azul brazilian airlines", "voe azul"], [
      "voeazul.com.br"
    ]),
    rule("travel", "shandong-airlines", "Shandong Airlines", ["shandong airlines"], [
      "sda.cn"
    ]),
    rule("travel", "emirates", "Emirates", ["emirates"], ["emirates.com"]),
    rule("travel", "qatar-airways", "Qatar Airways", ["qatar airways"], [
      "qatarairways.com"
    ]),
    rule("travel", "asiana-airlines", "Asiana Airlines", ["asiana airlines"], [
      "flyasiana.com"
    ]),

    rule("maps", "waze", "Waze", ["waze"], [
      "waze.com"
    ]),
    rule("maps", "openstreetmap", "OpenStreetMap", ["openstreetmap", "open street map", "osm"], [
      "openstreetmap.org",
      "osm.org"
    ]),
    rule("maps", "here-wego", "HERE WeGo", ["here wego", "here maps"], [
      "here.com"
    ]),
    rule("maps", "mapquest", "MapQuest", ["mapquest"], [
      "mapquest.com"
    ]),
    rule("maps", "tomtom", "TomTom", ["tomtom", "tomtom maps"], [
      "tomtom.com"
    ]),
    rule("maps", "mapbox", "Mapbox", ["mapbox"], [
      "mapbox.com"
    ]),
    rule("maps", "citymapper", "Citymapper", ["citymapper"], [
      "citymapper.com"
    ]),

    rule("privacy-security", "expressvpn", "ExpressVPN", ["expressvpn", "express vpn"], [
      "expressvpn.com"
    ]),
    rule("privacy-security", "nordvpn", "NordVPN", ["nordvpn", "nord vpn"], [
      "nordvpn.com"
    ]),
    rule("privacy-security", "surfshark", "Surfshark", ["surfshark"], [
      "surfshark.com"
    ]),
    rule("privacy-security", "proton-vpn", "Proton VPN", ["proton vpn", "protonvpn"], [
      "protonvpn.com"
    ]),
    rule("privacy-security", "cyberghost-vpn", "CyberGhost VPN", [
      "cyberghost",
      "cyberghost vpn"
    ], ["cyberghostvpn.com"]),
    rule("privacy-security", "private-internet-access", "Private Internet Access", [
      "private internet access",
      "pia vpn"
    ], ["privateinternetaccess.com"]),
    rule("privacy-security", "mullvad-vpn", "Mullvad VPN", ["mullvad", "mullvad vpn"], [
      "mullvad.net"
    ]),
    rule("privacy-security", "tunnelbear", "TunnelBear", ["tunnelbear", "tunnel bear"], [
      "tunnelbear.com"
    ]),
    rule("privacy-security", "windscribe", "Windscribe", ["windscribe"], [
      "windscribe.com"
    ]),
    rule("privacy-security", "hotspot-shield", "Hotspot Shield", [
      "hotspot shield",
      "hotspotshield"
    ], ["hotspotshield.com"]),
    rule("privacy-security", "ipvanish", "IPVanish", ["ipvanish", "ip vanish"], [
      "ipvanish.com"
    ]),
    rule("privacy-security", "hide-me", "hide.me", ["hide.me", "hide me"], [
      "hide.me"
    ]),
    rule("privacy-security", "ivpn", "IVPN", ["ivpn"], ["ivpn.net"]),
    rule("privacy-security", "vyprvpn", "VyprVPN", ["vyprvpn", "vypr vpn"], [
      "vyprvpn.com"
    ]),
    rule("privacy-security", "mozilla-vpn", "Mozilla VPN", ["mozilla vpn"], [
      "mozilla.org"
    ]),
    rule("privacy-security", "cloudflare-warp", "Cloudflare WARP / 1.1.1.1", [
      "cloudflare warp",
      "warp vpn",
      "1.1.1.1"
    ], [
      "1.1.1.1",
      "one.one.one.one",
      "cloudflare.com"
    ]),
    rule("privacy-security", "tor-project", "Tor Project", [
      "tor project",
      "tor browser",
      "tor"
    ], ["torproject.org"]),

    rule("workplace-saas", "webex", "Webex", ["webex", "cisco webex"], [
      "webex.com",
      "cisco.com",
      "wbx2.com",
      "ciscospark.com",
      "webexapis.com"
    ]),
    rule("workplace-saas", "ringcentral", "RingCentral", ["ringcentral", "ring central"], [
      "ringcentral.com"
    ]),
    rule("workplace-saas", "goto", "GoTo", ["goto meeting", "goto webinar", "gotomeeting"], [
      "goto.com",
      "gotomeeting.com",
      "gotowebinar.com",
      "gototraining.com",
      "gotoresolve.com",
      "join.me"
    ]),
    rule("workplace-saas", "grammarly", "Grammarly / Superhuman", [
      "grammarly",
      "superhuman",
      "superhuman go"
    ], [
      "grammarly.com",
      "superhuman.com"
    ]),
    rule("workplace-saas", "smartsheet", "Smartsheet", ["smartsheet"], [
      "smartsheet.com"
    ]),
    rule("workplace-saas", "wrike", "Wrike", ["wrike"], ["wrike.com"]),
    rule("workplace-saas", "productboard", "Productboard", ["productboard"], [
      "productboard.com"
    ]),
    rule("workplace-saas", "aha", "Aha!", ["aha roadmap", "aha.io"], ["aha.io"]),

    rule("sales-marketing", "pipedrive", "Pipedrive", ["pipedrive"], [
      "pipedrive.com"
    ]),
    rule("sales-marketing", "freshworks", "Freshworks / Freshdesk", [
      "freshworks",
      "freshdesk"
    ], [
      "freshworks.com",
      "freshdesk.com"
    ]),
    rule("sales-marketing", "help-scout", "Help Scout", ["help scout", "helpscout"], [
      "helpscout.com",
      "helpscoutdocs.com",
      "helpscout.net"
    ]),
    rule("sales-marketing", "front", "Front", ["front app", "front.com"], [
      "front.com",
      "frontapp.com"
    ]),
    rule("sales-marketing", "customer-io", "Customer.io", [
      "customer.io",
      "customer io"
    ], ["customer.io"]),
    rule("sales-marketing", "braze", "Braze", ["braze"], ["braze.com"]),
    rule("sales-marketing", "klaviyo", "Klaviyo", ["klaviyo"], ["klaviyo.com"]),
    rule("sales-marketing", "activecampaign", "ActiveCampaign", [
      "activecampaign",
      "active campaign"
    ], ["activecampaign.com"]),
    rule("sales-marketing", "constant-contact", "Constant Contact", [
      "constant contact"
    ], ["constantcontact.com"]),
    rule("sales-marketing", "brevo", "Brevo / Sendinblue", ["brevo", "sendinblue"], [
      "brevo.com",
      "sendinblue.com"
    ]),
    rule("sales-marketing", "mailerlite", "MailerLite", ["mailerlite", "mailer lite"], [
      "mailerlite.com"
    ]),
    rule("sales-marketing", "marketo", "Adobe Marketo Engage", ["marketo"], [
      "marketo.com"
    ]),

    rule("data-analytics", "tableau", "Tableau", ["tableau"], ["tableau.com"]),
    rule("data-analytics", "power-bi", "Microsoft Power BI", ["power bi", "powerbi"], [
      "powerbi.com"
    ]),
    rule("data-analytics", "looker", "Looker", ["looker"], [
      "looker.com"
    ]),
    rule("data-analytics", "snowflake", "Snowflake", ["snowflake"], [
      "snowflake.com"
    ]),
    rule("data-analytics", "databricks", "Databricks", ["databricks"], [
      "databricks.com"
    ]),
    rule("data-analytics", "dbt", "dbt Labs", ["dbt", "dbt labs", "dbt cloud"], [
      "getdbt.com",
      "dbtlabs.com"
    ]),
    rule("data-analytics", "fivetran", "Fivetran", ["fivetran"], ["fivetran.com"]),
    rule("data-analytics", "mixpanel", "Mixpanel", ["mixpanel"], ["mixpanel.com"]),
    rule("data-analytics", "amplitude", "Amplitude", ["amplitude analytics"], [
      "amplitude.com"
    ]),
    rule("data-analytics", "hotjar", "Contentsquare / Hotjar", ["hotjar", "contentsquare"], [
      "hotjar.com",
      "contentsquare.com"
    ]),

    rule("privacy-security", "duo", "Duo Security", ["duo security", "duo.com"], [
      "duo.com",
      "duosecurity.com",
      "duofederal.com"
    ]),
    rule("privacy-security", "dashlane", "Dashlane", ["dashlane"], ["dashlane.com"]),
    rule("privacy-security", "keeper", "Keeper", ["keeper security", "keeper password"], [
      "keepersecurity.com"
    ]),
    rule("privacy-security", "nordpass", "NordPass", ["nordpass", "nord pass"], [
      "nordpass.com"
    ]),
    rule("privacy-security", "knowbe4", "KnowBe4", ["knowbe4", "know be4"], [
      "knowbe4.com"
    ]),
    rule("privacy-security", "crowdstrike", "CrowdStrike", ["crowdstrike"], [
      "crowdstrike.com"
    ]),
    rule("privacy-security", "jamf", "Jamf", ["jamf"], ["jamf.com", "jamfcloud.com"]),
    rule("privacy-security", "jumpcloud", "JumpCloud", ["jumpcloud", "jump cloud"], [
      "jumpcloud.com"
    ]),
    rule("privacy-security", "zscaler", "Zscaler", ["zscaler"], [
      "zscaler.com",
      "zscaler.net",
      "zscalerone.net",
      "zscalertwo.net",
      "zscalerthree.net",
      "zscloud.net",
      "zpatwo.net",
      "zdxcloud.net",
      "zslogin.net"
    ]),
    rule("privacy-security", "tenable", "Tenable", ["tenable"], ["tenable.com"]),

    rule("big-tech", "microsoft", "Microsoft", [
      "microsoft",
      "outlook",
      "onedrive",
      "bing",
      "bing maps",
      "microsoft copilot",
      "microsoft teams"
    ], [
      "microsoft.com",
      "cloud.microsoft",
      "accountprotection.microsoft.com",
      "bing.com",
      "microsoft365.com",
      "microsoftonline.com",
      "outlook.com",
      "office.com",
      "office365.com",
      "sharepoint.com",
      "live.com",
      "onedrive.com"
    ]),
    rule("big-tech", "google", "Google", [
      "google",
      "gmail",
      "youtube",
      "google maps",
      "google gemini",
      "gemini",
      "google classroom"
    ], [
      "google.com",
      "google.fr",
      "google.co.uk",
      "google.de",
      "google.es",
      "google.it",
      "google.nl",
      "google.be",
      "google.ca",
      "google.com.br",
      "google.co.jp",
      "google.com.au",
      "google.ie",
      "google.pt",
      "google.ch",
      "google.at",
      "google.pl",
      "calendar.app.google",
      "maps.app.goo.gl",
      "g.co",
      "goo.gle",
      "c.gle",
      "gmail.com",
      "youtube.com",
      "youtu.be",
      "accounts.google.com"
    ], {
      brandLinkDomains: ["google-analytics.com"]
    }),
    rule("big-tech", "apple", "Apple", ["apple", "icloud", "itunes", "app store", "apple maps"], [
      "apple.com",
      "icloud.com",
      "me.com",
      "itunes.com"
    ], {
      exactSenderAliases: ["Apple"],
      senderAliases: ["apple support", "apple security", "apple store", "icloud", "itunes", "app store"]
    }),
    rule("big-tech", "meta", "Meta", ["meta platforms", "meta business", "meta ai"], [
      "meta.com",
      "meta.ai",
      "metamail.com"
    ]),
    rule("big-tech", "facebook", "Facebook / Messenger", ["facebook", "messenger"], [
      "facebook.com",
      "facebookmail.com",
      "messenger.com",
      "m.me"
    ]),
    rule("big-tech", "instagram", "Instagram", ["instagram"], ["instagram.com"]),
    rule("big-tech", "whatsapp", "WhatsApp", ["whatsapp"], ["whatsapp.com"]),
    rule("big-tech", "linkedin", "LinkedIn", ["linkedin", "linked in"], ["linkedin.com"], {
      senderDomains: ["linkedin.com"],
      brandLinkDomains: ["lnkd.in"]
    }),
    rule("big-tech", "twitter-x", "X / Twitter", ["twitter", "x.com"], [
      "x.com",
      "e.x.com",
      "twitter.com"
    ], {
      senderDomains: ["x.com", "e.x.com"],
      senderMatchSubdomains: false
    }),
    rule("big-tech", "xai", "xAI / Grok", ["x.ai", "xai", "x ai", "grok", "grokipedia"], [
      "x.ai",
      "grok.com",
      "grokipedia.com"
    ], {
      senderDomains: ["x.ai"],
      senderMatchSubdomains: false
    }),
    rule("big-tech", "tiktok", "TikTok", ["tiktok", "tik tok"], ["tiktok.com"]),
    rule("big-tech", "snapchat", "Snapchat", ["snapchat"], ["snapchat.com"]),
    rule("big-tech", "discord", "Discord", ["discord"], ["discord.com"]),
    rule("big-tech", "slack", "Slack", ["slack"], ["slack.com"]),
    rule("big-tech", "zoom", "Zoom", ["zoom"], ["zoom.com", "zoom.us"]),
    rule("big-tech", "dropbox", "Dropbox", ["dropbox"], ["dropbox.com"]),
    rule("big-tech", "box", "Box", ["box.com", "box cloud"], ["box.com"]),
    rule("big-tech", "adobe", "Adobe", ["adobe", "creative cloud"], ["adobe.com"]),
    rule("big-tech", "docusign", "DocuSign", ["docusign", "docu sign"], [
      "docusign.com",
      "docusign.net"
    ]),
    rule("big-tech", "dropbox-sign", "Dropbox Sign", ["dropbox sign", "hellosign"], [
      "dropboxsign.com",
      "hellosign.com",
      "dropbox.com"
    ]),
    rule("big-tech", "yousign", "Yousign / Youtrust", ["yousign", "youtrust"], [
      "yousign.com",
      "yousign.fr",
      "youtrust.com"
    ]),
    rule("big-tech", "notion", "Notion", ["notion"], [
      "notion.com",
      "www.notion.com",
      "notion.so",
      "notion.site"
    ], {
      hostedPlatform: true,
      matchSubdomains: false
    }),
    rule("big-tech", "figma", "Figma", ["figma", "figjam"], ["figma.com"]),
    rule("big-tech", "canva", "Canva", ["canva"], ["canva.com"]),
    rule("big-tech", "miro", "Miro", ["miro board", "miro.com"], ["miro.com"]),
    rule("big-tech", "mural", "Mural", ["mural board", "mural.co"], ["mural.co"]),
    rule("big-tech", "lucid", "Lucid", ["lucidchart", "lucidspark", "lucid.co"], [
      "lucid.co"
    ]),
    rule("big-tech", "airtable", "Airtable", ["airtable"], ["airtable.com"]),
    rule("big-tech", "asana", "Asana", ["asana"], ["asana.com"]),
    rule("big-tech", "trello", "Trello", ["trello"], ["trello.com"]),
    rule("big-tech", "monday", "monday.com", ["monday.com", "monday work"], [
      "monday.com"
    ]),
    rule("big-tech", "clickup", "ClickUp", ["clickup", "click up"], ["clickup.com"]),
    rule("big-tech", "coda", "Coda", ["coda.io", "coda docs"], ["coda.io"]),
    rule("big-tech", "basecamp", "Basecamp", ["basecamp"], ["basecamp.com"]),
    rule("big-tech", "loom", "Loom", ["loom video", "loom.com"], ["loom.com"]),
    rule("big-tech", "todoist", "Todoist", ["todoist"], ["todoist.com"]),
    rule("big-tech", "evernote", "Evernote", ["evernote"], ["evernote.com"]),
    rule("big-tech", "zapier", "Zapier", ["zapier"], ["zapier.com"]),
    rule("big-tech", "make", "Make", ["make.com", "make automation"], ["make.com"]),
    rule("big-tech", "1password", "1Password", ["1password", "one password"], [
      "1password.com"
    ]),
    rule("big-tech", "lastpass", "LastPass", ["lastpass", "last pass"], [
      "lastpass.com"
    ]),
    rule("big-tech", "bitwarden", "Bitwarden", ["bitwarden"], ["bitwarden.com"]),
    rule("big-tech", "okta", "Okta", ["okta"], ["okta.com"]),
    rule("big-tech", "auth0", "Auth0", ["auth0"], ["auth0.com", "okta.com"]),
    rule("big-tech", "yahoo", "Yahoo", ["yahoo"], [
      "yahoo.com",
      "yahoo.fr",
      "yahoo.co.uk",
      "yahoo.de",
      "yahoo.es",
      "yahoo.it",
      "ymail.com",
      "rocketmail.com"
    ]),
    rule("big-tech", "proton", "Proton", ["proton mail", "protonmail", "proton.me"], [
      "proton.me",
      "protonmail.com",
      "pm.me"
    ]),
    rule("big-tech", "fastmail", "Fastmail", ["fastmail"], [
      "fastmail.com",
      "fastmail.fm"
    ]),
    rule("big-tech", "zoho", "Zoho", ["zoho"], [
      "zoho.com",
      "zoho.eu",
      "zohomail.com",
      "zohomail.eu"
    ]),
    rule("mail-providers", "aol", "AOL Mail", ["aol", "aol mail"], ["aol.com"]),
    rule("mail-providers", "mail-com", "mail.com", ["mail.com", "mail com"], [
      "mail.com"
    ]),
    rule("mail-providers", "gmx", "GMX", ["gmx", "gmx mail"], [
      "gmx.com",
      "gmx.fr",
      "gmx.net",
      "gmx.de",
      "gmx.at",
      "gmx.ch"
    ]),
    rule("mail-providers", "web-de", "WEB.DE", ["web.de", "web de"], [
      "web.de"
    ]),
    rule("mail-providers", "t-online-mail", "T-Online Mail", [
      "t-online",
      "t online",
      "telekom mail"
    ], ["t-online.de"]),
    rule("mail-providers", "freenet-mail", "Freenet Mail", [
      "freenet mail",
      "freenet.de"
    ], ["freenet.de"]),
    rule("mail-providers", "mailo", "Mailo", ["mailo", "netcourrier"], [
      "mailo.com",
      "mailo.fr",
      "mailo.eu",
      "netcourrier.com"
    ]),
    rule("mail-providers", "tuta", "Tuta", ["tuta", "tutanota", "tuta mail"], [
      "tuta.com",
      "tutanota.com",
      "tutanota.de",
      "tutamail.com"
    ]),
    rule("mail-providers", "mailbox-org", "mailbox.org", [
      "mailbox.org",
      "mailbox org"
    ], ["mailbox.org"]),
    rule("mail-providers", "posteo", "Posteo", ["posteo"], ["posteo.de"]),
    rule("mail-providers", "seznam-email", "Seznam Email", [
      "seznam email",
      "seznam.cz"
    ], ["seznam.cz"]),
    rule("mail-providers", "wp-poczta", "Poczta WP", [
      "poczta wp",
      "wp poczta",
      "wp.pl mail"
    ], ["wp.pl"]),
    rule("mail-providers", "onet-poczta", "Onet Poczta", [
      "onet poczta",
      "poczta onet"
    ], ["onet.pl"]),
    rule("mail-providers", "o2-poczta", "O2 Poczta", [
      "o2 poczta",
      "o2.pl mail"
    ], ["o2.pl"]),
    rule("mail-providers", "interia-poczta", "Interia Poczta", [
      "interia poczta",
      "poczta interia"
    ], ["interia.pl"]),
    rule("mail-providers", "libero-mail", "Libero Mail", [
      "libero mail",
      "libero.it"
    ], ["libero.it"]),
    rule("mail-providers", "virgilio-mail", "Virgilio Mail", [
      "virgilio mail",
      "virgilio.it"
    ], ["virgilio.it"]),
    rule("big-tech", "salesforce", "Salesforce", ["salesforce"], ["salesforce.com"]),
    rule("big-tech", "hubspot", "HubSpot", ["hubspot"], ["hubspot.com"]),
    rule("big-tech", "zendesk", "Zendesk", ["zendesk"], [
      "zendesk.com",
      "zendesk.co.jp"
    ]),
    rule("big-tech", "intercom", "Intercom", ["intercom.com", "intercom support"], [
      "intercom.com"
    ]),
    rule("big-tech", "workday", "Workday", ["workday"], ["workday.com"]),
    rule("big-tech", "servicenow", "ServiceNow", ["servicenow", "service now"], [
      "servicenow.com"
    ]),
    rule("big-tech", "rippling", "Rippling", ["rippling"], ["rippling.com"]),
    rule("big-tech", "deel", "Deel", ["deel.com", "deel payroll"], ["deel.com"]),
    rule("big-tech", "gusto", "Gusto", ["gusto payroll", "gusto.com"], ["gusto.com"]),
    rule("big-tech", "dropbox-transfer", "Dropbox Transfer", ["dropbox transfer"], [
      "dropbox.com"
    ]),

    rule("ai", "perplexity", "Perplexity", ["perplexity", "perplexity ai"], [
      "perplexity.ai"
    ]),
    rule("ai", "deepseek", "DeepSeek", ["deepseek", "deepseek ai"], [
      "deepseek.com"
    ]),
    rule("ai", "character-ai", "Character.AI", ["character.ai", "character ai"], [
      "character.ai"
    ]),
    rule("ai", "quillbot", "QuillBot", ["quillbot", "quill bot"], ["quillbot.com"]),
    rule("ai", "poe", "Poe", ["poe.com", "poe ai"], ["poe.com"]),
    rule("ai", "mistral-ai", "Mistral AI", ["mistral ai", "chat mistral"], [
      "mistral.ai"
    ]),
    rule("ai", "hugging-face", "Hugging Face", ["hugging face", "huggingface"], [
      "huggingface.co"
    ]),
    rule("ai", "midjourney", "Midjourney", ["midjourney"], ["midjourney.com"]),
    rule("ai", "elevenlabs", "ElevenLabs", ["elevenlabs", "eleven labs"], [
      "elevenlabs.io"
    ]),
    rule("ai", "runway", "Runway", ["runwayml", "runway ai"], ["runwayml.com"]),
    rule("ai", "replicate", "Replicate", ["replicate ai", "replicate.com"], [
      "replicate.com"
    ]),

    rule("education", "coursera", "Coursera", ["coursera"], ["coursera.org"]),
    rule("education", "udemy", "Udemy", ["udemy"], ["udemy.com"]),
    rule("education", "khan-academy", "Khan Academy", ["khan academy"], [
      "khanacademy.org"
    ]),
    rule("education", "duolingo", "Duolingo", ["duolingo"], ["duolingo.com"]),
    rule("education", "edx", "edX", ["edx", "edx.org"], ["edx.org"]),
    rule("education", "instructure-canvas", "Canvas / Instructure", [
      "canvas lms",
      "instructure"
    ], [
      "instructure.com",
      "canvaslms.com"
    ]),
    rule("education", "moodle", "Moodle", ["moodle"], ["moodle.org", "moodlecloud.com"], {
      controlPlaneDomains: ["moodle.huauchinango.tecnm.mx"]
    }),
    rule("education", "blackboard", "Blackboard", ["blackboard", "anthology"], [
      "blackboard.com",
      "anthology.com"
    ]),
    rule("education", "wayground", "Wayground (formerly Quizizz)", [
      "wayground",
      "quizizz"
    ], ["wayground.com", "quizizz.com"]),
    rule("education", "pearson", "Pearson", ["pearson education", "pearsonvue"], [
      "pearson.com",
      "pearsonvue.com"
    ]),
    rule("education", "chegg", "Chegg", ["chegg"], ["chegg.com"]),
    rule("education", "quizlet", "Quizlet", ["quizlet"], ["quizlet.com"]),
    rule("education", "schoology", "Schoology", ["schoology"], ["schoology.com"]),
    rule("education", "clever", "Clever", ["clever.com", "clever school"], [
      "clever.com"
    ]),
    rule("education", "classdojo", "ClassDojo", ["classdojo", "class dojo"], [
      "classdojo.com"
    ]),
    rule("education", "kahoot", "Kahoot!", ["kahoot"], ["kahoot.com"]),
    rule("education", "turnitin", "Turnitin", ["turnitin"], ["turnitin.com"]),

    rule("news-reference", "wikipedia", "Wikipedia / Wikimedia", [
      "wikipedia",
      "wikimedia"
    ], [
      "wikipedia.org",
      "wikimedia.org",
      "wikimediafoundation.org"
    ]),
    rule("news-reference", "reddit", "Reddit", ["reddit"], ["reddit.com"]),
    rule("news-reference", "quora", "Quora", ["quora"], ["quora.com"]),
    rule("news-reference", "medium", "Medium", ["medium.com", "medium publication"], [
      "medium.com"
    ]),
    rule("news-reference", "substack", "Substack", ["substack"], ["substack.com"]),
    rule("news-reference", "bbc", "BBC", ["bbc", "bbc news"], ["bbc.com", "bbc.co.uk"]),
    rule("news-reference", "cnn", "CNN", ["cnn"], ["cnn.com"]),
    rule("news-reference", "nytimes", "The New York Times", [
      "new york times",
      "nytimes"
    ], ["nytimes.com"]),
    rule("news-reference", "washington-post", "The Washington Post", [
      "washington post"
    ], ["washingtonpost.com"]),
    rule("news-reference", "the-guardian", "The Guardian", ["the guardian"], [
      "theguardian.com"
    ]),
    rule("news-reference", "reuters", "Reuters", ["reuters"], ["reuters.com"]),
    rule("news-reference", "associated-press", "Associated Press", [
      "associated press",
      "ap news"
    ], ["apnews.com"]),
    rule("news-reference", "le-monde", "Le Monde", ["le monde"], ["lemonde.fr"]),
    rule("news-reference", "le-figaro", "Le Figaro", ["le figaro"], ["lefigaro.fr"]),
    rule("news-reference", "franceinfo", "Franceinfo", ["franceinfo"], [
      "franceinfo.fr"
    ]),
    rule("news-reference", "npr", "NPR", ["npr"], ["npr.org"]),
    rule("news-reference", "bloomberg", "Bloomberg", ["bloomberg"], [
      "bloomberg.com"
    ]),
    rule("news-reference", "forbes", "Forbes", ["forbes"], ["forbes.com"]),

    rule("regional-social", "baidu", "Baidu", ["baidu"], ["baidu.com"]),
    rule("regional-social", "naver", "Naver", ["naver"], ["naver.com"]),
    rule("regional-social", "yandex", "Yandex", ["yandex"], [
      "yandex.com",
      "yandex.ru",
      "ya.ru"
    ]),
    rule("regional-social", "mail-ru", "Mail.ru", ["mail.ru", "mail ru"], [
      "mail.ru"
    ]),
    rule("regional-social", "vk", "VK", ["vk.com", "vkontakte"], ["vk.com"]),
    rule("regional-social", "odnoklassniki", "Odnoklassniki", ["ok.ru", "odnoklassniki"], [
      "ok.ru"
    ]),
    rule("regional-social", "telegram", "Telegram", ["telegram", "telegram.org"], [
      "telegram.org",
      "t.me"
    ]),
    rule("regional-social", "wechat", "WeChat / Weixin", ["wechat", "weixin"], [
      "wechat.com",
      "weixin.qq.com"
    ]),
    rule("regional-social", "qq", "QQ", ["qq.com", "tencent qq"], ["qq.com"]),
    rule("regional-social", "weibo", "Weibo", ["weibo"], ["weibo.com"]),
    rule("regional-social", "line", "LINE", ["line.me", "line messenger"], [
      "line.me"
    ]),
    rule("regional-social", "kakao", "KakaoTalk", ["kakaotalk", "kakao talk"], [
      "kakao.com",
      "kakaocorp.com"
    ]),
    rule("regional-social", "pinterest", "Pinterest", ["pinterest"], ["pinterest.com"]),
    rule("regional-social", "threads", "Threads", ["threads", "threads.com", "threads.net", "meta threads"], [
      "threads.com",
      "threads.net"
    ]),
    rule("regional-social", "bluesky", "Bluesky", ["bluesky social", "bsky.app"], [
      "bsky.app",
      "bsky.social"
    ]),

    rule("jobs-real-estate", "indeed", "Indeed", ["indeed jobs", "indeed.com"], [
      "indeed.com"
    ]),
    rule("jobs-real-estate", "glassdoor", "Glassdoor", ["glassdoor"], [
      "glassdoor.com"
    ]),
    rule("jobs-real-estate", "monster", "Monster", ["monster jobs"], ["monster.com"]),
    rule("jobs-real-estate", "careerbuilder", "CareerBuilder", [
      "careerbuilder",
      "career builder"
    ], ["careerbuilder.com"]),
    rule("jobs-real-estate", "ziprecruiter", "ZipRecruiter", ["ziprecruiter"], [
      "ziprecruiter.com",
      "ziprecruiter.ie"
    ]),
    rule("jobs-real-estate", "welcome-to-the-jungle", "Welcome to the Jungle", [
      "welcome to the jungle"
    ], ["welcometothejungle.com"]),
    rule("jobs-real-estate", "smartrecruiters", "SmartRecruiters", [
      "smartrecruiters"
    ], ["smartrecruiters.com"]),
    rule("jobs-real-estate", "taleo", "Taleo / Oracle Recruiting", [
      "taleo",
      "oracle recruiting"
    ], [
      "taleo.net"
    ]),
    rule("jobs-real-estate", "zillow", "Zillow", ["zillow"], ["zillow.com"]),
    rule("jobs-real-estate", "realtor-com", "Realtor.com", [
      "realtor.com",
      "realtor"
    ], ["realtor.com"]),
    rule("jobs-real-estate", "redfin", "Redfin", ["redfin"], ["redfin.com"]),
    rule("jobs-real-estate", "seloger", "SeLoger", ["seloger", "se loger"], [
      "seloger.com"
    ]),
    rule("jobs-real-estate", "bienici", "Bien'ici", ["bienici", "bien ici"], [
      "bienici.com"
    ]),
    rule("jobs-real-estate", "pap", "PAP.fr", ["pap.fr", "particulier a particulier"], [
      "pap.fr"
    ]),
    rule("jobs-real-estate", "rightmove", "Rightmove", ["rightmove"], [
      "rightmove.co.uk"
    ]),
    rule("jobs-real-estate", "zoopla", "Zoopla", ["zoopla"], ["zoopla.co.uk"]),
    rule("jobs-real-estate", "idealista", "Idealista", ["idealista"], [
      "idealista.com"
    ]),
    rule("jobs-real-estate", "immobiliare-it", "Immobiliare.it", ["immobiliare.it"], [
      "immobiliare.it"
    ]),
    rule("jobs-real-estate", "immoscout24", "ImmoScout24", [
      "immoscout24",
      "immobilienscout24"
    ], [
      "immobilienscout24.de",
      "immoscout24.ch"
    ]),
    rule("jobs-real-estate", "domain-au", "Domain Australia", [
      "domain.com.au",
      "domain real estate"
    ], ["domain.com.au"]),
    rule("jobs-real-estate", "apartments-com", "Apartments.com", [
      "apartments.com"
    ], ["apartments.com"]),

    rule("food-local", "yelp", "Yelp", ["yelp"], ["yelp.com"]),
    rule("food-local", "tripadvisor", "Tripadvisor", ["tripadvisor", "trip advisor"], [
      "tripadvisor.com",
      "tripadvisor.fr"
    ]),
    rule("food-local", "grubhub", "Grubhub", ["grubhub", "grub hub"], [
      "grubhub.com"
    ]),
    rule("food-local", "postmates", "Postmates", ["postmates"], [
      "postmates.com",
      "uber.com"
    ]),
    rule("food-local", "too-good-to-go", "Too Good To Go", ["too good to go"], [
      "toogoodtogo.com"
    ]),
    rule("food-local", "hellofresh", "HelloFresh", ["hellofresh", "hello fresh"], [
      "hellofresh.com"
    ]),
    rule("food-local", "tesco", "Tesco", ["tesco"], ["tesco.com"]),
    rule("food-local", "sainsburys", "Sainsbury's", ["sainsburys", "sainsbury"], [
      "sainsburys.co.uk"
    ]),
    rule("food-local", "kroger", "Kroger", ["kroger"], ["kroger.com"]),
    rule("food-local", "aldi", "ALDI", ["aldi"], ["aldi.com"]),
    rule("food-local", "ocado", "Ocado", ["ocado"], ["ocado.com"]),
    rule("food-local", "whole-foods", "Whole Foods Market", ["whole foods"], [
      "wholefoodsmarket.com",
      "wholefoodsmarket.co.uk"
    ]),
    rule("food-local", "waitrose", "Waitrose", ["waitrose"], ["waitrose.com"]),
    rule("food-local", "thumbtack", "Thumbtack", ["thumbtack"], ["thumbtack.com"]),
    rule("food-local", "angi", "Angi", ["angi.com", "angi services"], ["angi.com"]),
    rule("food-local", "taskrabbit", "Taskrabbit", ["taskrabbit", "task rabbit"], [
      "taskrabbit.com"
    ]),
    rule("food-local", "nextdoor", "Nextdoor", ["nextdoor"], ["nextdoor.com"]),

    rule("health-global", "unitedhealthcare", "UnitedHealthcare", [
      "unitedhealthcare",
      "united healthcare"
    ], ["uhc.com", "unitedhealthcare.com"]),
    rule("health-global", "optum", "Optum", ["optum"], ["optum.com"]),
    rule("health-global", "kaiser-permanente", "Kaiser Permanente", [
      "kaiser permanente"
    ], ["kp.org", "kaiserpermanente.org"]),
    rule("health-global", "aetna", "Aetna", ["aetna"], ["aetna.com"]),
    rule("health-global", "cigna", "Cigna", ["cigna"], ["cigna.com"]),
    rule("health-global", "blue-cross-blue-shield", "Blue Cross Blue Shield", [
      "blue cross blue shield",
      "bcbs"
    ], ["bcbs.com", "bluecrossblueshield.com"]),
    rule("health-global", "anthem", "Anthem / Elevance Health", [
      "anthem insurance",
      "elevance health"
    ], ["anthem.com", "elevancehealth.com"]),
    rule("health-global", "humana", "Humana", ["humana"], ["humana.com"]),
    rule("health-global", "bupa", "Bupa", ["bupa"], ["bupa.com"]),
    rule("health-global", "nhs", "NHS", ["nhs", "nhs uk"], ["nhs.uk"]),
    rule("health-global", "cvs-health", "CVS Health", ["cvs health", "cvs pharmacy"], [
      "cvs.com",
      "cvshealth.com"
    ]),
    rule("health-global", "walgreens", "Walgreens", ["walgreens"], [
      "walgreens.com"
    ]),
    rule("health-global", "goodrx", "GoodRx", ["goodrx", "good rx"], ["goodrx.com"]),
    rule("health-global", "zocdoc", "Zocdoc", ["zocdoc"], ["zocdoc.com"]),
    rule("health-global", "mychart", "MyChart", ["mychart", "epic mychart"], [
      "mychart.com",
      "mychart.org",
      "epic.com"
    ]),
    rule("health-global", "mayo-clinic", "Mayo Clinic", ["mayo clinic"], [
      "mayoclinic.org"
    ]),
    rule("health-global", "cleveland-clinic", "Cleveland Clinic", [
      "cleveland clinic"
    ], ["clevelandclinic.org"]),
    rule("health-global", "webmd", "WebMD", ["webmd"], ["webmd.com"]),
    rule("health-global", "healthline", "Healthline", ["healthline"], [
      "healthline.com"
    ]),

    rule("devices", "samsung", "Samsung", ["samsung"], ["samsung.com"]),
    rule("devices", "xiaomi", "Xiaomi", ["xiaomi"], ["mi.com", "xiaomi.com"]),
    rule("devices", "huawei", "Huawei", ["huawei"], ["huawei.com"]),
    rule("devices", "sony", "Sony", ["sony"], ["sony.com"]),
    rule("devices", "lg", "LG", ["lg.com", "lg electronics"], ["lg.com"]),
    rule("devices", "hp", "HP", ["hp.com", "hewlett packard"], ["hp.com"]),
    rule("devices", "dell", "Dell", ["dell"], ["dell.com"]),
    rule("devices", "lenovo", "Lenovo", ["lenovo"], ["lenovo.com"]),
    rule("devices", "garmin", "Garmin", ["garmin"], ["garmin.com"]),
    rule("devices", "asus", "ASUS", ["asus"], ["asus.com"]),
    rule("devices", "acer", "Acer", ["acer"], ["acer.com"]),
    rule("devices", "logitech", "Logitech", ["logitech"], ["logitech.com"]),
    rule("devices", "roku", "Roku", ["roku"], ["roku.com"]),
    rule("devices", "sonos", "Sonos", ["sonos"], ["sonos.com"]),
    rule("devices", "fitbit", "Fitbit", ["fitbit"], ["fitbit.com"]),
    rule("devices", "dyson", "Dyson", ["dyson"], ["dyson.com"]),
    rule("devices", "bose", "Bose", ["bose"], ["bose.com"]),

    rule("weather-emergency", "weather-channel", "The Weather Channel", [
      "weather.com",
      "the weather channel"
    ], ["weather.com"]),
    rule("weather-emergency", "accuweather", "AccuWeather", ["accuweather"], [
      "accuweather.com"
    ]),
    rule("weather-emergency", "weather-gov", "National Weather Service", [
      "weather.gov",
      "national weather service"
    ], ["weather.gov", "noaa.gov"]),
    rule("weather-emergency", "met-office", "Met Office", ["met office"], [
      "metoffice.gov.uk"
    ]),
    rule("weather-emergency", "meteo-france", "Meteo-France", [
      "meteo france",
      "meteofrance"
    ], ["meteofrance.com", "meteofrance.fr"]),
    rule("weather-emergency", "windy", "Windy", ["windy.com", "windy weather"], [
      "windy.com"
    ]),
    rule("weather-emergency", "ventusky", "Ventusky", ["ventusky"], [
      "ventusky.com"
    ]),
    rule("weather-emergency", "weather-network", "The Weather Network", [
      "the weather network"
    ], ["theweathernetwork.com"]),
    rule("weather-emergency", "usgs", "USGS", ["usgs", "us geological survey"], [
      "usgs.gov"
    ]),
    rule("weather-emergency", "fema", "FEMA", ["fema"], ["fema.gov"]),
    rule("weather-emergency", "ready-gov", "Ready.gov", ["ready.gov"], [
      "ready.gov"
    ]),
    rule("weather-emergency", "red-cross", "Red Cross", ["red cross"], [
      "redcross.org",
      "ifrc.org"
    ]),
    rule("weather-emergency", "croix-rouge", "Croix-Rouge francaise", [
      "croix rouge",
      "croix-rouge"
    ], ["croix-rouge.fr"]),
    rule("weather-emergency", "alertswiss", "Alertswiss", ["alertswiss"], [
      "alert.swiss"
    ]),
    rule("weather-emergency", "gdacs", "GDACS", [
      "gdacs",
      "global disaster alert"
    ], ["gdacs.org"]),

    rule("sports-entertainment", "espn", "ESPN", ["espn"], ["espn.com"]),
    rule("sports-entertainment", "fifa", "FIFA", ["fifa"], ["fifa.com"]),
    rule("sports-entertainment", "uefa", "UEFA", ["uefa"], ["uefa.com"]),
    rule("sports-entertainment", "olympics", "Olympics", ["olympics"], [
      "olympics.com"
    ]),
    rule("sports-entertainment", "nba", "NBA", ["nba"], ["nba.com"]),
    rule("sports-entertainment", "nfl", "NFL", ["nfl"], ["nfl.com"]),
    rule("sports-entertainment", "mlb", "MLB", ["mlb"], ["mlb.com"]),
    rule("sports-entertainment", "nhl", "NHL", ["nhl"], ["nhl.com"]),
    rule("sports-entertainment", "formula1", "Formula 1", ["formula 1", "f1"], [
      "formula1.com"
    ]),
    rule("sports-entertainment", "strava", "Strava", ["strava"], ["strava.com"]),
    rule("sports-entertainment", "alltrails", "AllTrails", ["alltrails"], [
      "alltrails.com"
    ]),
    rule("sports-entertainment", "imdb", "IMDb", ["imdb"], ["imdb.com"]),
    rule("sports-entertainment", "fandango", "Fandango", ["fandango"], [
      "fandango.com"
    ]),
    rule("sports-entertainment", "rotten-tomatoes", "Rotten Tomatoes", [
      "rotten tomatoes"
    ], ["rottentomatoes.com"]),
    rule("sports-entertainment", "seatgeek", "SeatGeek", ["seatgeek", "seat geek"], [
      "seatgeek.com"
    ]),
    rule("sports-entertainment", "stubhub", "StubHub", ["stubhub", "stub hub"], [
      "stubhub.com"
    ]),
    rule("sports-entertainment", "axs", "AXS", ["axs tickets", "axs.com"], [
      "axs.com"
    ]),
    rule("sports-entertainment", "vivid-seats", "Vivid Seats", ["vivid seats"], [
      "vividseats.com"
    ]),
    rule("sports-entertainment", "bandsintown", "Bandsintown", ["bandsintown"], [
      "bandsintown.com"
    ]),
    rule("sports-entertainment", "songkick", "Songkick", ["songkick"], [
      "songkick.com"
    ]),

    rule("media-gaming", "netflix", "Netflix", ["netflix"], ["netflix.com"]),
    rule("media-gaming", "prime-video", "Prime Video", [
      "prime video",
      "primevideo",
      "amazon prime video"
    ], [
      "primevideo.com",
      "amazon.com",
      "amazon.fr",
      "amazon.co.uk",
      "amazon.de",
      "amazon.es",
      "amazon.it",
      "amazon.nl",
      "amazon.ca",
      "amazon.com.mx",
      "amazon.com.be",
      "amazon.com.au",
      "amazon.co.jp"
    ], {
      senderDomains: [
        "primevideo.com",
        "amazon.com",
        "amazon.fr",
        "amazon.co.uk",
        "amazon.de",
        "amazon.es",
        "amazon.it",
        "amazon.nl",
        "amazon.ca",
        "amazon.com.mx",
        "amazon.com.be",
        "amazon.com.au",
        "amazon.co.jp"
      ]
    }),
    rule("media-gaming", "spotify", "Spotify", ["spotify"], ["spotify.com"]),
    rule("media-gaming", "disney", "Disney+", ["disney plus", "disney+"], [
      "disneyplus.com",
      "disney.com"
    ]),
    rule("media-gaming", "twitch", "Twitch", ["twitch"], ["twitch.tv"]),
    rule("media-gaming", "steam", "Steam", ["steam", "steam support"], [
      "steampowered.com",
      "steamcommunity.com"
    ]),
    rule("media-gaming", "epic-games", "Epic Games", ["epic games"], [
      "epicgames.com"
    ]),
    rule("media-gaming", "playstation", "PlayStation", ["playstation"], [
      "playstation.com",
      "sony.com"
    ]),
    rule("media-gaming", "xbox", "Xbox", ["xbox"], ["xbox.com", "microsoft.com"]),
    rule("media-gaming", "nintendo", "Nintendo", ["nintendo"], ["nintendo.com"]),
    rule("media-gaming", "hulu", "Hulu", ["hulu"], ["hulu.com"]),
    rule("media-gaming", "max", "HBO Max", ["max", "max.com", "hbo max"], [
      "max.com",
      "hbomax.com"
    ], {
      senderAliases: ["hbo max", "max.com"]
    }),
    rule("media-gaming", "paramount-plus", "Paramount+", ["paramount plus"], [
      "paramountplus.com"
    ]),
    rule("media-gaming", "peacock", "Peacock", ["peacock tv", "peacocktv"], [
      "peacocktv.com"
    ]),
    rule("media-gaming", "crunchyroll", "Crunchyroll", ["crunchyroll"], [
      "crunchyroll.com"
    ]),
    rule("media-gaming", "roblox", "Roblox", ["roblox"], ["roblox.com"]),
    rule("media-gaming", "ea", "Electronic Arts", ["electronic arts", "ea.com"], [
      "ea.com"
    ]),
    rule("media-gaming", "ubisoft", "Ubisoft", ["ubisoft"], ["ubisoft.com"]),
    rule("media-gaming", "riot-games", "Riot Games", ["riot games"], [
      "riotgames.com"
    ]),
    rule("media-gaming", "battle-net", "Battle.net", ["battle.net", "blizzard"], [
      "battle.net",
      "blizzard.com"
    ]),
    rule("media-gaming", "minecraft", "Minecraft", ["minecraft"], [
      "minecraft.net",
      "microsoft.com"
    ])
  ];

  global.BYEBYEFISHING_RULESET_VERSION = RULESET_VERSION;
  global.BYEBYEFISHING_DEFAULT_RULES = rules;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = rules;
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
