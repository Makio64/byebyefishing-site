(function exposeDetector(global) {
  "use strict";

  const EMAIL_RE = /[A-Z0-9._%+-]+@([\p{L}\p{N}.-]+\.[\p{L}\p{N}-]{2,63})/iu;
  const EMAIL_GLOBAL_RE = /[A-Z0-9._%+-]+@[\p{L}\p{N}.-]+\.[\p{L}\p{N}-]{2,63}/giu;
  const ANGLE_EMAIL_RE = /<\s*([^<>@\s]+@[^<>@\s]+)\s*>/i;
  const TOKEN_SPLIT_RE = /[^\p{L}\p{N}]+/gu;
  const HIGH_RISK_TLDS = new Set([
    "beauty",
    "bond",
    "cam",
    "click",
    "club",
    "country",
    "cyou",
    "gq",
    "icu",
    "info",
    "kim",
    "loan",
    "lol",
    "mom",
    "mov",
    "party",
    "quest",
    "rest",
    "review",
    "run",
    "sbs",
    "services",
    "shop",
    "site",
    "skin",
    "space",
    "support",
    "tk",
    "top",
    "trade",
    "vip",
    "wang",
    "win",
    "work",
    "world",
    "xyz",
    "zip",
    "zone"
  ]);
  const STANDARD_TLDS = new Set([
    "com",
    "org",
    "net",
    "edu",
    "gov",
    "mil",
    "int",
    "fr",
    "eu",
    "be",
    "ch",
    "ca",
    "us",
    "uk",
    "de",
    "es",
    "it",
    "nl",
    "se",
    "no",
    "dk",
    "fi",
    "ie",
    "pt",
    "at",
    "lu",
    "pl",
    "cz",
    "sk",
    "si",
    "hr",
    "hu",
    "ro",
    "bg",
    "gr",
    "ee",
    "lv",
    "lt",
    "is",
    "au",
    "nz",
    "jp",
    "kr",
    "sg",
    "hk",
    "tw",
    "in",
    "br",
    "mx",
    "ar",
    "cl",
    "za",
    "ma",
    "tn",
    "il",
    "ae"
  ]);
  const COMMON_TECH_TLDS = new Set(["io", "dev", "app", "ai", "co"]);
  // Curated subset of the Public Suffix List: multi-label suffixes (ccTLD second-levels)
  // common enough to matter for brand/lookalike logic. NOT the full PSL (~14k entries) —
  // missing one only degrades the message wording for a legit brand domain, never the safety.
  const MULTI_LABEL_PUBLIC_SUFFIXES = new Set([
    "co.uk", "org.uk", "gov.uk", "ac.uk", "me.uk", "net.uk", "ltd.uk", "plc.uk", "nhs.uk", "sch.uk",
    "com.au", "net.au", "org.au", "gov.au", "edu.au", "asn.au", "id.au",
    "co.jp", "or.jp", "ne.jp", "go.jp", "ac.jp", "ad.jp", "ed.jp", "gr.jp", "lg.jp",
    "co.nz", "org.nz", "net.nz", "govt.nz", "ac.nz", "school.nz",
    "co.in", "net.in", "org.in", "gen.in", "firm.in", "ind.in", "gov.in", "ac.in", "edu.in",
    "co.za", "org.za", "net.za", "gov.za", "ac.za", "web.za",
    "com.br", "net.br", "org.br", "gov.br", "edu.br",
    "com.mx", "org.mx", "gob.mx", "com.ar", "net.ar", "org.ar", "gob.ar", "com.co", "com.pe", "com.uy", "com.ve",
    "com.tr", "net.tr", "org.tr", "gov.tr", "edu.tr",
    "com.sg", "edu.sg", "gov.sg", "net.sg", "org.sg",
    "com.hk", "edu.hk", "gov.hk", "net.hk", "org.hk", "idv.hk",
    "com.tw", "net.tw", "org.tw", "gov.tw", "edu.tw",
    "com.my", "net.my", "org.my", "gov.my", "edu.my",
    "com.ph", "net.ph", "org.ph", "gov.ph",
    "com.vn", "net.vn", "org.vn", "gov.vn", "edu.vn",
    "co.th", "in.th", "or.th", "go.th", "ac.th",
    "co.id", "or.id", "web.id", "go.id", "ac.id", "net.id",
    "co.kr", "or.kr", "ne.kr", "re.kr", "go.kr", "ac.kr", "pe.kr",
    "co.il", "org.il", "net.il", "ac.il", "gov.il",
    "com.sa", "net.sa", "org.sa", "gov.sa", "edu.sa",
    "co.ae", "net.ae", "org.ae", "gov.ae", "ac.ae", "sch.ae",
    "com.ua", "net.ua", "org.ua", "in.ua",
    "com.ru", "net.ru", "org.ru", "msk.ru", "spb.ru",
    "com.cn", "net.cn", "org.cn", "gov.cn", "edu.cn", "ac.cn",
    "co.at", "or.at", "com.pl", "net.pl", "org.pl", "gov.pl", "com.es", "org.es", "edu.es", "gob.es",
    "com.kw", "com.qa", "net.qa", "org.qa", "com.eg", "com.ng", "com.gh", "co.ke", "co.tz", "com.bd", "com.pk", "co.cr"
  ]);
  // Many country-code registries use the same conventional second-level
  // namespaces. Treat an otherwise-unlisted `co.xx`, `com.xx`, etc. as a
  // public suffix so sibling registrants are not mistaken for one site.
  const COMMON_CCTLD_SECOND_LEVEL_LABELS = new Set([
    "ac",
    "co",
    "com",
    "edu",
    "firm",
    "gen",
    "go",
    "gob",
    "gov",
    "ind",
    "mil",
    "ne",
    "net",
    "nom",
    "or",
    "org",
    "sch"
  ]);
  const FREE_MAIL_DOMAINS = new Set([
    "gmail.com",
    "googlemail.com",
    "outlook.com",
    "hotmail.com",
    "hotmail.fr",
    "live.com",
    "live.fr",
    "msn.com",
    "outlook.fr",
    "yahoo.com",
    "yahoo.fr",
    "yahoo.co.uk",
    "yahoo.de",
    "yahoo.es",
    "yahoo.it",
    "ymail.com",
    "rocketmail.com",
    "aol.com",
    "icloud.com",
    "me.com",
    "proton.me",
    "protonmail.com",
    "pm.me",
    "gmx.com",
    "gmx.fr",
    "gmx.net",
    "gmx.de",
    "gmx.at",
    "gmx.ch",
    "web.de",
    "t-online.de",
    "freenet.de",
    "mail.com",
    "europe.com",
    "mailo.com",
    "mailo.fr",
    "mailo.eu",
    "netcourrier.com",
    "tuta.com",
    "tutanota.com",
    "tutanota.de",
    "tutamail.com",
    "fastmail.com",
    "fastmail.fm",
    "mailbox.org",
    "posteo.de",
    "yandex.com",
    "yandex.ru",
    "zoho.com",
    "zoho.eu",
    "zohomail.com",
    "zohomail.eu",
    "seznam.cz",
    "wp.pl",
    "o2.pl",
    "onet.pl",
    "interia.pl",
    "libero.it",
    "virgilio.it",
    "laposte.net",
    "orange.fr",
    "wanadoo.fr",
    "bbox.fr",
    "free.fr",
    "neuf.fr",
    "sfr.fr"
  ]);
  const URL_SHORTENER_DOMAINS = new Set([
    "bit.ly",
    "tinyurl.com",
    "t.co",
    "goo.gl",
    "ow.ly",
    "buff.ly",
    "rebrand.ly",
    "cutt.ly",
    "shorturl.at",
    "tiny.cc",
    "is.gd",
    "s.id",
    "lnkd.in",
    "amzn.to",
    "fb.me",
    "bitly.com",
    "rb.gy",
    "1drv.ms",
    "t.ly",
    "v.gd",
    "bit.do",
    "qrco.de",
    "surl.li"
  ]);
  const PUBLIC_HOSTING_DOMAINS = [
    // These domains are operated by known vendors, but their URLs can contain
    // customer redirects, uploaded campaign assets, or customer API tenants.
    // Treating the vendor name as proof of identity creates noisy brand
    // warnings; the link still gets a quiet shared-infrastructure notice.
    {
      name: "SendGrid email infrastructure",
      domains: ["sendgrid.net"],
      passiveInfrastructure: true
    },
    {
      name: "HubSpot customer CDN",
      domains: ["hubspot.net"],
      passiveInfrastructure: true
    },
    {
      name: "Braze campaign media",
      domains: ["braze-images.com"],
      passiveInfrastructure: true
    },
    {
      name: "Pipedrive email redirect",
      domains: ["pipedrive.email"],
      pathPattern: /^\/c(?:\/|$)/i,
      passiveInfrastructure: true
    },
    {
      name: "Azure API Management",
      domains: ["azure-api.net"],
      passiveInfrastructure: true
    },
    {
      name: "Google Analytics",
      domains: ["google-analytics.com"],
      passiveInfrastructure: true
    },
    {
      name: "Amazon media CDN",
      domains: ["media-amazon.com"],
      passiveInfrastructure: true
    },
    {
      name: "SHEIN static media",
      domains: ["ltwebstatic.com"],
      passiveInfrastructure: true
    },
    {
      name: "Amazon CloudFront",
      domains: ["cloudfront.net"],
      passiveInfrastructure: true
    },
    {
      name: "Google Cloud Storage",
      domains: ["storage.googleapis.com", "storage.cloud.google.com", "googleusercontent.com"]
    },
    {
      name: "Amazon S3",
      domains: ["s3.amazonaws.com", "amazonaws.com"]
    },
    {
      name: "Microsoft Azure Blob Storage",
      domains: ["blob.core.windows.net", "web.core.windows.net"]
    },
    {
      name: "Cloudflare Pages",
      domains: ["pages.dev"]
    },
    {
      name: "Firebase Hosting",
      domains: ["firebaseapp.com", "web.app"]
    },
    {
      name: "GitHub Pages",
      domains: ["github.io"]
    },
    {
      name: "Netlify",
      domains: ["netlify.app"]
    },
    {
      name: "Pantheon",
      domains: ["pantheonsite.io"]
    },
    {
      name: "Vercel",
      domains: ["vercel.app"]
    },
    {
      name: "Railway",
      domains: ["up.railway.app"],
      subdomainsOnly: true
    },
    {
      name: "Google Sites",
      domains: ["sites.google.com"],
      pathPattern: /^\/(?:a|site|view)(?:\/|$)/i
    },
    {
      name: "Google Forms",
      domains: ["docs.google.com"],
      pathPattern: /^\/forms(?:\/|$)/i
    },
    {
      name: "Google Forms",
      domains: ["forms.gle"]
    },
    {
      name: "Microsoft Forms",
      domains: ["forms.office.com", "forms.microsoft.com"]
    },
    {
      name: "Microsoft SharePoint",
      domains: ["sharepoint.com"],
      subdomainsOnly: true,
      trustedDomains: ["www.sharepoint.com"]
    },
    {
      name: "Salesforce",
      domains: ["my.salesforce.com", "my.site.com", "salesforce-sites.com"],
      subdomainsOnly: true
    },
    {
      name: "Atlassian Statuspage",
      domains: ["statuspage.io"],
      subdomainsOnly: true,
      trustedDomains: ["www.statuspage.io", "manage.statuspage.io"]
    },
    {
      name: "Zendesk",
      domains: ["zendesk.com"],
      subdomainsOnly: true,
      trustedDomains: [
        "www.zendesk.com",
        "support.zendesk.com",
        "developer.zendesk.com",
        "login.zendesk.com"
      ]
    },
    {
      name: "Oracle Cloud / Taleo",
      domains: ["taleo.net", "oraclecloud.com"],
      subdomainsOnly: true,
      trustedDomains: ["www.taleo.net", "www.oraclecloud.com"]
    },
    {
      name: "Substack",
      domains: ["substack.com"],
      subdomainsOnly: true,
      trustedDomains: ["www.substack.com", "support.substack.com"]
    },
    {
      name: "Splash",
      domains: ["splashthat.com"],
      subdomainsOnly: true,
      trustedDomains: ["www.splashthat.com", "help.splashthat.com"]
    },
    {
      name: "Help Scout Docs",
      domains: ["helpscoutdocs.com"],
      subdomainsOnly: true,
      trustedDomains: ["www.helpscoutdocs.com"]
    },
    {
      name: "Freshdesk",
      domains: ["freshdesk.com"],
      subdomainsOnly: true,
      trustedDomains: [
        "www.freshdesk.com",
        "support.freshdesk.com",
        "developers.freshdesk.com",
        "login.freshdesk.com"
      ]
    },
    {
      name: "MoodleCloud",
      domains: ["moodlecloud.com"],
      subdomainsOnly: true,
      trustedDomains: ["www.moodlecloud.com", "support.moodlecloud.com"]
    },
    {
      name: "Free Personal Pages",
      domains: ["pages-perso.free.fr"],
      subdomainsOnly: true
    }
  ];
  const PIPEDRIVE_OPEN_TRACKING_PROVIDER = Object.freeze({
    name: "Pipedrive email open tracker",
    domains: ["pipedrive.email"],
    passiveInfrastructure: true
  });
  const CABIFY_LEGACY_SIGNATURE_ASSET_PATHS = new Set([
    "/assets.cabify.com/web_content/blog/pe/Email+Signature+-+Facebook",
    "/assets.cabify.com/web_content/blog/pe/Email+Signature+-+Instagram",
    "/assets.cabify.com/web_content/blog/pe/Email+Signature+-+Twitter"
  ]);
  const SUSPICIOUS_TERMS = [
    "account",
    "alerte",
    "auth",
    "billing",
    "blocked",
    "carte",
    "claim",
    "colis",
    "confirm",
    "delivery",
    "facture",
    "finance",
    "gift",
    "grant",
    "impots",
    "invoice",
    "livraison",
    "login",
    "password",
    "pay",
    "payment",
    "refund",
    "remboursement",
    "reset",
    "secure",
    "security",
    "signin",
    "support",
    "tax",
    "tracking",
    "unlock",
    "update",
    "validation",
    "verify",
    "wallet"
  ];
  const FAST_SENSITIVE_LINK_RE =
    /(?:^|[^a-z0-9])(?:account|alerte|auth|billing|blocked|claim|confirm|credential|delivery|facture|finance|gift|grant|invoice|login|password|pay|payment|recover|refund|reset|secure|security|signin|support|suspend|tax|tracking|unlock|update|validation|verify|wallet)(?:[^a-z0-9]|$)/i;
  const FAST_SUSPICIOUS_DOMAIN_RE =
    /(?:^|[.\s_-])(?:account|auth|billing|claim|confirm|delivery|finance|invoice|login|password|pay|payment|refund|reset|secure|security|signin|support|tracking|unlock|update|validation|verify|wallet)(?:[.\s_-]|$)/i;
  // Some campaign domains put a familiar-looking public suffix to the left of
  // the real registrable domain: bofa.com-onlinebanking.com is controlled under
  // com-onlinebanking.com, not bofa.com. Keep this list finite and action-focused
  // so ordinary hyphenated product names do not become warnings.
  const PSEUDO_TLD_SENSITIVE_LABEL_RE =
    /^(com|net|org|co|edu|gov|io|app)-(online-?banking|banking|login|sign-?in|auth(?:entication)?|token-auth|account|secure|security|verify|verification|portal)$/i;
  const PROTECTED_WORKFLOW_ROOT_LABEL_RE = /^(?:protected|secure)-(?:forms?|portal)$/i;
  const WORKFLOW_SUBDOMAIN_LABEL_RE =
    /^(?:web-?conference|video-?conference|meeting|document-?share)$/i;
  const TRANSFER_SUBDOMAIN_LABEL_RE = /^(?:files?|documents?)-transfers?$/i;
  // Shared-content services naturally use paths such as /support/solutions or
  // /tracking. Those words merit context, but are not sensitive actions by
  // themselves. Keep the high-severity tier for credential, payment, account,
  // or impersonation signals.
  const SHARED_CONTENT_SENSITIVE_TERMS = SUSPICIOUS_TERMS.filter(
    (term) => !["colis", "delivery", "facture", "invoice", "livraison", "support", "tracking"].includes(term)
  );
  const SHARED_CONTENT_GENERIC_IDENTITY_LABELS = new Set([
    "acme",
    "article",
    "careersection",
    "course",
    "customer",
    "demo",
    "docs",
    "event",
    "form",
    "forms",
    "help",
    "home",
    "jobs",
    "page",
    "portal",
    "post",
    "school",
    "site",
    "support",
    "survey",
    "team",
    "view",
    "welcome",
    "writer"
  ]);
  const DELIVERY_PRESSURE_TERMS = [
    "confirmation required",
    "package awaiting",
    "delivery suspended",
    "held at customs",
    "paquete pendiente",
    "paquete esperando ser entregado",
    "paquete retenido",
    "entrega detenida",
    "entrega suspendida",
    "envio esta en espera",
    "envio en espera",
    "no ha podido ser entregado",
    "liberar tu envio",
    "liberar su envio",
    "liberar tu paquete",
    "liberar su paquete",
    "programar entrega ahora"
  ];
  const DELIVERY_TERMS = [
    "access point",
    "centre logistique",
    "colis",
    "confirmation de livraison",
    "confirmation requise",
    "confirmer ma livraison",
    "confirmer vos informations",
    "creneau de livraison",
    "customs",
    "delivery confirmation",
    "delivery slot",
    "douane",
    "en attente",
    "expediteur",
    "informations de livraison",
    "livraison",
    "logistique",
    "package awaiting",
    "parcel",
    "retard",
    "shipment",
    "suivi",
    "tracking",
    ...DELIVERY_PRESSURE_TERMS
  ];
  const DISPLAYED_DOMAIN_RE = /(?:https?:\/\/)?(?:www\.)?([a-z0-9][a-z0-9.-]*\.[a-z]{2,63})/i;
  // Suffixes that look like a TLD to DISPLAYED_DOMAIN_RE but are really file extensions
  // or library names ("Vue.js", "Node.js", "Three.js", …) appearing in email text.
  const NON_NAVIGATIONAL_TLDS = new Set([
    "csv",
    "doc",
    "docm",
    "docx",
    "eml",
    "ics",
    "jpeg",
    "js",
    "mjs",
    "cjs",
    "ts",
    "tsx",
    "jsx",
    "mts",
    "cts",
    "json",
    "msg",
    "md",
    "odf",
    "odp",
    "ods",
    "odt",
    "pdf",
    "png",
    "ppt",
    "pptm",
    "pptx",
    "rtf",
    "yml",
    "yaml",
    "txt",
    "css",
    "html",
    "xml",
    "sh",
    "svg",
    "xls",
    "xlsm",
    "xlsx",
    "zip"
  ]);
  const REDIRECT_PARAMS = [
    "url",
    "u",
    "q",
    "target",
    "to",
    "redirect",
    "redirect_url",
    "redirecturl",
    "continue",
    "next",
    "dest",
    "destination",
    "return",
    "returnurl",
    "rurl",
    "goto"
  ];
  const KNOWN_REDIRECT_HOSTS = new Set([
    "www.google.com",
    "google.com",
    "l.facebook.com",
    "lm.facebook.com",
    "m.facebook.com",
    "www.linkedin.com",
    "linkedin.com",
    "safelinks.protection.outlook.com",
    "nam12.safelinks.protection.outlook.com",
    "eur01.safelinks.protection.outlook.com"
  ]);
  const LOCALIZED_GOOGLE_REDIRECT_HOSTS = new Set(
    [
      "google.fr",
      "google.co.uk",
      "google.de",
      "google.es",
      "google.it",
      "google.nl",
      "google.be",
      "google.ca",
      "google.com.br",
      "google.co.jp",
      "google.com.au",
      "google.ie",
      "google.pt",
      "google.ch",
      "google.at",
      "google.pl"
    ].flatMap((hostname) => [hostname, `www.${hostname}`])
  );
  const GENERIC_IDENTITY_TERMS = [
    "admin",
    "assistance",
    "billing",
    "customer service",
    "helpdesk",
    "invoice",
    "payment",
    "security",
    "service client",
    "support",
    "team",
    "verification",
    "finance",
    "grant"
  ];
  const CONTENT_SIGNAL_GROUPS = [
    {
      id: "credentials",
      weight: 4,
      label: "credential or security-code request",
      phrases: [
        "confirm your password",
        "confirmer votre mot de passe",
        "bestatigen sie ihr passwort",
        "conferma la password",
        "confirme su contrasena",
        "confirme sua senha",
        "verify your account",
        "verifier votre compte",
        "verifizieren sie ihr konto",
        "verifica il tuo account",
        "verifique su cuenta",
        "nombre de usuario y contrasena",
        "credenciales de inicio de sesion",
        "verifique sua conta",
        "validate your account",
        "valider votre compte",
        "update your payment information",
        "mettre a jour vos informations",
        "confirm your identity",
        "confirmer votre identite",
        "enter your security code",
        "saisissez votre code",
        "code de securite",
        "sicherheitscode",
        "codice di sicurezza",
        "codigo de seguridad",
        "codigo de seguranca",
        "подтвердите пароль",
        "подтвердите учетную запись",
        "код безопасности",
        "パスワードを確認",
        "アカウントを確認",
        "セキュリティコード",
        "確認コード",
        "确认您的密码",
        "验证您的账户",
        "安全码",
        "输入验证码",
        "अपना पासवर्ड पुष्टि करें",
        "अपना खाता सत्यापित करें",
        "सुरक्षा कोड",
        "أكد كلمة المرور",
        "تحقق من حسابك",
        "رمز الأمان",
        "আপনার পাসওয়ার্ড নিশ্চিত করুন",
        "আপনার অ্যাকাউন্ট যাচাই করুন",
        "নিরাপত্তা কোড",
        "اپنا پاس ورڈ تصدیق کریں",
        "اپنا اکاؤنٹ تصدیق کریں",
        "سیکیورٹی کوڈ",
        "one time code",
        "otp",
        "password",
        "passcode",
        "verification code",
        "security code",
        "login credentials",
        "connection code",
        "2fa code",
        "seed phrase",
        "backup phrase",
        "wallet recovery words",
        "recovery phrase",
        "private key",
        "api key",
        "access token"
      ]
    },
    {
      id: "personal-info",
      weight: 3,
      label: "personal information request",
      phrases: [
        "send your information",
        "send your details",
        "full name",
        "first and last name",
        "phone number",
        "telephone number",
        "home address",
        "current address",
        "birth date",
        "passport",
        "national id",
        "government id",
        "bank details",
        "account details",
        "personal information",
        "bank account number",
        "mothers maiden name",
        "mother s maiden name",
        "full card number",
        "expiry date",
        "cvv",
        "occupation",
        "reference number",
        "date of birth",
        "envoyez vos informations",
        "nom et prenom",
        "numero de telephone",
        "adresse personnelle",
        "adresse postale",
        "adresse complete",
        "adresse de domicile",
        "envoyer vos informations",
        "senden sie ihre informationen",
        "ihre informationen",
        "vor und nachname",
        "telefonnummer",
        "postadresse",
        "anschrift",
        "beruf",
        "referenznummer",
        "invia le tue informazioni",
        "nome e cognome",
        "numero di telefono",
        "professione",
        "numero di riferimento",
        "envie su informacion",
        "confirma tus datos",
        "confirme sus datos",
        "nombre y apellido",
        "numero de telefono",
        "ocupacion",
        "numero de referencia",
        "envie suas informacoes",
        "nome completo",
        "numero de telefone",
        "profissao",
        "numero de referencia",
        "отправьте ваши данные",
        "имя и фамилия",
        "номер телефона",
        "адрес",
        "профессия",
        "регистрационный номер",
        "情報を送信",
        "氏名",
        "電話番号",
        "住所",
        "職業",
        "参照番号",
        "发送您的信息",
        "姓名",
        "电话号码",
        "地址",
        "职业",
        "参考编号",
        "अपनी जानकारी भेजें",
        "पूरा नाम",
        "फोन नंबर",
        "पता",
        "पेशा",
        "संदर्भ संख्या",
        "أرسل معلوماتك",
        "الاسم الكامل",
        "رقم الهاتف",
        "العنوان",
        "المهنة",
        "رقم المرجع",
        "আপনার তথ্য পাঠান",
        "পূর্ণ নাম",
        "ফোন নম্বর",
        "ঠিকানা",
        "পেশা",
        "রেফারেন্স নম্বর",
        "اپنی معلومات بھیجیں",
        "پورا نام",
        "فون نمبر",
        "پتہ",
        "پیشہ",
        "حوالہ نمبر"
      ]
    },
    {
      id: "urgency",
      weight: 3,
      label: "urgent action pressure",
      phrases: [
        "urgent",
        "immediate action required",
        "action required",
        "act now",
        "within 24 hours",
        "within 48 hours",
        "last chance",
        "final notice",
        "dernier rappel",
        "derniere relance",
        "action requise",
        "sous 24h",
        "sous 48h",
        "immediatement",
        "aujourd hui",
        "sans delai",
        "dringend",
        "aktion erforderlich",
        "innerhalb von 24 stunden",
        "letzte mahnung",
        "urgente",
        "azione richiesta",
        "entro 24 ore",
        "ultimo avviso",
        "accion requerida",
        "accion necesaria",
        "accion obligatoria",
        "actua ahora",
        "actue ahora",
        "ultima oportunidad",
        "dentro de 48 horas",
        "proximas 48 horas",
        "antes de la medianoche",
        "en los proximos 3 minutos",
        "en 24 horas",
        "ultimo aviso",
        "acao necessaria",
        "em 24 horas",
        "срочно",
        "требуется действие",
        "в течение 24 часов",
        "последнее уведомление",
        "緊急",
        "至急",
        "24時間以内",
        "最終通知",
        "紧急",
        "立即行动",
        "24小时内",
        "最后通知",
        "तुरंत",
        "कार्रवाई आवश्यक",
        "24 घंटे के भीतर",
        "अंतिम सूचना",
        "عاجل",
        "إجراء مطلوب",
        "خلال 24 ساعة",
        "الإشعار الأخير",
        "জরুরি",
        "পদক্ষেপ প্রয়োজন",
        "২৪ ঘন্টার মধ্যে",
        "শেষ বিজ্ঞপ্তি",
        "فوری",
        "کارروائی ضروری",
        "24 گھنٹوں کے اندر",
        "آخری نوٹس"
      ]
    },
    {
      id: "payment",
      weight: 3,
      label: "payment or money demand",
      phrases: [
        "pay now",
        "payment required",
        "payment failed",
        "unpaid invoice",
        "outstanding invoice",
        "wire transfer",
        "pay this invoice",
        "release fee",
        "processing fee",
        "settlement payment",
        "bank transfer",
        "gift card",
        "apple gift card",
        "amazon gift card",
        "steam card",
        "change of bank details",
        "new bank details",
        "payer maintenant",
        "paiement requis",
        "paiement refuse",
        "facture impayee",
        "regulariser",
        "virement bancaire",
        "nouvelles coordonnees bancaires",
        "rib",
        "iban",
        "carte bancaire",
        "frais de livraison",
        "taxes douanieres",
        "amende",
        "peage",
        "stationnement",
        "douane",
        "crypto",
        "bitcoin",
        "usdt",
        "remboursement",
        "jetzt bezahlen",
        "zahlung erforderlich",
        "zahlung abgelehnt",
        "bankuberweisung",
        "geschenkkarte",
        "paga ora",
        "pagamento richiesto",
        "pagamento rifiutato",
        "bonifico bancario",
        "carta regalo",
        "pagar ahora",
        "pago requerido",
        "pago rechazado",
        "metodo de pago rechazado",
        "metodo de pago ha sido rechazado",
        "actualiza tu metodo de pago",
        "actualice su metodo de pago",
        "actualiza tu informacion de pago",
        "actualice su informacion de pago",
        "monto pendiente",
        "derechos de aduana",
        "aranceles aduanales",
        "falta de pago",
        "tarifa de envio",
        "completar el pago",
        "realizar el pago",
        "transferencia bancaria",
        "tarjeta regalo",
        "pague agora",
        "pagamento necessario",
        "pagamento recusado",
        "transferencia bancaria",
        "cartao presente",
        "оплатите сейчас",
        "требуется оплата",
        "платеж отклонен",
        "банковский перевод",
        "подарочная карта",
        "今すぐ支払",
        "支払いが必要",
        "支払いに失敗",
        "銀行振込",
        "ギフトカード",
        "立即付款",
        "需要付款",
        "付款失败",
        "银行转账",
        "礼品卡",
        "अभी भुगतान करें",
        "भुगतान आवश्यक",
        "भुगतान विफल",
        "बैंक हस्तांतरण",
        "गिफ्ट कार्ड",
        "ادفع الآن",
        "الدفع مطلوب",
        "فشل الدفع",
        "تحويل مصرفي",
        "بطاقة هدايا",
        "এখনই পেমেন্ট করুন",
        "পেমেন্ট প্রয়োজন",
        "পেমেন্ট ব্যর্থ",
        "ব্যাংক ট্রান্সফার",
        "গিফট কার্ড",
        "ابھی ادائیگی کریں",
        "ادائیگی ضروری",
        "ادائیگی ناکام",
        "بینک ٹرانسفر",
        "گفٹ کارڈ"
      ]
    },
    {
      id: "threat",
      weight: 3,
      label: "account threat",
      phrases: [
        "account suspended",
        "account locked",
        "account blocked",
        "will be blocked",
        "avoid suspension",
        "prevent suspension",
        "permanently suspended",
        "your access will be disabled",
        "service interruption",
        "legal action",
        "escalated to court",
        "late penalty",
        "compte suspendu",
        "compte bloque",
        "acces bloque",
        "carte bloquee",
        "service suspendu",
        "penalite",
        "poursuites",
        "mise en demeure",
        "konto gesperrt",
        "zugang wird deaktiviert",
        "account sospeso",
        "account bloccato",
        "accesso disabilitato",
        "cuenta suspendida",
        "cuenta bloqueada",
        "bloqueado tu cuenta",
        "bloqueado su cuenta",
        "cuenta sera suspendida",
        "cuenta ha sido desactivada",
        "desactivacion de su cuenta",
        "desactivacion de tu cuenta",
        "desactivacion de su correo",
        "eliminacion de su cuenta",
        "eliminacion de tu cuenta",
        "perdida de todos sus datos",
        "fotos y videos seran eliminados",
        "perderas el acceso",
        "acceso deshabilitado",
        "conta suspensa",
        "conta bloqueada",
        "acesso desativado",
        "учетная запись заблокирована",
        "аккаунт заблокирован",
        "доступ будет отключен",
        "アカウントが停止",
        "アカウントがロック",
        "アクセスが無効",
        "账户已暂停",
        "账户被锁定",
        "访问将被禁用",
        "खाता निलंबित",
        "खाता बंद",
        "आपकी पहुंच बंद",
        "تم تعليق الحساب",
        "تم قفل الحساب",
        "سيتم تعطيل الوصول",
        "অ্যাকাউন্ট স্থগিত",
        "অ্যাকাউন্ট লক",
        "অ্যাক্সেস বন্ধ",
        "اکاؤنٹ معطل",
        "اکاؤنٹ بند",
        "رسائی بند"
      ]
    },
    {
      id: "link-pressure",
      weight: 2,
      label: "click-through pressure",
      phrases: [
        "click here",
        "click the link",
        "open the attachment",
        "download the document",
        "scan the qr code",
        "call this number",
        "call technical support",
        "give the agent remote access",
        "enable macros",
        "enable editing",
        "install the remote support tool",
        "open the attached html file",
        "sign in to listen",
        "share the connection code",
        "contact support immediately",
        "cliquez ici",
        "cliquez sur le lien",
        "ouvrez la piece jointe",
        "telechargez le document",
        "scannez le qr code",
        "appelez ce numero",
        "contactez le support",
        "confirmez maintenant",
        "confirmer ma livraison",
        "je confirme mes informations",
        "suivez ce lien",
        "connectez vous",
        "klicken sie hier",
        "klicken sie auf den link",
        "laden sie das dokument herunter",
        "rufen sie diese nummer an",
        "clicca qui",
        "clicca sul link",
        "scarica il documento",
        "chiama questo numero",
        "haga clic aqui",
        "haga clic en el enlace",
        "descargue el documento",
        "llame a este numero",
        "clique aqui",
        "clique no link",
        "baixe o documento",
        "ligue para este numero",
        "нажмите здесь",
        "перейдите по ссылке",
        "скачайте документ",
        "позвоните по этому номеру",
        "ここをクリック",
        "リンクをクリック",
        "書類をダウンロード",
        "この番号に電話",
        "点击这里",
        "点击链接",
        "下载文件",
        "拨打此号码",
        "यहां क्लिक करें",
        "लिंक पर क्लिक करें",
        "दस्तावेज डाउनलोड करें",
        "इस नंबर पर कॉल करें",
        "اضغط هنا",
        "انقر على الرابط",
        "قم بتنزيل المستند",
        "اتصل بهذا الرقم",
        "এখানে ক্লিক করুন",
        "লিঙ্কে ক্লিক করুন",
        "ডকুমেন্ট ডাউনলোড করুন",
        "এই নম্বরে কল করুন",
        "یہاں کلک کریں",
        "لنک پر کلک کریں",
        "دستاویز ڈاؤن لوڈ کریں",
        "اس نمبر پر کال کریں"
      ]
    },
    {
      id: "delivery",
      weight: 3,
      label: "delivery or parcel pressure",
      phrases: DELIVERY_TERMS
    },
    {
      id: "reward",
      weight: 2,
      label: "unexpected reward",
      phrases: [
        "you have won",
        "you won",
        "claim your prize",
        "claim the reward",
        "lottery prize",
        "inheritance",
        "donation beneficiary",
        "unexpected tax refund",
        "gift card",
        "free reward",
        "received a grant",
        "grant of",
        "grant",
        "vous avez gagne",
        "reclamez votre prix",
        "carte cadeau",
        "cadeau gratuit",
        "loterie",
        "subvention",
        "vous avez recu une subvention",
        "sie haben gewonnen",
        "erhalten haben",
        "zuschuss",
        "gewinn",
        "preis beanspruchen",
        "hai vinto",
        "richiedi il premio",
        "sovvenzione",
        "contributo",
        "hai ricevuto una sovvenzione",
        "ha ganado",
        "has ganado",
        "has sido seleccionado",
        "ha sido seleccionado",
        "reclama tu regalo",
        "reclama tu premio",
        "afortunado ganador",
        "ganador de hoy",
        "premio mayor",
        "reclame su premio",
        "subvencion",
        "recibido una subvencion",
        "voce ganhou",
        "resgate seu premio",
        "subsidio",
        "recebeu uma bolsa",
        "вы выиграли",
        "получили грант",
        "грант",
        "получить приз",
        "当選しました",
        "賞金",
        "助成金",
        "給付金",
        "助成金を受け取り",
        "您已中奖",
        "领取奖金",
        "补助金",
        "获得补助金",
        "आप जीत गए",
        "इनाम प्राप्त करें",
        "अनुदान",
        "आपको अनुदान मिला",
        "لقد فزت",
        "اطلب جائزتك",
        "منحة",
        "تلقيت منحة",
        "আপনি জিতেছেন",
        "পুরস্কার দাবি করুন",
        "অনুদান",
        "আপনি অনুদান পেয়েছেন",
        "آپ جیت گئے",
        "انعام حاصل کریں",
        "گرانٹ",
        "آپ کو گرانٹ ملی"
      ]
    },
    {
      id: "attachment",
      weight: 3,
      label: "suspicious attachment pressure",
      phrases: [
        "password protected zip",
        "encrypted attachment",
        "open the invoice attached",
        "see attached invoice",
        "attached invoice",
        "piece jointe chiffree",
        "archive zip protegee",
        "ouvrez la facture jointe",
        "facture en piece jointe"
      ]
    },
    {
      id: "data-loss",
      weight: 3,
      label: "data or document deletion threat",
      phrases: [
        "document will be deleted",
        "deleted from the server",
        "documento sera eliminado",
        "sera eliminado del servidor",
        "no lo abre en 24 horas"
      ]
    },
    {
      id: "impersonation",
      weight: 3,
      label: "authority or support impersonation",
      phrases: [
        "technical support",
        "fraud department",
        "security department",
        "tax office",
        "customs office",
        "service fraude",
        "service securite",
        "service des impots",
        "service douane",
        "support technique",
        "adresse e mail officielle",
        "initiative fmi ue",
        "imf",
        "imf eu initiative",
        "joint imf eu initiative",
        "iwf",
        "eu initiative",
        "iwf eu initiative",
        "internationaler wahrungsfonds",
        "official email address",
        "offizielle e mail adresse",
        "supporto tecnico",
        "dipartimento frodi",
        "ufficio delle imposte",
        "indirizzo email ufficiale",
        "iniziativa fmi ue",
        "soporte tecnico",
        "departamento de fraude",
        "oficina de impuestos",
        "direccion de correo oficial",
        "iniciativa fmi ue",
        "suporte tecnico",
        "departamento de fraude",
        "secretaria da receita",
        "endereco de email oficial",
        "iniciativa fmi ue",
        "техническая поддержка",
        "отдел мошенничества",
        "налоговая служба",
        "официальный адрес электронной почты",
        "инициатива мвф ес",
        "テクニカルサポート",
        "詐欺対策部門",
        "税務署",
        "公式メールアドレス",
        "技術支持",
        "欺诈部门",
        "税务局",
        "官方电子邮件地址",
        "国际货币基金组织",
        "欧盟倡议",
        "तकनीकी सहायता",
        "धोखाधड़ी विभाग",
        "कर कार्यालय",
        "आधिकारिक ईमेल पता",
        "आईएमएफ ईयू पहल",
        "الدعم الفني",
        "قسم الاحتيال",
        "مكتب الضرائب",
        "البريد الإلكتروني الرسمي",
        "صندوق النقد الدولي",
        "مبادرة الاتحاد الأوروبي",
        "প্রযুক্তিগত সহায়তা",
        "প্রতারণা বিভাগ",
        "কর অফিস",
        "সরকারি ইমেইল ঠিকানা",
        "আইএমএফ ইইউ উদ্যোগ",
        "تکنیکی مدد",
        "فراڈ ڈیپارٹمنٹ",
        "ٹیکس آفس",
        "سرکاری ای میل پتہ",
        "آئی ایم ایف ای یو اقدام"
      ]
    },
    {
      id: "secrecy",
      weight: 2,
      label: "secrecy pressure",
      phrases: [
        "do not tell anyone",
        "confidential request",
        "keep this confidential",
        "do not mention this request",
        "do not contact anyone else",
        "ne dites rien",
        "demande confidentielle",
        "gardez cela confidentiel"
      ]
    }
  ];
  const STRONG_REWARD_CLAIM_TERMS = [
    "has ganado",
    "ha ganado",
    "has sido seleccionado",
    "ha sido seleccionado",
    "reclama tu regalo",
    "reclama tu premio",
    "afortunado ganador",
    "ganador de hoy",
    "premio mayor"
  ];
  const CONTEXTUAL_CREDENTIAL_PHRASES = new Set([
    "one time code",
    "otp",
    "password",
    "passcode",
    "verification code",
    "security code",
    "login credentials",
    "connection code",
    "2fa code",
    "code de securite",
    "sicherheitscode",
    "codice di sicurezza",
    "codigo de seguridad",
    "nombre de usuario y contrasena",
    "credenciales de inicio de sesion",
    "codigo de seguranca",
    "код безопасности",
    "セキュリティコード",
    "確認コード",
    "安全码",
    "सुरक्षा कोड",
    "رمز الأمان",
    "নিরাপত্তা কোড",
    "سیکیورٹی کوڈ",
    "seed phrase",
    "backup phrase",
    "wallet recovery words",
    "recovery phrase",
    "private key",
    "api key",
    "access token"
  ]);
  const CREDENTIAL_DISCLOSURE_TERMS = [
    "send",
    "text",
    "share",
    "provide",
    "enter",
    "paste",
    "submit",
    "reply with",
    "replying with",
    "verify",
    "confirm",
    "email",
    "e mail",
    "give",
    "forward",
    "copy",
    "upload",
    "read aloud",
    "read it aloud",
    "dictate",
    "tell me",
    "envoyez",
    "envoyer",
    "partagez",
    "fournissez",
    "saisissez",
    "entrez",
    "collez",
    "repondez avec",
    "senden",
    "eingeben",
    "teilen",
    "invia",
    "inserisci",
    "condividi",
    "envie",
    "enviemela",
    "enviemelo",
    "ingrese",
    "comparta",
    "confirme",
    "confirmar",
    "verifique",
    "verificar",
    "introduzca",
    "ingresa",
    "insira",
    "отправьте",
    "введите",
    "поделитесь"
  ];
  const CREDENTIAL_FOLLOWUP_DISCLOSURE_TERMS = [
    "send",
    "text",
    "share",
    "provide",
    "paste",
    "reply with",
    "replying with",
    "email",
    "give",
    "forward",
    "upload",
    "read aloud",
    "read it aloud",
    "dictate",
    "tell me",
    "envoyez",
    "envoyer",
    "partagez",
    "fournissez",
    "repondez avec",
    "senden",
    "teilen",
    "invia",
    "condividi",
    "envie",
    "comparta",
    "отправьте",
    "поделитесь"
  ];
  const CREDENTIAL_FOLLOWUP_REFERENCES = [
    "the code",
    "this code",
    "that code",
    "your code",
    "the token",
    "this token",
    "the key",
    "this key",
    "the password",
    "the phrase",
    "it",
    "them"
  ];
  const PAYMENT_ACTION_TERMS = [
    "buy",
    "purchase",
    "send",
    "pay",
    "make the transfer",
    "make a transfer",
    "transfer bitcoin",
    "transfer usdt",
    "transfer crypto",
    "transfer funds",
    "wire funds",
    "achetez",
    "envoyez",
    "payez",
    "effectuez le virement",
    "uberweisen sie",
    "kaufen sie",
    "invia",
    "paga",
    "compre",
    "envie",
    "pague",
    "paguela",
    "paguelo"
  ];
  const BEHAVIOR_MONEY_ACTION_TERMS = [
    ...PAYMENT_ACTION_TERMS.filter((term) => term !== "purchase"),
    "wire",
    "transfer",
    "remit",
    "settle",
    "deposit",
    "approve",
    "cover",
    "move funds",
    "move money",
    "move stablecoins",
    "move bitcoin",
    "move crypto",
    "replace",
    "route",
    "resolve",
    "pick up",
    "acheter",
    "achete",
    "achetez",
    "envoyer",
    "envoie",
    "envoyez",
    "transferer",
    "transferez",
    "verser",
    "versez",
    "regler",
    "reglez",
    "payer",
    "payez",
    "deposer",
    "deposez",
    "approuver",
    "approuvez",
    "remplacer",
    "remplacez",
    "comprar",
    "compre",
    "mandar",
    "manda",
    "mande",
    "transferir",
    "transfiera",
    "liquidar",
    "liquide",
    "pagar",
    "pague",
    "abonar",
    "abone",
    "cubra",
    "mueva",
    "resuelva",
    "resuelvala",
    "depositar",
    "deposite",
    "aprobar",
    "apruebe",
    "sustituir",
    "sustituya",
    "kaufen",
    "kaufe",
    "senden",
    "sende",
    "uberweisen",
    "uberweise",
    "zahlen",
    "zahle",
    "begleichen",
    "einzahlen",
    "einzuzahlen",
    "genehmigen",
    "ersetzen",
    "compra",
    "acquista",
    "trasferisci",
    "deposita",
    "approva",
    "sostituisci"
  ];
  const PAYMENT_RECEIPT_TERMS = [
    "received successfully",
    "was received",
    "purchase is complete",
    "payment complete",
    "payment completed",
    "transfer receipt",
    "for your records",
    "no action required",
    "aucune action requise",
    "paiement recu",
    "virement recu",
    "zahlung erhalten",
    "pagamento ricevuto",
    "pago recibido",
    "recibo de operacion",
    "operacion completada",
    "pago completado",
    "transferencia completada",
    "para sus registros",
    "ninguna accion requerida"
  ];
  const PAYMENT_SAFETY_TERMS = [
    "never buy",
    "do not buy",
    "dont buy",
    "should never",
    "never send",
    "never email",
    "never ask",
    "will never ask",
    "ne jamais acheter",
    "n achetez jamais",
    "ne jamais envoyer",
    "kaufen sie niemals",
    "non comprare mai",
    "nunca compre",
    "nunca envie",
    "no compre",
    "no envie",
    "no refund is due",
    "no payment is due",
    "aucun remboursement",
    "aucun paiement",
    "aucune somme",
    "no hay reembolso",
    "no hay pago",
    "ningun reembolso",
    "ningun pago",
    "keine erstattung",
    "keine zahlung"
  ];
  const HIGH_RISK_PAYMENT_TERMS = [
    "bitcoin",
    "crypto",
    "gift card",
    "usdt",
    "wire transfer"
  ];
  const PERSONAL_INFO_SAFETY_TERMS = [
    "do not reply to this email with any bank details",
    "do not send personal information",
    "do not send an image by email",
    "do not share personal information",
    "never share your personal information",
    "will never ask for your bank details",
    "ne repondez pas avec vos coordonnees bancaires",
    "ne partagez jamais vos informations personnelles"
  ];
  const PERSONAL_INFO_REQUEST_ACTION_TERMS = [
    "reply with",
    "send",
    "provide",
    "submit",
    "upload",
    "share",
    "email",
    "forward",
    "repondez avec",
    "envoyez",
    "fournissez",
    "senden",
    "invia",
    "envie",
    "confirma",
    "confirme",
    "confirmar",
    "отправьте"
  ];
  const HIGH_RISK_PERSONAL_INFO_TERMS = [
    "passport",
    "national id",
    "government id",
    "bank details",
    "account details",
    "bank account number",
    "mothers maiden name",
    "mother s maiden name",
    "full card number",
    "expiry date",
    "cvv",
    "date of birth"
  ];
  const PAYMENT_INFO_CREDENTIAL_PHRASES = new Set([
    "update your payment information"
  ]);
  const BEHAVIOR_PATTERNS = Object.freeze({
    moneyAction: /(?:\b(?:buy|purchase|send|wire|transfer|remit|settle|pay|deposit|approve|cover|move|replace|change|reserve|route|resolve|pick up)\b|achet|envoi|envoy|transfer|verse|regl|pay|depos|approuv|couvr|remplac|resou|compr|mand|transfier|liquid|pag|abon|deposit|aprueb|sustitu|resuel|kauf|send|uberweis|zahl|begleich|einzahl|genehmig|ersetz|los)/u,
    moneyObject: /(?:voucher|gift card|gaming voucher|beneficiary|routing detail|bank detail|bank account|balance|invoice|wallet|stablecoin|digital currency|cryptocurrency|bitcoin|usdt|cheque|\bcheck\b|deposit|fee|charge|card|refund|reimbursement|debit|payment|mobile money|cash|supplier|routing|transfer|wire|inspection amount|redelivery balance|bons? de jeu|coupon|beneficiaire|rib|coordonnees bancaire|solde|facture|portefeuille|monnaie|argent mobile|cheque|depot|frais|debit|carte|remboursement|acompte|montant d inspection|vales?|cupon|beneficiario|datos bancarios|saldo|factura|monedero|moneda|dinero movil|cheque|deposito|tasa|cargo|tarjeta|reembolso|inspeccion|reentrega|gutschein|empfanger|bankverbindung|restbetrag|rechnung|wallet|mobilgeld|einzahlung|gebuhr|prufgebuhr|belastung|karte|erstattung|uberweisung)/u,
    bankChange: /(?:(?:treasury|usual|bank|payment) account(?: [\p{L}\p{N}]+){0,4} \b(?:changed|change|under audit|alternate)\b|switched banks?|replace the beneficiary|revised beneficiary|replacement beneficiary|substitute beneficiary|new routing|alternate subsidiary|bank detail change|compte (?:de tresorerie|bancaire|habituel|de paiement)(?: [\p{L}\p{N}]+){0,4} \b(?:change(?:e|es|s)?|audit)\b|remplace(?: [\p{L}\p{N}]+){0,5} beneficiaire|beneficiaire(?: [\p{L}\p{N}]+){0,5} remplac|filiale alternative|changement bancaire|cuenta (?:de tesoreria|bancaria|habitual|de pago)(?: [\p{L}\p{N}]+){0,4} \b(?:cambi(?:o|ada|ado)?|audit)\b|sustitu(?: [\p{L}\p{N}]+){0,5} beneficiario|beneficiario(?: [\p{L}\p{N}]+){0,5} sustitu|filial alternativa|(?:geschaftskonto|zahlungskonto)(?: [\p{L}\p{N}]+){0,4} \bgeander(?:t|te|ten)?\b|(?:ubliche|bank|zahlungs) konto(?: [\p{L}\p{N}]+){0,4} \b(?:geander(?:t|te|ten)?|gepruft)\b|ersetzen sie(?: [\p{L}\p{N}]+){0,5} empfanger|empfanger(?: [\p{L}\p{N}]+){0,5} ersetz|andere tochtergesellschaft)/u,
    credentialAction: /(?:\b(?:re authenticate|reauthenticate|sign in|sign on|log in|enter|provide|submit|confirm|approve|unlock|connect)\b|use the(?: [\p{L}\p{N}]+){0,5} page|(?:utilisez|ouvrez)(?: [\p{L}\p{N}]+){0,5} (?:page|portail|formulaire)|\b(?:authentifiez|authentifier|reauthentifiez|connectez|entrez|saisissez|confirmez|approuvez|debloquez)\b|(?:usa|use|abra)(?: [\p{L}\p{N}]+){0,5} (?:pagina|portal|formulario)|\b(?:autentique|autentiquese|reautentique|reautentiquese|inicia|inicie|introduzca|introduce|ingresa|ingrese|confirma|confirme|aprueba|apruebe|desbloquea|desbloquee|conecte)\b|offnen sie(?: [\p{L}\p{N}]+){0,5} (?:seite|prufseite|portal|formular)|\b(?:anmelden|melden sie|authentifizieren sie|geben sie|bestatige|bestatigen sie|freischalten sie|schalten sie)\b)/u,
    credentialObject: /(?:password|passcode|security code|verification code|one time code|otp|mfa|authenticator|sign on secret|login secret|session key|session digit|access number|banking access|backup phrase|backup codes?|recovery code|recovery word|recovery phrase|seed phrase|seed words?|private key|token|mot de passe|code de securite|codes? de secours|application d?authentification|secret de connexion|numero d acces|palabra clave|clave habitual|contrasena|codigos? de respaldo|autenticador|clave de sesion|numero de acceso|passwort|authenticator|ersatzcodes?|anmeldegeheimnis|sitzungsschlussel|zugangsnummer|wiederherstellungswort)/u,
    riskySurface: /(?:shared portal|review page|case portal|linked (?:page|step)|reimbursement form|\bform\b|page below|button below|\breply\b|answer with|send (?:a )?photo|\bupload\b|attached (?:html|image)|portal partage|page de revision|page liee|etape liee|\bportail\b|\brepond(?:re|ez)?\b|envoy(?:er|ez)(?: [\p{L}\p{N}]+){0,4} photo|\btelevers(?:er|ez)\b|\bformulaire\b|portal compartido|pagina de revision|pagina enlazada|paso enlazado|\bformulario\b|\bresponde(?:r)?\b|envie(?: [\p{L}\p{N}]+){0,4} foto|\bsuba\b|gemeinsamen portal|prufseite|verlinkte(?:n|r|s)? (?:seite|schritt)|\bformular\b|\bantwort(?:en)?\b|senden sie ein foto|laden sie(?: [\p{L}\p{N}]+){0,4} hoch)/u,
    sensitiveAction: /(?:send|provide|submit|upload|reply(?:ing)? with|confirm|enter|complete|fill|envoy|fourn|televers|repond|confirm|compl|entrez|rempl|envie|proporc|suba|respon|confirme|introdu|completa|senden|hochlad|laden sie|antwort|bestatig|geben sie|fullen sie)/u,
    sensitiveObject: /(?:identity card|identity scan|passport|birth date|date of birth|insurance (?:card )?number|medical identifier|full address|national id|card number|three digit|check value|household declaration|piece d identite|passeport|date de naissance|numero .*assurance|identifiant medical|adresse complete|trois chiffre|declaration du foyer|documento de identidad|escaneo de identidad|pasaporte|fecha de nacimiento|numero de seguro|identificador medico|direccion completa|tres digito|declaracion familiar|ausweis|reisepass|geburtsdatum|versicherungskartennummer|medizinische kennung|vollstandige anschrift|dreistellig.*prufzahl|haushaltserklarung)/u,
    secrecy: /(?:quietly|discreetly|reply only|only to me|do not call because|keep(?: [\p{L}\p{N}]+){0,8} off the thread|keep(?: [\p{L}\p{N}]+){0,8} between us|private chat|do not use(?: [\p{L}\p{N}]+){0,8} memo|discret|reponds seulement|ne m?appelle pas|retirez(?: [\p{L}\p{N}]+){0,8} conversation|garde(?: [\p{L}\p{N}]+){0,8} entre nous|messagerie privee|sans memo|discretamente|respondeme solo|no llames porque|quite(?: [\p{L}\p{N}]+){0,8} hilo|mantenlo entre nosotros|chat privado|sin nota|diskret|antworte nur|nicht anrufen|entfernen(?: [\p{L}\p{N}]+){0,8} verlauf|behalte es fur dich|privaten chat|keinen(?: [\p{L}\p{N}]+){0,8} vermerk)/u,
    emergency: /(?:operation tonight|hospital accepts only|warrant|patrol|arrest|frozen|before noon|within twenty minutes|daughter needs|border assessment|operation ce soir|doit etre opere|hopital accepte uniquement|\bmandat (?:darret|d arret)\b|patrouille|gele|avant midi|sous vingt minutes|operacion esta noche|hospital solo acepta|hija necesita|orden(?: [\p{L}\p{N}]+){0,5} ciudadano|enviar una patrulla|congelado|antes del mediodia|veinte minutos|operation heute nacht|krankenhaus akzeptiert nur|tochter braucht|haftbefehl|streife|eingefroren|bis mittag|zwanzig minuten)/u,
    investment: /(?:guaranteed .*return|weekly return|trading profit|withdrawal (?:fee|deposit|blocked)|liquidity pool|release deposit|stablecoin .*(?:return|profit|deposit)|(?:bitcoin|crypto|usdt) .*(?:return|profit|deposit|withdrawal)|rendement garanti|benefice de trading|frais de retrait|pool prive|depot de deblocage|stablecoin .*(?:rendement|benefice|depot)|semanal garantizado|ganancia comercial|tasa de retiro|fondo privado|deposito de liberacion|garantierte .*pro woche|handelsgewinn|auszahlungsgebuhr|liquiditatspool|freigabeeinzahlung)/u,
    jobScheme: /(?:text only interview|remote assistant|equipment cheque|starter kit|rate products|pay(?: [\p{L}\p{N}]+){0,4} per day|laptop supplier|entretien uniquement par messages|assistant a distance|cheque d equipement|kit de depart|noter des produits|payer(?: [\p{L}\p{N}]+){0,4} par jour|fournisseur d ordinateur|entrevista solo por mensajes|asistente remoto|cheque de equipo|kit inicial|valorar productos|pagar(?: [\p{L}\p{N}]+){0,4} al dia|proveedor de portatiles|textinterview|remote assistenz|geratescheck|starterpaket|produktbewertungen|zahlen(?: [\p{L}\p{N}]+){0,4} pro tag|laptop lieferant)/u,
    delivery: /(?:parcel|shipment|delivery|redelivery|customs|consignee|tracking|street number|time window|colis|envoi|livr|nouveau creneau|douane|destinataire|suivi|numero de rue|paquete|envio|entreg|reentrega|aduana|destinatario|seguimiento|numero de calle|paket|sendung|zustell|zoll|empfanger|verfolg|hausnummer|zeitfenster)/u,
    callback: /(?:call|phone|telephone|dial|ring|hotline|cancellation desk|fraud control|appelez|telephonez|service annulation|controle fraude|llame|telefono|cancelaciones|control de fraude|rufen sie|stornierung|betrugskontrolle)/u,
    phoneNumber: /(?:\+?\d[\d ()-]{6,}\d)/u,
    disputedCharge: /(?:renewed|did not authorize|large .*order|charge|reversed|cancellation|receipt|fraud|renouvele|pas autorise|grosse commande|debit|annul|recu|fraude|se renovo|no .*autoriz|pedido grande|cargo|revert|cancel|recibo|fraude|verlangert|nicht genehmigt|gro.e bestellung|belastung|ruckbuch|storn|beleg|betrug)/u,
    remoteAccess: /(?:install|remote access|remote support|diagnostic viewer|anydesk|teamviewer|quick assist|screenconnect|session key|session digit|connection code|installe|acces a distance|visionneuse de diagnostic|cle de session|chiffre de session|instale|acceso remoto|visor de diagnostico|clave de sesion|installieren|fernwartung|diagnoseanzeige|sitzungsschlussel)/u,
    riskyAttachment: /(?:attached html|html file|\.html\b|\.htm\b|\.iso\b|\.lnk\b|macro enabled|protected html|qr preview|full notice .*attached|fichier html|apercu qr|avis complet .*image|archivo html|vista qr|aviso completo .*imagen|html datei|qr vorschau|vollstandige hinweis .*bild)/u,
    qrAction: /(?:scan|camera|square barcode|qr code|qr preview|scanne|appareil photo|code qr|apercu qr|escane|camara|codigo qr|vista qr|scannen|kamera|qr code|qr vorschau)/u,
    safeFlow: /\b(?:you requested|requested reset|reset was requested|request was made|record of|already opened|finish signing in|official app|official portal|usual app|usual (?:supplier|vendor) portal|patient app|may be asked|bookmarked|already registered|original card|received successfully|for your records|completed|no action|no [\p{L}\p{N} ]{0,28}(?:is )?needed|my own|you(?:r)? subscription|subscription offer|trial period|contains no|days? for \d|vous avez demande|application officielle|portail officiel|application patient|peut vous etre demande|deja enregistre|carte d origine|recu avec succes|pour vos archives|termine(?:e|es|s)?|aucune action|moi meme|soutenez|je teste|periode de decouverte|offre resiliable|contributions? .* abonne|jours? pour \d|solicitaste|aplicacion oficial|portal oficial|aplicacion del paciente|puede que le pidan|ya registrada|tarjeta original|recibido correctamente|para sus registros|completad[oa]s?|sin accion|por mi cuenta|von ihnen angefordert|offiziellen app|offiziellen portal|patienten app|moglicherweise .* gebeten|bereits(?: [\p{L}\p{N}]+){0,4} hinterlegt|ursprungliche karte|erfolgreich eingegangen|fur ihre unterlagen|abgeschlossen|keine aktion|selbst gebucht)\b/u,
    education: /\b(?:training|seminar|fraud indicators?|security education|example of|never|do not (?!call because)|dont (?!call because)|will not|no action|contains no|no [\p{L}\p{N} ]{0,28}(?:(?:is )?needed|required)|not being offered|report such|reject(?:ed|ion|ing|s)?|refus(?:e|ed|al|ing)?|formation|seminaire|indicateurs? de fraude|exemples?|jamais|n(?:envoyez|achetez|appelez|installez|exigez|partagez)[\p{L} ]{0,20} pas|ne (?:demanderons|demande|partagez|envoyez|achetez|appelez|installez)[\p{L} ]{0,20} pas|ne .* ni|ni .* ni|aucun|aucune|signalez|refus[\p{L}]*|formacion|seminario|indica(?:dor(?:es)?)? fraude|ejemplos?|nunca|no (?:envie|pague|llame|instale|pediremos|exigen|amenazan|contiene|hay)|denuncie|rechaz[\p{L}]*|schulung|betrugszeichen|beispiel|niemals|kein(?:e|en|em|er|es)?|lehnen .*ab|melden sie (?:dies|den betrug|verdachtige|solche))\b/u
  });
  // High-recall, low-cost vocabulary used only to choose which bounded body
  // windows receive full analysis. A match never creates a warning by itself.
  // Keeping this alongside the detector prevents the scan policy from silently
  // drifting away from supported phishing categories.
  const CONTENT_SELECTION_RISK_RE =
    /(?:access token|attached image|banking access|benefits? (?:file )?(?:is )?frozen|browser vulnerability|callback|cancellation desk|case portal|compensation (?:cheque|check|funds?)|computer(?: [\p{L}\p{N}]+){0,3} infected|date of birth|delivery failed|diagnostic viewer|document permissions?|fraud control|full (?:home )?address|full name|identity scan|import adjustment|login information|lose all (?:your )?messages|page below|quick assist|redelivery fee|remote (?:access|support)|security vulnerability|square barcode|time window|unclaimed (?:life )?policy|update your account|update(?: [\p{L}\p{N}]+){0,3} license|webcam (?:images?|recordings?|videos?)|weekly return|withdrawal fee|ajuste de importaci[oó]n|actualice su cuenta|actualice su informaci[oó]n de inicio de sesi[oó]n|actualice(?: [\p{L}\p{N}]+){0,3} licencia|cheque(?: [\p{L}\p{N}]+){0,3} compensacion|cheque internacional|compensar(?:te|le)?(?: [\p{L}\p{N}]+){0,3} cheque|computadora(?: [\p{L}\p{N}]+){0,3} infectad|cuenta ser[aá] eliminada|ampl[ií]a tu membres[ií]a|fondos? de compensacion|imagenes?(?: [\p{L}\p{N}]+){0,3} webcam|informacion de inicio de sesion|paquete esperando|perder todos sus mensajes|poliza(?: [\p{L}\p{N}]+){0,5} no reclamada|verificaci[oó]n aduanal|vulnerabilidad de seguridad)|\b(?:addresses?|anydesk|arrest|attached|barcode|benefits?|birth|callback|camera|cancellation|charges?|compensation|confidential|crypto|customs|deadline|delivery|diagnostic|dispatch|dispute|fraud|frozen|grant|inheritance|infected|install|identity|invoice|license|login|medical|noon|occupation|parcel|passport|phone|qr|redelivery|refund|renewal|returned|ring|routing|scan|secret|session|support|suspend|telephone|token|unclaimed|vulnerability|webcam|voicemail|warrant|wire|withdrawal)\b/iu;
  const CONTENT_SELECTION_HIGH_RISK_RE =
    /(?:access token|anydesk|attached image|authenticator|backup phrase|banking access|benefits? (?:file )?(?:is )?frozen|bitcoin|browser vulnerability|cancellation desk|case portal|compensation (?:cheque|check|funds?)|computer(?: [\p{L}\p{N}]+){0,3} infected|crypto|date of birth|delivery failed|diagnostic viewer|fraud control|gift card|identity scan|import adjustment|login information|login secret|lose all (?:your )?messages|mfa|one time code|otp|passport|passcode|password|private key|quick assist|recovery (?:phrase|words?)|redelivery fee|remote (?:access|support)|security code|security vulnerability|seed phrase|session (?:digit|key)|sign on secret|square barcode|time window|unclaimed (?:life )?policy|update your account|update(?: [\p{L}\p{N}]+){0,3} license|usdt|verification code|wallet|webcam (?:images?|recordings?|videos?)|weekly return|wire|withdrawal fee|access number|ajuste de importaci[oó]n|actualice su cuenta|actualice su informaci[oó]n de inicio de sesi[oó]n|actualice(?: [\p{L}\p{N}]+){0,3} licencia|cheque(?: [\p{L}\p{N}]+){0,3} compensacion|cheque internacional|compensar(?:te|le)?(?: [\p{L}\p{N}]+){0,3} cheque|computadora(?: [\p{L}\p{N}]+){0,3} infectad|cuenta ser[aá] eliminada|ampl[ií]a tu membres[ií]a|fondos? de compensacion|imagenes?(?: [\p{L}\p{N}]+){0,3} webcam|informacion de inicio de sesion|paquete esperando|perder todos sus mensajes|poliza(?: [\p{L}\p{N}]+){0,5} no reclamada|verificaci[oó]n aduanal|vulnerabilidad de seguridad)/iu;
  const CONTENT_SELECTION_FAMILY_RE =
    /(?:[eé]chec de livraison|livraison [eé]chou[eé]e|n[’']?a pas pu(?: [\p{L}\p{N}]+){0,5} (?:livrer|remettre)|succession dormante|effacement des messages|sauvegardes? ser(?:a|ont) detruit|faille de securite|cheval de troie|vid[eé]o intime|d[eé]claration douani[eè]re incomplete|frais douaniers?|entrega fallida|herencia sin reclamar|borrar los mensajes|se borraran los archivos|vulnerabilidad de seguridad|malware en el navegador|grabaci[oó]n comprometedora|tasa de liberaci[oó]n|ruhender nachlass|zustellung fehlgeschlagen|nachrichten gel[oö]scht|dateien gel[oö]scht|sicherheitsl[uü]cke|trojaner|bildschirmaufnahme|zollgeb[uü]hr)/iu;
  const CONTENT_SELECTION_COMPOUND_RE =
    /(?:(?:different|revised|changed) sort code|sort code(?: has| was| is)? (?:changed|revised)|login secret|recovery answers?|backup codes?|authenticator number|mot de passe|r[eé]ponses? de r[eé]cup[eé]ration|codes? de secours|contrase[nñ]a|respuestas? de recuperaci[oó]n|c[oó]digos? de respaldo|passwort|wiederherstellungsantworten|ersatzcodes|beneficiary|new account|alternate account|company bank(?:ing)? details|b[eé]n[eé]ficiaire|nouveau compte|compte de remplacement|coordonn[eé]es bancaires|beneficiario|cuenta (?:nueva|alternativa)|datos bancarios|empf[aä]nger|neues konto|ersatzkonto|bankdaten|redelivery|card (?:security code|verification digits?)|failed postage|handling amount|seconde livraison|cryptogramme de la carte|affranchissement|montant de manutention|reentrega|d[ií]gitos de seguridad de la tarjeta|franqueo|importe de manipulaci[oó]n|erneute zustellung|kartenpr[uü]fziffer|porto|bearbeitungsbetrag|callback number|banking code|code(?: [\p{L}\p{N}]+){0,3} banking app|refund helper|session id|num[eé]ro de rappel|code bancaire|assistant de remboursement|identifiant de session|n[uú]mero de (?:devoluci[oó]n|mensaje)|c[oó]digo bancario|asistente de devoluci[oó]n|identificador de sesi[oó]n|r[uü]ckrufnummer|bankcode|erstattungshelfer|sitzungskennung|\bqr(?: code)?\b|code qr|c[oó]digo qr|remote control tool|endpoint protection|unattended control|outil de contr[oô]le [aà] distance|protection du poste|contr[oô]le permanent|herramienta de control remoto|protecci[oó]n del equipo|control desatendido|fernsteuerungswerkzeug|endpunktschutz|unbeaufsichtigten zugriff|risk free return|private allocation|guaranteed doubl|entry amount|rendement sans risque|allocation priv[eé]e|doublement garanti|mise d[’' ]?entr[eé]e|rentabilidad sin riesgo|asignaci[oó]n privada|importe inicial|risikofreie rendite|private zuteilung|garantiert verdoppel|einstiegsbetrag|release charge|processing fee|surprise inheritance|unrequested grant|frais de d[eé]blocage|frais de dossier|h[eé]ritage surprise|subvention non sollicit[eé]e|cargo de liberaci[oó]n|tasa de tr[aá]mite|herencia sorpresa|subvenci[oó]n no solicitada|freigabegeb[uü]hr|bearbeitungsgeb[uü]hr|[uü]berraschende erbschaft|unverlangte zuschuss|claimed private recording|supposed video|camera capture|alleged files|pr[eé]tendu enregistrement|diffusion suppos[eé]e|capture de cam[eé]ra|fichiers all[eé]gu[eé]s|supuesta grabaci[oó]n|supuesto v[ií]deo|captura de la c[aá]mara|archivos alegados|angebliche private aufnahme|vermeintliche videover[oö]ffentlichung|behauptete kameraaufnahme|angeblichen dateien|seizure penalty|inspection amount|customs charge|p[eé]nalit[eé] de saisie|montant de l[’' ]?inspection|droits de douane|sanci[oó]n por incautaci[oó]n|importe de inspecci[oó]n|cargo de aduanas|beschlagnahmestrafe|pr[uü]fbetrag|zollgeb[uü]hr|recovery application|account (?:is )?wiped|erase timer|stored files|application de r[eé]cup[eé]ration|effacement du compte|fichiers stock[eé]s|aplicaci[oó]n de recuperaci[oó]n|borrar la cuenta|archivos almacenados|wiederherstellungsanwendung|konto gel[oö]scht|dateien behalten)/iu;
  const CONTENT_SELECTION_RELATIONSHIP_RE =
    /(?:(?:new|different|revised|changed) swift(?: bic)?|swift(?: bic)?(?: has| was| is)? (?:changed|revised)|(?:change|update|replace) (?:the )?employee direct[ -]deposit|direct[ -]deposit(?: [\p{L}\p{N}]+){0,7} (?:routing and account numbers?|new checking account)|recovery app|recovery code|account will be wiped|(?:moved|switched) banks?|replacement iban|(?:postage(?: [\p{L}\p{N}]+){0,3} underpaid|underpaid(?: [\p{L}\p{N}]+){0,3} postage)|screenconnect|seed words?|email(?: [\p{L}\p{N}]+){0,3} won(?: [\p{L}\p{N}]+){0,2} lottery|lottery(?: [\p{L}\p{N}]+){0,8} courier(?: [\p{L}\p{N}]+){0,4} tax fee)/iu;
  const CONTENT_SELECTION_REVEALED_RELATION_RE =
    /(?:verification number|login number|one[ -]time (?:login |bank )?number|second[ -]factor value|password[ -]manager export|reset token|company[ -]card details|purchase validation number|remittance destination|substitute account|dual approval|bank coordinates|instant[ -]payment accounts?|call[ -]assistance program|remote helper|control pin|unattended connection|remote view of online banking|browser[ -]control extension|square image|code destination|downloaded profile|guaranteed tripling|no[ -]loss (?:automated )?fund|invitation[ -]only presale|private allocation|unentered lottery|validation cost|award tax|private recordings?|alleged captures?|warehouse storage|insurance deposit|import bond|quarantine inspection|purge timer|preservation levy|num[eé]ro de v[eé]rification|num[eé]ro de connexion|num[eé]ro [aà] usage unique|valeur du second facteur|gestionnaire de mots de passe|jeton de r[eé]initialisation|carte d entreprise|validation d achat|destination du versement|compte de substitution|double validation|coordonn[eé]es bancaires|paiement instantan[eé]|aide t[eé]l[eé]phonique|assistant distant|code de contr[oô]le|connexion permanente|vue distante|contr[oô]le du navigateur|image carr[eé]e|destination du code|profil t[eé]l[eé]charg[eé]|triplement garanti|fonds automatis[eé] sans perte|pr[eé]vente sur invitation|allocation priv[eé]e|loterie [aà] laquelle[^.!?]{0,40} pas particip[eé]|frais de validation|taxe de r[eé]compense|enregistrements? priv[eé]s?|captures? all[eé]gu[eé]es?|stockage en entrep[oô]t|garantie d assurance|caution d importation|contr[oô]le sanitaire|compte [aà] rebours|redevance de conservation|n[uú]mero de verificaci[oó]n|n[uú]mero de acceso|n[uú]mero de un solo uso|valor del segundo factor|gestor de contrase[nñ]as|token de restablecimiento|tarjeta empresarial|validaci[oó]n de compra|destino de la remesa|cuenta sustitutiva|doble aprobaci[oó]n|coordenadas bancarias|pago instant[aá]neo|ayuda telef[oó]nica|asistente remoto|pin de control|conexi[oó]n desatendida|vista remota|control del navegador|imagen cuadrada|destino del c[oó]digo|perfil descargado|triplicaci[oó]n garantizada|fondo automatizado sin p[eé]rdidas|preventa solo por invitaci[oó]n|asignaci[oó]n privada|loter[ií]a en la que no particip[oó]|coste de validaci[oó]n|impuesto del premio|grabaciones? privadas?|supuestas? capturas?|almacenaje|dep[oó]sito de seguro|fianza de importaci[oó]n|inspecci[oó]n sanitaria|cuenta atr[aá]s|tasa de conservaci[oó]n|pr[uü]fnummer|anmeldenummer|einmalnummer|zweitfaktorwert|passwortmanager|r[uü]cksetz[ -]token|firmenkartendaten|kaufpr[uü]fnummer|[uü]berweisungsziel|ersatzkonto|doppelte freigabe|bankkoordinaten|sofortzahlungskonten|anrufhilfe|fernzugriffshelfer|steuerungs[ -]pin|unbeaufsichtigte verbindung|fernansicht|browsersteuerung|quadratische(?:s)? bild|codeziel|geladenes profil|garantierte verdreifachung|verlustfreiheit|privater vorverkauf|private zuteilung|nicht gespielte lotterie|pr[uü]fkosten|gewinnsteuer|privat(?:e|en|er|es)? aufnahmen?|behauptete aufnahmen?|lagerung|versicherungsleistung|importsicherheit|quarant[aä]nepr[uü]fung|erhaltungsabgabe)/iu;
  const LOOKALIKE_MAP = new Map([
    ["0", "o"],
    ["1", "l"],
    ["3", "e"],
    ["4", "a"],
    ["5", "s"],
    ["7", "t"],
    ["@", "a"],
    ["$", "s"]
  ]);
  const HIGH_CONFIDENCE_NEUTRAL_TYPO_ALIASES = new Set([
    "amazon",
    "google",
    "microsoft",
    "netflix",
    "paypal"
  ]);
  const HIGH_CONFIDENCE_NEUTRAL_TYPOS = new Set([
    "amazon:amazom",
    "amazon:amazn",
    "amazon:amazonn",
    "amazon:amazozn",
    "google:googlee",
    "google:gooogle",
    "google:gooqle",
    "google:qoogle",
    "microsoft:microsift",
    "microsoft:microsooft",
    "microsoft:microsoftt",
    "microsoft:nicrosoft",
    "netflix:neetflix",
    "netflix:netflis",
    "netflix:netflixx",
    "paypal:paypall",
    "paypal:paypol",
    "paypal:payypal",
    "paypal:pypal"
  ]);
  const CYRILLIC_LOOKALIKE_MAP = new Map([
    ["а", "a"],
    ["ԁ", "d"],
    ["е", "e"],
    ["о", "o"],
    ["р", "p"],
    ["с", "c"],
    ["х", "x"],
    ["у", "y"],
    ["к", "k"],
    ["м", "m"],
    ["т", "t"],
    ["в", "b"],
    ["н", "h"],
    ["і", "i"],
    ["ј", "j"],
    ["ӏ", "l"],
    ["ѕ", "s"]
  ]);
  const GREEK_LOOKALIKE_MAP = new Map([
    ["α", "a"],
    ["β", "b"],
    ["ϲ", "c"],
    ["ε", "e"],
    ["η", "n"],
    ["ι", "i"],
    ["κ", "k"],
    ["μ", "m"],
    ["ν", "v"],
    ["ο", "o"],
    ["ρ", "p"],
    ["τ", "t"],
    ["υ", "y"],
    ["χ", "x"],
    ["ζ", "z"]
  ]);
  const SCRIPT_LOOKALIKE_MAP = new Map([
    ...CYRILLIC_LOOKALIKE_MAP,
    ...GREEK_LOOKALIKE_MAP
  ]);
  const CONTENT_OBFUSCATION_TERMS = new Map([
    ["account", "account"],
    ["authenticatorcode", "authenticator code"],
    ["banktransfer", "bank transfer"],
    ["code", "code"],
    ["giftcard", "gift card"],
    ["login", "login"],
    ["onetimecode", "one time code"],
    ["mfa", "mfa"],
    ["otp", "otp"],
    ["passcode", "passcode"],
    ["password", "password"],
    ["payment", "payment"],
    ["recoveryphrase", "recovery phrase"],
    ["securitycode", "security code"],
    ["seedphrase", "seed phrase"],
    ["urgent", "urgent"],
    ["verificationcode", "verification code"],
    ["verification", "verification"],
    ["verify", "verify"],
    ["wallet", "wallet"]
  ]);
  const EMPTY_RULES = [];
  const NORMALIZE_CACHE_LIMIT = 4096;
  const NORMALIZE_CACHE_MAX_LENGTH = 512;
  const ANALYSIS_CACHE_LIMIT = 768;
  const normalizeDomainCache = new Map();
  const normalizeTextCache = new Map();
  const normalizeLooseCache = new Map();
  const analysisCacheByRules = new WeakMap();
  let looseSuspiciousTerms = null;
  let looseGenericRiskCandidates = null;
  let normalizedContentSignalGroups = null;
  let normalizedContextualCredentialPhrases = null;
  let normalizedPaymentInfoCredentialPhrases = null;

  function memoized(cache, key, producer, maxLength = NORMALIZE_CACHE_MAX_LENGTH) {
    if (key.length > maxLength) {
      return producer();
    }

    if (cache.has(key)) {
      return cache.get(key);
    }

    const value = producer();
    if (cache.size >= NORMALIZE_CACHE_LIMIT) {
      cache.clear();
    }
    cache.set(key, value);
    return value;
  }

  function activeRuleList(rules) {
    return Array.isArray(rules) ? rules : EMPTY_RULES;
  }

  function analysisCacheForRules(rules) {
    let cache = analysisCacheByRules.get(rules);
    if (!cache) {
      cache = {
        domainRuleIndexes: null,
        links: new Map(),
        lookalikeRules: null,
        senderAliasesByRule: null,
        senders: new Map(),
        urls: new Map()
      };
      analysisCacheByRules.set(rules, cache);
    }

    return cache;
  }

  function cachedAnalysis(rules, cacheName, key, producer) {
    if (key.length > NORMALIZE_CACHE_MAX_LENGTH * 2) {
      return producer();
    }

    const cache = analysisCacheForRules(rules)[cacheName];
    if (cache.has(key)) {
      return cache.get(key);
    }

    const value = producer();
    if (cache.size >= ANALYSIS_CACHE_LIMIT) {
      cache.clear();
    }
    cache.set(key, value);
    return value;
  }

  function stripAccents(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
  }

  function canonicalUnicode(value) {
    return String(value || "")
      .normalize("NFKC")
      .replace(/[\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]/gi, "");
  }

  function replaceScriptLookalikes(token, requireMixedLatin = true) {
    const input = String(token || "");
    const hasMappedScript = [...input].some((char) =>
      SCRIPT_LOOKALIKE_MAP.has(char.toLowerCase())
    );
    if (!hasMappedScript || (requireMixedLatin && !/[a-z]/i.test(input))) {
      return input;
    }

    return [...input]
      .map((char) => SCRIPT_LOOKALIKE_MAP.get(char.toLowerCase()) || char)
      .join("");
  }

  function contentTokenSkeleton(token) {
    const scriptMapped = replaceScriptLookalikes(token, true);
    const compactMapped = [...scriptMapped]
      .map((char) => LOOKALIKE_MAP.get(char.toLowerCase()) || char)
      .join("")
      .toLowerCase();
    const normalizedKey = compactMapped.replace(/[^a-z0-9-]/g, "");
    return CONTENT_OBFUSCATION_TERMS.has(normalizedKey)
      ? CONTENT_OBFUSCATION_TERMS.get(normalizedKey)
      : scriptMapped;
  }

  function securitySkeleton(value) {
    const input = canonicalUnicode(value);
    return input.replace(/[\p{L}\p{N}@$]+/gu, contentTokenSkeleton);
  }

  function domainSecuritySkeleton(value) {
    return canonicalUnicode(value).replace(/[\p{L}\p{N}]+/gu, (token) =>
      replaceScriptLookalikes(token, false)
    );
  }

  function collapseObfuscatedContentTerms(value) {
    let normalized = String(value || "");
    for (const [compact, replacement] of CONTENT_OBFUSCATION_TERMS) {
      const letters = [...compact.replace(/[^a-z0-9]/g, "")];
      if (letters.length < 3) {
        continue;
      }
      const pattern = letters.map((char) => escapeRegExp(char)).join("\\s*");
      normalized = normalized.replace(
        new RegExp(`(?:^| )${pattern}(?= |$)`, "g"),
        (match) => `${match.startsWith(" ") ? " " : ""}${replacement}`
      );
    }
    return normalized;
  }

  function normalizeText(value) {
    const input = String(value || "");
    return memoized(normalizeTextCache, input, () =>
      stripAccents(canonicalUnicode(input))
        .toLowerCase()
        .replace(/[\u2019']/g, "")
        .replace(TOKEN_SPLIT_RE, " ")
        .trim()
    );
  }

  function normalizeSecurityText(value) {
    return collapseObfuscatedContentTerms(normalizeText(securitySkeleton(value)));
  }

  // Keep dismissals scoped to one message without storing its text. Two
  // unrelated messages with the same score must never silence each other.
  function fingerprintText(value) {
    const normalized = normalizeText(value);
    let hash = 2166136261;
    for (let index = 0; index < normalized.length; index += 1) {
      hash ^= normalized.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(36);
  }

  function contentSelectionRiskPattern() {
    return new RegExp(
      `(?:${CONTENT_SELECTION_HIGH_RISK_RE.source}|${CONTENT_SELECTION_RISK_RE.source}|${CONTENT_SELECTION_FAMILY_RE.source}|${CONTENT_SELECTION_COMPOUND_RE.source}|${CONTENT_SELECTION_RELATIONSHIP_RE.source}|${CONTENT_SELECTION_REVEALED_RELATION_RE.source})`,
      "giu"
    );
  }

  function contentSelectionRisk(value) {
    const normalized = normalizeSecurityText(value);
    if (
      CONTENT_SELECTION_HIGH_RISK_RE.test(normalized) ||
      CONTENT_SELECTION_FAMILY_RE.test(normalized) ||
      CONTENT_SELECTION_COMPOUND_RE.test(normalized) ||
      CONTENT_SELECTION_RELATIONSHIP_RE.test(normalized) ||
      CONTENT_SELECTION_REVEALED_RELATION_RE.test(normalized)
    ) {
      return 3;
    }
    return CONTENT_SELECTION_RISK_RE.test(normalized) ? 2 : 0;
  }

  function normalizeLoose(value) {
    const input = String(value || "");
    return memoized(normalizeLooseCache, input, () =>
      normalizeSecurityText(input)
        .replace(/[013457@$]/g, (char) => LOOKALIKE_MAP.get(char) || char)
        .replace(/rn/g, "m")
        .replace(/vv/g, "w")
        .replace(/cl/g, "d")
        .replace(/\s+/g, "")
    );
  }

  function normalizeDomain(value) {
    const raw = String(value || "")
      .trim()
      .replace(/^mailto:/i, "")
      .replace(/[<>()\[\],;:]+$/g, "")
      .replace(/^[<>()\[\],;:]+/g, "")
      .replace(/\.$/, "")
      .toLowerCase();

    if (!raw) {
      return "";
    }

    return memoized(normalizeDomainCache, raw, () => {
      const domain = raw.includes("@") ? raw.split("@").pop() : raw;
      try {
        if (/^[a-z][a-z0-9+.-]*:\/\//i.test(domain)) {
          return new URL(domain).hostname.replace(/\.$/, "").toLowerCase();
        }
        return new URL(`https://${domain}`).hostname.replace(/\.$/, "").toLowerCase();
      } catch (_error) {
        return domain.replace(/[^a-z0-9.-]/g, "");
      }
    });
  }

  function isIpv4Address(domain) {
    const normalized = String(domain || "").trim();
    if (!/^\d{1,3}(?:\.\d{1,3}){3}$/.test(normalized)) {
      return false;
    }

    return normalized.split(".").every((part) => Number(part) >= 0 && Number(part) <= 255);
  }

  function isIpAddress(domain) {
    const normalized = String(domain || "").replace(/^\[|\]$/g, "").trim();
    return isIpv4Address(normalized) || (normalized.includes(":") && /^[0-9a-f:.]+$/i.test(normalized));
  }

  function decodePunycodeDigit(codePoint) {
    if (codePoint >= 48 && codePoint <= 57) {
      return codePoint - 22;
    }
    if (codePoint >= 65 && codePoint <= 90) {
      return codePoint - 65;
    }
    if (codePoint >= 97 && codePoint <= 122) {
      return codePoint - 97;
    }
    return 36;
  }

  function adaptPunycodeBias(delta, pointCount, firstTime) {
    let value = firstTime ? Math.floor(delta / 700) : delta >> 1;
    value += Math.floor(value / pointCount);
    let k = 0;
    while (value > 455) {
      value = Math.floor(value / 35);
      k += 36;
    }
    return k + Math.floor((36 * value) / (value + 38));
  }

  // Small RFC 3492 decoder kept local so browser builds can inspect the Unicode
  // spelling hidden inside an xn-- A-label without adding a dependency.
  function decodePunycodeLabel(label) {
    const input = String(label || "").toLowerCase();
    if (!input.startsWith("xn--")) {
      return input;
    }

    const encoded = input.slice(4);
    const output = [];
    const basicEnd = encoded.lastIndexOf("-");
    let index = 0;
    if (basicEnd >= 0) {
      for (const char of encoded.slice(0, basicEnd)) {
        if (char.charCodeAt(0) >= 128) {
          return input;
        }
        output.push(char.codePointAt(0));
      }
      index = basicEnd + 1;
    }

    let n = 128;
    let i = 0;
    let bias = 72;
    try {
      while (index < encoded.length) {
        const oldI = i;
        let weight = 1;
        for (let k = 36; ; k += 36) {
          if (index >= encoded.length) {
            return input;
          }
          const digit = decodePunycodeDigit(encoded.charCodeAt(index++));
          if (digit >= 36 || digit > Math.floor((Number.MAX_SAFE_INTEGER - i) / weight)) {
            return input;
          }
          i += digit * weight;
          const threshold = k <= bias ? 1 : k >= bias + 26 ? 26 : k - bias;
          if (digit < threshold) {
            break;
          }
          const baseMinusThreshold = 36 - threshold;
          if (weight > Math.floor(Number.MAX_SAFE_INTEGER / baseMinusThreshold)) {
            return input;
          }
          weight *= baseMinusThreshold;
        }

        const pointCount = output.length + 1;
        bias = adaptPunycodeBias(i - oldI, pointCount, oldI === 0);
        if (Math.floor(i / pointCount) > 0x10ffff - n) {
          return input;
        }
        n += Math.floor(i / pointCount);
        i %= pointCount;
        output.splice(i, 0, n);
        i += 1;
      }
      return String.fromCodePoint(...output);
    } catch (_error) {
      return input;
    }
  }

  function decodePunycodeHostname(hostname) {
    return String(hostname || "")
      .split(".")
      .map(decodePunycodeLabel)
      .join(".");
  }

  function rawUrlHostname(value) {
    const match = canonicalUnicode(value).match(/^(?:[a-z][a-z0-9+.-]*:)?\/\/([^/?#]+)/i);
    if (!match) {
      return "";
    }
    const authority = match[1].split("@").pop() || "";
    if (authority.startsWith("[")) {
      return authority.slice(1, authority.indexOf("]"));
    }
    return authority.replace(/:\d+$/, "");
  }

  function activeLinkSchemeResult(value) {
    const raw = String(value || "").trim();
    const schemeMatch = raw.match(/^([a-z][a-z0-9+.-]*):/i);
    if (!schemeMatch) {
      return null;
    }
    const scheme = schemeMatch[1].toLowerCase();

    if (scheme === "javascript" || scheme === "vbscript") {
      const payload = raw.slice(schemeMatch[0].length).trim();
      if (
        scheme === "javascript" &&
        /^(?:;|void\s*\(\s*0\s*\)|void\s+0)?$/i.test(payload)
      ) {
        return {
          status: "unknown",
          severity: "none",
          context: "inert-script-link",
          url: `${scheme}:`,
          urlDomain: "",
          message: "The link is an inert page control with no web destination."
        };
      }
      return {
        status: "warning",
        severity: "high",
        context: "active-script-link",
        url: `${scheme}:[redacted]`,
        urlDomain: "",
        allowedDomains: [],
        message: `This link contains active ${scheme} code instead of a normal web destination.`
      };
    }

    if (scheme === "data") {
      const commaIndex = raw.indexOf(",");
      const header = raw.slice(5, commaIndex >= 0 ? commaIndex : undefined).toLowerCase();
      if (!/^(?:text\/html|application\/xhtml\+xml|image\/svg\+xml)(?:;|$)/i.test(header)) {
        return null;
      }
      let payload = commaIndex >= 0 ? raw.slice(commaIndex + 1, commaIndex + 4097) : "";
      try {
        payload = decodeURIComponent(payload);
      } catch (_error) {
        // Inspect the readable prefix when malformed escaping prevents decoding.
      }
      if (/;base64(?:;|$)/i.test(header) && typeof global.atob === "function") {
        try {
          payload = global.atob(payload.replace(/\s+/g, "").slice(0, 5464)).slice(0, 4096);
        } catch (_error) {
          // The active document MIME is itself sufficient to keep the warning.
        }
      }
      const activeMarkup =
        /<(?:script|form|iframe|object|embed)\b|http-equiv\s*=\s*["']?refresh|(?:password|passcode|login|sign[ -]?in|verification code)/i.test(
          payload
        );
      return {
        status: "warning",
        severity: "high",
        context: "active-data-link",
        url: `data:${header.split(";")[0] || "document"},[redacted]`,
        urlDomain: "",
        allowedDomains: [],
        message: activeMarkup
          ? "This link opens active document content embedded inside the email instead of a normal website."
          : "This link opens an embedded HTML, XHTML, or SVG document that can run active content without showing a website domain."
      };
    }

    return null;
  }

  function parseUrl(value) {
    const raw = String(value || "").trim();
    if (!raw || /^(mailto|tel|sms|javascript|data|blob):/i.test(raw)) {
      return null;
    }

    try {
      return new URL(raw);
    } catch (_error) {
      try {
        return new URL(`https://${raw}`);
      } catch (__error) {
        return null;
      }
    }
  }

  function isKnownRedirectUrl(url) {
    const hostname = url.hostname.toLowerCase();
    const pathname = url.pathname || "/";
    if (
      KNOWN_REDIRECT_HOSTS.has(hostname) ||
      hostname.endsWith(".safelinks.protection.outlook.com")
    ) {
      return true;
    }

    if (
      (hostname === "pipedrive.email" || hostname.endsWith(".pipedrive.email")) &&
      /^\/c(?:\/|$)/i.test(pathname)
    ) {
      return true;
    }

    // Google uses the same /url redirect surface on localized domains. Limit
    // this to the redirect route so an ordinary search `q=` parameter is never
    // mistaken for a nested destination.
    return (
      LOCALIZED_GOOGLE_REDIRECT_HOSTS.has(hostname) &&
      /^\/url(?:\/|$)/i.test(pathname)
    );
  }

  function unwrapRedirectUrl(url) {
    let current = parseUrl(url);
    const seen = new Set();

    for (let depth = 0; depth < 5 && current; depth += 1) {
      const key = current.toString();
      if (seen.has(key)) {
        break;
      }
      seen.add(key);

      if (!isKnownRedirectUrl(current)) {
        break;
      }

      let nested = [...current.searchParams.entries()]
        .find(([param]) => REDIRECT_PARAMS.includes(param.toLowerCase()))?.[1];

      for (let decodeDepth = 0; decodeDepth < 2 && nested && !/^https?:\/\//i.test(nested); decodeDepth += 1) {
        try {
          const decoded = decodeURIComponent(nested.replace(/&amp;/gi, "&"));
          if (decoded === nested) {
            break;
          }
          nested = decoded;
        } catch (_error) {
          break;
        }
      }

      if (!nested || !/^https?:\/\//i.test(nested)) {
        break;
      }

      current = parseUrl(nested);
    }

    return current;
  }

  function extractEmail(value) {
    const text = String(value || "");
    const angleMatch = text.match(ANGLE_EMAIL_RE);
    if (angleMatch) {
      return angleMatch[1].toLowerCase();
    }

    const match = text.match(EMAIL_RE);
    return match ? match[0].toLowerCase() : "";
  }

  function stripEmailAddresses(value) {
    return String(value || "")
      .replace(EMAIL_GLOBAL_RE, " ")
      .replace(/\bmailto\s*:/giu, " ")
      .replace(/[<>]/g, " ");
  }

  function domainMatchesAllowed(senderDomain, allowedDomain) {
    const sender = normalizeDomain(senderDomain);
    const allowed = normalizeDomain(allowedDomain);
    return sender === allowed || sender.endsWith(`.${allowed}`);
  }

  function domainMatchesAllowedForRule(rule, domain, allowedDomain) {
    const normalized = normalizeDomain(domain);
    const allowed = normalizeDomain(allowedDomain);
    if (!normalized || !allowed) {
      return false;
    }
    if (rule.matchSubdomains === false) {
      return normalized === allowed;
    }
    return domainMatchesAllowed(normalized, allowed);
  }

  function domainFallsUnderRuleDomain(rule, domain) {
    return (rule.allowedDomains || []).some((allowedDomain) => domainMatchesAllowed(domain, allowedDomain));
  }

  function isPersonalMailboxDomain(domain) {
    const normalized = normalizeDomain(domain);
    return FREE_MAIL_DOMAINS.has(normalized);
  }

  function trustedSenderDomainsForRule(rule) {
    const domains = Array.isArray(rule.senderDomains) ? rule.senderDomains : rule.allowedDomains || [];
    return domains.filter((domain) => !isPersonalMailboxDomain(domain));
  }

  function domainMatchesTrustedSender(rule, senderDomain) {
    return trustedSenderDomainsForRule(rule).some((allowedDomain) => {
      if (Array.isArray(rule.senderDomains)) {
        const matchSubdomains =
          rule.senderMatchSubdomains === true ||
          (rule.senderMatchSubdomains !== false && !rule.hostedPlatform);
        if (matchSubdomains) {
          return domainMatchesAllowed(senderDomain, allowedDomain);
        }

        const normalized = normalizeDomain(senderDomain);
        const allowed = normalizeDomain(allowedDomain);
        return normalized === allowed;
      }

      return domainMatchesAllowedForRule(rule, senderDomain, allowedDomain);
    });
  }

  function domainIsExactControlPlane(rule, domain) {
    const normalized = normalizeDomain(domain);
    return Boolean(
      normalized &&
      Array.isArray(rule.controlPlaneDomains) &&
      rule.controlPlaneDomains.some(
        (controlPlaneDomain) => normalized === normalizeDomain(controlPlaneDomain)
      )
    );
  }

  function domainMatchesTrustedLink(rule, domain) {
    if (domainIsExactControlPlane(rule, domain)) {
      return true;
    }

    return (rule.allowedDomains || []).some((allowedDomain) =>
      domainMatchesAllowedForRule(rule, domain, allowedDomain)
    );
  }

  function isUserContentPlatformDomain(rule, domain) {
    return Boolean(
      rule.userContentPlatform &&
      domainFallsUnderRuleDomain(rule, domain) &&
      !domainIsExactControlPlane(rule, domain)
    );
  }

  function isHostedPlatformCustomerDomain(rule, domain) {
    return Boolean(
      rule.hostedPlatform &&
      domainFallsUnderRuleDomain(rule, domain) &&
      !domainMatchesTrustedLink(rule, domain)
    );
  }

  function domainLabels(domain) {
    return normalizeDomain(domain).split(".").filter(Boolean);
  }

  // The effective public suffix: a known multi-label ccTLD second-level (e.g. "co.uk"),
  // or a conventional second-level namespace under a country code (e.g. an unlisted
  // "co.ug"), when present. NOTE: domainTld() intentionally still returns only the
  // final label — the TLD-risk sets it is checked against are single-label.
  function publicSuffix(domain) {
    const labels = domainLabels(domain);
    if (labels.length >= 3) {
      const lastTwo = labels.slice(-2).join(".");
      const secondLevelLabel = labels[labels.length - 2];
      const countryCode = labels[labels.length - 1];
      if (
        MULTI_LABEL_PUBLIC_SUFFIXES.has(lastTwo) ||
        (countryCode.length === 2 && COMMON_CCTLD_SECOND_LEVEL_LABELS.has(secondLevelLabel))
      ) {
        return lastTwo;
      }
    }
    return labels.length ? labels[labels.length - 1] : "";
  }

  function effectiveTldLabelCount(domain) {
    return publicSuffix(domain).split(".").filter(Boolean).length;
  }

  // The registrable domain (eTLD+1): the label immediately left of the public suffix,
  // joined with that suffix. registrableDomain("track.deliveroo.co.uk") === "deliveroo.co.uk".
  function registrableDomain(domain) {
    const labels = domainLabels(domain);
    const keep = effectiveTldLabelCount(domain) + 1;
    return labels.length > keep ? labels.slice(-keep).join(".") : labels.join(".");
  }

  function registrableLeadingLabel(domain) {
    const labels = domainLabels(domain);
    const tldCount = effectiveTldLabelCount(domain);
    return labels.length > tldCount ? labels[labels.length - tldCount - 1] : "";
  }

  function registrableDomainParts(domain) {
    const labels = domainLabels(domain);
    const registrableIndex = labels.length - effectiveTldLabelCount(domain) - 1;
    if (registrableIndex < 0 || registrableIndex >= labels.length) {
      return { labels, registrableIndex: -1, registrableLabel: "", subdomainLabels: [] };
    }
    return {
      labels,
      registrableIndex,
      registrableLabel: labels[registrableIndex] || "",
      subdomainLabels: labels.slice(0, registrableIndex)
    };
  }

  function pseudoTldSensitiveDomain(domain) {
    const parts = registrableDomainParts(domain);
    const match = parts.registrableLabel.match(PSEUDO_TLD_SENSITIVE_LABEL_RE);
    const apparentLabel = parts.subdomainLabels[parts.subdomainLabels.length - 1] || "";
    if (!match || !apparentLabel || /^www\d*$/i.test(apparentLabel)) {
      return null;
    }
    return {
      apparentDomain: `${apparentLabel}.${match[1].toLowerCase()}`,
      registrableDomain: parts.labels.slice(parts.registrableIndex).join("."),
      pseudoTld: match[1].toLowerCase()
    };
  }

  function hasOpaquePathSegment(pathname) {
    return String(pathname || "")
      .split("/")
      .some((segment) => {
        if (segment.length < 24 || !/^[a-z0-9_+=-]+$/i.test(segment)) {
          return false;
        }
        return (
          (/[a-z]/.test(segment) && /[A-Z]/.test(segment) && /\d/.test(segment)) ||
          /^[a-f0-9]{32,}$/i.test(segment)
        );
      });
  }

  function opaqueWorkflowDomain(domain, pathname) {
    if (!hasOpaquePathSegment(pathname)) {
      return null;
    }
    const parts = registrableDomainParts(domain);
    const protectedWorkflow =
      PROTECTED_WORKFLOW_ROOT_LABEL_RE.test(parts.registrableLabel) &&
      parts.subdomainLabels.some((label) => WORKFLOW_SUBDOMAIN_LABEL_RE.test(label));
    const schemeLikeTransfer =
      parts.subdomainLabels[0] === "https" &&
      parts.subdomainLabels.slice(1).some((label) => TRANSFER_SUBDOMAIN_LABEL_RE.test(label));
    if (!protectedWorkflow && !schemeLikeTransfer) {
      return null;
    }
    return {
      reason: schemeLikeTransfer ? "scheme-like-transfer" : "protected-workflow"
    };
  }

  function domainTld(domain) {
    const labels = domainLabels(domain);
    return labels.length ? labels[labels.length - 1] : "";
  }

  function rootDomain(domain) {
    return registrableDomain(domain);
  }

  function rootDomainsMatch(firstDomain, secondDomain) {
    return rootDomain(firstDomain) === rootDomain(secondDomain);
  }

  function isUrlShortenerDomain(domain) {
    const normalized = normalizeDomain(domain);
    return URL_SHORTENER_DOMAINS.has(normalized) || URL_SHORTENER_DOMAINS.has(rootDomain(normalized));
  }

  function isKnownPipedriveOpenTracker(
    domain,
    pathname,
    search = "",
    hash = "",
    protocol = "",
    port = ""
  ) {
    return Boolean(
      protocol === "https:" &&
      !port &&
      !hash &&
      /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\.pipedrive\.email$/i.test(
        normalizeDomain(domain)
      ) &&
      /^\/o\/[a-z0-9]{10}\/[a-z0-9]{10}\/[a-z0-9]{10}$/i.test(String(pathname || "")) &&
      /^\?cache_buster=\d+$/.test(String(search || ""))
    );
  }

  function findPublicHostingProvider(
    domain,
    pathname = "",
    search = "",
    hash = "",
    protocol = "",
    port = ""
  ) {
    const normalized = normalizeDomain(domain);
    if (isKnownPipedriveOpenTracker(normalized, pathname, search, hash, protocol, port)) {
      return PIPEDRIVE_OPEN_TRACKING_PROVIDER;
    }
    return PUBLIC_HOSTING_DOMAINS.find((provider) => {
      if (provider.pathPattern && !provider.pathPattern.test(pathname)) {
        return false;
      }
      if ((provider.trustedDomains || []).some((trustedDomain) => normalized === normalizeDomain(trustedDomain))) {
        return false;
      }
      return provider.domains.some((providerDomain) => {
        const base = normalizeDomain(providerDomain);
        return (
          domainMatchesAllowed(normalized, base) &&
          (!provider.subdomainsOnly || normalized !== base)
        );
      });
    });
  }

  function safeDecodePath(pathname) {
    let value = String(pathname || "");
    for (let depth = 0; depth < 2; depth += 1) {
      try {
        const decoded = decodeURIComponent(value);
        if (decoded === value) {
          break;
        }
        value = decoded;
      } catch (_error) {
        break;
      }
    }
    return value;
  }

  function isStaticAssetPath(pathname) {
    return /\.(?:avif|bmp|css|eot|gif|ico|jpe?g|js|mjs|mp3|mp4|ogg|otf|png|svg|tiff?|ttf|webm|webp|woff2?)(?:$|\/)/i.test(
      safeDecodePath(pathname).split("?")[0]
    );
  }

  function isKnownPassiveAssetPath(
    domain,
    pathname,
    search = "",
    hash = "",
    protocol = "",
    port = ""
  ) {
    const normalized = normalizeDomain(domain);
    if (
      normalized === "beaconimages.netflix.net" &&
      !search &&
      !hash &&
      /^\/img\/[a-z0-9_-]{64,}\/?$/i.test(String(pathname || ""))
    ) {
      return true;
    }

    return Boolean(
      protocol === "https:" &&
      !port &&
      normalized === "s3-eu-west-1.amazonaws.com" &&
      !search &&
      !hash &&
      CABIFY_LEGACY_SIGNATURE_ASSET_PATHS.has(String(pathname || ""))
    );
  }

  function hostedContentIdentityDomain(domain, baseDomain, pathname) {
    const normalizedDomain = normalizeDomain(domain);
    const normalizedBase = normalizeDomain(baseDomain);
    const identityLabels = [];

    if (
      normalizedBase &&
      normalizedDomain !== normalizedBase &&
      domainMatchesAllowed(normalizedDomain, normalizedBase)
    ) {
      identityLabels.push(
        ...normalizedDomain
          .slice(0, -(normalizedBase.length + 1))
          .split(".")
          .filter((label) => label && !SHARED_CONTENT_GENERIC_IDENTITY_LABELS.has(normalizeText(label)))
      );
    }

    identityLabels.push(
      ...safeDecodePath(pathname)
        .split("/")
        .filter((label) => label && !SHARED_CONTENT_GENERIC_IDENTITY_LABELS.has(normalizeText(label)))
        .slice(0, 8)
        .map((segment) => normalizeText(segment).replace(/\s+/g, "-"))
        .filter(Boolean)
    );

    return identityLabels.length ? `${identityLabels.join(".")}.example` : "";
  }

  function findHostedContentBrandMatch(domain, baseDomain, pathname, rules, ignoredRuleId, allowFuzzy) {
    const identityDomain = hostedContentIdentityDomain(domain, baseDomain, pathname);
    if (!identityDomain) {
      return null;
    }

    return findLookalikeDomainBrand(identityDomain, rules, { allowFuzzy, ignoredRuleId });
  }

  function displayedDomainText(value) {
    return securitySkeleton(value)
      .trim()
      .toLowerCase()
      .replace(/[\u2024\u3002\uff0e\uff61]/gu, ".")
      .replace(/\s*(?:\[\s*(?:\.|dot)\s*\]|\(\s*(?:\.|dot)\s*\)|\{\s*(?:\.|dot)\s*\}|\bdot\b)\s*/giu, ".");
  }

  function extractDisplayedDomains(value) {
    const text = displayedDomainText(value);
    const domains = [];
    const seen = new Set();
    const pattern = /(?:https?:\/\/)?(?:www\.)?([a-z0-9][a-z0-9.-]*\.[a-z]{2,63})/gi;
    for (const match of text.matchAll(pattern)) {
      const lastLabel = match[1].split(".").pop();
      if (NON_NAVIGATIONAL_TLDS.has(lastLabel)) {
        continue;
      }
      const domain = normalizeDomain(match[1]);
      if (domain && !seen.has(domain)) {
        seen.add(domain);
        domains.push(domain);
      }
    }
    return domains;
  }

  function extractDisplayedDomain(value) {
    const text = displayedDomainText(value);
    const match = text.match(DISPLAYED_DOMAIN_RE);
    if (!match) {
      return "";
    }
    const prefix = text
      .slice(0, match.index)
      .replace(/^[\s<>()\[\]{}"'`.,:;!?-]+|[\s<>()\[\]{}"'`.,:;!?-]+$/g, "");
    const suffix = text.slice((match.index || 0) + match[0].length).trim();
    if (prefix || (suffix && !/^[/?#][^\s]*$/.test(suffix))) {
      return "";
    }
    const lastLabel = match[1].split(".").pop();
    if (NON_NAVIGATIONAL_TLDS.has(lastLabel)) {
      return "";
    }
    return normalizeDomain(match[1]);
  }

  function domainWithoutTld(domain) {
    const labels = domainLabels(domain);
    const tldCount = effectiveTldLabelCount(domain);
    return labels.length > tldCount ? labels.slice(0, -tldCount) : labels;
  }

  function labelCandidates(domain) {
    const labels = domainWithoutTld(domain);
    const candidates = new Set();

    for (const label of labels) {
      candidates.add(label);
      const parts = normalizeText(label).split(/\s+/).filter(Boolean);
      for (const part of parts) {
        candidates.add(part);
      }
      if (parts.length > 1) {
        candidates.add(parts.join(""));
        for (let index = 0; index < parts.length - 1; index += 1) {
          candidates.add(`${parts[index]}${parts[index + 1]}`);
        }
      }

      const stripped = stripSuspiciousEdgeTerms(parts.join(""));
      if (stripped) {
        candidates.add(stripped);
      }
    }

    if (labels.length > 1) {
      candidates.add(labels.join(""));
      for (let index = 0; index < labels.length - 1; index += 1) {
        candidates.add(`${labels[index]}${labels[index + 1]}`);
      }
    }

    return [...candidates]
      .map((candidate) => normalizeLoose(candidate))
      .filter((candidate) => candidate.length >= 3);
  }

  function stripSuspiciousEdgeTerms(value) {
    let result = normalizeLoose(value);
    let changed = true;

    if (!looseSuspiciousTerms) {
      looseSuspiciousTerms = SUSPICIOUS_TERMS.map((term) => normalizeLoose(term))
        .filter((term) => term.length >= 4);
    }

    while (changed && result.length >= 4) {
      changed = false;
      for (const looseTerm of looseSuspiciousTerms) {
        if (looseTerm.length >= result.length) {
          continue;
        }
        if (result.startsWith(looseTerm)) {
          result = result.slice(looseTerm.length);
          changed = true;
        }
        if (result.endsWith(looseTerm)) {
          result = result.slice(0, -looseTerm.length);
          changed = true;
        }
      }
    }

    return result;
  }

  function compactDomain(domain) {
    return normalizeLoose(domainWithoutTld(domain).join(""));
  }

  function domainIsExactBrandLabel(domain, rule) {
    const label = normalizeLoose(registrableLeadingLabel(domain));
    if (!label) {
      return false;
    }

    return (rule.aliases || []).some((alias) => label === normalizeLoose(alias));
  }

  function repeatedCharacterRun(value) {
    const match = String(value || "").match(/([a-z0-9])\1{4,}/i);
    return Boolean(match);
  }

  function looksMachineGeneratedLabel(label) {
    const value = String(label || "").replace(/[^a-z0-9]/gi, "").toLowerCase();
    if (value.length < 14) {
      return false;
    }

    const digitCount = (value.match(/\d/g) || []).length;
    const vowelCount = (value.match(/[aeiou]/g) || []).length;
    const consonantRuns = value.match(/[bcdfghjklmnpqrstvwxyz]{6,}/g) || [];

    return digitCount >= 3 || vowelCount <= 2 || consonantRuns.length > 0;
  }

  function hasAlias(value, alias) {
    const text = normalizeSecurityText(value);
    const normalizedAlias = normalizeText(alias);

    return normalizedHasAlias(text, normalizedAlias);
  }

  function normalizedHasAlias(normalizedText, normalizedAlias) {
    if (!normalizedAlias) {
      return false;
    }

    // Brand names and risk terms must be distinct tokens. Loose substring
    // matching turned ordinary names such as Appleton and Amazonas into brand
    // impersonation warnings.
    return normalizedTextHasWholeTerm(normalizedText, normalizedAlias);
  }

  function levenshteinDistance(a, b) {
    if (a === b) {
      return 0;
    }
    if (!a) {
      return b.length;
    }
    if (!b) {
      return a.length;
    }

    const previous = Array.from({ length: b.length + 1 }, (_value, index) => index);
    const current = Array.from({ length: b.length + 1 }, () => 0);

    for (let i = 1; i <= a.length; i += 1) {
      current[0] = i;
      for (let j = 1; j <= b.length; j += 1) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        current[j] = Math.min(
          previous[j] + 1,
          current[j - 1] + 1,
          previous[j - 1] + cost
        );
      }
      previous.splice(0, previous.length, ...current);
    }

    return previous[b.length];
  }

  function maxAliasDistance(alias) {
    if (alias.length < 5) {
      return 0;
    }
    if (alias.length <= 6) {
      return 1;
    }
    if (alias.length <= 10) {
      return 2;
    }
    return 3;
  }

  function isLikelyAliasLookalike(candidate, alias) {
    const looseCandidate = normalizeLoose(candidate);
    const looseAlias = normalizeLoose(alias);

    if (looseAlias.length < 5 || looseCandidate.length < 4) {
      return false;
    }
    if (looseCandidate === looseAlias) {
      return true;
    }

    // Unmapped digits are usually ordinary product/domain names (mail2), not
    // visual confusables. Known confusable digits were already normalized.
    if (/\d/.test(looseCandidate)) {
      return false;
    }

    const distanceLimit = maxAliasDistance(looseAlias);
    if (distanceLimit === 0) {
      return false;
    }

    if (
      looseCandidate.slice(0, 2) === looseAlias.slice(0, 2) &&
      Math.abs(looseCandidate.length - looseAlias.length) <= distanceLimit
    ) {
      return levenshteinDistance(looseCandidate, looseAlias) <= distanceLimit;
    }

    return false;
  }

  function isKnownBenignLookalike(candidate, alias) {
    const looseCandidate = normalizeLoose(candidate);
    const looseAlias = normalizeLoose(alias);

    return (
      (looseAlias === "calendly" && looseCandidate === "calendar") ||
      (looseAlias === "gmail" && (looseCandidate === "email" || looseCandidate === "mail")) ||
      (looseAlias === "apple" && looseCandidate === "ample") ||
      (looseAlias === "stripe" && looseCandidate === "strive") ||
      // German "Nordstern" (north star) is a real lexical neighbor of the
      // Nordstrom brand, not a visual typo. Keep this pair narrow so actual
      // Nordstrom misspellings still receive the normal fuzzy check.
      (looseAlias === "nordstrom" &&
        // normalizeLoose intentionally folds the rn confusable pair to m, so
        // original "Nordstern" / "Nordstern-Intern" labels arrive here as
        // nordstem / nordstemintem. Enumerate only those lexical compounds.
        /^(?:nordstem)(?:intem|intemal|security|sicherheit|team)?$/u.test(looseCandidate))
    );
  }

  function isStrongVisualTypo(candidate, alias) {
    const looseCandidate = normalizeLoose(candidate);
    const looseAlias = normalizeLoose(alias);
    if (
      looseCandidate.length < 5 ||
      looseCandidate.length !== looseAlias.length ||
      looseCandidate.slice(0, 2) !== looseAlias.slice(0, 2)
    ) {
      return false;
    }

    const differences = [];
    for (let index = 0; index < looseAlias.length; index += 1) {
      if (looseCandidate[index] !== looseAlias[index]) {
        differences.push(index);
      }
    }

    if (differences.length === 1) {
      const index = differences[0];
      return new Set(["il", "li"]).has(`${looseCandidate[index]}${looseAlias[index]}`);
    }

    return (
      differences.length === 2 &&
      differences[1] === differences[0] + 1 &&
      looseCandidate[differences[0]] === looseAlias[differences[1]] &&
      looseCandidate[differences[1]] === looseAlias[differences[0]]
    );
  }

  function isHighConfidenceNeutralTypo(candidate, alias) {
    const looseCandidate = normalizeLoose(candidate);
    const looseAlias = normalizeLoose(alias);
    return HIGH_CONFIDENCE_NEUTRAL_TYPOS.has(`${looseAlias}:${looseCandidate}`);
  }

  function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  // A "bounded token" is a normalized phrase that is a single Latin/digit word
  // (normalizeText already lowercases and strips diacritics). Such phrases match
  // only on word boundaries so short tokens like "rib" or "iban" don't match
  // inside ordinary words ("contributions", "libanais", ...). Multi-word phrases
  // and non-Latin scripts (CJK, Cyrillic, Arabic, ...) keep substring matching.
  function isBoundedToken(normalized) {
    return /^[a-z0-9]+$/.test(normalized);
  }

  function normalizedPhraseRecords(phrases) {
    return phrases.map((phrase) => {
      const normalized = normalizeText(phrase);
      return {
        phrase,
        normalized,
        matcher: isBoundedToken(normalized) ? new RegExp(`\\b${escapeRegExp(normalized)}\\b`) : null
      };
    });
  }

  function contentGroupsWithNormalizedPhrases() {
    if (!normalizedContentSignalGroups) {
      normalizedContentSignalGroups = CONTENT_SIGNAL_GROUPS.map((group) => ({
        ...group,
        phrases: normalizedPhraseRecords(group.phrases)
      }));
    }

    return normalizedContentSignalGroups;
  }

  function contextualCredentialPhrases() {
    if (!normalizedContextualCredentialPhrases) {
      normalizedContextualCredentialPhrases = new Set(
        [...CONTEXTUAL_CREDENTIAL_PHRASES].map((phrase) => normalizeText(phrase))
      );
    }

    return normalizedContextualCredentialPhrases;
  }

  function paymentInfoCredentialPhrases() {
    if (!normalizedPaymentInfoCredentialPhrases) {
      normalizedPaymentInfoCredentialPhrases = new Set(
        [...PAYMENT_INFO_CREDENTIAL_PHRASES].map((phrase) => normalizeText(phrase))
      );
    }

    return normalizedPaymentInfoCredentialPhrases;
  }

  function normalizedTextHasWholeTerm(text, term) {
    return (
      text === term ||
      text.startsWith(`${term} `) ||
      text.endsWith(` ${term}`) ||
      text.includes(` ${term} `)
    );
  }

  function normalizedSenderAliasesForRules(rules) {
    const cache = analysisCacheForRules(rules);
    if (!cache.senderAliasesByRule) {
      const aliasesByRule = new Map();
      for (const rule of rules) {
        const aliases = Array.isArray(rule.senderAliases)
          ? rule.senderAliases
          : rule.aliases || [];
        aliasesByRule.set(
          rule,
          [...new Set(aliases.map(normalizeText).filter(Boolean))]
        );
      }
      cache.senderAliasesByRule = aliasesByRule;
    }
    return cache.senderAliasesByRule;
  }

  function findClaimedBrand(senderText, senderEmail, senderDomain, rules) {
    const displayText = stripEmailAddresses(senderText);
    const localPart = senderEmail.split("@")[0] || "";
    const normalizedDisplayText = normalizeSecurityText(displayText);
    const normalizedLocalPart = normalizeSecurityText(localPart);
    const normalizedSenderDomainText = normalizeSecurityText(
      senderDomain.replace(/\./g, " ")
    );
    const aliasesByRule = normalizedSenderAliasesForRules(rules);
    const senderUsesHostedPlatform = findHostedPlatformCustomerDomainRule(senderDomain, rules);
    const trustedSenderRules = domainRuleCandidates(senderDomain, rules, "senders").filter(
      (rule) => domainMatchesTrustedSender(rule, senderDomain)
    );
    const trustedSenderRuleSet = new Set(trustedSenderRules);
    const trustedIdentityRule = trustedSenderRules.find(
      (rule) =>
        (aliasesByRule.get(rule) || []).some(
          (alias) =>
            normalizedHasAlias(normalizedDisplayText, alias) ||
            normalizedHasAlias(normalizedLocalPart, alias)
        )
    );
    const trustedDomainRule = trustedSenderRules[0] || null;

    // Legitimate cross-brand mail is common (for example an eBay notice that
    // mentions PayPal). When the visible identity also names the brand that
    // owns the known sender domain, prefer that coherent match over whichever
    // other catalog alias happens to appear first.
    if (trustedIdentityRule) {
      return {
        rule: trustedIdentityRule,
        reason: "sender domain and visible identity match the known list"
      };
    }

    const exactMatch = rules.find((rule) => {
      const aliases = aliasesByRule.get(rule) || [];
      const searchableParts = [normalizedDisplayText, normalizedLocalPart];
      if (
        !trustedSenderRuleSet.has(rule) &&
        !isPersonalMailboxDomain(senderDomain) &&
        !senderUsesHostedPlatform
      ) {
        searchableParts.push(normalizedSenderDomainText);
      }

      return (
        aliases.some((alias) =>
          searchableParts.some((part) => normalizedHasAlias(part, alias))
        ) ||
        (rule.exactSenderAliases || []).some((alias) =>
          exactSenderAliasMatches(displayText, alias)
        )
      );
    });

    if (exactMatch) {
      return {
        rule: exactMatch,
        reason: "brand name appears in the sender"
      };
    }

    if (trustedDomainRule) {
      return {
        rule: trustedDomainRule,
        reason: "sender domain matches the trusted list"
      };
    }

    const allowFuzzy = containsAnyTerm(
      `${displayText} ${localPart}`,
      [...GENERIC_IDENTITY_TERMS, ...SUSPICIOUS_TERMS]
    );
    return findLookalikeDomainBrand(senderDomain, rules, { allowFuzzy });
  }

  function exactSenderAliasMatches(displayText, alias) {
    const rawAlias = String(alias || "").trim();
    if (!rawAlias) {
      return false;
    }

    // Very short all-caps names such as ANA remain case-sensitive so ordinary
    // personal names ("Ana") do not become brand claims. Longer title-case
    // brands are matched case-insensitively because mail clients routinely
    // alter their casing.
    const caseSensitive = /^[A-Z0-9]{2,4}$/.test(rawAlias);
    const normalizeExactText = (value) => {
      const normalized = stripAccents(canonicalUnicode(String(value || "")))
        .replace(/[\u2019']/g, "")
        .replace(TOKEN_SPLIT_RE, " ")
        .replace(/\s+/g, " ")
        .trim();
      return caseSensitive ? normalized : normalized.toLowerCase();
    };
    const normalizedAlias = normalizeExactText(rawAlias);
    const normalizedDisplay = normalizeExactText(displayText);
    if (!normalizedAlias || !normalizedDisplay) {
      return false;
    }

    // candidateText() may collect the same display name from name/title/text
    // attributes. Accept exact repetitions, but reject extra words such as
    // "Apple Records" or "Orange County".
    const repeatedAlias = new RegExp(
      `^(?:${escapeRegExp(normalizedAlias)})(?: ${escapeRegExp(normalizedAlias)})*$`,
      caseSensitive ? "u" : "iu"
    );
    return repeatedAlias.test(normalizedDisplay);
  }

  function normalizedLookalikeRules(rules) {
    const cache = analysisCacheForRules(rules);
    if (!cache.lookalikeRules) {
      const exactAliases = new Map();
      const prefixAliases = new Map();
      const neutralTypoEntries = [];
      rules.forEach((rule, ruleIndex) => {
        [...new Set((rule.aliases || []).map(normalizeLoose))]
          .filter((alias) => alias.length >= 3)
          .forEach((alias, aliasIndex) => {
            const entry = { rule, alias, order: ruleIndex * 1000 + aliasIndex };
            const exactEntries = exactAliases.get(alias) || [];
            exactEntries.push(entry);
            exactAliases.set(alias, exactEntries);
            if (alias.length >= 5) {
              const prefix = alias.slice(0, 2);
              const prefixEntries = prefixAliases.get(prefix) || [];
              prefixEntries.push(entry);
              prefixAliases.set(prefix, prefixEntries);
            }
            if (HIGH_CONFIDENCE_NEUTRAL_TYPO_ALIASES.has(alias)) {
              neutralTypoEntries.push(entry);
            }
          });
      });
      cache.lookalikeRules = { exactAliases, prefixAliases, neutralTypoEntries };
    }
    return cache.lookalikeRules;
  }

  function isKnownDomainBrandCollision(domain, ruleId) {
    const normalized = normalizeDomain(domain);
    return (
      ruleId === "telegram" &&
      (normalized === "telegram.com" || normalized === "www.telegram.com")
    );
  }

  function findLookalikeDomainBrand(senderDomain, rules, options = {}) {
    if (!senderDomain) {
      return null;
    }
    if (findTrustedDomainRule(senderDomain, rules) || findHostedPlatformCustomerDomainRule(senderDomain, rules)) {
      return null;
    }

    const candidates = [...new Set(labelCandidates(senderDomain))];
    if (!looseGenericRiskCandidates) {
      looseGenericRiskCandidates = new Set(
        [...SUSPICIOUS_TERMS, ...GENERIC_IDENTITY_TERMS].map((term) => normalizeLoose(term))
      );
    }
    const compact = compactDomain(senderDomain);
    const registrableLabel = normalizeLoose(registrableLeadingLabel(senderDomain));
    const domainHasSuspiciousTerm = FAST_SUSPICIOUS_DOMAIN_RE.test(
      senderDomain.replace(/[.-]/g, " ")
    );

    const { exactAliases, prefixAliases, neutralTypoEntries } = normalizedLookalikeRules(rules);
    const matches = new Map();
    const addMatch = (entry, matchType) => {
      if (
        entry.rule.id === options.ignoredRuleId ||
        isKnownDomainBrandCollision(senderDomain, entry.rule.id) ||
        (entry.alias.length < 5 &&
          registrableLabel !== entry.alias &&
          !domainHasSuspiciousTerm)
      ) {
        return;
      }
      const existing = matches.get(entry.order);
      if (!existing || (existing.matchType === "fuzzy" && matchType === "exact")) {
        matches.set(entry.order, { entry, matchType });
      }
    };

    for (const candidate of new Set([...candidates, compact])) {
      for (const entry of exactAliases.get(candidate) || []) {
        addMatch(entry, "exact");
      }
    }

    for (const candidate of candidates) {
      for (const entry of neutralTypoEntries) {
        if (isHighConfidenceNeutralTypo(candidate, entry.alias)) {
          addMatch(entry, "fuzzy");
        }
      }
    }

    for (const candidate of new Set([...candidates, compact])) {
      if (
        candidate.length < 4 ||
        looseGenericRiskCandidates.has(candidate)
      ) {
        continue;
      }
      for (const entry of prefixAliases.get(candidate.slice(0, 2)) || []) {
        if (
          isKnownBenignLookalike(candidate, entry.alias) ||
          Math.abs(candidate.length - entry.alias.length) > maxAliasDistance(entry.alias)
        ) {
          continue;
        }
        if (
          isStrongVisualTypo(candidate, entry.alias) ||
          (Boolean(options.allowFuzzy) && isLikelyAliasLookalike(candidate, entry.alias))
        ) {
          addMatch(entry, "fuzzy");
        }
      }
    }

    const bestMatch = [...matches.values()].sort(
      (first, second) => first.entry.order - second.entry.order
    )[0];
    if (bestMatch) {
      return {
        rule: bestMatch.entry.rule,
        matchType: bestMatch.matchType,
        reason: `sender domain looks like ${bestMatch.entry.rule.name}`
      };
    }

    return null;
  }

  function findTrustedDomainRule(domain, rules) {
    return domainRuleCandidates(domain, rules, "links").find((rule) =>
      domainMatchesTrustedLink(rule, domain)
    );
  }

  function findTrustedSenderDomainRule(domain, rules) {
    return domainRuleCandidates(domain, rules, "senders").find((rule) =>
      domainMatchesTrustedSender(rule, domain)
    );
  }

  function domainRuleIndexesForRules(rules) {
    const cache = analysisCacheForRules(rules);
    if (cache.domainRuleIndexes) {
      return cache.domainRuleIndexes;
    }

    const links = new Map();
    const senders = new Map();
    const add = (index, domain, rule, order) => {
      const normalized = normalizeDomain(domain);
      if (!normalized) {
        return;
      }
      const entries = index.get(normalized) || [];
      if (!entries.some((entry) => entry.rule === rule)) {
        entries.push({ rule, order });
        index.set(normalized, entries);
      }
    };

    rules.forEach((rule, order) => {
      for (const domain of rule.allowedDomains || []) {
        add(links, domain, rule, order);
      }
      for (const domain of rule.controlPlaneDomains || []) {
        add(links, domain, rule, order);
      }
      for (const domain of trustedSenderDomainsForRule(rule)) {
        add(senders, domain, rule, order);
      }
    });

    cache.domainRuleIndexes = { links, senders };
    return cache.domainRuleIndexes;
  }

  function domainRuleCandidates(domain, rules, indexName) {
    const normalized = normalizeDomain(domain);
    if (!normalized) {
      return [];
    }
    const index = domainRuleIndexesForRules(rules)[indexName];
    const labels = normalized.split(".");
    const matches = new Map();
    for (let offset = 0; offset < labels.length; offset += 1) {
      const suffix = labels.slice(offset).join(".");
      for (const entry of index.get(suffix) || []) {
        if (!matches.has(entry.order)) {
          matches.set(entry.order, entry.rule);
        }
      }
    }
    return [...matches.entries()]
      .sort((first, second) => first[0] - second[0])
      .map((entry) => entry[1]);
  }

  function findUnicodeHomographRule(rawHostname, asciiHostname, rules) {
    const normalizedAscii = normalizeDomain(asciiHostname);
    const decodedHostname = decodePunycodeHostname(rawHostname || normalizedAscii);
    if (!decodedHostname || decodedHostname === normalizedAscii) {
      return null;
    }

    const skeletonHostname = normalizeDomain(domainSecuritySkeleton(decodedHostname));
    if (!skeletonHostname || skeletonHostname === normalizedAscii) {
      return null;
    }

    const rule = findTrustedDomainRule(skeletonHostname, rules);
    return rule && !domainMatchesTrustedLink(rule, normalizedAscii)
      ? { rule, skeletonHostname, decodedHostname }
      : null;
  }

  function findHostedPlatformCustomerDomainRule(domain, rules) {
    return domainRuleCandidates(domain, rules, "links").find(
      (rule) => rule.hostedPlatform && isHostedPlatformCustomerDomain(rule, domain)
    );
  }

  function findUserContentPlatformRule(domain, rules) {
    return domainRuleCandidates(domain, rules, "links").find(
      (rule) => rule.userContentPlatform && isUserContentPlatformDomain(rule, domain)
    );
  }

  function containsAnyTerm(value, terms) {
    const text = normalizeSecurityText(value);
    return terms.some((term) => normalizedHasAlias(text, normalizeText(term)));
  }

  function normalizedContentClauses(value) {
    const softLineBreaksJoined = String(value || "")
      .replace(/([\p{L}\p{N}])[\u00ad-]\s*[\r\n]+\s*(?=[\p{L}\p{N}])/gu, "$1");
    const clauses = softLineBreaksJoined
      .split(/[.!?;\r\n\u3002\uff01\uff1f\u061b]+/u)
      .flatMap((clause) =>
        clause.split(
          /\b(?:but|however|yet|although|mais|cependant|pourtant|pero|sin embargo|mas|porem|aber|jedoch)\b/iu
        )
      )
      .map((clause) => normalizeSecurityText(clause))
      .filter(Boolean);
    return clauses.length > 0 ? clauses : [normalizeSecurityText(value)].filter(Boolean);
  }

  function actionFollowsProtectivePolicyConjunction(
    normalizedText,
    actionIndex,
    matchLength = 0
  ) {
    const prefix = normalizedText
      .slice(Math.max(0, actionIndex - 220), actionIndex)
      .trim();
    const action = normalizedText
      .slice(actionIndex, actionIndex + Math.max(matchLength, 32))
      .trim();
    const protectivePolicyPrefix =
      /(?:(?:support|service|team|staff|company|we|it|security)(?: [\p{L}\p{N}]+){0,8} (?:will not|does not|never) (?:ask|request|require)(?: [\p{L}\p{N}]+){0,28} (?:email|e mail|message)|(?:support|service|equipe|securite|informatique)(?: [\p{L}\p{N}]+){0,8} ne (?:demande|sollicite|exige)(?: [\p{L}\p{N}]+){0,5} jamais(?: [\p{L}\p{N}]+){0,28} (?:courriel|email|message)|(?:soporte|servicio|equipo|seguridad|informatica)(?: [\p{L}\p{N}]+){0,8} nunca (?:pide|solicita|exige)(?: [\p{L}\p{N}]+){0,28} (?:correo|email|mensaje)|(?:support|dienst|team|sicherheit|it)(?: [\p{L}\p{N}]+){0,8} (?:fragt|fordert|verlangt)(?: [\p{L}\p{N}]+){0,12} (?:nie|niemals)(?: [\p{L}\p{N}]+){0,20} (?:e mail|email|nachricht)) (?:and|et|y|und)$/u.test(
        prefix
      );
    const imperativeRestart =
      /^(?:please )?(?:send|share|provide|enter|submit|reply|pay|transfer|install|scan|envoyez|partagez|fournissez|saisissez|repondez|payez|transferez|installez|scannez|envie|comparta|introduzca|responda|pague|transfiera|instale|escanee|senden sie|teilen sie|geben sie|zahlen sie|uberweisen sie|installieren sie|scannen sie)\b/u.test(
        action
      );
    return protectivePolicyPrefix && imperativeRestart;
  }

  function actionRepeatsAfterNegatedConjunction(
    normalizedText,
    actionIndex,
    matchLength = 0
  ) {
    const prefix = normalizedText
      .slice(Math.max(0, actionIndex - 160), actionIndex)
      .trim();
    const action = normalizedText
      .slice(actionIndex, actionIndex + Math.max(matchLength, 36))
      .trim();
    if (!/(?:^| )(?:and|et|y|und)$/u.test(prefix)) {
      return false;
    }
    const beforeConjunction = prefix.replace(/ (?:and|et|y|und)$/u, "");
    if (
      !/(?:^| )(?:do not|dont|never|no|nunca|ne|n|jamais|niemals|nicht)(?: |$)/u.test(
        beforeConjunction
      )
    ) {
      return false;
    }

    const repeatedActionFamilies = [
      /(?:\bsend\b|\benvoy(?:er|ez)?\b|\benvi(?:e|a|emel[ao]s?)\b|\bsenden(?: sie)?\b)/u,
      /(?:\bpay\b|\bpayez\b|\bpag(?:a|ue|uel[ao]s?)\b|\bzahlen(?: sie)?\b)/u,
      /(?:\binstall\b|\binstallez\b|\binstale\b|\binstallieren(?: sie)?\b)/u,
      /(?:\btransfer\b|\btransferez\b|\btransfiera\b|\buberweisen(?: sie)?\b)/u,
      /(?:\bscan\b|\bscannez\b|\bescanee\b|\bscannen(?: sie)?\b)/u,
      /(?:\bprovide\b|\bfournissez\b|\bfacilite\b|\bgeben(?: sie)?\b)/u
    ];
    return repeatedActionFamilies.some(
      (family) => family.test(action) && family.test(beforeConjunction)
    );
  }

  function actionIsNegated(normalizedText, actionIndex, matchLength = 0) {
    const prefix = normalizedText.slice(Math.max(0, actionIndex - 96), actionIndex).trim();
    const recentWords = prefix.split(/\s+/).slice(-12).join(" ");
    const suffixWords =
      matchLength > 0
        ? normalizedText
            .slice(actionIndex + matchLength)
            .trim()
            .split(/\s+/)
            .slice(0, 6)
            .join(" ")
        : "";
    const negation = "(?:never|not|dont|cannot|cant|shouldnt|wouldnt|mustnt|havent|hasnt|hadnt|avoid|ne|niemals|non|no|nunca|nao)";
    const safetyAction =
      "(?:send|share|forward|email|give|enter|paste|submit|provide|copy|upload|envoyez|partagez|fournissez|senden|teilen|invia|condividi|envie|comparta)";
    const completedProtectiveInstruction =
      /(?:^| )(?:do not|dont|never|no|nunca|nao|non|niemals|nicht)(?: [\p{L}\p{N}]+){0,2} (?:pay|share|send|forward|install|run|open|enter|provide|scan|call|dial|transfer|deposit|cover|remit|settle)(?: (?!(?:and|or|nor|ni|et|und)\b)[\p{L}\p{N}]+){1,5}$/u.test(
        recentWords
      );
    const restartedAfterProtectiveInstruction =
      /(?:^| )(?:do not|dont|never|no|nunca|nao|non|niemals|nicht)(?: [\p{L}\p{N}]+){0,2} (?:pay|share|send|forward|install|run|open|enter|provide|scan|call|dial|transfer|deposit|cover|remit|settle)(?: (?!(?:and|or|nor|ni|et|und)\b)[\p{L}\p{N}]+){1,5} (?:remit|settle|deposit|cover|forward|give|run|start|launch|reauthenticate|install|open|scan|send|pay|transfer)(?: [\p{L}\p{N}]+){0,5} (?:and|then)$/u.test(
        recentWords
      );
    if (completedProtectiveInstruction || restartedAfterProtectiveInstruction) {
      return false;
    }
    if (
      /(?:^| )(?:do not|dont|never|no|nunca|nao|nicht)(?: forget| fail| hesitate| olvides?| oublier| vergessen)? to$/u.test(
        recentWords
      )
    ) {
      return false;
    }
    if (/(?:^| )(?:nunca|no) (?:deje|dejes|dejen|dejar) de$/u.test(recentWords)) {
      return false;
    }
    if (actionRestartsAfterProtectiveInstruction(normalizedText, actionIndex)) {
      return false;
    }
    if (
      actionFollowsProtectivePolicyConjunction(
        normalizedText,
        actionIndex,
        matchLength
      )
    ) {
      return false;
    }
    if (
      actionRepeatsAfterNegatedConjunction(
        normalizedText,
        actionIndex,
        matchLength
      )
    ) {
      return false;
    }
    return (
      new RegExp(`(?:^| )${negation}$`, "u").test(recentWords) ||
      /(?:^| )(?:do not|dont|never|no|ni|nunca|nao|non|niemals|nicht|nichts|kein|keine|keinen|keinem|keiner|keines|ne|n|aucun|aucune)(?: [\p{L}\p{N}]+){0,2}$/u.test(
        recentWords
      ) ||
      /(?:^| )(?:ne [\p{L}]+|n[\p{L}]+)(?: [\p{L}\p{N}]+){0,3} pas(?: (?:d|de|du|des))?$/u.test(
        recentWords
      ) ||
      new RegExp(`(?:^| )${negation} ${safetyAction}(?: it| them)? or$`, "u").test(recentWords) ||
      new RegExp(`(?:^| )${negation} (?:ask|tell|request)(?: you| anyone| users| customers)? to$`, "u").test(
        recentWords
      ) ||
      /(?:^| )(?:(?:have|has|had|do|does|did|will|would) not|havent|hasnt|hadnt|dont|doesnt|didnt) (?:asked?|told|requested)(?: you| anyone| users| customers)? to$/u.test(
        recentWords
      ) ||
      /(?:^| )(?:do not|dont|never|no|nunca|nao|non|niemals|nicht|kein|keine|keinen|keinem|keiner|keines|ne|n)(?: [\p{L}\p{N}]+){0,8} (?:or|nor|and|ni|et|und)$/u.test(
        recentWords
      ) ||
      /^(?:(?:you|sie|ihr|ihre|le|la|el|los|las) )?(?:not|nicht|kein|keine|keinen|keinem|keiner|keines|never|niemals|jamais|nunca|no)\b/u.test(
        suffixWords
      ) ||
      /^(?:sie )?bitte kein(?:e|en|em|er|es)?\b/u.test(suffixWords) ||
      /^(?:sie )?(?:[\p{L}\p{N}]+ ){0,3}niemals\b/u.test(suffixWords) ||
      /^(?:(?:was|were|is|are|a ete|fue|wurde) )?(?:rejected|refused|denied|declined|refuse|rechazad|abgelehnt)\b/u.test(
        suffixWords
      )
    );
  }

  function contentTextHasPhrase(normalizedText, phrase) {
    if (!phrase || !phrase.normalized) {
      return false;
    }
    return phrase.matcher ? phrase.matcher.test(normalizedText) : normalizedText.includes(phrase.normalized);
  }

  function clauseHasRiskyCredentialPhrase(normalizedClause, phrase) {
    const riskText = normalizedClause;
    if (!contentTextHasPhrase(riskText, phrase)) {
      return false;
    }

    const normalizedPhrase = phrase.normalized;
    const phrasePattern = escapeRegExp(normalizedPhrase).replace(/\s+/g, "\\s+");
    if (!contextualCredentialPhrases().has(normalizedPhrase)) {
      const matches = riskText.matchAll(new RegExp(phrasePattern, "g"));
      for (const match of matches) {
        if (!actionIsNegated(riskText, match.index || 0)) {
          return true;
        }
      }
      return false;
    }

    return CREDENTIAL_DISCLOSURE_TERMS.some((term) => {
      const termPattern = escapeRegExp(normalizeText(term)).replace(/\s+/g, "\\s+");
      const matches = riskText.matchAll(
        new RegExp(`\\b${termPattern}(?:\\s+[\\p{L}\\p{N}]+){0,6}\\s+${phrasePattern}\\b`, "gu")
      );
      for (const match of matches) {
        if (!actionIsNegated(riskText, match.index || 0)) {
          return true;
        }
      }
      return false;
    });
  }

  function clauseHasUnnegatedAction(normalizedClause, terms) {
    for (const term of terms) {
      const normalizedTerm = normalizeText(term);
      if (!normalizedTerm) {
        continue;
      }
      const pattern = new RegExp(`(?:^| )${escapeRegExp(normalizedTerm)}(?= |$)`, "g");
      for (const match of normalizedClause.matchAll(pattern)) {
        const actionIndex = (match.index || 0) + (match[0].startsWith(" ") ? 1 : 0);
        if (!actionIsNegated(normalizedClause, actionIndex, normalizedTerm.length)) {
          return true;
        }
      }
    }
    return false;
  }

  function patternHasUnnegatedMatch(normalizedClause, patternName) {
    const pattern = BEHAVIOR_PATTERNS[patternName];
    const flags = pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`;
    const matcher = new RegExp(pattern.source, flags);
    for (const match of normalizedClause.matchAll(matcher)) {
      const matchIndex = match.index || 0;
      const prefix = normalizedClause.slice(Math.max(0, matchIndex - 72), matchIndex);
      const suffix = normalizedClause.slice(matchIndex + match[0].length, matchIndex + match[0].length + 96);
      const protectiveBankContext =
        patternName === "bankChange" &&
        (/(?:remains? unchanged|reste(?: [\p{L}\p{N}]+){0,3} inchange|no ha cambiado|sigue(?: [\p{L}\p{N}]+){0,3} sin cambios|bleibt(?: [\p{L}\p{N}]+){0,3} unverandert)/u.test(
          match[0]
        ) ||
          /(?:reject|refus[\p{L}]*|deny|decline|rechaz[\p{L}]*|ablehn[\p{L}]*|lehn[\p{L}]*)(?: [\p{L}\p{N}]+){0,5}\s*$/u.test(
          prefix
        ) ||
          /^(?: [\p{L}\p{N}]+){0,5} (?:rejected|refused|denied|declined|rechazad[\p{L}]*|abgelehnt|lehn[\p{L}]* .* ab|did not pass)\b/u.test(
            suffix
          ) ||
          /^\s*(?:(?:is|was|were)\s+)?(?:false|incorrect|untrue|fake)\b/u.test(
            suffix
          ) ||
          /^\s*(?:policy|procedure|rules?|notice|guidance)\b/u.test(
            suffix
          ));
      if (
        !protectiveBankContext &&
        !actionIsNegated(normalizedClause, matchIndex, match[0].length)
      ) {
        return true;
      }
    }
    return false;
  }

  function clauseHasUnnegatedMoneyAction(normalizedClause) {
    if (clauseHasUnnegatedAction(normalizedClause, BEHAVIOR_MONEY_ACTION_TERMS)) {
      return true;
    }

    const requestedTransfer =
      /\b(?:need|needs|needed|require|requires|besoin|necesit[\p{L}]*|brauch[\p{L}]*)\b(?: [\p{L}\p{N}]+){0,7} \b(?:transfer|transfert|transferencia|wire|virement|uberweisung)\b/gu;
    for (const match of normalizedClause.matchAll(requestedTransfer)) {
      if (!actionIsNegated(normalizedClause, match.index || 0, match[0].length)) {
        return true;
      }
    }
    return false;
  }

  function clauseHasUnnegatedRemoteAccessInstruction(normalizedClause) {
    const hasRemoteAccessObject =
      /(?:remote access|remote support|diagnostic viewer|anydesk|teamviewer|quick assist|session key|session digit|connection code|acces a distance|visionneuse de diagnostic|cle de session|chiffre de session|acceso remoto|visor de diagnostico|clave de sesion|fernwartung|diagnoseanzeige|sitzungsschlussel)/u.test(
        normalizedClause
      );
    return (
      hasRemoteAccessObject &&
      clauseHasUnnegatedAction(normalizedClause, [
        "install",
        "download",
        "open",
        "run",
        "provide",
        "give",
        "enter",
        "installez",
        "telechargez",
        "ouvrez",
        "fournissez",
        "instale",
        "descargue",
        "abra",
        "proporcione",
        "installieren",
        "laden sie",
        "offnen sie",
        "geben sie"
      ])
    );
  }

  function clauseHasAuthenticatorCodeRequest(normalizedClause) {
    return (
      /\b(?:code|number|digits?)\b(?: [\p{L}\p{N}]+){0,4} \b(?:authenticator|authentication app)\b/u.test(
        normalizedClause
      ) &&
      clauseHasUnnegatedAction(normalizedClause, CREDENTIAL_DISCLOSURE_TERMS)
    );
  }

  function clauseHasCredentialTransmissionRequest(normalizedClause) {
    const governedDisclosureAction =
      /(?:\b(?:send|text|share|provide|paste|submit|email|e mail|give|forward|copy|upload|dictate|tell)\b|\btype\b(?! (?:of|is|was|can|may|should|refers|includes|contains)\b)|envoyez|envoyer|transmettez|partagez|fournissez|repondez|antworten sie|senden sie|ubermitteln sie|teilen sie|invia|condividi|envie|enviemela|enviemelo|responda|comparta|отправьте)/u;
    const governedRequest = new RegExp(
      `(?:${governedDisclosureAction.source})(?: (?!(?:never|not|no|nunca|jamais|pas|nicht|niemals|kein(?:e|en|em|er|es)?)\\b)[\\p{L}\\p{N}]+){0,8} (?:${BEHAVIOR_PATTERNS.credentialObject.source})`,
      "u"
    );
    if (
      textHasUnnegatedDirectRequest(normalizedClause, governedRequest) &&
      textHasUnnegatedPattern(normalizedClause, governedRequest)
    ) {
      return true;
    }
    const actionMatcher =
      /(?:\b(?:send|text|share|provide|paste|submit|email|e mail|give|forward|copy|upload|dictate|tell|envoyez|envoyer|transmettez|partagez|fournissez|repondez|senden|ubermitteln|teilen|invia|condividi|envie|enviemela|enviemelo|responda|comparta|отправьте)\b|\btype\b(?! (?:of|is|was|can|may|should|refers|includes|contains)\b)|\b(?:antworten|ubermitteln) sie\b|\breply(?: [\p{L}\p{N}]+){0,5} with\b)/gu;
    const objectMatcher = new RegExp(
      BEHAVIOR_PATTERNS.credentialObject.source,
      BEHAVIOR_PATTERNS.credentialObject.flags.includes("g")
        ? BEHAVIOR_PATTERNS.credentialObject.flags
        : `${BEHAVIOR_PATTERNS.credentialObject.flags}g`
    );
    const actionMatches = [...normalizedClause.matchAll(actionMatcher)];
    const objectMatches = [...normalizedClause.matchAll(objectMatcher)];

    return actionMatches.some((actionMatch) => {
      const actionIndex = actionMatch.index || 0;
      if (
        /^(?:email|e mail)$/u.test(actionMatch[0]) &&
        /^(?:email|e mail) (?:contains?|includes?|says?|asks?|confirms?|notes?|is|was|will|does|did|has|had|never)\b/u.test(
          normalizedClause.slice(actionIndex)
        )
      ) {
        return false;
      }
      if (
        actionIsSafeProtectiveFollowUp(
          normalizedClause,
          actionIndex,
          actionMatch[0]
        )
      ) {
        return false;
      }
      if (actionIsNegated(normalizedClause, actionIndex, actionMatch[0].length)) {
        return false;
      }
      return objectMatches.some((objectMatch) => {
        const objectIndex = objectMatch.index || 0;
        if (objectIndex < actionIndex) {
          const explicitReference = normalizedClause.slice(
            actionIndex + actionMatch[0].length,
            actionIndex + actionMatch[0].length + 64
          );
          const hasImmediatePronounReference =
            /^ (?:(?:it|them|es|ihn|le|la|les|lo|los|las)|sie (?:es|ihn))\b/u.test(
              explicitReference
            );
          const hasNamedSecretReference =
            /^ (?:[\p{L}\p{N}]+ ){0,4}(?:this|that|the) (?:code|password|secret|key)\b/u.test(
              explicitReference
            );
          if (
            !/^(?:enviemela|enviemelo)$/u.test(actionMatch[0]) &&
            !hasImmediatePronounReference &&
            !hasNamedSecretReference
          ) {
            return false;
          }
        }
        const start = Math.min(actionIndex, objectIndex);
        const end = Math.max(
          actionIndex + actionMatch[0].length,
          objectIndex + objectMatch[0].length
        );
        const between = normalizedClause.slice(start, end);
        if (
          objectIndex >= actionIndex &&
          /(?:^| )(?:never|not|no|nunca|jamais|pas|nicht|niemals)(?: |$)/u.test(
            between
          )
        ) {
          return false;
        }
        return end - start <= 140 && between.split(/\s+/).length <= 12;
      });
    });
  }

  function clauseHasCredentialExceptionRequest(normalizedClause) {
    return (
      behavioralPatternMatches(normalizedClause, "credentialObject") &&
      (/(?:never|do not|dont|no|nunca|nicht|niemals).{0,80}\b(?:send|share|provide|paste|approve|forward|upload|envoy|partag|senden|teilen|envie|comparta)\b.{0,80}\b(?:except|other than|unless|except for|sauf|au technicien|salvo|excepto|ausser)\b.{0,80}\b(?:technician|support|agent|form|chat|page|link|request|one|me|us|technicien|formulaire|soporte|tecnico|formular)\b/u.test(
        normalizedClause
      ) ||
        /(?:never|do not|dont|no|nunca|nicht|niemals|jamais).{0,120}\b(?:only|except|unless|seulement|sauf|solo|salvo|nur|ausser)\b.{0,50}\b(?:send|share|provide|paste|submit|enter|forward|upload|envoy|partag|fourn|collez|sais|envie|comparta|pegue|introdu|senden|teilen|einfug|eingeb)\b.{0,60}\b(?:technician|support|agent|form|chat|page|link|reply|below|technicien|formulaire|soporte|tecnico|pagina|enlace|formular|seite|link)\b/u.test(
          normalizedClause
        ) ||
        /(?:never|do not|dont|no|nunca|nicht|niemals|jamais).{0,100}\b(?:send|share|provide|read|say|dictate|tell)\b.{0,80}\b(?:except|unless|after|until|when)\b.{0,80}\b(?:i|we|support|agent|manager|technician)\b.{0,30}\b(?:say|tell|call|ask|request|ready)\b/u.test(
          normalizedClause
        ))
    );
  }

  function clauseHasMfaPushRequest(normalizedClause) {
    return (
      /(?:\bmfa\b|multi factor|authenticator)(?: [\p{L}\p{N}]+){0,5} \b(?:push|notification|request)\b|\b(?:push|notification)(?: [\p{L}\p{N}]+){0,5} \b(?:mfa|authenticator)\b/u.test(
        normalizedClause
      ) &&
      (clauseHasUnnegatedAction(normalizedClause, ["approve", "confirm", "accept"]) ||
        clauseHasCredentialExceptionRequest(normalizedClause))
    );
  }

  function clauseHasGiftCardEvidenceRequest(normalizedClause) {
    return (
      /\bgift card\b/u.test(normalizedClause) &&
      /\b(?:photo|picture|image|back|number|code|pin)\b/u.test(normalizedClause) &&
      clauseHasUnnegatedAction(normalizedClause, [
        "take",
        "send",
        "share",
        "provide",
        "reply with",
        "forward",
        "upload"
      ])
    );
  }

  function clauseHasCredentialFollowUpRequest(normalizedClause) {
    return (
      containsAnyTerm(normalizedClause, CREDENTIAL_FOLLOWUP_REFERENCES) &&
      clauseHasUnnegatedAction(normalizedClause, CREDENTIAL_FOLLOWUP_DISCLOSURE_TERMS)
    );
  }

  function clauseHasUnsafeInstruction(normalizedClause) {
    const clause = String(normalizedClause || "");
    if (!clause) {
      return false;
    }

    const hasCredentialObject = behavioralPatternMatches(clause, "credentialObject");
    const hasCredentialDisclosure =
      hasCredentialObject &&
      clauseHasUnnegatedAction(clause, CREDENTIAL_DISCLOSURE_TERMS);
    const hasRiskyCredentialSurface =
      behavioralPatternMatches(clause, "riskySurface") ||
      /(?:\bhere\b|\bbelow\b|following (?:link|button|page)|this (?:link|button|form)|by repl(?:y|ying)|in (?:a )?reply)/u.test(
        clause
      );
    const hasSecretExfiltration =
      hasCredentialDisclosure &&
      /(?:send|share|provide|paste|submit|reply|email|give|forward|copy|upload|envoy|partag|fourn|repond|senden|teilen|invia|condividi|envie|comparta)/u.test(
        clause
      );
    const hasSensitiveDataInstruction =
      patternHasUnnegatedMatch(clause, "sensitiveAction") &&
      behavioralPatternMatches(clause, "sensitiveObject") &&
      (behavioralPatternMatches(clause, "riskySurface") || /\b(?:here|below|reply|email|upload)\b/u.test(clause));
    const hasDangerousMoneyInstruction =
      patternHasUnnegatedMatch(clause, "bankChange") ||
      (clauseHasUnnegatedMoneyAction(clause) &&
        /(?:gift card|voucher|bitcoin|crypto|usdt|wallet|new beneficiary|bank detail|routing detail)/u.test(
          clause
        ));

    return Boolean(
      (hasCredentialDisclosure && hasRiskyCredentialSurface) ||
        hasSecretExfiltration ||
        hasSensitiveDataInstruction ||
        hasDangerousMoneyInstruction ||
        clauseHasAuthenticatorCodeRequest(clause) ||
        clauseHasCredentialExceptionRequest(clause) ||
        clauseHasMfaPushRequest(clause) ||
        clauseHasGiftCardEvidenceRequest(clause) ||
        clauseHasUnnegatedRemoteAccessInstruction(clause)
    );
  }

  function contentHasRiskyCredentialPhrase(normalizedClauses, phrase) {
    if (normalizedClauses.some((clause) => clauseHasRiskyCredentialPhrase(clause, phrase))) {
      return true;
    }
    if (!contextualCredentialPhrases().has(phrase.normalized)) {
      return false;
    }

    for (let index = 0; index < normalizedClauses.length; index += 1) {
      if (!contentTextHasPhrase(normalizedClauses[index], phrase)) {
        continue;
      }
      if (
        normalizedClauses
          .slice(index + 1, index + 3)
          .some((clause) => clauseHasCredentialFollowUpRequest(clause))
      ) {
        return true;
      }
    }
    return false;
  }

  function clauseIsRoutineInPersonIdentityCheck(clause) {
    return /(?:\b(?:bring|present|show)\b(?: [\p{L}\p{N}]+){0,5} (?:passport|identity card|id)(?: [\p{L}\p{N}]+){0,7} (?:in person|appointment|office|counter|desk)|(?:in person|office|counter|desk)(?: [\p{L}\p{N}]+){0,7} \b(?:bring|present|show)\b(?: [\p{L}\p{N}]+){0,5} (?:passport|identity card|id))/u.test(
      clause
    );
  }

  function contentHasSignalPhrase(
    normalizedText,
    normalizedClauses,
    personalInfoRiskText,
    paymentRiskText,
    group,
    phrase
  ) {
    if (group.id === "credentials") {
      return contentHasRiskyCredentialPhrase(normalizedClauses, phrase);
    }
    if (group.id === "personal-info") {
      return contentTextHasPhrase(personalInfoRiskText, phrase);
    }
    if (group.id === "payment") {
      return contentTextHasPhrase(paymentRiskText, phrase);
    }
    if (group.id === "reward") {
      return normalizedClauses.some(
        (clause) =>
          contentTextHasPhrase(clause, phrase) &&
          !/(?:book club|reading group|novel|fiction)(?: [\p{L}\p{N}]+){0,8} (?:discuss|review|plot|story)/u.test(
            clause
          )
      );
    }
    if (group.id === "delivery") {
      return normalizedClauses.some(
        (clause) =>
          contentTextHasPhrase(clause, phrase) &&
          !clauseIsRoutineInPersonIdentityCheck(clause) &&
          !/(?:customs training|training example|course example)(?: [\p{L}\p{N}]+){0,10} (?:describe|explain|review|show|use)/u.test(
            clause
          )
      );
    }

    if (!["impersonation", "link-pressure", "urgency"].includes(group.id)) {
      return contentTextHasPhrase(normalizedText, phrase);
    }

    return normalizedClauses.some((clause) => {
      if (!contentTextHasPhrase(clause, phrase)) {
        return false;
      }

      const phrasePattern = escapeRegExp(phrase.normalized).replace(/\s+/g, "\\s+");
      for (const match of clause.matchAll(new RegExp(phrasePattern, "g"))) {
        if (!actionIsNegated(clause, match.index || 0)) {
          return true;
        }
      }
      return false;
    });
  }

  function behavioralPatternMatches(clause, patternName) {
    return BEHAVIOR_PATTERNS[patternName].test(clause);
  }

  // Behavioral rules below describe relationships, not independent keyword
  // scores. Keep every required part inside one clause or a short adjacent
  // clause window so unrelated material elsewhere in a long message cannot be
  // assembled into an attack.
  function textHasBoundedPatternCombination(
    text,
    patterns,
    maximumCharacters = 300,
    maximumWords = 34
  ) {
    const spanGroups = patterns.map((pattern) => {
      const flags = pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`;
      return [...text.matchAll(new RegExp(pattern.source, flags))]
        .slice(0, 16)
        .map((match) => ({
          start: match.index || 0,
          end: (match.index || 0) + match[0].length
        }));
    });
    if (spanGroups.some((spans) => spans.length === 0)) {
      return false;
    }

    function search(groupIndex, start, end) {
      if (groupIndex >= spanGroups.length) {
        const boundedText = text.slice(start, end).trim();
        return (
          end - start <= maximumCharacters &&
          boundedText.split(/\s+/u).filter(Boolean).length <= maximumWords
        );
      }
      return spanGroups[groupIndex].some((span) => {
        const combinedStart = Math.min(start, span.start);
        const combinedEnd = Math.max(end, span.end);
        if (combinedEnd - combinedStart > maximumCharacters) {
          return false;
        }
        return search(groupIndex + 1, combinedStart, combinedEnd);
      });
    }

    return spanGroups[0].some((span) => search(1, span.start, span.end));
  }

  function textHasUnnegatedPattern(text, pattern) {
    const flags = pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`;
    for (const match of text.matchAll(new RegExp(pattern.source, flags))) {
      if (!actionIsNegated(text, match.index || 0, match[0].length)) {
        return true;
      }
    }
    return false;
  }

  function actionFollowsCompletedStatusConjunction(text, actionIndex) {
    const prefix = text.slice(Math.max(0, actionIndex - 220), actionIndex).trim();
    return /(?:password reset(?: [\p{L}\p{N}]+){0,6} completed|payment account(?: [\p{L}\p{N}]+){0,6} unchanged|workflow status requires no action|ticket(?: [\p{L}\p{N}]+){0,8} qr(?: [\p{L}\p{N}]+){0,8} only(?: [\p{L}\p{N}]+){0,4} gate|support policy(?: [\p{L}\p{N}]+){0,18} never|clinic(?: [\p{L}\p{N}]+){0,3} already (?:paid|covered)|reinitialisation(?: [\p{L}\p{N}]+){0,6} terminee|compte de paiement(?: [\p{L}\p{N}]+){0,6} inchange|statut(?: [\p{L}\p{N}]+){0,5} aucune action|ticket(?: [\p{L}\p{N}]+){0,8} qr(?: [\p{L}\p{N}]+){0,8} uniquement(?: [\p{L}\p{N}]+){0,4} portillon|politique d assistance(?: [\p{L}\p{N}]+){0,18} jamais|clinique(?: [\p{L}\p{N}]+){0,3} deja paye|restablecimiento(?: [\p{L}\p{N}]+){0,6} finalizado|cuenta de pago(?: [\p{L}\p{N}]+){0,6} sigue igual|estado(?: [\p{L}\p{N}]+){0,5} sin accion|billete(?: [\p{L}\p{N}]+){0,8} qr(?: [\p{L}\p{N}]+){0,8} solo(?: [\p{L}\p{N}]+){0,4} torno|politica de soporte(?: [\p{L}\p{N}]+){0,18} nunca|clinica(?: [\p{L}\p{N}]+){0,3} ya pago|passwortanderung(?: [\p{L}\p{N}]+){0,6} abgeschlossen|zahlungskonto(?: [\p{L}\p{N}]+){0,6} unverandert|status(?: [\p{L}\p{N}]+){0,5} keine aktion|ticket(?: [\p{L}\p{N}]+){0,8} qr(?: [\p{L}\p{N}]+){0,8} nur(?: [\p{L}\p{N}]+){0,4} sperre|fernsupport regel(?: [\p{L}\p{N}]+){0,18} nie|klinik(?: [\p{L}\p{N}]+){0,3} bereits bezahlt)(?: [\p{L}\p{N}]+){0,8} (?:and|but|yet|however|et|mais|pourtant|y|pero|sin embargo|und|aber|jedoch)$/u.test(
      prefix
    );
  }

  function textHasUnnegatedDirectRequest(text, actionPattern) {
    const flags = actionPattern.flags.includes("g")
      ? actionPattern.flags
      : `${actionPattern.flags}g`;
    for (const match of text.matchAll(new RegExp(actionPattern.source, flags))) {
      const actionIndex = match.index || 0;
      const prefix = text.slice(Math.max(0, actionIndex - 48), actionIndex).trim();
      const suffix = text
        .slice(actionIndex + match[0].length, actionIndex + match[0].length + 80)
        .trim();
      const directlyNegated =
        /(?:^| )(?:do not|dont|never|no|nunca|jamais|ne|n|niemals|nicht)$/u.test(
          prefix
        );
      const germanPostposedNegationMatch = suffix.match(
        /^((?:[\p{L}\p{N}]+ ){0,8})(?:nicht|niemals|kein(?:e|en|em|er|es)?)\b/u
      );
      const germanPostposedNegation = Boolean(
        germanPostposedNegationMatch &&
          !/(?:^| )(?:damit|dass|sodass|weil|wenn|bevor|nachdem|obwohl|um)(?: |$)/u.test(
            germanPostposedNegationMatch[1]
          )
      );
      if (
        actionFollowsCompletedStatusConjunction(text, actionIndex) ||
        actionFollowsProtectivePolicyConjunction(
          text,
          actionIndex,
          match[0].length
        ) ||
        actionRepeatsAfterNegatedConjunction(
          text,
          actionIndex,
          match[0].length
        ) ||
        (!directlyNegated &&
          !germanPostposedNegation &&
          !actionIsEducationallyReported(text, actionIndex))
      ) {
        return true;
      }
    }
    return false;
  }

  function actionIsEducationallyReported(clause, actionIndex) {
    const prefix = clause.slice(Math.max(0, actionIndex - 220), actionIndex).trim();
    const attributedExample =
      /(?:attackers?|scammers?|fraudsters?|criminals?|fake (?:emails?|messages?|receipts?|requests?)|training examples?|education examples?|attaquants?|escrocs?|fraudeurs?|faux (?:courriels?|messages?|recus?|demandes?)|exemples? de formation|atacantes?|estafadores?|delincuentes?|correos? falsos?|mensajes? falsos?|ejemplos? de formacion|angreifer|betruger|gefangte nachrichten|schulungsbeispiele?)(?: [\p{L}\p{N}]+){0,24} (?:ask|asks|asked|asking|tell|tells|told|telling|request|requests|requested|requesting|instruct|instructs|instructed|claim|claims|claimed|demand|demands|demanded|demande|demandent|demanderaient|disent|demander|pedir(?:le|les)?|piden|solicitar(?:le|les)?|solicitan|indican|dicen|fordern|fordert|auffordern|sagen|behaupten)(?: [\p{L}\p{N}]+){0,18}$/u.test(
        prefix
      );
    const passiveEducationalModal =
      /(?:(?:you|users?|recipients?) (?:may|might|can|could) be (?:asked|told|instructed|requested) to|(?:il )?peut vous etre (?:demande|dit|ordonne) de|vous pourriez etre (?:invite|incite) a|(?:se le puede|puede que le) (?:pedir|pidan|decir|digan|indicar|indiquen)(?: que| a)?|sie (?:konnen|konnten) (?:aufgefordert|angewiesen|gebeten) werden)(?: [\p{L}\p{N}]+){0,18}$/u.test(
        prefix
      );
    const describedTrainingRequest =
      /\b(?:a )?request to(?: [\p{L}\p{N}]+){0,14}$/u.test(prefix) &&
      !/\bfraud indicator\b/u.test(prefix.slice(-140));
    const rejectedEmailRequest =
      /\b(?:reject|ignore|report) any (?:email|message|request)(?: [\p{L}\p{N}]+){0,8} asking(?: you| users?| recipients?)? to(?: [\p{L}\p{N}]+){0,14}$/u.test(
        prefix
      ) && !/\bverified independently\b/u.test(prefix.slice(-140));
    const protectedEmailObject =
      /\b(?:reject|ignore|report) any$/u.test(prefix);
    return (
      attributedExample ||
      passiveEducationalModal ||
      describedTrainingRequest ||
      rejectedEmailRequest ||
      protectedEmailObject
    );
  }

  function actionRestartsAfterProtectiveInstruction(clause, actionIndex) {
    const prefix = clause.slice(Math.max(0, actionIndex - 220), actionIndex).trim();
    const protectiveCompletion =
      /(?:\b(?:you|users?|recipients?|staff|customers?)?(?: (?:must|should|need to))? never (?:comply|obey|follow|respond|react|proceed|act|do (?:it|this|that))\b|\b(?:vous )?(?:ne devez )?jamais (?:obeir|suivre|repondre|reagir|agir|faire cela)\b|\bnunca (?:debe|debes|deben)? ?(?:obedecer|seguir|responder|reaccionar|actuar|hacerlo)\b|\b(?:sie )?(?:durfen|sollten|mussen)? ?niemals (?:gehorchen|folgen|reagieren|handeln|darauf eingehen)\b)/gu;
    let lastCompletion = null;
    for (const match of prefix.matchAll(protectiveCompletion)) {
      lastCompletion = match;
    }
    if (!lastCompletion) {
      return false;
    }

    const completionEnd = (lastCompletion.index || 0) + lastCompletion[0].length;
    const between = prefix.slice(completionEnd).trim();
    const betweenWords = between.split(/\s+/u).filter(Boolean);
    if (betweenWords.length > 8) {
      return false;
    }
    if (!between) {
      return true;
    }

    const restartsExplicitly =
      /\b(?:now|then|instead|next|maintenant|desormais|ensuite|ahora|entonces|ahora si|jetzt|danach|stattdessen)\b/u.test(
        between
      );
    const continuesProtectiveInstruction =
      /(?:^| )(?:or|nor|and|ou|ni|et|o|y|und|oder)(?: [\p{L}\p{N}]+){0,3}$/u.test(
        between
      ) ||
      /(?:^| )(?:to|by|de|a|al|en|zu|durch)$/u.test(between);
    return restartsExplicitly || !continuesProtectiveInstruction;
  }

  function actionIsSafeProtectiveFollowUp(clause, actionIndex, actionText) {
    const action = String(actionText || "").trim();
    const suffix = clause.slice(actionIndex, actionIndex + 240);
    const internalSafetyTeam =
      /(?:\b(?:it|internal|company|corporate) security(?: team|desk)?\b|\binternal (?:fraud|it)(?: team|desk)?\b|\b(?:your )?fraud team\b|equipe (?:interne )?(?:de securite|anti fraude)|equipo (?:interno )?(?:de seguridad|contra el fraude)|intern(?:e|en|er|es)? (?:sicherheits|betrugs|it) ?team)/u.test(
        suffix
      );
    const trustedInternalRoute =
      /(?:usual help desk|company directory|internal directory|official (?:internal )?(?:security )?portal|usual (?:security )?app|service d assistance habituel|annuaire de l entreprise|portail (?:interne )?officiel|application habituelle|mesa de ayuda habitual|directorio de la empresa|portal (?:interno )?oficial|aplicacion habitual|ublicher helpdesk|firmenverzeichnis|offizielles internes portal|ubliche app)/u.test(
        suffix
      );
    const reportsMessage =
      /(?:report|flag|signal|signalez|signaler|denuncie|denunciar|melden)(?: [\p{L}\p{N}]+){0,5} (?:message|email|mail|request|attempt|courriel|demande|mensaje|correo|solicitud|nachricht|anfrage)/u.test(
        suffix
      );
    const messageOnlyForward =
      /(?:send|forward|email|envoyez|faites suivre|envie|reenvie|senden sie|leiten sie weiter)(?: [\p{L}\p{N}]+){0,4} (?:message|email|mail|request|attempt|courriel|demande|mensaje|correo|solicitud|nachricht|anfrage)/u.test(
        suffix
      );
    const containsSensitivePayload =
      /(?:password|passcode|security code|verification code|session key|private key|recovery phrase|seed phrase|wallet|mot de passe|code de securite|cle de session|contrasena|clave de sesion|passwort|sitzungsschlussel)/u.test(
        suffix
      );

    if (
      /^(?:contact|call|dial|ring|write|contactez|appelez|telephonez|ecrivez|contacte|llame|marque|escriba|kontaktieren sie|rufen sie|schreiben sie)$/u.test(
        action
      )
    ) {
      return internalSafetyTeam && trustedInternalRoute && !containsSensitivePayload;
    }
    if (
      /^(?:open|use|ouvrez|utilisez|abra|use|offnen sie|verwenden sie)$/u.test(action)
    ) {
      return trustedInternalRoute && reportsMessage && !containsSensitivePayload;
    }
    if (
      /^(?:send|forward|email|envoyez|faites suivre|envie|reenvie|senden sie|leiten sie weiter)$/u.test(
        action
      )
    ) {
      return internalSafetyTeam && messageOnlyForward && !containsSensitivePayload;
    }
    return false;
  }

  function clauseHasDirectUnnegatedRequest(clause) {
    const directAction =
      /\b(?:pay|send|email|transfer|wire|remit|settle|deposit|approve|cover|buy|purchase|replace|route|resolve|forward|give|call|dial|ring|install|download|open|run|start|launch|scan|use|reauthenticate|re authenticate|sign in|log in|enter|provide|submit|upload|reply|share|paste|confirm|choose|schedule|update|reset|verify|contact|write|claim|payez|envoyez|transferez|versez|reglez|deposez|couvrez|achetez|remplacez|faites suivre|donnez|appelez|telephonez|installez|telechargez|ouvrez|executez|demarrez|lancez|scannez|utilisez|reauthentifiez|connectez|saisissez|fournissez|soumettez|repondez|partagez|collez|confirmez|approuvez|choisissez|programmez|mettez a jour|reinitialisez|verifiez|contactez|ecrivez|reclamez|pague|paga|paguela|paguelo|envie|envia|enviemela|enviemelo|transfiera|liquide|deposite|cubra|compre|sustituya|reenvie|dele|llame|marque|instale|descargue|abra|ejecute|inicie|lance|escanee|use|reautentique|inicie sesion|inicia sesion|introduzca|ingrese|proporcione|responda|comparta|pegue|confirme|apruebe|elija|programe|actualice|restablezca|verifique|contacte|escriba|reclame|zahlen sie|senden sie|uberweisen sie|begleichen sie|einzahlen sie|decken sie|kaufen sie|ersetzen sie|leiten sie weiter|geben sie|rufen sie|installieren sie|laden sie|offnen sie|fuhren sie aus|starten sie|scannen sie|verwenden sie|authentifizieren sie sich erneut|melden sie sich an|teilen sie|einfugen sie|bestatigen sie|genehmigen sie|wahlen sie|aktualisieren sie|zurucksetzen sie|uberprufen sie|kontaktieren sie|schreiben sie)\b/gu;

    for (const match of clause.matchAll(directAction)) {
      const actionIndex = match.index || 0;
      const immediatePrefix = clause
        .slice(Math.max(0, actionIndex - 24), actionIndex)
        .trim();
      if (
        match[0] === "email" &&
        /(?:^| )(?:by|via|per)$/u.test(immediatePrefix)
      ) {
        continue;
      }
      const protectiveRestart = actionRestartsAfterProtectiveInstruction(
        clause,
        actionIndex
      );
      const completedStatusRestart = actionFollowsCompletedStatusConjunction(
        clause,
        actionIndex
      );
      if (
        protectiveRestart &&
        actionIsSafeProtectiveFollowUp(clause, actionIndex, match[0])
      ) {
        continue;
      }
      if (
        (protectiveRestart ||
          completedStatusRestart ||
          !actionIsNegated(clause, actionIndex, match[0].length)) &&
        (protectiveRestart ||
          completedStatusRestart ||
          !actionIsEducationallyReported(clause, actionIndex))
      ) {
        return true;
      }
    }
    return false;
  }

  function clauseHasExplicitEducationFrame(clause) {
    return /\b(?:(?:security|fraud|phishing|awareness) training|security awareness|training (?:examples?|reminders?)|security education|fraud (?:indicators?|awareness)|policy workshop|callback phishing|seminar|example of (?:fraud|phishing|an? attack|a scam)|attackers? may ask|fake receipts? (?:often )?tell recipients?|formation(?: de securite| anti fraude)?|exemples? de (?:formation|phishing|fraude)|sensibilisation(?: a la fraude| au phishing)?|indicateurs? de fraude|seminaire|formacion(?: de seguridad| contra el fraude)?|ejemplos? de (?:formacion|phishing|fraude)|concienciacion(?: sobre el fraude| contra el phishing)?|indicadores? de fraude|seminario|sicherheitsschulung|betrugsschulung|schulungsbeispiele?|betrugszeichen|seminar|beispiel(?:e)? fur (?:phishing|betrug))\b/u.test(
      clause
    );
  }

  function textHasProtectiveEducationInstruction(text) {
    return /\b(?:never|do not|dont|will not|would not|should not|must not|fictional example|no action (?:is )?(?:needed|required)|contains no|no investment is being offered|not being offered|report such|reject (?:it|them|such|the request|any (?:email|message|request))|refuse (?:it|them|such|the request)|jamais|ne [\p{L} ]{0,36} pas|n[\p{L}]+ [\p{L} ]{0,30} pas|aucun placement n est propose|aucune action (?:n est )?(?:requise|necessaire)|signalez|refusez|rejetez|nunca|no se ofrece inversion|no (?:envie|pague|llame|instale|comparta|introduzca|responda|pediremos|exigen|amenazan|contiene|hay)|sin accion (?:necesaria|requerida)|denuncie|rechace|niemals|nicht|kein(?:e|en|em|er|es)?|es wird keine anlage angeboten|keine aktion erforderlich|lehnen sie [\p{L} ]{0,24} ab|melden sie (?:dies|den betrug|verdachtige|solche))\b/u.test(
      text
    );
  }

  function clauseHasProtectiveCredentialReview(clause) {
    const deniedCredentialTransmission =
      /nenvoyez jamais(?: [\p{L}\p{N}]+){0,3} mot de passe(?: [\p{L}\p{N}]+){0,4} nombre dauthentification/u.test(
        clause
      );
    const trustedInternalReportRoute =
      /(?:consultez|ouvrez|visitez)(?: [\p{L}\p{N}]+){0,3} portail interne favori(?: [\p{L}\p{N}]+){0,5} rapport/u.test(
        clause
      );
    return (
      deniedCredentialTransmission &&
      trustedInternalReportRoute &&
      !clauseHasDirectUnnegatedRequest(clause)
    );
  }

  function hasEducationalSafetyFrame(normalizedClauses, index) {
    const clause = normalizedClauses[index] || "";
    const nearbySafety = [clause, normalizedClauses[index + 1] || ""].join(" ");
    return (
      clauseHasExplicitEducationFrame(clause) &&
      textHasProtectiveEducationInstruction(nearbySafety) &&
      !clauseHasDirectUnnegatedRequest(clause)
    );
  }

  function clauseHasExplicitSafetyExampleFrame(clause) {
    const text = String(clause || "").trim();
    if (!text) {
      return false;
    }

    const educationFrame =
      /(?:security awareness|security drill|security lesson|awareness (?:note|training|exercise)|training example|fraud training|customs training|consumer alert|travel course|anti fraud (?:bulletin|review|guide|notice|specimen)|fraud bulletin|policy example|investor education|scam awareness lesson|travel guidance|exercice de sensibilisation|exercice de securite|lecon de securite|note de sensibilisation|exemple de formation|formation(?: financiere)?|alerte aux consommateurs|cours de voyage|bulletin antifraude|analyse antifraude|guide antifraude|avis antifraude|specimen antifraude|exemple de procedure|lecon antifraude|conseil aux voyageurs|simulacro de concienciacion|simulacro de seguridad|leccion de seguridad|aviso educativo|ejemplo formativo|formacion|alerta al consumidor|curso de viaje|boletin antifraude|revision antifraude|guia antifraude|aviso antifraude|muestra antifraude|ejemplo de la politica|educacion financiera|leccion sobre estafas|guia de viaje|sicherheitsubung|sicherheitslektion|sicherheitshinweis|schulungsbeispiel|schulung|verbraucherwarnung|reisekurs|betrugsmerkblatt|betrugsprufung|betrugsleitfaden|betrugshinweis|betrugsbeispiel|richtlinienbeispiel|anlegerbildung|betrugsschulung|reisehinweis)/u;
    if (!educationFrame.test(text)) {
      return false;
    }

    // The risky wording must be explicitly characterized as teaching material,
    // fiction, or a rejected warning example. A real imperative after that
    // characterization remains visible to the normal behavioral rules.
    const conclusion =
      /(?:simulation|warning example|warning signs?|fraud signals?|scam pattern|hypothetical|fictional|false example|fraudulent example|labels?(?: [\p{L}\p{N}]+){0,10} as fraud|warning only|only as (?:a )?warning|shown as|quoted request|quotes?|describes?|explains?(?: [\p{L}\p{N}]+){0,10} scams?|illustrat(?:es?|ing)|reject(?:s|ed)? the claim|recogniz(?:e|ing) extortion|not a real award|exemple(?: d alerte| de pression)?|exemple frauduleux|simulation|signaux? d alerte|signalent une fraude|comme hypothese|illustre une fraude|comme avertissement|fictif|fictive|faux exemple|refuter|pas un vrai gain|reconnaitre l extorsion|ejemplo(?: de alerta| de presion)?|ejemplo fraudulento|simulacro|senales? de alarma|indican fraude|como supuesto|patron de estafa|fictici[oa]|ejemplo falso|rechazar la promesa|no es real|reconocer la extorsion|warnbeispiel|betrugerisches beispiel|betrugsmuster|warnzeichen|hypothetisch|simuliert|erfunden|falsches beispiel|zuruckzuweisen|kein echter preis|erpressung erkennbar)/gu;
    let lastConclusionEnd = -1;
    for (const match of text.matchAll(conclusion)) {
      lastConclusionEnd = Math.max(
        lastConclusionEnd,
        (match.index || 0) + match[0].length
      );
    }
    if (lastConclusionEnd < 0) {
      return false;
    }

    const laterText = text.slice(lastConclusionEnd).trim();
    return (
      !clauseHasUnsafeInstruction(laterText) &&
      !clauseHasDirectUnnegatedRequest(laterText)
    );
  }

  function clauseIsExplicitlyNonActionableNotice(clause) {
    const text = String(clause || "").trim();
    if (!text) {
      return false;
    }

    const denialOrCompletedStatus =
      /(?:\b(?:nobody|no one) needs\b|\b(?:does|will|would) not (?:open|request|ask|require|authorize|change|direct|offer)\b|\bnever (?:asks?|requests?|requires?|initiates?)\b|\bneither [\p{L}\p{N} ]{0,70}(?:changes?|authorizes?|requests?|requires?)\b|\b(?:offers|requests|asks for|contains) no\b|\bno [\p{L}\p{N} ]{0,70}\b(?:awaits?|awaiting|needed|requires?|required|requested|scheduled|held|seized|due|pending|associated)\b|\brequested(?: [\p{L}\p{N}]+){0,8} (?:has )?completed\b|\b(?:invoice|payment)(?: [\p{L}\p{N}]+){0,6} (?:was|has been) paid\b|\bbank details have not changed\b|\breceipt only\b|\bpassed dual review\b|\bremains? unchanged\b|\balready (?:paid|covered)\b|\bnot permitted\b|(?:^| )personne n a besoin\b|(?:^| )(?:ne|n) [\p{L} ]{0,50} (?:demande|modifie|autorise|ouvre|reclame|propose|exige)[\p{L} ]{0,12} (?:pas|jamais)\b|(?:^| )aucun(?:e)? [\p{L} ]{0,60}(?:attend|retenu|demande|du|associe|requis)\b|\breste inchange\b|\best terminee?\b|\bdeja paye\b|\bn exige jamais\b|(?:^| )nadie necesita\b|(?:^| )no [\p{L} ]{0,60}(?:hay|existe|ofrece|pide|solicita|requiere|necesita|debe|esta retenid|esta pendiente|esta asociado)\b|\bnunca (?:pide|solicita|exige|inicia)\b|\bsigue igual\b|\bha finalizado\b|\bya pago\b|\bno se permite\b|(?:^| )niemand benotigt\b|(?:^| )kein(?:e|en|em|er|es)? [\p{L} ]{0,60}(?:wartet|fallig|verlangt|benotigt|geplant|festgehalten|beschlagnahmt|verbunden)\b|\b(?:fragt|fordert|verlangt|beginnt) nie\b|\bbleibt unverandert\b|\bist abgeschlossen\b|\bbereits bezahlt\b|\bnicht erlaubt\b|\bverboten\b)/u.test(
        text
      );
    const clearlyCompletedOrSafePurpose =
      /(?:password reset(?: [\p{L}\p{N}]+){0,6} completed|existing payment account remains unchanged|workflow status requires no action|rail ticket(?: [\p{L}\p{N}]+){0,8} qr(?: [\p{L}\p{N}]+){0,8} only at the gate|remote support policy(?: [\p{L}\p{N}]+){0,18} never|clinic already (?:paid|covered)|reinitialisation(?: [\p{L}\p{N}]+){0,6} terminee|compte de paiement(?: [\p{L}\p{N}]+){0,5} reste inchange|qr(?: [\p{L}\p{N}]+){0,8} uniquement au portillon|regle d assistance distante(?: [\p{L}\p{N}]+){0,18} jamais|clinique a deja paye|restablecimiento(?: [\p{L}\p{N}]+){0,6} finalizado|cuenta de pago(?: [\p{L}\p{N}]+){0,5} sigue igual|qr(?: [\p{L}\p{N}]+){0,8} solo se usa en el torno|politica de soporte remoto(?: [\p{L}\p{N}]+){0,18} nunca|clinica ya pago|passwortanderung(?: [\p{L}\p{N}]+){0,6} abgeschlossen|zahlungskonto(?: [\p{L}\p{N}]+){0,5} bleibt unverandert|qr code(?: [\p{L}\p{N}]+){0,8} nur fur die sperre|fernsupport regel(?: [\p{L}\p{N}]+){0,18} nie|klinik hat bezahlt)/u.test(
        text
      );
    if (!denialOrCompletedStatus && !clearlyCompletedOrSafePurpose) {
      return false;
    }

    const stillAdverse =
      /(?:\b(?:account|access|mailbox)\b(?: [\p{L}\p{N}]+){0,5} \b(?:suspended|restricted|blocked|locked|removed)\b|\b(?:compte|acces|messagerie)\b(?: [\p{L}\p{N}]+){0,5} \b(?:suspendu|restreint|bloque|retire)\b|\b(?:cuenta|acceso|correo)\b(?: [\p{L}\p{N}]+){0,5} \b(?:suspendid|restringid|bloquead|retirad)\b|\b(?:konto|zugang|postfach)\b(?: [\p{L}\p{N}]+){0,5} \b(?:gesperrt|eingeschrankt|entfernt)\b)/u.test(
        text
      );
    if (stillAdverse && !clearlyCompletedOrSafePurpose) {
      return false;
    }

    const restartedRequest =
      /(?:^| )(?:but|however|instead|now|then|next|please|kindly|must|need to|maintenant|ensuite|veuillez|devez|ahora|entonces|debe|debes|jetzt|danach|bitte|mussen)(?: [\p{L}\p{N}]+){0,7} (?:send|share|provide|enter|submit|reply|pay|transfer|buy|install|scan|call|envoy|partag|fourn|sais|repond|pay|transfer|achet|envie|comparta|introdu|respon|pague|transfier|instale|escanee|llame|senden|teilen|eingeben|zahlen|uberweisen|installieren|scannen|rufen)/u.test(
        text
      );
    if (restartedRequest) {
      return false;
    }

    const safeOwnedSupportTicket =
      /(?:open your own service ticket|ouvrez votre propre ticket d assistance|abra usted mismo un ticket|eroffnen sie selbst ein ticket)/u.test(
        text
      ) &&
      !/(?:password|security code|access code|session key|mot de passe|code de securite|contrasena|codigo de acceso|passwort|zugangscode)/u.test(
        text.slice(text.search(/(?:open your own|ouvrez votre propre|abra usted|eroffnen sie)/u))
      );
    if (clauseHasDirectUnnegatedRequest(text) && !safeOwnedSupportTicket) {
      return false;
    }

    return clearlyCompletedOrSafePurpose || !clauseHasUnsafeInstruction(text);
  }

  function clauseIsProtectivePolicyStatement(clause) {
    const text = String(clause || "").trim();
    if (!text) {
      return false;
    }

    // Product and security notices often enumerate exactly the secrets or
    // payment methods that support will never request. Keep this exemption
    // clause-local and require a complete denial frame: a later sentence (or
    // an explicitly restarted imperative in this clause) is still analyzed.
    const protectivePolicy =
      /^(?:(?:our|the|customer|technical|security|it) )?(?:support|service|team|staff|company|we|it|security)(?: [\p{L}\p{N}]+){0,6} (?:will not|would not|does not|do not|never) (?:ask|request|require)(?: [\p{L}\p{N}]+){0,36}(?: by (?:email|e mail|message)| in (?:an )?(?:email|e mail|message))?$|^(?:le |notre |la )?(?:support|service|equipe|securite|informatique)(?: [\p{L}\p{N}]+){0,5} ne (?:demande|demandera|sollicite|exige)(?: [\p{L}\p{N}]+){0,4} jamais(?: [\p{L}\p{N}]+){0,36}(?: par (?:courriel|email|message))?$|^(?:el |nuestro )?(?:soporte|servicio|equipo|seguridad|informatica)(?: [\p{L}\p{N}]+){0,5} nunca (?:pide|pedira|solicita|exige)(?: [\p{L}\p{N}]+){0,36}(?: por (?:correo|email|mensaje))?$|^(?:der |unser )?(?:support|dienst|team|sicherheit|it)(?: [\p{L}\p{N}]+){0,6} (?:fragt|fordert|verlangt)(?: [\p{L}\p{N}]+){0,5} (?:nie|niemals)(?: [\p{L}\p{N}]+){0,36}(?: per (?:e mail|email|nachricht))?$/u.test(
        text
      );
    const financeGiftCardPolicy =
      /^(?:policy reminder )?finance(?: [\p{L}\p{N}]+){0,4} never asks(?: [\p{L}\p{N}]+){0,8} (?:purchase|buy) gift cards?(?: [\p{L}\p{N}]+){0,8} reply(?: [\p{L}\p{N}]+){0,5} (?:numbers?|codes?)$/u.test(
        text
      );
    if (!protectivePolicy && !financeGiftCardPolicy) {
      return false;
    }

    const restartedRequest =
      /(?:^| )(?:but|however|instead|now|then|next|please|kindly|must|need to|maintenant|ensuite|veuillez|devez|ahora|entonces|debe|debes|jetzt|danach|bitte|mussen)(?: [\p{L}\p{N}]+){0,6} (?:send|share|provide|enter|submit|reply|pay|transfer|buy|install|scan|call|envoy|partag|fourn|sais|repond|pay|transfer|achet|envie|comparta|introdu|respon|pague|transfier|instale|escanee|llame|senden|teilen|eingeben|zahlen|uberweisen|installieren|scannen|rufen)/u.test(
        text
      ) ||
      /(?:^| )(?:and|et|y|und)(?: please| maintenant| ahora| jetzt)? (?:send|share|provide|enter|submit|reply|pay|transfer|buy|install|scan|call|envoyez|partagez|fournissez|saisissez|repondez|payez|transferez|achetez|envie|comparta|introduzca|responda|pague|transfiera|instale|escanee|llame|senden sie|teilen sie|geben sie|zahlen sie|uberweisen sie|installieren sie|scannen sie|rufen sie)\b/u.test(
        text
      ) ||
      /(?:email|e mail|message|courriel|correo|mensaje|nachricht)(?: and| et| y| und)? (?:send|share|provide|enter|submit|reply|envoyez|partagez|fournissez|saisissez|repondez|envie|comparta|introduzca|responda|senden sie|teilen sie|geben sie)\b/u.test(
        text
      );
    return !restartedRequest;
  }

  function contentRiskClauses(normalizedClauses) {
    return normalizedClauses.filter(
      (clause, index) =>
        !hasEducationalSafetyFrame(normalizedClauses, index) &&
        !clauseHasExplicitSafetyExampleFrame(clause) &&
        !clauseIsProtectivePolicyStatement(clause) &&
        !clauseIsExplicitlyNonActionableNotice(clause)
    );
  }

  function behavioralRiskClauses(normalizedClauses) {
    // Generic receipts, completion language, or a nearby negation are context,
    // not permission to discard an entire clause. Explicit protective training
    // examples are removed by contentRiskClauses before behavioral analysis.
    return normalizedClauses.filter(Boolean);
  }

  function boundedBehavioralContexts(normalizedClauses) {
    const maximumCharacters = 520;
    const overlapCharacters = 160;
    const contexts = [];
    const seen = new Set();

    function addContext(value) {
      const text = String(value || "").trim();
      if (!text) {
        return;
      }
      if (text.length <= maximumCharacters) {
        if (!seen.has(text)) {
          seen.add(text);
          contexts.push(text);
        }
        return;
      }

      const step = maximumCharacters - overlapCharacters;
      for (let start = 0; start < text.length; start += step) {
        const window = text.slice(start, start + maximumCharacters).trim();
        if (window && !seen.has(window)) {
          seen.add(window);
          contexts.push(window);
        }
        if (start + maximumCharacters >= text.length) {
          break;
        }
      }
    }

    normalizedClauses.forEach((clause, index) => {
      addContext(clause);
      const nextClause = normalizedClauses[index + 1] || "";
      if (
        nextClause &&
        clause.length <= 300 &&
        nextClause.length <= 300 &&
        clause.length + nextClause.length + 1 <= maximumCharacters
      ) {
        addContext(`${clause} ${nextClause}`);
      }
    });

    return contexts;
  }

  function boundedNearbyClauseContexts(normalizedClauses) {
    const maximumCharacters = 520;
    const maximumClauses = 4;
    const contexts = boundedBehavioralContexts(normalizedClauses);
    const seen = new Set(contexts);

    for (let start = 0; start < normalizedClauses.length; start += 1) {
      let value = "";
      for (
        let end = start;
        end < normalizedClauses.length && end < start + maximumClauses;
        end += 1
      ) {
        const next = normalizedClauses[end] || "";
        if (!next || next.length > 360) {
          break;
        }
        value = value ? `${value} ${next}` : next;
        if (value.length > maximumCharacters) {
          break;
        }
        if (end >= start + 2 && !seen.has(value)) {
          seen.add(value);
          contexts.push(value);
        }
      }
    }

    return contexts;
  }

  function clauseHasCryptoTransferRisk(clause) {
    const hasCrypto =
      /(?:\bbitcoins?\b|\bcrypto\b|\busdt\b|cryptocurrency|stablecoin|digital currency|wallet|monnaie numerique|portefeuille|moneda digital|monedero)/u.test(
        clause
      );
    if (!hasCrypto) {
      return false;
    }

    const transferTerms = [
      "send",
      "transfer",
      "wire",
      "deposit",
      "pay",
      "remit",
      "withdraw",
      "envoyez",
      "transferez",
      "versez",
      "payez",
      "envie",
      "transfiera",
      "deposite",
      "pague",
      "senden",
      "uberweisen",
      "einzahlen",
      "zahlen"
    ];
    const hasTransferAction = clauseHasUnnegatedAction(clause, transferTerms);
    const explicitDestinationOrFee =
      /(?:wallet address|to (?:this|the|our) wallet|withdrawal fee|release deposit|adresse .*portefeuille|vers ce portefeuille|frais de retrait|depot de deblocage|direccion .*monedero|a este monedero|tasa de retiro|deposito de liberacion|wallet adresse|an diese wallet|auszahlungsgebuhr|freigabeeinzahlung)/u.test(
        clause
      );
    const directImperativeOrPressure =
      /^(?:please |kindly )?(?:send|transfer|wire|deposit|pay|remit|withdraw|envoyez|transferez|versez|payez|envie|transfiera|deposite|pague|senden sie|uberweisen sie|zahlen sie)(?= |$)|(?:\b(?:must|need|needs|required|urgent|immediately|today|now|before|within)\b|debe|debes|necesit|urgente|inmediat|hoy|ahora|antes|dentro|veuillez|devez|urgent|immediat|aujourd hui|avant|sous|mussen|dringend|sofort|heute|vor|innerhalb)(?: [\p{L}\p{N}]+){0,9} (?:send|transfer|wire|deposit|pay|remit|withdraw|envoy|transfer|verse|pay|envie|transfier|deposit|pague|send|uberweis|einzahl|zahl)/u.test(
        clause
      );
    const capabilityOrTutorial =
      /(?:\b(?:can|could|may)\b(?: [\p{L}\p{N}]+){0,3}|how to|learn(?: [\p{L}\p{N}]+){0,2} to|allows? you to|tutorial(?: [\p{L}\p{N}]+){0,3}) (?:send|transfer|receive|buy|sell)|(?:puede|puedes|como|aprenda|tutorial)(?: [\p{L}\p{N}]+){0,5} (?:enviar|transferir|recibir|comprar|vender)|(?:pouvez|comment|apprenez)(?: [\p{L}\p{N}]+){0,5} (?:envoyer|transferer|recevoir|acheter|vendre)|(?:konnen|wie|lernen sie)(?: [\p{L}\p{N}]+){0,5} (?:senden|uberweisen|empfangen|kaufen|verkaufen)/u.test(
        clause
      );

    return (
      (explicitDestinationOrFee && !capabilityOrTutorial) ||
      (hasTransferAction && directImperativeOrPressure && !capabilityOrTutorial)
    );
  }

  function clauseHasNarrativeReviewContext(clause) {
    const narrativeFrame =
      /(?:film (?:plot|review)|movie plot|screenplay|novel plot|fictional (?:story|scene)|book review)/u;
    const depictedThreat =
      /(?:private video threat|supposed video|gift card demand|gift vouchers?|extortion threat|ransom demand)/u;
    const reviewAction =
      /(?:send|submit|email)(?: [\p{L}\p{N}]+){0,4} (?:review|comments?)(?: [\p{L}\p{N}]+){0,4} (?:editor|author|publisher)/u;
    return textHasBoundedPatternCombination(
      clause,
      [narrativeFrame, depictedThreat, reviewAction],
      360,
      44
    );
  }

  function clauseHasHighRiskPaymentInstruction(clause) {
    if (clauseHasNarrativeReviewContext(clause)) {
      return false;
    }
    if (
      /(?:customs training|training slide)(?: [\p{L}\p{N}]+){0,24} (?:bad example|workshop registration)/u.test(
        clause
      ) &&
      /(?:transfer|move|change)(?: [\p{L}\p{N}]+){0,5} workshop registration/u.test(
        clause
      )
    ) {
      return false;
    }
    const completedPaymentRecord =
      /(?:received successfully|record of(?: [\p{L}\p{N}]+){0,5} (?:approved )?(?:wire transfer|payment|transfer)|(?:wire transfer|payment|transfer|virement|paiement|transferencia|pago|uberweisung|zahlung)(?: [\p{L}\p{N}]+){0,6} (?:was|were|is|has been|had been|a ete|fue|ha sido|wurde) (?:received|completed|approved|paid|recu|termine|approuve|paye|recibido|completado|aprobado|pagado|erhalten|abgeschlossen|genehmigt|bezahlt))/u.test(
        clause
      );
    const laterPaymentRequest =
      /(?:^|\b(?:please|kindly|now|today|urgent|must|need to|required to|then|next|veuillez|maintenant|urgent|devez|puis|ahora|hoy|urgente|debe|entonces|bitte|jetzt|heute|dringend|mussen|danach) )\b(?:send|pay|wire|transfer|buy|purchase|deposit|approve|envoyez|payez|transferez|achetez|deposez|approuvez|envie|pague|transfiera|compre|deposite|apruebe|senden sie|zahlen sie|uberweisen sie|kaufen sie|einzahlen sie|genehmigen sie)\b/u.test(
        clause
      );
    if (completedPaymentRecord && !laterPaymentRequest) {
      return false;
    }

    if (!clauseHasUnnegatedMoneyAction(clause)) {
      return false;
    }

    const highRiskObject =
      /(?:gift card|gaming voucher|retail voucher|beneficiary|routing detail|bank detail|wire transfer|mobile money|redelivery (?:balance|fee)|inspection amount|release (?:charge|fee|deposit)|withdrawal (?:fee|deposit)|bons? de jeu|coupons? de magasin|coupon prepay|beneficiaire|coordonnees bancaire|argent mobile|frais (?:obligatoires?|de retrait)|depot de deblocage|vales? (?:comerciales?|de videojuegos)|cupon (?:prepago|de efectivo)|beneficiario|datos bancarios|dinero movil|tasa de liberacion|deposito de liberacion|gutschein|bankverbindung|mobilgeld|freigabegebuhr|auszahlungsgebuhr|freigabeeinzahlung)/u.test(
        clause
      ) || clauseHasCryptoTransferRisk(clause);
    const pressuredTransfer =
      /(?:need|require|must|urgent|today|before(?: [\p{L}\p{N}]+){0,4} cutoff|besoin|aujourd hui|avant(?: [\p{L}\p{N}]+){0,4} cloture|necesit|hoy|antes(?: [\p{L}\p{N}]+){0,4} cierre|brauch|heute|vor(?: [\p{L}\p{N}]+){0,4} annahmeschluss)/u.test(
        clause
      ) &&
      /(?:wire|transfer|transfert|virement|transferencia|uberweisung)/u.test(clause) &&
      behavioralPatternMatches(clause, "secrecy");

    return highRiskObject || pressuredTransfer;
  }

  function clauseHasJobSchemeRisk(clause) {
    const riskClause = clause
      .replace(
        /candidates? never deposit (?:cheques?|checks?) buy starter kits? or send identity copies over chat/u,
        ""
      )
      .replace(
        /(?:candidate notice )?we never send equipment (?:cheques?|checks?) or ask applicants? to buy laptops? and return money/u,
        ""
      );
    const strongScheme =
      /(?:text only interview|equipment cheque|rate products|pay(?: [\p{L}\p{N}]+){0,4} per day|entretien uniquement par messages|cheque d equipement|noter des produits|payer(?: [\p{L}\p{N}]+){0,4} par jour|entrevista solo por mensajes|cheque de equipo|valorar productos|pagar(?: [\p{L}\p{N}]+){0,4} al dia|textinterview|geratescheck|produktbewertungen|zahlen(?: [\p{L}\p{N}]+){0,4} pro tag)/u.test(
        riskClause
      );
    const remoteRole =
      /(?:remote assistant|assistant a distance|asistente remoto|remote assistenz)/u.test(riskClause);
    const candidatePayment =
      /(?:candidate|candidat|candidato|bewerber)/u.test(riskClause) &&
      /(?:equipment|starter kit|cheque|check|supplier|private chat|equipement|kit de depart|fournisseur|messagerie privee|equipo|kit inicial|proveedor|chat privado|gerat|starterpaket|lieferant|privaten chat)/u.test(
        riskClause
      );
    const remotePayment =
      remoteRole &&
      /(?:equipment|starter kit|cheque|check|supplier|private chat|equipement|kit de depart|fournisseur|messagerie privee|equipo|kit inicial|proveedor|chat privado|gerat|starterpaket|lieferant|privaten chat)/u.test(
        riskClause
      );
    return strongScheme || candidatePayment || remotePayment;
  }

  function clauseHasFailedDeliveryAction(clause) {
    const deliveryObject =
      /(?:parcel|package|shipment|consignment|delivery|item|courier|route|colis|paquet|envoi|livraison|coursier|tournee|paquete|envio|entrega|mensajero|ruta|paket|sendung|zustellung|kurier|tour)/u;
    const failedOrHeld =
      /(?:(?:could not|couldnt|unable to|failed to|was not possible to)(?: [\p{L}\p{N}]+){0,5} (?:deliver|hand over|complete)|(?:delivery|parcel|shipment|package|consignment)(?: [\p{L}\p{N}]+){0,10} (?:failed|failure|suspended|held|waiting|incomplete|mismatch|could not be handed over|on hold)|(?:echec|impossible|n ?a pas pu|ne peut pas)(?: [\p{L}\p{N}]+){0,6} (?:livr|remet|termin)|(?:colis|paquet|envoi|livraison|tournee)(?: [\p{L}\p{N}]+){0,10} (?:echec|suspendu|retenu|attend|incomplet|incoherence|n ?a pas pu)|(?:no (?:se )?pud[\p{L}]*|no fue posible|fallo|error)(?: [\p{L}\p{N}]+){0,6} (?:entreg|complet)|(?:paquete|envio|entrega|ruta)(?: [\p{L}\p{N}]+){0,10} (?:fallid|suspendid|retenid|espera|incomplet|discrepancia|no fue posible)|(?:konnte(?: [\p{L}\p{N}]+){0,5} nicht|nicht moglich|fehlgeschlagen)(?: [\p{L}\p{N}]+){0,6} (?:zustell|ubergeb)|(?:paket|sendung|zustellung|tour)(?: [\p{L}\p{N}]+){0,10} (?:fehlgeschlagen|ausgesetzt|angehalten|wartet|unvollstandig|abweichend|konnte nicht))/u;
    const requestedDeliveryChoice =
      /(?:(?:choose|select|confirm|correct|provide|enter|update|schedule|tell us|indicate)(?: [\p{L}\p{N}]+){0,8} (?:address|street|apartment|access code|delivery (?:window|information|details|instructions)|home delivery|pickup point|where|how|second attempt|leave it)|(?:choisissez|selectionnez|confirmez|corrigez|fournissez|saisissez|mettez a jour|programmez|indiquez)(?: [\p{L}\p{N}]+){0,8} (?:adresse|rue|appartement|code d acces|creneau|informations?|consignes?|domicile|point de retrait|endroit|comment|ou|seconde tentative)|(?:elige|selecciona|confirma|corrige|facilita|introduce|ingres[ae]|actualiza|programa|indica)(?: [\p{L}\p{N}]+){0,8} (?:direccion|calle|piso|codigo de acceso|franja|informacion|instrucciones?|domicilio|punto de recogida|donde|como|segundo intento)|(?:como(?: le)? gustaria|como desea)(?: [\p{L}\p{N}]+){0,3} recibir(?: [\p{L}\p{N}]+){0,3} paquete|donde desea(?: [\p{L}\p{N}]+){0,4} entreg[\p{L}]* paquete|consulta aqui|(?:wahlen sie|bestatigen sie|korrigieren sie|geben sie|tragen sie|aktualisieren sie|planen sie|teilen sie uns)(?: [\p{L}\p{N}]+){0,8} (?:anschrift|adresse|strasse|wohnung|zugangscode|zeitfenster|informationen|zustellhinweise|hauszustellung|abholstelle|wo|wie|zweite versuch))/u;
    const directDeliveryAction =
      /(?:choose|select|confirm|correct|provide|enter|update|schedule|tell us|indicate|choisissez|selectionnez|confirmez|corrigez|fournissez|saisissez|mettez a jour|programmez|indiquez|elige|selecciona|confirma|corrige|facilita|introduce|ingres[ae]|actualiza|programa|indica|(?:como(?: le)? gustaria|como desea)(?: [\p{L}\p{N}]+){0,3} recibir|donde desea(?: [\p{L}\p{N}]+){0,4} entreg|consulta aqui|wahlen sie|bestatigen sie|korrigieren sie|geben sie|tragen sie|aktualisieren sie|planen sie|teilen sie uns)/u;
    const returnOrDeadline =
      /(?:on hold|prevent|avoid|otherwise|or it will|before|within|today|tomorrow|by noon|sent back|returned|leave the local|release it|retenu|eviter|sinon|faute de quoi|avant|dans les|aujourd hui|demain|retour|renvoye|quittera|permettre sa remise|retenid|suspendid|detenid|evitar|de lo contrario|o sera|antes|durante las|hoy|manana|devuelt|saldra|liberar|angehalten|damit|andernfalls|sonst|bevor|innerhalb|heute|morgen|zuruckgeschickt|verlasst|freigegeben)/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [deliveryObject, failedOrHeld, requestedDeliveryChoice, returnOrDeadline],
        500,
        62
      ) &&
      textHasUnnegatedDirectRequest(clause, directDeliveryAction)
    );
  }

  function clauseHasWaitingParcelTrackingAction(clause) {
    const waitingParcel =
      /(?:(?:parcel|package|shipment|delivery|paquete|envio|entrega|colis|livraison|paket|sendung|zustellung)(?: [\p{L}\p{N}]+){0,7} (?:waiting|pending|awaiting|on hold|espera|esperando|pendiente|en espera|attente|wartend|ausstehend)|(?:waiting|pending|awaiting|espera|esperando|pendiente|attente|wartend|ausstehend)(?: [\p{L}\p{N}]+){0,5} (?:parcel|package|shipment|delivery|paquete|envio|entrega|colis|livraison|paket|sendung|zustellung))/u;
    const trackingReference =
      /(?:(?:tracking|rastre|seguir|seguimiento|suivi|verfolg)(?: [\p{L}\p{N}]+){0,5} (?:code|number|codigo|numero|nummer)|(?:code|number|codigo|numero|nummer)(?: [\p{L}\p{N}]+){0,5} (?:tracking|rastre|seguir|seguimiento|suivi|verfolg))/u;
    const completionAction =
      /(?:schedule|program(?:ar|a|e)?|confirm(?:ar|a|e)?|complete|continue|receive|recibir|recibirlo|rastrear|rastrearlo|seguirlo|confirmer|programmer|recevoir|planen|bestatigen|erhalten)(?: [\p{L}\p{N}]+){0,6} (?:delivery|details|process|parcel|package|entrega|detalles|proceso|paquete|livraison|details|colis|zustellung|paket)|(?:rastrear|rastrearlo|seguirlo)(?: [\p{L}\p{N}]+){0,3} (?:recibir|recibirlo)|programa tu entrega|confirmar detalles de entrega/u;
    return (
      textHasBoundedPatternCombination(clause, [waitingParcel, trackingReference, completionAction], 320, 38) &&
      textHasUnnegatedPattern(clause, completionAction)
    );
  }

  function clauseHasCustomsReleaseRisk(clause) {
    const parcel = /(?:parcel|package|shipment|delivery|consignment|paquete|envio|entrega|colis|envoi|livraison|paket|sendung|zustellung)/u;
    const customsHold =
      /(?:retained|held|blocked|suspended|cannot leave customs|customs check|customs verification|declaration (?:is )?incomplete|declaration mismatch|retenid|bloquead|suspendi[\p{L}]*|no puede salir de aduanas|declaracion aduanera incompleta|discrepancia en la declaracion|verificacion aduanal|revision aduanal|aduana|retenu|bloque|suspendu|ne peut pas quitter la douane|declaration douaniere incomplete|incoherence de declaration|verification douaniere|douane|zuruckgehalten|angehalten|blockiert|darf den zoll erst verlassen|zollerklarung unvollstandig|abweichung in der erklarung|zollprufung|zoll)/u;
    const importCharge =
      /(?:import (?:adjustment|balance|fee|duty)|customs (?:adjustment|charge|fee|duty)|release (?:charge|duty|fee)|card payment|delivery details|recipient (?:record|details)|address|ajuste de importacion|saldo de importacion|tarifa de importacion|cargo aduan(?:al|er[oa])|tasa de liberacion|pago con tarjeta|tarjeta de pago|datos del destinatario|direccion|ajustement d importation|solde d importation|frais (?:de douane|douaniers?)|droits de sortie|paiement par carte|carte de paiement|coordonnees|adresse|einfuhr(?:anpassung|saldo|abgabe)|zollgebuhr|freigabeabgabe|kartenzahlung|zahlungskarte|empfangerdaten|anschrift|\b\d{1,4}(?: \d{2})? (?:mxn|usd|eur|gbp)\b)/u;
    const releaseAction =
      /(?:complete|confirm|release|clear|pay|submit|enter|provide)(?: [\p{L}\p{N}]+){0,8} (?:adjustment|balance|charge|duty|fee|parcel|package|shipment|delivery|address|details|card|name)|(?:completar|complete|confirma|confirme|confirmes|libera|libere|paga|pague|pagues|envia|envie|introduce|facilita)(?: [\p{L}\p{N}]+){0,8} (?:ajuste|saldo|cargo|tasa|paquete|envio|entrega|direccion|datos|tarjeta|nombre)|(?:remplir|confirmer|liberer|payer|payez|soumettez|saisissez|fournissez)(?: [\p{L}\p{N}]+){0,8} (?:ajustement|solde|frais|droits|colis|envoi|livraison|adresse|coordonnees|carte|nom)|(?:abschliessen|bestatigen|freigeben|bezahlen|ubermitteln|geben sie)(?: [\p{L}\p{N}]+){0,8} (?:anpassung|saldo|abgabe|gebuhr|zollgebuhr|paket|sendung|zustellung|anschrift|daten|empfangerdaten|karte|zahlungskarte|name)/u;
    const directReleaseAction =
      /(?:\b(?:complete|confirm|release|clear|pay|submit|enter|provide|completar|confirma|confirme|confirmes|libera|libere|paga|pague|pagues|envia|envie|introduce|facilita|remplir|confirmer|liberer|payer|payez|soumettez|saisissez|fournissez|abschliessen|bestatigen|freigeben|bezahlen|ubermitteln)\b|geben sie)/u;
    const conditionalReleaseAction =
      /(?:(?:cannot|can not|could not)(?: [\p{L}\p{N}]+){0,8} leave customs(?: [\p{L}\p{N}]+){0,8} (?:until|before)(?: [\p{L}\p{N}]+){0,8} (?:pay|payment|confirm)|ne peut pas(?: [\p{L}\p{N}]+){0,6} quitter la douane(?: [\p{L}\p{N}]+){0,8} avant(?: [\p{L}\p{N}]+){0,8} (?:paiement|confirmation)|no puede(?: [\p{L}\p{N}]+){0,6} salir de aduanas(?: [\p{L}\p{N}]+){0,8} hasta que(?: [\p{L}\p{N}]+){0,4} (?:pagues|pague|confirmes|confirme)|darf(?: [\p{L}\p{N}]+){0,8} zoll(?: [\p{L}\p{N}]+){0,8} erst(?: [\p{L}\p{N}]+){0,8} (?:zahlung|bestatigung))/u;
    const scopedReleaseAction = new RegExp(
      `(?:${releaseAction.source}|${conditionalReleaseAction.source})`,
      "u"
    );
    const completedReleaseRecord =
      /(?:(?:adjustment|fee|ajuste|tarifa|frais|gebuhr)(?: [\p{L}\p{N}]+){0,6} (?:was|were|has been|had been|fue|ha sido|a ete|wurde) (?:paid|completed|approved|pagad[oa]|completad[oa]|paye|termine|bezahlt|abgeschlossen)|(?:parcel|package|shipment|delivery|paquete|envio|entrega|colis|livraison|paket|sendung|zustellung)(?: [\p{L}\p{N}]+){0,6} (?:was|were|has been|had been|fue|ha sido|a ete|wurde) (?:released|delivered|liberad[oa]|entregad[oa]|libere|livre|freigegeben|zugestellt))/u.test(
        clause
      );
    const directReleaseRequest =
      /(?:^|\b(?:please|kindly|now|today|urgent|must|need to|required to|veuillez|maintenant|devez|ahora|hoy|urgente|debe|bitte|jetzt|heute|dringend|mussen) )\b(?:complete|confirm|release|pay|completar|confirme|libere|pague|remplir|confirmer|liberer|payer|abschliessen|bestatigen|freigeben|bezahlen)\b/u.test(
        clause
      );
    if (completedReleaseRecord && !directReleaseRequest) {
      return false;
    }
    return (
      textHasBoundedPatternCombination(
        clause,
        [parcel, customsHold, importCharge, scopedReleaseAction],
        500,
        62
      ) &&
      (textHasUnnegatedDirectRequest(clause, directReleaseAction) ||
        textHasUnnegatedPattern(clause, conditionalReleaseAction))
    );
  }

  function clauseHasAdvanceFeeWindfallRisk(clause) {
    const largeAmount =
      /(?:\b\d{1,3}(?: \d{1,3})? (?:million|millions|millon|millones|millionen)(?: (?:dollars?|dolares?|euros?|pounds?|livres?|libras?|pfund))?\b|\b\d{3}(?: \d{3})+(?: \d{2})?\b(?: (?:usd|dollars?|dolares?|euros?|gbp|pounds?|livres?|libras?))?|\b\d{6,}\b(?: (?:usd|dollars?|dolares?|euros?|gbp|pounds?|livres?|libras?))?)/u;
    const distinctiveSetup =
      /(?:unclaimed (?:estate|inheritance|policy|deposit|funds?)|dormant estate|abandoned account|selected beneficiary|compensation (?:award|cheque|check|funds?)|charitable fortune|inherit(?: [\p{L}\p{N}]+){0,5} (?:fortune|estate)|succession (?:dormante|non reclamee)|compte abandonne|beneficiaire(?: [\p{L}\p{N}]+){0,4} choisi|indemnis(?:ation|e)|fortune caritative|heriter(?: [\p{L}\p{N}]+){0,5} (?:fortune|succession)|herencia (?:inactiva|sin reclamar)|cuenta abandonada|beneficiario(?: [\p{L}\p{N}]+){0,4} elegid|compensar(?:te|le)?(?: [\p{L}\p{N}]+){0,4} cheque|cheque internacional|fondos? de compensacion|compensacion|indemnizacion|fortuna benefica|hered(?:ar|e)(?: [\p{L}\p{N}]+){0,5} fortuna|deseo transferir(?: [\p{L}\p{N}]+){0,6} cantidad|transferir(?: [\p{L}\p{N}]+){0,8} cuenta en el extranjero|ruhender nachlass|nicht beanspruchte[rn]? nachlass|verlassenen konto|begunstigt(?:en|er)?(?: [\p{L}\p{N}]+){0,4} ausgewahlt|entschadigung|wohltatigen vermogens|erb(?:en|t)(?: [\p{L}\p{N}]+){0,5} vermogen)/u;
    const lotterySetup =
      /(?:lottery (?:winner|prize|reserve)|matched(?: [\p{L}\p{N}]+){0,5} prize|gain(?: [\p{L}\p{N}]+){0,5} loterie|reserve de loterie|premio(?: [\p{L}\p{N}]+){0,5} loteria|reserva de loteria|ganador(?: [\p{L}\p{N}]+){0,8} loteria|lotteriegewinn|gewinn(?: [\p{L}\p{N}]+){0,5} lotterie)/u;
    const claimAction =
      /(?:(?:claim|reply|respond|contact|write|send|provide|submit|pay|settle|remit|cover)(?: [\p{L}\p{N}]+){0,10} (?:agent|officer|bank|funds?|prize|award|identity|passport|bank details|bank coordinates|full details|fee|charge|certificate|bond|levy|cheque|check)|(?:reclamer|repondez|contactez|ecrivez|envoyez|fournissez|soumettez|payez|reglez|versez|acquittez)(?: [\p{L}\p{N}]+){0,10} (?:agent|banque|fonds?|gain|prix|identite|passeport|coordonnees bancaires|informations completes|frais|certificat|caution|taxe|cheque)|(?:reclama|responde|contact[\p{L}]*|ponte en contacto|escribe|escriba|envia|envie|facilita|proporciona|deposit[\p{L}]*|retir[\p{L}]*|paga|abona|remite|cubre)(?: [\p{L}\p{N}]+){0,10} (?:gestor|agente|banco|fondos?|premio|documento|pasaporte|nombre|genero|pais|datos personales|datos bancarios|datos completos|gastos|cargo|certificado|fianza|tasa|cheque|conmigo|correo)|necesito(?: [\p{L}\p{N}]+){0,4} ayuda(?: [\p{L}\p{N}]+){0,4} invertir|(?:beanspruchen|antworten sie|kontaktieren sie|schreiben sie|senden sie|reichen sie|zahlen sie|begleichen sie|uberweisen sie)(?: [\p{L}\p{N}]+){0,10} (?:sachbearbeiter|bank|fonds?|gewinn|ausweis|passkopie|bankdaten|angaben|gebuhr|kaution|abgabe|scheck))/u;
    const setup = new RegExp(`(?:${distinctiveSetup.source}|${lotterySetup.source})`, "u");
    return (
      textHasBoundedPatternCombination(clause, [setup, largeAmount, claimAction], 520, 68) &&
      textHasUnnegatedPattern(clause, claimAction)
    );
  }

  function clauseHasMailboxTakeoverRisk(clause) {
    const mailbox =
      /(?:mailbox|mail profile|webmail|inbox|mail quota|email quota|mail server|login information|boite|profil mail|messagerie|webmail|quota|buzon|perfil de correo|correo|correos electronicos|webmail|cuota|informacion de inicio de sesion|postfach|mailprofil|webmail|kontingent)/u;
    const mailboxProblem =
      /(?:incompatible|expires?|could not renew|certificate(?: [\p{L}\p{N}]+){0,4} no longer accepted|synchronization fault|locked|expire|n a pas pu renouveler|certificat(?: [\p{L}\p{N}]+){0,4} plus accepte|erreur de synchronisation|verrouille|caduca|no pudo renovar|certificado(?: [\p{L}\p{N}]+){0,4} ya no se acepta|fallo de sincronizacion|bloqueo|inkompatibel|lauft ab|konnte(?: [\p{L}\p{N}]+){0,3} nicht verlangern|zertifikat(?: [\p{L}\p{N}]+){0,4} nicht mehr akzeptiert|synchronisierungsfehler|gesperrt)/u;
    const loginUpdate =
      /(?:(?:sign in again|reconfirm|validate|update|enter)(?: [\p{L}\p{N}]+){0,7} (?:password|login|security question|credentials|username|login information)|(?:reconnectez|confirmez|validez|mettez a jour|saisissez)(?: [\p{L}\p{N}]+){0,7} (?:mot de passe|identifiant|question secrete|identifiants|nom d utilisateur)|(?:vuelve a iniciar sesion|confirma|valida|actuali[cz][\p{L}]*|introduce)(?: [\p{L}\p{N}]+){0,7} (?:contrasena|usuario|pregunta de seguridad|credenciales|nombre de usuario|informacion de inicio de sesion)|(?:melden sie sich erneut an|bestatigen sie|aktualisieren sie|geben sie)(?: [\p{L}\p{N}]+){0,7} (?:passwort|anmeldung|sicherheitsfrage|zugangsdaten|benutzernamen))/u;
    const loginAction =
      /(?:sign in again|reconfirm|validate|update|enter|reconnectez|confirmez|validez|mettez a jour|saisissez|vuelve a iniciar sesion|confirma|valida|actuali[cz][\p{L}]*|introduce|melden sie sich erneut an|bestatigen sie|aktualisieren sie|geben sie)/u;
    const mailboxConsequence =
      /(?:incoming messages(?: [\p{L}\p{N}]+){0,4} stop|old mail(?: [\p{L}\p{N}]+){0,4} removed|keep(?: [\p{L}\p{N}]+){0,4} sending and receiving|accounts?(?: [\p{L}\p{N}]+){0,5} disconnected|messages?(?: [\p{L}\p{N}]+){0,5} erased|nouveaux messages(?: [\p{L}\p{N}]+){0,4} bloques|anciens(?: [\p{L}\p{N}]+){0,4} supprimes|continuer a envoyer et recevoir|comptes(?: [\p{L}\p{N}]+){0,5} deconnectes|messages(?: [\p{L}\p{N}]+){0,5} effaces|effacement(?: [\p{L}\p{N}]+){0,4} messages|no podra(?: [\p{L}\p{N}]+){0,4} enviar ni recibir correos|dejaras de recibir mensajes|mensajes antiguos(?: [\p{L}\p{N}]+){0,4} borrar|seguir enviando y recibiendo|cuentas(?: [\p{L}\p{N}]+){0,5} desconectaran|mensajes(?: [\p{L}\p{N}]+){0,5} borrar|borrar(?: [\p{L}\p{N}]+){0,4} mensajes|neue nachrichten(?: [\p{L}\p{N}]+){0,4} gestoppt|alte(?: [\p{L}\p{N}]+){0,4} geloscht|weiter e mails zu senden und zu empfangen|konten(?: [\p{L}\p{N}]+){0,5} getrennt|nachrichten(?: [\p{L}\p{N}]+){0,5} geloscht)/u;
    const readMessageAction =
      /(?:read this message|leer este mensaje|lire ce message|diese nachricht lesen|button(?: [\p{L}\p{N}]+){0,3} (?:read|open)|boton(?: [\p{L}\p{N}]+){0,3} (?:leer|abrir))/u;
    const loseAllMessages =
      /(?:lose all (?:your )?messages|perder todos sus mensajes|perdre tous vos messages|alle ihre nachrichten verlieren)/u;
    const negatedLoginUpdate =
      /(?:do not|dont|never|no|nunca|ne|nicht)(?: [\p{L}\p{N}]+){0,4} (?:update|actuali[cz][\p{L}]*|mettre a jour|mettez a jour|aktualis[\p{L}]*)(?: [\p{L}\p{N}]+){0,6} (?:login information|sign in information|informacion de inicio de sesion|datos de inicio de sesion|informations? de connexion|anmeldeinformationen?)/u.test(
        clause
      );
    return (
      (textHasBoundedPatternCombination(
        clause,
        [mailbox, loginUpdate, mailboxConsequence],
        520,
        66
      ) &&
        !negatedLoginUpdate &&
        textHasUnnegatedDirectRequest(clause, loginAction)) ||
      (textHasBoundedPatternCombination(clause, [readMessageAction, loseAllMessages], 300, 36) &&
        textHasUnnegatedPattern(clause, readMessageAction))
    );
  }

  function clauseHasDestructiveSubscriptionRisk(clause) {
    const protectedObject =
      /(?:account|photos?|files?|documents?|data|profiles?|watch history|downloads?|backups?|drive contents|cuenta|fotos?|archivos?|documentos?|datos|perfiles?|historial|descargas?|copias?|contenido|compte|fichiers?|donnees?|profils?|historique|telechargements?|sauvegardes?|contenu|konto|dateien?|daten|profile?|verlauf|downloads?|backups?|inhalt)/u;
    const destructiveConsequence =
      /(?:will be (?:permanently )?(?:deleted|erased|removed|destroyed)|lose(?: [\p{L}\p{N}]+){0,6} (?:files|contents)|deletion(?: [\p{L}\p{N}]+){0,3} queued|prevent(?: [\p{L}\p{N}]+){0,5} destruction|se (?:eliminaran|borraran|destruiran)|sera(?:n)?(?: [\p{L}\p{N}]+){0,3} (?:eliminad|borrad|destruid)|perder(?:a|as)?(?: [\p{L}\p{N}]+){0,6} (?:archivos|contenido)|borrado(?: [\p{L}\p{N}]+){0,3} en cola|evitar(?: [\p{L}\p{N}]+){0,5} destruccion|ser(?:ont|a)(?: [\p{L}\p{N}]+){0,3} (?:supprime|efface|detruit)|perd(?:ez|re)(?: [\p{L}\p{N}]+){0,6} contenu|suppression(?: [\p{L}\p{N}]+){0,3} planifiee|empecher(?: [\p{L}\p{N}]+){0,5} destruction|werden(?: [\p{L}\p{N}]+){0,3} (?:geloscht|entfernt|vernichtet)|verlieren sie(?: [\p{L}\p{N}]+){0,6} inhalt|loschung(?: [\p{L}\p{N}]+){0,3} (?:eingeplant|vorgemerkt)|damit nicht(?: [\p{L}\p{N}]+){0,5} vernichtet)/u;
    const subscriptionFailure =
      /(?:expired|inactive|terminated|payment(?: [\p{L}\p{N}]+){0,3} failed|could not charge|renewal(?: [\p{L}\p{N}]+){0,5} could not be charged|expire|inactif|resilie|paiement(?: [\p{L}\p{N}]+){0,3} echoue|renouvellement(?: [\p{L}\p{N}]+){0,6} n ?a pas pu etre debite|caducad|inactiv|cancelad|fallo(?: [\p{L}\p{N}]+){0,3} pago|no pudimos cobrar|renovacion(?: [\p{L}\p{N}]+){0,5} no pudo cobrarse|abgelaufen|inaktiv|beendet|zahlung(?: [\p{L}\p{N}]+){0,5} fehlgeschlagen|konnte nicht abgebucht|verlangerung(?: [\p{L}\p{N}]+){0,6} nicht abgebucht)/u;
    const subscriptionAction =
      /(?:membership|subscription|storage plan|billing|renewal|payment|balance|card|membresia|suscripcion|plan de almacenamiento|facturacion|renovacion|pago|saldo|tarjeta|abonnement|forfait|facturation|renouvellement|paiement|solde|carte|mitgliedschaft|abonnement|speicherplan|abrechnung|verlangerung|zahlung|ruckstand|karte)/u;
    const freeExtension =
      /(?:extend[\p{L}]*|ampli[\p{L}]*|prolong[\p{L}]*|verlang[\p{L}]*)(?: [\p{L}\p{N}]+){0,6} (?:free|gratis|gratuit|kostenlos)|(?:free|gratis|gratuit|kostenlos)(?: [\p{L}\p{N}]+){0,6} (?:extension|renewal|ampliacion|renovacion|prolongation|verlangerung)/u;
    const destructiveAction =
      /(?:(?:update|renew|extend|activate|restore|pay)(?: [\p{L}\p{N}]+){0,7} (?:payment|subscription|membership|billing|balance|card)|(?:actualiza|renueva|amplia|extiende|activa|restablece|paga)(?: [\p{L}\p{N}]+){0,7} (?:pago|suscripcion|membresia|facturacion|saldo|tarjeta)|(?:mettez a jour|renouvelez|prolongez|activez|retablissez|payez)(?: [\p{L}\p{N}]+){0,7} (?:paiement|abonnement|facturation|solde|carte)|(?:aktualisieren sie|verlangern sie|aktivieren sie|stellen sie|zahlen sie)(?: [\p{L}\p{N}]+){0,7} (?:zahlung|mitgliedschaft|abonnement|abrechnung|ruckstand|karte))/u;
    const directDestructiveAction =
      /(?:\b(?:update|renew|extend|activate|restore|pay|actualiza|renueva|amplia|extiende|activa|restablece|paga|renouvelez|prolongez|activez|retablissez|payez)\b|mettez(?: [\p{L}\p{N}]+){0,5} a jour|aktualisieren sie|verlangern sie|aktivieren sie|stellen sie|zahlen sie)/u;
    return (
      (textHasBoundedPatternCombination(
        clause,
        [protectedObject, destructiveConsequence, freeExtension],
        330,
        40
      ) && textHasUnnegatedPattern(clause, destructiveConsequence)) ||
      (textHasBoundedPatternCombination(
        clause,
        [
          protectedObject,
          destructiveConsequence,
          subscriptionFailure,
          subscriptionAction
        ],
        520,
        66
      ) &&
        textHasUnnegatedPattern(clause, destructiveConsequence) &&
        textHasUnnegatedDirectRequest(clause, directDestructiveAction))
    );
  }

  function clauseHasBrowserUpdateImpersonationRisk(clause) {
    const browser = /(?:google chrome|chrome browser|web browser|\bbrowser\b|browser version|browser protection|navegador|proteccion del navegador|version del navegador|navigateur|protection du navigateur|version du navigateur|browser schutz|browserversion)/u;
    const vulnerability =
      /(?:(?:critical )?browser vulnerability|security vulnerability|reported vulnerability|malware(?: [\p{L}\p{N}]+){0,4} detected|detected(?: [\p{L}\p{N}]+){0,4} malware|exposes?(?: [\p{L}\p{N}]+){0,4} banking sessions|protection(?: [\p{L}\p{N}]+){0,3} stopped|vulnerabilidad de seguridad|vulnerabilidad reportada|malware(?: [\p{L}\p{N}]+){0,4} detectado|se detecto(?: [\p{L}\p{N}]+){0,4} malware|expone(?: [\p{L}\p{N}]+){0,4} sesiones bancarias|proteccion(?: [\p{L}\p{N}]+){0,3} detenido|faille de securite|vulnerabilite signalee|logiciel malveillant(?: [\p{L}\p{N}]+){0,4} detecte|detecte(?: [\p{L}\p{N}]+){0,4} logiciel malveillant|expose(?: [\p{L}\p{N}]+){0,4} sessions bancaires|protection(?: [\p{L}\p{N}]+){0,3} arretee|sicherheitslucke|gemeldete schwachstelle|schadsoftware(?: [\p{L}\p{N}]+){0,4} erkannt|erkannt(?: [\p{L}\p{N}]+){0,4} schadsoftware|legt(?: [\p{L}\p{N}]+){0,4} banksitzungen offen|schutz(?: [\p{L}\p{N}]+){0,3} angehalten)/u;
    const accountUpdate =
      /(?:(?:update|install|download|run|enter)(?: [\p{L}\p{N}]+){0,7} (?:account|security update|patch|repair|administrator password)|(?:actualice|actualiza|instala|descarga|ejecuta|introduce)(?: [\p{L}\p{N}]+){0,7} (?:cuenta|actualizacion de seguridad|parche|reparacion|contrasena de administrador)|(?:mettez a jour|installez|telechargez|lancez|saisissez)(?: [\p{L}\p{N}]+){0,7} (?:compte|mise a jour|correctif|reparation|mot de passe administrateur)|(?:aktualisieren sie|installieren sie|laden sie|starten sie|geben sie)(?: [\p{L}\p{N}]+){0,7} (?:konto|sicherheitsupdate|patch|reparatur|administratorpasswort))/u;
    const directBrowserAction =
      /(?:\b(?:update|install|download|run|enter|actualice|actualiza|instala|descarga|ejecuta|introduce|installez|telechargez|lancez|saisissez)\b|mettez(?: [\p{L}\p{N}]+){0,5} a jour|aktualisieren sie|installieren sie|laden sie|starten sie|geben sie)/u;
    const accountChange =
      /(?:update your account|actualice su cuenta|actualiza tu cuenta|mettez a jour votre compte|aktualisieren sie ihr konto)/u;
    const pressureOrConsequence =
      /(?:urgent|mandatory|when prompted|unpatched devices?(?: [\p{L}\p{N}]+){0,4} locked|urgente|obligatorio|cuando se solicite|equipos?(?: [\p{L}\p{N}]+){0,4} bloqueados|urgent|obligatoire|a l invite|appareils?(?: [\p{L}\p{N}]+){0,4} bloques|dringend|vorgeschrieben|auf aufforderung|ungepatchte gerate(?: [\p{L}\p{N}]+){0,4} gesperrt)/u;
    return (
      (textHasBoundedPatternCombination(
        clause,
        [browser, vulnerability, accountUpdate, pressureOrConsequence],
        520,
        66
      ) && textHasUnnegatedDirectRequest(clause, directBrowserAction)) ||
      (textHasBoundedPatternCombination(
        clause,
        [browser, vulnerability, accountChange],
        420,
        52
      ) && textHasUnnegatedDirectRequest(clause, directBrowserAction))
    );
  }

  function clauseHasAntivirusScareRisk(clause) {
    const device = /(?:computer|device|pc|computadora|ordenador|dispositivo|ordinateur|appareil|rechner|computer|gerat)/u;
    const infection =
      /(?:\binfected\b|\binfection\b|\bvirus\b|\bmalware\b|trojan|infectad|infeccion|software malicioso|troyano|infecte|logiciel malveillant|cheval de troie|infiziert|schadsoftware|trojaner)/u;
    const protection =
      /(?:antivirus|protection engine|security subscription|license|motor de proteccion|suscripcion|licencia|moteur de protection|abonnement|licence|schutzmodul|sicherheitsabonnement|lizenz)/u;
    const scareAction =
      /(?:(?:update|renew|open|run|install|grant)(?: [\p{L}\p{N}]+){0,8} (?:license|subscription|antivirus|repair|remote access)|(?:actualice|actualiza|renueva|abre|ejecuta|instala|concede)(?: [\p{L}\p{N}]+){0,8} (?:licencia|suscripcion|antivirus|reparacion|acceso remoto)|(?:mettez a jour|renouvelez|ouvrez|lancez|installez|accordez)(?: [\p{L}\p{N}]+){0,8} (?:licence|abonnement|antivirus|lantivirus|reparation|acces a distance)|(?:aktualisieren sie|verlangern sie|offnen sie|starten sie|installieren sie|gewahren sie)(?: [\p{L}\p{N}]+){0,8} (?:lizenz|abonnement|virenschutz|reparatur|fernzugriff))/u;
    const directScareAction =
      /(?:update|renew|open|run|install|grant|actualice|actualiza|renueva|abre|ejecuta|instala|concede|mettez a jour|renouvelez|ouvrez|lancez|installez|accordez|aktualisieren sie|verlangern sie|offnen sie|starten sie|installieren sie|gewahren sie)/u;
    const scareConsequence =
      /(?:disabled|infected files?(?: [\p{L}\p{N}]+){0,4} spreading|copying passwords|quarantine|remote access|desactivad|archivos infectados(?: [\p{L}\p{N}]+){0,4} propagan|copiando contrasenas|cuarentena|acceso remoto|desactive|fichiers infectes(?: [\p{L}\p{N}]+){0,4} propagent|copie les mots de passe|quarantaine|acces a distance|deaktiviert|infizierte dateien(?: [\p{L}\p{N}]+){0,4} verbreiten|kopiert passworter|isolieren|fernzugriff|immediately|inmediatamente|immediatement|sofort)/u;
    const licenseScare = textHasBoundedPatternCombination(
      clause,
      [infection, protection, scareAction, scareConsequence],
      520,
      66
    );
    const remoteRepairScare = textHasBoundedPatternCombination(
      clause,
      [device, infection, scareAction, scareConsequence],
      520,
      66
    );
    return (
      (licenseScare || remoteRepairScare) &&
      textHasUnnegatedDirectRequest(clause, directScareAction)
    );
  }

  function contextsHaveSextortionRisk(clauses) {
    const webcamEvidence =
      /(?:(?:images?|photos?|videos?|recordings?)(?: [\p{L}\p{N}]+){0,7} (?:webcam|camera)|(?:private|intimate|compromising)(?: [\p{L}\p{N}]+){0,5} (?:video|recording|footage|session)|(?:spyware|webcam|camera)(?: [\p{L}\p{N}]+){0,8} (?:captured|recorded|archive|video|recording)|(?:video|recording|footage|archive)(?: [\p{L}\p{N}]+){0,8} (?:webcam|camera|private|intimate|compromising)|(?:imagenes?|fotos?|videos?|grabaciones?)(?: [\p{L}\p{N}]+){0,7} (?:webcam|camara)|(?:video|sesion|grabacion)(?: [\p{L}\p{N}]+){0,5} (?:privad|intim|comprometedor)|(?:software espia|webcam|camara)(?: [\p{L}\p{N}]+){0,8} (?:capture|grabe|archivo|video|grabacion)|(?:video|grabacion|archivo)(?: [\p{L}\p{N}]+){0,8} (?:webcam|camara|privad|intim|comprometedor)|grabaciones?(?: [\p{L}\p{N}]+){0,7} (?:contactos|libreta de direcciones)|(?:images?|videos?|enregistrements?)(?: [\p{L}\p{N}]+){0,7} (?:webcam|camera)|(?:video|session|enregistrement)(?: [\p{L}\p{N}]+){0,5} (?:prive|intime|compromettant)|(?:logiciel espion|webcam|camera)(?: [\p{L}\p{N}]+){0,8} (?:capture|enregistre|archive|video)|(?:video|enregistrement|archive)(?: [\p{L}\p{N}]+){0,8} (?:webcam|camera|prive|intime|compromettant)|(?:bilder?|videos?|aufnahmen?)(?: [\p{L}\p{N}]+){0,7} (?:webcam|kamera)|(?:privat|intim|kompromittierend)(?: [\p{L}\p{N}]+){0,5} (?:video|aufnahme|sitzung)|kompromittier[\p{L}]*(?: [\p{L}\p{N}]+){0,5} bildschirmaufnahme|(?:spionagesoftware|webcam|kamera)(?: [\p{L}\p{N}]+){0,8} (?:aufgenommen|aufnahme|archiv|video)|(?:video|aufnahme|archiv)(?: [\p{L}\p{N}]+){0,8} (?:webcam|kamera|privat|intim|kompromittierend)|(?:aufnahmen?|bildschirmaufnahme)(?: [\p{L}\p{N}]+){0,7} (?:kontakte|adressbuch|privat|kompromittierend))/u;
    const publicationThreat =
      /(?:publish|publication|share|send|distribute)(?: [\p{L}\p{N}]+){0,10} (?:contacts|friends|family|coworkers|publicly)|(?:publicar|compartir|enviar|distribuir)[\p{L}]*(?: [\p{L}\p{N}]+){0,10} (?:contactos|amigos|familia|publicamente)|familia(?: [\p{L}\p{N}]+){0,5} recib[\p{L}]*(?: [\p{L}\p{N}]+){0,5} (?:video|material)|(?:detener|evitar)(?: [\p{L}\p{N}]+){0,4} publicacion|(?:publier|partager|envoyer|diffuser)[\p{L}]*(?: [\p{L}\p{N}]+){0,10} (?:contacts|amis|famille|collegues|publiquement)|publication|veroffentlich|teilen|senden|verteilen(?: [\p{L}\p{N}]+){0,10} (?:kontakte|freunde|familie|kollegen|offentlich)|(?:familie(?: [\p{L}\p{N}]+){0,5} erhalt[\p{L}]*|erhalt[\p{L}]*(?: [\p{L}\p{N}]+){0,5} familie)(?: [\p{L}\p{N}]+){0,5} (?:video|material)|(?:deadline|plazo|delai|frist)(?: [\p{L}\p{N}]+){0,4} (?:publication|publicacion|publication|veroffentlichung)/u;
    const cryptoPayment =
      /(?:bitcoin|btc|usdt|crypto|cryptocurrency|monedero|wallet|portefeuille)(?: [\p{L}\p{N}]+){0,10} (?:payment|pay|send|transfer|pago|pagar|paga|envia|transfiere|paiement|payer|envoyez|transferez|zahlung|zahlen|senden|ubertragen|address|direccion|adresse)|(?:payment|pay|send|transfer|buy|pago|pagar|paga|envia|transfiere|compra|paiement|payer|envoyez|transferez|achetez|zahlung|zahlen|senden|ubertragen|kaufen)(?: [\p{L}\p{N}]+){0,10} (?:bitcoin|btc|usdt|crypto|cryptocurrency|monedero|wallet|portefeuille)/u;
    return clauses.some(
      (clause) =>
        textHasBoundedPatternCombination(
          clause,
          [webcamEvidence, publicationThreat, cryptoPayment],
          500,
          62
        ) &&
        (clauseHasCryptoTransferRisk(clause) || textHasUnnegatedPattern(clause, cryptoPayment))
    );
  }

  function clauseHasDeliveryRisk(clause) {
    if (!behavioralPatternMatches(clause, "delivery")) {
      return false;
    }
    if (
      /(?:courier|delivery) app(?: [\p{L}\p{N}]+){0,5} (?:you )?already use/u.test(
        clause
      )
    ) {
      return false;
    }

    const deliveryMoney =
      clauseHasUnnegatedMoneyAction(clause) &&
      /(?:redelivery|customs|inspection|delivery (?:balance|fee)|shipping fee|tarifa de (?:reentrega|envio)|reentrega|aduana|inspeccion|frais de (?:livraison|nouvelle presentation)|douane|montant d inspection|erneute zustellung|zoll|prufgebuhr|restbetrag)/u.test(
        clause
      );
    const reschedule =
      /(?:new (?:slot|time window)|choose(?: [\p{L}\p{N}]+){0,3} window|schedule delivery now|nouveau creneau|choisissez(?: [\p{L}\p{N}]+){0,3} creneau|programar entrega ahora|programe(?: [\p{L}\p{N}]+){0,3} entrega|nuevo horario|neues zeitfenster|wahlen sie(?: [\p{L}\p{N}]+){0,3} zeitfenster)/u.test(
        clause
      );
    const heldConsequence =
      /(?:delivery|parcel|shipment|package|colis|livraison|paquete|entrega|envio|paket|sendung|zustellung)(?: [\p{L}\p{N}]+){0,8} (?:suspended|failed|held|waiting|returned|disposed|pending|on hold|detenido|suspendid|retenid|esperando|pendiente|en espera|devuelt|eliminad|echec|suspendu|retenu|attente|retour|detruit|ausgesetzt|fehlgeschlagen|angehalten|wartet|zuruck|entsorgt)/u.test(
        clause
      ) &&
      /(?:confirm(?: [\p{L}\p{N}]+){0,5} (?:address|delivery)|program(?: [\p{L}\p{N}]+){0,4} delivery|track(?: [\p{L}\p{N}]+){0,5} (?:code|parcel|package|delivery)|confirmez(?: [\p{L}\p{N}]+){0,5} (?:adresse|livraison)|programar(?: [\p{L}\p{N}]+){0,4} entrega|rastre(?:a|ar|e)(?: [\p{L}\p{N}]+){0,5} (?:codigo|paquete|entrega)|confirma(?: [\p{L}\p{N}]+){0,5} (?:direccion|entrega)|bestatigen sie(?: [\p{L}\p{N}]+){0,5} (?:adresse|zustellung))/u.test(
        clause
      );
    const pendingTracking =
      /(?:paquete|entrega|envio)(?: [\p{L}\p{N}]+){0,8} (?:pendiente|en espera)/u.test(
        clause
      ) &&
      /(?:codigo|seguimiento)/u.test(clause) &&
      clauseHasUnnegatedAction(clause, [
        "rastrear",
        "rastrearlo",
        "rastrearla",
        "rastree"
      ]);
    const namedPackageClaim =
      /paquete(?: [\p{L}\p{N}]+){0,6} con tu nombre/u.test(clause) &&
      clauseHasUnnegatedAction(clause, [
        "reclama",
        "reclamalo",
        "reclamar",
        "reclamarlo",
        "reclame"
      ]);

    return (
      deliveryMoney ||
      reschedule ||
      heldConsequence ||
      pendingTracking ||
      namedPackageClaim ||
      clauseHasFailedDeliveryAction(clause) ||
      clauseHasWaitingParcelTrackingAction(clause)
    );
  }

  function clauseHasCallbackRisk(clause) {
    const routineCompletedState =
      /(?:(?:subscription|membership|protection plan)(?: [\p{L}\p{N}]+){0,6} (?:renewed|extended) successfully|(?:returned item )?refund(?: [\p{L}\p{N}]+){0,4} (?:was )?processed|(?:abonnement|adhesion)(?: [\p{L}\p{N}]+){0,6} renouvele avec succes|remboursement(?: [\p{L}\p{N}]+){0,4} traite|(?:suscripcion|membresia)(?: [\p{L}\p{N}]+){0,6} (?:se renovo|fue renovada) correctamente|reembolso(?: [\p{L}\p{N}]+){0,4} procesado|(?:abonnement|mitgliedschaft)(?: [\p{L}\p{N}]+){0,6} erfolgreich verlangert|ruckerstattung(?: [\p{L}\p{N}]+){0,4} bearbeitet)/u.test(
        clause
      );
    const routineServicePurpose =
      /(?:with (?:any )?questions|if (?:the|your) receipt is missing|pour (?:toute )?question|si (?:le )?recu manque|si tiene preguntas|si falta el recibo|bei fragen|wenn (?:der )?beleg fehlt)/u.test(
        clause
      );
    const lacksAdverseCallbackContext =
      !/(?:did not authorize|not authorized|unrecognized|fraud|cancel|remote access|session (?:key|code)|pas autorise|fraude|annul|acces a distance|no autoriz|fraude|cancel|acceso remoto|nicht genehmigt|betrug|storn|fernwartung)/u.test(
        clause
      );
    const routineMissingReceipt =
      /(?:if (?:the|your) receipt is missing|si (?:le )?recu manque|si falta el recibo|wenn (?:der )?beleg fehlt)/u.test(
        clause
      );
    if (
      (routineCompletedState && routineServicePurpose && lacksAdverseCallbackContext) ||
      (routineMissingReceipt && lacksAdverseCallbackContext)
    ) {
      return false;
    }
    const callbackInstruction =
      clauseHasUnnegatedAction(clause, [
        "call",
        "dial",
        "ring",
        "telephone",
        "appelez",
        "telephonez",
        "llame",
        "marque",
        "rufen sie"
      ]) ||
      /(?:if (?:you )?(?:did not|do not|dont)|si vous ne|si no|falls nicht)(?: [\p{L}\p{N}]+){0,10}\s+(?:call|dial|ring|telephone|appelez|telephonez|llame|marque|rufen sie)/u.test(
        clause
      );
    return (
      callbackInstruction &&
      behavioralPatternMatches(clause, "phoneNumber") &&
      (behavioralPatternMatches(clause, "disputedCharge") ||
        /(?:payment(?: [\p{L}\p{N}]+){0,4}\s+(?:unfamiliar|unrecognized|not yours)|transaction(?: [\p{L}\p{N}]+){0,4}\s+(?:unfamiliar|unrecognized|not yours)|cancellation desk|fraud control|service annulation|controle fraude|cancelaciones|control de fraude|stornierung|betrugskontrolle)/u.test(
          clause
        ))
    );
  }

  function clauseHasQrRisk(clause) {
    const qrObject =
      /(?:qr code|square barcode|qr preview|code qr|apercu qr|codigo qr|vista qr|qr vorschau)/u.test(
        clause
      );
    const qrInstruction = clauseHasUnnegatedAction(clause, [
      "scan",
      "open",
      "use",
      "scannez",
      "ouvrez",
      "utilisez",
      "escanee",
      "abra",
      "use",
      "scannen sie",
      "offnen sie",
      "verwenden sie"
    ]);
    const routineAttachedTicketScan =
      /(?:venue|event|gate|box office) staff(?: [\p{L}\p{N}]+){0,6} (?:will|may|can) scan(?: [\p{L}\p{N}]+){0,8} qr code(?: [\p{L}\p{N}]+){0,8} already attached(?: [\p{L}\p{N}]+){0,6} ticket/u.test(
        clause
      ) &&
      /(?:they|staff)(?: [\p{L}\p{N}]+){0,4} will not ask(?: [\p{L}\p{N}]+){0,8} (?:password|security code)/u.test(
        clause
      ) &&
      !/(?:sign in|log in|page below|form below|(?:please|now|must|need to) scan)/u.test(
        clause
      );
    if (routineAttachedTicketScan) {
      return false;
    }
    const routinePublicQrScan =
      /(?:scan(?: [\p{L}\p{N}]+){0,3} qr ticket(?: [\p{L}\p{N}]+){0,3} (?:at entry|at the gate)|scan(?: [\p{L}\p{N}]+){0,3} qr code(?: [\p{L}\p{N}]+){0,3} (?:public agenda|event agenda))/u.test(
        clause
      );
    if (routinePublicQrScan) {
      return false;
    }
    return (
      qrObject &&
      qrInstruction &&
      (behavioralPatternMatches(clause, "credentialAction") ||
        behavioralPatternMatches(clause, "credentialObject") ||
        /(?:\b(?:account|login|password|portal|page|form)\b|compte|connexion|mot de passe|portail|page|formulaire|cuenta|inicio de sesion|contrasena|pagina|formulario|konto|anmeld|passwort|portal|seite|formular)/u.test(
          clause
        ))
    );
  }

  function clauseHasAccountRestrictionRisk(clause) {
    const riskText = clause.replace(
      /\bcomprometid[oa]s? con\b/gu,
      " "
    );
    const patterns = {
      account:
        /(?:\b(?:account|access|mailbox|email|banking)\b|compte|acces|messagerie|cuenta|acceso|correo|konto|zugang|postfach)/u,
      restriction:
        /(?:suspended|suspension|restricted|disabled|blocked|locked|compromised|unusual activity|suspendu|restreint|desactive|bloque|compromis|activite inhabituelle|suspendid|restringid|deshabilitad|bloquead|comprometid|actividad inusual|gesperrt|eingeschrankt|deaktiviert|kompromittiert|ungewohnliche aktivitat)/u,
      action:
        /(?:action required|sign in|log in|login|reset|change(?: [\p{L}\p{N}]+){0,3} password|verify|restore|open(?: [\p{L}\p{N}]+){0,3}(?:link|page)|action requise|connectez|reinitialis|changez(?: [\p{L}\p{N}]+){0,3} mot de passe|verifiez|retabl|ouvrez(?: [\p{L}\p{N}]+){0,3}(?:lien|page)|accion requerida|inicia(?: [\p{L}\p{N}]+){0,3} sesion|restable|cambi(?:e|a)(?: [\p{L}\p{N}]+){0,3} contrasena|verifi|recuper|abra(?: [\p{L}\p{N}]+){0,3}(?:enlace|pagina)|aktion erforderlich|anmeld|zurucksetz|andern sie(?: [\p{L}\p{N}]+){0,3} passwort|bestatig|wiederherstell|offnen sie(?: [\p{L}\p{N}]+){0,3}(?:link|seite))/u
    };
    const spans = Object.fromEntries(
      Object.entries(patterns).map(([name, pattern]) => {
        const matcher = new RegExp(pattern.source, `${pattern.flags}g`);
        return [
          name,
          [...riskText.matchAll(matcher)]
            .filter((match) => {
              if (!["restriction", "action"].includes(name)) {
                return true;
              }
              if (
                name === "restriction" &&
                /(?:found no|n a trouve aucun(?:e)?|no encontro(?: [\p{L}\p{N}]+){0,4}|fand kein(?:e|en|em|er|es)?)(?: [\p{L}\p{N}]+){0,5}$/u.test(
                  riskText.slice(
                    Math.max(0, (match.index || 0) - 120),
                    match.index || 0
                  ).trimEnd()
                )
              ) {
                return false;
              }
              return !actionIsNegated(
                riskText,
                match.index || 0,
                match[0].length
              );
            })
            .map((match) => ({
              start: match.index || 0,
              end: (match.index || 0) + match[0].length
            }))
        ];
      })
    );

    return spans.account.some((account) =>
      spans.restriction.some((restriction) => {
        const pairStart = Math.min(account.start, restriction.start);
        const pairEnd = Math.max(account.end, restriction.end);
        if (
          pairEnd - pairStart > 110 ||
          riskText.slice(pairStart, pairEnd).split(/\s+/).length > 9
        ) {
          return false;
        }
        return spans.action.some((action) => {
          const combinedStart = Math.min(pairStart, action.start);
          const combinedEnd = Math.max(pairEnd, action.end);
          return (
            combinedEnd - combinedStart <= 240 &&
            riskText.slice(combinedStart, combinedEnd).split(/\s+/).length <= 24
          );
        });
      })
    );
  }

  function clauseHasDestructiveDeadlineRisk(clause) {
    const dataObject =
      /(?:\b(?:files?|photos?|videos?|documents?|data|account)\b|fichiers?|photos?|videos?|documents?|donnees?|compte|archivos?|fotos?|videos?|documentos?|datos|cuenta|dateien?|fotos?|videos?|dokumente?|daten|konto)/u.test(
        clause
      );
    const deletion =
      /(?:deleted|removed|erased|eliminated|supprime|efface|elimine|borrad|eliminad|geloscht|entfernt)/u.test(
        clause
      );
    const deadline =
      /(?:\btoday\b|within 24 hours?|in 24 hours?|before midnight|if you do not|unless you|renewal|aujourd hui|sous 24 heures?|dans les 24 heures?|si vous ne|renouvellement|a menos que|hoy|en 24 horas?|dentro de 24 horas?|si no|renovacion|heute|innerhalb von 24 stunden|wenn sie nicht|verlangerung)/u.test(
        clause
      );
    return dataObject && deletion && deadline;
  }

  function clauseHasSwiftPaymentDiversionRisk(clause) {
    const businessContext =
      /(?:supplier|vendor|invoice|fournisseur|facture|proveedor|factura|lieferant|rechnung)/u;
    const changedSwift =
      /(?:(?:\b(?:new|different|revised|changed|replacement)\b(?: [\p{L}\p{N}]+){0,3} \b(?:swift(?: bic)?|bic)\b)|(?:\b(?:swift(?: bic)?|bic)\b)(?: [\p{L}\p{N}]+){0,3} \b(?:changed|revised|replaced|different)\b)/u;
    const invoiceBalance =
      /(?:outstanding invoice|invoice balance|invoice|facture(?: [\p{L}\p{N}]+){0,3} impayee|solde de la facture|factura pendiente|saldo de la factura|offene rechnung|rechnungsbetrag)/u;
    const destination =
      /(?:account (?:listed|shown|given) below|account below|compte(?: [\p{L}\p{N}]+){0,3} ci dessous|cuenta(?: [\p{L}\p{N}]+){0,3} abajo|konto(?: [\p{L}\p{N}]+){0,3} unten)/u;
    const transferAction =
      /(?:\b(?:wire|transfer|pay|remit|settle)\b|virez|transferez|payez|reglez|transfiera|pague|abone|uberweisen sie|zahlen sie|begleichen sie)/u;
    const overdueBalance =
      /(?:(?:overdue|outstanding) balance|balance(?: [\p{L}\p{N}]+){0,3} (?:overdue|outstanding))/u;
    const businessDeadline =
      /(?:before (?:the )?(?:close of business|end of (?:the )?day)|by close of business|today)/u;
    const fullDestinationChange = textHasBoundedPatternCombination(
      clause,
      [businessContext, changedSwift, invoiceBalance, destination, transferAction],
      520,
      68
    );
    const overdueSwiftChange = textHasBoundedPatternCombination(
      clause,
      [changedSwift, overdueBalance, businessDeadline, transferAction],
      420,
      52
    );
    return (
      (fullDestinationChange || overdueSwiftChange) &&
      textHasUnnegatedDirectRequest(clause, transferAction)
    );
  }

  function clauseHasPayrollDiversionRisk(clause) {
    const payrollContext =
      /(?:(?:employee|staff|worker)(?: [\p{L}\p{N}]+){0,4} direct deposit|direct deposit(?: [\p{L}\p{N}]+){0,5} payroll|payroll(?: [\p{L}\p{N}]+){0,6} direct deposit)/u;
    const changeRequest =
      /(?:\b(?:change|update|replace|switch)\b(?: [\p{L}\p{N}]+){0,6} direct deposit(?: [\p{L}\p{N}]+){0,4} (?:account|details)|direct deposit(?: [\p{L}\p{N}]+){0,3} (?:account|details)(?: [\p{L}\p{N}]+){0,5} \b(?:change|update|replace|switch)\b)/u;
    const replacementDestination =
      /(?:(?:routing and account numbers?|account and routing numbers?)(?: [\p{L}\p{N}]+){0,3} (?:below|provided|listed)|(?:new|replacement|alternate)(?: [\p{L}\p{N}]+){0,2} (?:checking|deposit|bank) account)/u;
    const payrollDeadline =
      /(?:before payroll(?: [\p{L}\p{N}]+){0,2}|before (?:the )?(?:next )?payroll run|for (?:the )?next payroll)/u;
    const directChangeAction = /\b(?:change|update|replace|switch)\b/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [payrollContext, changeRequest, replacementDestination, payrollDeadline],
        500,
        62
      ) && textHasUnnegatedDirectRequest(clause, directChangeAction)
    );
  }

  function clauseHasBusinessPaymentDiversionRisk(clause) {
    if (
      !/(?:invoice|supplier|vendor|beneficiary|escrow|gift cards?|facture|fournisseur|beneficiaire|sequestre|cartes? cadeaux?|factura|proveedor|beneficiario|custodia|tarjetas? regalos?|rechnung|lieferant|empfanger|treuhand|geschenkkart)/u.test(
        clause
      )
    ) {
      return false;
    }
    const riskClause = clause.replace(
      /(?:payment account(?: [\p{L}\p{N}]+){0,4} remains? unchanged|compte de paiement(?: [\p{L}\p{N}]+){0,4} reste(?: [\p{L}\p{N}]+){0,3} inchange|cuenta de pago(?: [\p{L}\p{N}]+){0,4} (?:no ha cambiado|sigue(?: [\p{L}\p{N}]+){0,3} sin cambios)|zahlungskonto(?: [\p{L}\p{N}]+){0,4} bleibt(?: [\p{L}\p{N}]+){0,3} unverandert)/gu,
      " "
    );
    const businessContext =
      /(?:invoice|supplier|vendor|board meeting|acquisition|escrow|settlement bank|client workshop|finance|facture|fournisseur|reunion du conseil|acquisition|sequestre|l?atelier client|direction financiere|factura|proveedor|reunion del consejo|adquisicion|custodia|taller del cliente|direccion financiera|rechnung|lieferant|vorstandssitzung|akquisition|treuhand|kundenworkshop|finanzvorstand)/u;
    const destinationChange =
      /(?:(?:\b(?:changed|different|new|alternate|revised|replacement|substitute)\b(?: [\p{L}\p{N}]+){0,5} \b(?:beneficiary|bank(?:ing)? (?:account|details?|instructions?)|account|escrow(?: account| coordinates?)?|routing (?:details?|numbers?)|iban|ach (?:details?|instructions?)|sort code|payment destination|wire instructions?)\b|\b(?:beneficiary|bank(?:ing)? (?:account|details?|instructions?)|account|escrow(?: account| coordinates?)?|routing (?:details?|numbers?)|iban|ach (?:details?|instructions?)|sort code|payment destination|wire instructions?)\b(?: [\p{L}\p{N}]+){0,5} \b(?:changed|different|new|alternate|revised|replaced|substituted)\b|switched banks?|replace(?: [\p{L}\p{N}]+){0,4} beneficiary)|(?:\b(?:nouveau|change|revise|remplace|alternatif)\b(?: [\p{L}\p{N}]+){0,5} \b(?:beneficiaire|banque|compte|sequestre|rib|iban|coordonnees bancaires|destination de paiement)\b|\b(?:beneficiaire|banque|compte|sequestre|rib|iban|coordonnees bancaires|destination de paiement)\b(?: [\p{L}\p{N}]+){0,5} \b(?:nouveau|change|revise|remplace|alternatif)\b|change de banque)|(?:\b(?:nuev[oa]|cambiad[oa]|revisad[oa]|sustitut[oa]|alternativ[oa])\b(?: [\p{L}\p{N}]+){0,5} \b(?:beneficiario|banco|cuenta|custodia|iban|datos bancarios|ruta bancaria|destino de pago)\b|\b(?:beneficiario|banco|cuenta|custodia|iban|datos bancarios|ruta bancaria|destino de pago)\b(?: [\p{L}\p{N}]+){0,5} \b(?:nuev[oa]|cambiad[oa]|revisad[oa]|sustituid[oa]|alternativ[oa])\b|cambiamos de banco)|(?:\b(?:neu(?:e|en|er|es)?|geandert|uberarbeitet|ersetzt|alternativ(?:e|en|er|es)?)\b(?: [\p{L}\p{N}]+){0,5} \b(?:empfanger|bank|konto|treuhandkonto|iban|bankdaten|bankleitzahl|zahlungsziel)\b|\b(?:empfanger|bank|konto|treuhandkonto|iban|bankdaten|bankleitzahl|zahlungsziel)\b(?: [\p{L}\p{N}]+){0,5} \b(?:neu(?:e|en|er|es)?|geandert|uberarbeitet|ersetzt|alternativ(?:e|en|er|es)?)\b|firmenbankdaten(?: [\p{L}\p{N}]+){0,10} begunstigt(?:e|en|er|es)?(?: [\p{L}\p{N}]+){0,6} ersetzt|bank gewechselt))/u;
    const secrecyDiversion =
      /(?:\b(?:quietly|confidential)\b|between us|within the hour|\b(?:discretement|confidentiel)\b|entre nous|dans l heure|\b(?:discretamente|confidencial)\b|entre nosotros|en una hora|\b(?:diskret|vertraulich)\b|fur sich|binnen einer stunde)/u;
    const giftCardObject =
      /(?:gift cards?|cartes? cadeaux?|tarjetas? regalos?|geschenkkarten?)/u;
    const diversion = new RegExp(
      `(?:${destinationChange.source}|${secrecyDiversion.source}|${giftCardObject.source})`,
      "u"
    );
    const paymentObject =
      /(?:beneficiary|payment|transfer|wire|deposit|escrow|gift cards?|bank account|routing|iban|ach|sort code|beneficiaire|paiement|virement|acompte|sequestre|cartes? cadeaux?|compte|rib|beneficiario|pago|transferencia|deposito|custodia|tarjetas? regalos?|cuenta|ruta bancaria|empfanger|zahlung|uberweisung|anzahlung|treuhand|geschenkkart|konto|bankleitzahl)/u;
    const requestedAction =
      /(?:\b(?:replace|change|pay|release|send|buy|transfer|wire|remit|settle|process|route|use|approve|confirm)\b|need(?: [\p{L}\p{N}]+){0,6} paid|remplacez|changez|payez|virez|liberez|envoyez|renvoyez|achetez|transferez|traitez|utilisez|confirmez|doit(?: [\p{L}\p{N}]+){0,5} paye|sustituya|cambie|pague|envie|envia|enviame|remite|compra|compre|transfiera|procese|dirija|use|apruebe|confirme|necesit(?:o|a)(?: [\p{L}\p{N}]+){0,5} pagar|ersetzen sie|andern sie|zahlen sie|senden sie|kaufen sie|uberweisen sie|bearbeiten sie|leiten sie|verwenden sie|genehmigen sie|bestatigen sie|muss(?: [\p{L}\p{N}]+){0,5} bezahl)/u;
    const fundsAction =
      /(?:\b(?:pay|release|send|buy|transfer|wire|remit|settle|process|route)\b|need(?: [\p{L}\p{N}]+){0,6} paid|payez|virez|liberez|envoyez|renvoyez|achetez|transferez|traitez|doit(?: [\p{L}\p{N}]+){0,5} paye|pague|envie|envia|enviame|remite|compra|compre|transfiera|procese|dirija|necesit(?:o|a)(?: [\p{L}\p{N}]+){0,5} pagar|zahlen sie|senden sie|kaufen sie|uberweisen sie|bearbeiten sie|leiten sie|muss(?: [\p{L}\p{N}]+){0,5} bezahl)/u;
    const hasBoundedDiversion = textHasBoundedPatternCombination(
      riskClause,
      [businessContext, diversion, paymentObject, requestedAction],
      520,
      68
    );
    return (
      hasBoundedDiversion &&
      (textHasUnnegatedDirectRequest(riskClause, fundsAction) ||
        (textHasUnnegatedPattern(riskClause, destinationChange) &&
          textHasUnnegatedDirectRequest(riskClause, requestedAction)) ||
        (textHasUnnegatedPattern(riskClause, secrecyDiversion) &&
          textHasUnnegatedDirectRequest(riskClause, requestedAction)))
    );
  }

  function clauseHasExpandedCallbackRisk(clause) {
    if (!behavioralPatternMatches(clause, "phoneNumber")) {
      return false;
    }
    const callAction =
      /(?:\b(?:call|dial|ring|telephone|contact)\b|appelez|telephonez|contactez|llame|marque|contacte|rufen sie|kontaktieren sie)/u;
    const adverseContext =
      /(?:\b(?:fraud|unauthorized|blocked|restricted|discrepancy|enforcement|arrest|penalty|suspicious)\b|fraud (?:desk|office|control)|(?:card )?payment(?: [\p{L}\p{N}]+){0,4} flagged|did not authorize|not authorized|do not recognize|flagged(?: [\p{L}\p{N}]+){0,4} suspicious|prevent(?: [\p{L}\p{N}]+){0,4} enforcement|remote support|remote technician|access code|connection code|session code|\b(?:fraude|bloque|restreint|anomalie|procedure|arrestation|penalite|suspect)\b|service fraude|paiement(?: [\p{L}\p{N}]+){0,4} signale|pas autorise|non autorise|ne reconnaissez pas|assistance a distance|technicien a distance|code d acces|code de connexion|code de session|\b(?:fraude|bloquead[oa]|restringid[oa]|discrepancia|medidas|arresto|sancion|sospechoso)\b|control de fraude|pago(?: [\p{L}\p{N}]+){0,4} marcado|no autorizad[oa]|no reconoce|soporte remoto|tecnico remoto|codigo de acceso|codigo de conexion|codigo de sesion|\b(?:betrug|betrugsstelle|gesperrt|eingeschrankt|abweichung|vollstreckung|verhaftung|strafe|verdachtig)\b|kartenzahlung(?: [\p{L}\p{N}]+){0,4} markiert|nicht genehmigt|nicht autorisiert|erkennen sie nicht|fernsupport|fernwartungstechniker|zugangscode|verbindungscode|sitzungscode)/u;
    return (
      textHasBoundedPatternCombination(clause, [callAction, BEHAVIOR_PATTERNS.phoneNumber, adverseContext], 420, 52) &&
      textHasUnnegatedDirectRequest(clause, callAction)
    );
  }

  function clauseHasExpandedQrRisk(clause) {
    if (!/(?:qr|square barcode|code carre)/u.test(clause)) {
      return false;
    }
    const qrObject =
      /(?:qr(?: code| image| notice| joint| adjunto| bild| hinweis)?|square barcode|code qr|image qr|avis qr|codigo qr|imagen qr|aviso qr)/u;
    const qrAction =
      /(?:\b(?:scan|open|use)\b|scannez|ouvrez|utilisez|escanee|abra|use|scannen sie|offnen sie|verwenden sie|rufen sie(?: [\p{L}\p{N}]+){0,5} ab)/u;
    const riskyPurpose =
      /(?:mobile mail|device token|sign in|log in(?:to)?|login|account|payroll|compensation statement|salary|voicemail|quarantine|parking notice|card details|payment|messagerie mobile|jeton|connectez|compte|paie|remuneration|message vocal|quarantaine|stationnement|carte|paiement|correo movil|token|inicie sesion|cuenta|nomina|salari|mensaje de voz|cuarentena|estacionamiento|tarjeta|pago|mobile e mail|geratetoken|melden sie|konto|gehalt|voicemail|quarantane|parkhinweis|kartendaten|zahlung)/u;
    const pressureOrAccess =
      /(?:expires?|tonight|renew|retrieve|secure(?: [\p{L}\p{N}]+){0,2} viewer|payroll viewer|doubles?|enter|sign in|log in(?:to)?|expire|ce soir|renouvel|recuper|ecouter|lecteur|double|saisissez|connectez|caduca|esta noche|renov|escuch|visor|duplica|introduzca|inicie sesion|lauft|heute aus|verlang|abrufen|anhoren|rufen sie(?: [\p{L}\p{N}]+){0,5} ab|ansicht|verdoppelt|geben sie|melden sie)/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [qrObject, qrAction, riskyPurpose, pressureOrAccess],
        440,
        56
      ) && textHasUnnegatedDirectRequest(clause, qrAction)
    );
  }

  function clauseHasExpandedRemoteAccessRisk(clause) {
    if (
      !/(?:remote|distance|remot|fern|screen control|controle de l ecran|control de pantalla|bildschirmsteuerung|session code|code de session|codigo de sesion|sitzungscode)/u.test(
        clause
      )
    ) {
      return false;
    }
    const remoteObject =
      /(?:remote (?:support|repair|access|window|session)|support client|screen control|session code|diagnostic utility|technician|assistance a distance|client distant|reparation a distance|fenetre distante|controle de l ecran|code de session|utilitaire de diagnostic|technicien|soporte remoto|reparacion remota|ventana remota|control de pantalla|codigo de sesion|utilidad de diagnostico|tecnico|fernsupport|fernreparatur|fernfenster|bildschirmsteuerung|sitzungscode|diagnoseprogramm|techniker)/u;
    const remoteAction =
      /(?:\b(?:install|download|start|connect|approve|authorize|accept|give|provide|share|leave|run)\b|installez|telechargez|demarrez|connectez|approuvez|autorisez|acceptez|donnez|fournissez|laissez|lancez|instale|descargue|inicie|conecte|apruebe|autorice|acepte|facilite|comparta|deje|ejecute|installieren sie|laden sie|starten sie|verbinden sie|genehmigen sie|erlauben sie|akzeptieren sie|geben sie|teilen sie|lassen sie|fuhren sie)/u;
    const problemOrHandoff =
      /(?:failed|blocked|quarantine|isolated|malware|corrupt|compliance|diagnostic|restore access|month end|session code|screen control|technician|echoue|bloque|quarantaine|isole|corrompu|conformite|diagnostic|retablir l acces|code de session|controle de l ecran|technicien|fallo|bloquead|cuarentena|aislo|danad|cumplimiento|diagnostico|restablecer el acceso|codigo de sesion|control de pantalla|tecnico|fehlgeschlagen|blockiert|quarantane|isoliert|beschadigt|compliance|diagnose|zugang wieder|sitzungscode|bildschirmsteuerung|techniker)/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [remoteObject, remoteAction, problemOrHandoff],
        500,
        62
      ) && textHasUnnegatedDirectRequest(clause, remoteAction)
    );
  }

  function clauseHasNamedRemoteToolHandoff(clause) {
    const protectiveToolDenial = clause.match(
      /(?:support|help ?desk)(?: [\p{L}\p{N}]+){0,5} (?:never|does not|will not)(?: [\p{L}\p{N}]+){0,8} install(?: [\p{L}\p{N}]+){0,3} (?:anydesk|teamviewer|quick assist|screenconnect)(?: [\p{L}\p{N}]+){0,8} (?:disclose|share|provide|read)(?: [\p{L}\p{N}]+){0,4} access code/u
    );
    if (protectiveToolDenial) {
      const denialEnd =
        (protectiveToolDenial.index || 0) + protectiveToolDenial[0].length;
      const laterText = clause.slice(denialEnd);
      const restartedToolHandoff =
        /(?:(?:install|download|open|run|start|launch)(?: [\p{L}\p{N}]+){0,5} (?:anydesk|teamviewer|quick assist|screenconnect)|(?:disclose|share|provide|read|tell|send)(?: [\p{L}\p{N}]+){0,6} (?:access code|connection code|session code|screen id))/u.test(
          laterText
        );
      if (!restartedToolHandoff) {
        return false;
      }
    }
    const namedTool = /\b(?:anydesk|teamviewer|quick assist|screenconnect)\b/u;
    const accessIdentifier =
      /(?:\b(?:access|connection|session|remote|partner) (?:code|id)\b|\b(?:nine|eight|seven|six)[ -]digit (?:address|code|id)\b|address shown on screen|code d?acces|code de connexion|code de session|identifiant(?: [\p{L}\p{N}]+){0,3} (?:distant|affiche)|adresse(?: [\p{L}\p{N}]+){0,4} affichee|codigo de acceso|codigo de conexion|codigo de sesion|id remoto|direccion(?: [\p{L}\p{N}]+){0,4} pantalla|zugangscode|verbindungscode|sitzungscode|partner id|fern id|adresse(?: [\p{L}\p{N}]+){0,4} bildschirm)/u;
    const handoffAction =
      /(?:\b(?:install|download|open|run|start|launch|provide|give|share|read|tell|send|enter)\b|installez|telechargez|ouvrez|lancez|demarrez|fournissez|donnez|partagez|lisez|dites|envoyez|saisissez|instale|descargue|abra|ejecute|inicie|proporcione|facilite|comparta|lea|diga|envie|introduzca|installieren sie|laden sie|offnen sie|starten sie|geben sie|teilen sie|lesen sie|nennen sie|senden sie|tragen sie)/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [namedTool, accessIdentifier, handoffAction],
        440,
        54
      ) &&
      textHasUnnegatedDirectRequest(clause, handoffAction) &&
      textHasUnnegatedPattern(clause, handoffAction)
    );
  }

  function clauseHasExpandedAdvanceFeeRisk(clause) {
    if (
      !/(?:estate|inheritance|beneficiary|grant|tender|refund|succession|beneficiaire|subvention|appel d offres|remboursement|herencia|beneficiario|subvencion|licitacion|reembolso|nachlass|begunstigt|zuschuss|ausschreibung|ruckzahlung)/u.test(
        clause
      )
    ) {
      return false;
    }
    const entitlement =
      /(?:unclaimed estate|inheritance|beneficiary|grant(?: [\p{L}\p{N}]+){0,3} approved|tender deposit|refund pending|estate lists|succession non reclamee|beneficiaire|subvention(?: [\p{L}\p{N}]+){0,3} approuvee|depot d appel d offres|remboursement|herencia sin reclamar|beneficiario|subvencion(?: [\p{L}\p{N}]+){0,3} aprobada|deposito de licitacion|reembolso|nicht beanspruchter nachlass|nachlassbegunstigt|zuschuss(?: [\p{L}\p{N}]+){0,3} genehmigt|ausschreibungskaution|ruckzahlung)/u;
    const releaseCondition =
      /(?:release|disbursement|processing|clearance|notari|identity|bank details|fee|charge|liberer|versement|traitement|deblocage|notaire|identite|coordonnees bancaires|frais|liberar|desembolso|tramitacion|autorizacion|notarial|identidad|datos bancarios|tasa|gastos|freigeben|auszahlung|bearbeitung|freigabe|notar|identitat|bankdaten|gebuhr)/u;
    const claimAction =
      /(?:(?:\b(?:reply|provide|send|pay|settle|transfer|activate|release)\b)(?: [\p{L}\p{N}]+){0,8} \b(?:identity|bank details|fee|charge|deposit|funds|payment|disbursement|grant|refund|claim)\b|(?:repondez|fournissez|envoyez|payez|reglez|transferez|activez|liberez)(?: [\p{L}\p{N}]+){0,8} \b(?:identite|coordonnees bancaires|frais|depot|fonds|paiement|versement|subvention|remboursement)\b|(?:responda|facilite|envie|pague|abone|transfiera|active|libere)(?: [\p{L}\p{N}]+){0,8} \b(?:identidad|datos bancarios|tasa|gastos|deposito|fondos|pago|desembolso|subvencion|reembolso)\b|(?:antworten sie|senden sie|zahlen sie|begleichen sie|uberweisen sie|aktivieren sie|freigeben)(?: [\p{L}\p{N}]+){0,8} \b(?:identitat|bankdaten|gebuhr|steuer|gewinnsteuer|einzahlung|fonds|zahlung|auszahlung|zuschuss|ruckzahlung)\b)/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [entitlement, releaseCondition, claimAction],
        520,
        66
      ) && textHasUnnegatedDirectRequest(clause, claimAction)
    );
  }

  function clauseHasExpandedSextortionRisk(clause) {
    if (clauseHasNarrativeReviewContext(clause)) {
      return false;
    }
    if (
      !/(?:webcam|camera|recording|video|screen|contacts|enregistrement|ecran|grabacion|pantalla|contactos|aufnahme|bildschirm|kontakte)/u.test(
        clause
      )
    ) {
      return false;
    }
    const capturedMaterial =
      /(?:private recording|private video|camera|webcam|screen|copied your contacts|enregistrement prive|video privee|camera|webcam|ecran|copie vos contacts|grabacion privada|video privado|camara|webcam|pantalla|copie tus contactos|private aufnahme|privates video|kamera|webcam|bildschirm|kontakte kopiert)/u;
    const coercion =
      /(?:send(?: [\p{L}\p{N}]+){0,8} everyone|goes to everyone|queued to|scheduled|deleted|do not contact police|countdown|within 24 hours?|diffuse|partira|collegues|suppression|ne prevenez pas la police|compte a rebours|sous 24 heures?|mandar|enviara|preparad|programad|borrar|no avises a la policia|cuenta atras|dentro de 24 horas?|versendet|kollegen|vorgemerkt|geloscht|nicht die polizei|zeit ablauft|binnen 24 stunden|innerhalb von 24 stunden)/u;
    const payment =
      /(?:cryptocurrency|crypto|bitcoin|wallet|pay|transfer|send [\p{L}\p{N} ]{0,6}(?:usd|eur)|cryptomonnaie|portefeuille|payez|transferez|envoyez|criptomoneda|monedero|paga|transfiere|envia|kryptowahrung|wallet|zahlen|ubertragen|senden)/u;
    const paymentAction =
      /(?:\b(?:pay|transfer|send)\b|payez|transferez|envoyez|paga|transfiere|envia|zahlen sie|ubertragen sie|senden sie)/u;
    const hasPaymentRequest =
      textHasUnnegatedDirectRequest(clause, paymentAction) ||
      (/(?:^| )(?:zahlen|ubertragen|senden) sie\b/u.test(clause) &&
        textHasUnnegatedPattern(clause, paymentAction));
    return (
      textHasBoundedPatternCombination(
        clause,
        [capturedMaterial, coercion, payment, paymentAction],
        520,
        68
      ) && hasPaymentRequest
    );
  }

  function clauseHasAccountDeletionActionRisk(clause) {
    if (!/(?:account|mailbox|storage|files|cloud files|compte|boite|stockage|fichiers|cuenta|buzon|archivos|konto|postfach|speicher|dateien)/u.test(clause)) {
      return false;
    }
    const protectedObject =
      /(?:account|mailbox|storage account|cloud files|synced files|\bfiles\b|messages|contacts|compte|boite|stockage|fichiers synchronises|\bfichiers\b|cuenta|buzon|archivos sincronizados|\barchivos\b|konto|postfach|speicherkonto|synchronisierte dateien|\bdateien\b)/u;
    const deletionThreat =
      /(?:removed|deleted|erased|purged|closure|permanent deletion|supprime|efface|fermeture|suppression definitive|eliminar|borrar|purg|cierre|borrado definitivo|entfernt|geloscht|schliessung|endgultige loschung|bereinigt)/u;
    const correctiveAction =
      /(?:\b(?:confirm|validate|complete|stop|keep|retain|sign in|log in)\b|confirmez|validez|effectuez|arretez|conservez|connectez|confirme|valide|complete|detenga|conserve|inicie sesion|bestatigen sie|validieren sie|schliessen sie|schließen sie|stoppen sie|behalten sie|melden sie)/u;
    const deadlineOrCause =
      /(?:inactive|tonight|deadline|unanswered|immediately|overdue|inactif|ce soir|delai|sans reponse|immediatement|inactiv|esta noche|plazo|sin respuesta|de inmediato|inaktiv|heute nacht|frist|unbeantwortet|sofort)/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [protectedObject, deletionThreat, correctiveAction, deadlineOrCause],
        500,
        62
      ) &&
      textHasUnnegatedPattern(clause, deletionThreat) &&
      textHasUnnegatedDirectRequest(clause, correctiveAction)
    );
  }

  function clauseHasExpandedCustomsRisk(clause) {
    if (!/(?:customs|import|border|declaration|douane|frontiere|aduana|frontera|arancel|zoll|grenze|einfuhr)/u.test(clause)) {
      return false;
    }
    const customsProblem =
      /(?:customs|import|border|declaration|douane|frontiere|declaration|aduana|frontera|declaracion|arancel|zoll|grenze|einfuhr|erklarung)/u;
    const adverseState =
      /(?:held|stopped|rejected|missing|lacks|storage|seizure|outstanding|due|bloque|rejete|manque|stockage|saisie|du|retenid|rechazad|falta|almacenaje|decomiso|pendiente|festgehalten|abgelehnt|fehlt|lagerung|beschlagnahme|offen|fallig)/u;
    const feeOrRecord =
      /(?:duty|fee|payment|tax identifier|identity|record|balance|droits|frais|paiement|identifiant fiscal|identite|dossier|solde|arancel|tasa|pago|identificador fiscal|identidad|registro|saldo|abgabe|gebuhr|zahlung|steuerkennung|identitat|datensatz|saldo)/u;
    const correctionAction =
      /(?:\b(?:pay|settle|correct|submit|confirm|provide|authorize|release)\b|payez|reglez|corrigez|soumettez|confirmez|fournissez|autorisez|liberez|pague|liquide|corrija|envie|confirme|facilite|autorice|libere|zahlen sie|begleichen sie|korrigieren sie|ubermitteln sie|bestatigen sie|geben sie|genehmigen sie|freigeben)/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [customsProblem, adverseState, feeOrRecord, correctionAction],
        500,
        62
      ) && textHasUnnegatedDirectRequest(clause, correctionAction)
    );
  }

  function clauseHasExpandedDeliveryRisk(clause) {
    if (!/(?:parcel|package|delivery|shipment|locker|depot|colis|livraison|consigne|paquete|entrega|taquilla|deposito|paket|zustellung|abholfach)/u.test(clause)) {
      return false;
    }
    const deliveryObject =
      /(?:parcel|package|delivery|shipment|locker|depot|colis|livraison|envoi|consigne|depot|paquete|entrega|envio|taquilla|deposito|paket|zustellung|sendung|abholfach)/u;
    const pressure =
      /(?:failed|held|expires|return|missed|waiting|signature|required|incomplete|echec|retenu|expire|renverra|manquee|attente|signature|incomplet|fallid|retenid|vence|devolvera|perdida|espera|firma|incomplet|fehlgeschlagen|angehalten|lauft ab|ablauf|zuruck|verpasst|wartet|unterschrift|unvollstandig)/u;
    const deliveryAction =
      /(?:\b(?:confirm|validate|select|choose|arrange|schedule|pay|settle|provide|correct)\b|confirmez|validez|selectionnez|choisissez|organisez|programmez|payez|reglez|fournissez|corrigez|confirme|valide|seleccione|elija|organice|programe|pague|liquide|facilite|corrija|bestatigen sie|validieren sie|wahlen sie|vereinbaren sie|planen sie|zahlen sie|begleichen sie|geben sie|korrigieren sie)/u;
    const requestedDetail =
      /(?:address|contact details|time slot|second attempt|fee|charge|adresse|coordonnees|creneau|second passage|frais|direccion|datos de contacto|franja|segundo intento|tasa|cargo|adresse|kontaktdaten|zeitfenster|zweiten versuch|gebuhr)/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [deliveryObject, pressure, deliveryAction, requestedDetail],
        500,
        62
      ) && textHasUnnegatedDirectRequest(clause, deliveryAction)
    );
  }

  function clauseHasExpandedInvestmentRisk(clause) {
    if (!/(?:trading|return|token|crypto|bond|investment|rendement|jeton|obligation|placement|rentabilidad|asignacion|bono|inversion|cripto|monedero|rendite|zuteilung|anleihe|anlage|handel|kapital|krypto|wallet)/u.test(clause)) {
      return false;
    }
    if (
      /(?:seminar|education|webinar|course|training|compliance|scams?|fraud awareness)/u.test(
        clause
      ) &&
      /(?:reserve|buy|book)(?: [\p{L}\p{N}]+){0,5} (?:seat|place|ticket|workshop|session)/u.test(
        clause
      )
    ) {
      return false;
    }
    const investmentPitch =
      /(?:trading engine|weekly return|protected principal|pre listing token|token allocation|recover(?:ed)? crypto|recovery desk|corporate note|bond|guaranteed|private trading|moteur(?: [\p{L}\p{N}]+){0,3} trading|rendement|capital protege|avant cotation|allocation(?: [\p{L}\p{N}]+){0,3} jeton|recuper[\p{L}]*(?: [\p{L}\p{N}]+){0,4} cryptomonnaie|obligation|garanti|motor(?: [\p{L}\p{N}]+){0,3} trading|rentabilidad|capital protegido|previa a cotizacion|asignacion(?: [\p{L}\p{N}]+){0,3} token|recuper[\p{L}]*(?: [\p{L}\p{N}]+){0,4} criptomoneda|bono|garantiz|handelssystem|privates system|rendite|geschutztem kapital|vor dem borsenstart|token zuteilung|kryptoverluste|anleihe|garantiert)/u;
    const extraordinaryTerm =
      /(?:\b(?:1[0-9]|[2-9][0-9]) ?%|weekly|per week|thirty days|pre listing|fully guaranteed|protected principal|recover(?:ed)? balance|par semaine|trente jours|avant cotation|garantie totale|capital protege|solde recupere|frais (?:reseau|juridiques)|debloquer le solde|semanal|treinta dias|previa a cotizacion|totalmente garantizada|capital protegido|saldo recuperado|gastos legales|desbloquear el saldo|pro woche|dreissig tagen|borsenstart|vollgarantie|geschutztem kapital|wiedererlangt|netzwerk|rechtskosten|freischaltung)/u;
    const fundingAction =
      /(?:\b(?:fund|deposit|transfer|pay|reserve|buy|send|invest)\b|alimentez|deposez|transferez|payez|reservez|achetez|investissez|deposite|transfiera|pague|reserve|compre|invierta|zahlen sie ein|uberweisen sie|zahlen sie|reservieren sie|kaufen sie|investieren sie)/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [investmentPitch, extraordinaryTerm, fundingAction],
        520,
        66
      ) && textHasUnnegatedDirectRequest(clause, fundingAction)
    );
  }

  function clauseHasCredentialExfiltrationCompound(clause) {
    const secretObject =
      /(?:current password|bank(?:ing)? password|login secret|email secret|sign in code|authenticat(?:or|ion) (?:number|code)|recovery answers?|backup codes?|banking credentials|online banking credentials|card pin|mot de passe (?:actuel|bancaire)|secret (?:de messagerie|de connexion)|code de connexion|numero d authentificat(?:eur|ion)|reponses de recuperation|codes? de secours|acces bancaires?|code de la carte|contrasena (?:actual|bancaria)|secreto (?:de inicio|del correo)|codigo de acceso|numero del autenticador|respuestas de recuperacion|codigos? de respaldo|acceso bancario|pin de la tarjeta|aktuell(?:e|en|er|es)? passwort|bankpasswort|e mail geheimnis|anmeldecode|authentifikatornummer|wiederherstellungsantworten|ersatzcodes|onlinebanking daten|karten pin)/u;
    if (!secretObject.test(clause)) {
      return false;
    }
    const disclosureAction =
      /\b(?:reply|send|submit|transmit|provide|give|read|dictate|tell|type|enter|confirm|disclose|re enter|open|repondez|envoyez|soumettez|transmettez|fournissez|donnez|dictez|lisez|saisissez|confirmez|ouvrez|responda|envie|presente|transmita|facilite|proporcione|dicte|lea|escriba|introduzca|confirme|abra|antworten sie|senden sie|ubermitteln sie|geben sie|lesen sie|nennen sie|tragen sie|bestatigen sie|offnen sie)\b/u;
    const unsafeSurface =
      /(?:\b(?:reply|message|email|form|linked page|linked step|outside (?:the )?(?:normal|usual) (?:sign in|login)|operator|private|within (?:one|an) hour|immediately)\b|reponse|message|courriel|formulaire|page liee|etape liee|hors de l ecran|operateur|confidentiel|sous une heure|immediatement|respuesta|mensaje|correo|formulario|pagina enlazada|paso enlazado|fuera (?:de )?(?:la )?pantalla|operador|en privado|menos de una hora|de inmediato|antwort|nachricht|e mail|formular|verlinkte seite|verlinkten schritt|ausserhalb der ublichen anmeldung|operator|vertraulich|binnen einer stunde|sofort)/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [secretObject, disclosureAction, unsafeSurface],
        520,
        68
      ) && textHasUnnegatedDirectRequest(clause, disclosureAction)
    );
  }

  function clauseHasSecretBundledForwardRequest(clause) {
    const currentSecret =
      /(?:current password|mot de passe actuel|contrasena actual|aktuell(?:e|en|er|es)? passwort)/u;
    const forwardedMessage =
      /(?:this (?:email|message)|ce (?:courriel|message)|este (?:correo|mensaje)|diese nachricht)/u;
    const destination =
      /(?:security team|support team|equipe de securite|equipe d assistance|equipo de seguridad|equipo de soporte|sicherheitsteam|supportteam)/u;
    const forwardAction =
      /\b(?:forward|transfer|send|transferez|faites suivre|envoyez|reenvie|envie|leiten sie|senden sie)\b/u;
    return (
      currentSecret.test(clause) &&
      forwardedMessage.test(clause) &&
      destination.test(clause) &&
      textHasUnnegatedDirectRequest(clause, forwardAction)
    );
  }

  function clauseHasPaymentDiversionCompound(clause) {
    if (
      !/(?:supplier|vendor|beneficiary|invoice|banking details|fournisseur|beneficiaire|facture|coordonnees bancaires|proveedor|beneficiario|factura|datos bancarios|lieferant|empfanger|rechnung|bankdaten)/u.test(
        clause
      )
    ) {
      return false;
    }
    const businessObject =
      /(?:supplier|vendor|beneficiary|invoice|fournisseur|beneficiaire|facture|proveedor|beneficiario|factura|lieferant|empfanger|rechnung)/u;
    const changedDestination =
      /(?:beneficiary(?: [\p{L}\p{N}]+){0,5} replaced|company banking details|new account|alternate account|corrected invoice|beneficiaire(?: [\p{L}\p{N}]+){0,5} remplace|coordonnees bancaires|nouveau compte|compte de remplacement|facture corrigee|beneficiario(?: [\p{L}\p{N}]+){0,5} sustituid|datos bancarios|cuenta nueva|cuenta alternativa|factura corregida|begunstigte(?: [\p{L}\p{N}]+){0,5} ersetzt|firmenbankdaten|neues konto|ersatzkonto|korrigierte rechnung)/u;
    const paymentAction =
      /\b(?:reply|pay|settle|wire|transfer|replace|repondez|payez|reglez|virez|transferez|remplacez|responda|pague|abone|transfiera|sustituya|antworten sie|zahlen sie|begleichen sie|uberweisen sie|ersetzen sie)\b/u;
    const bypassOrPressure =
      /(?:before today|before (?:the )?(?:payment )?run|do not call|without calling|confidential|keep (?:this|the instruction) private|avant (?:le )?(?:traitement|lot|virement)|sans appeler|confidentiel|gardez (?:cette )?consigne|antes (?:de )?(?:la ejecucion|el lote)|sin llamar|confidencial|mantenga (?:la )?instruccion|vor dem heutigen lauf|ohne (?:den )?lieferant(?:en)? anzurufen|vertraulich|behandeln sie (?:die )?anweisung)/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [businessObject, changedDestination, paymentAction, bypassOrPressure],
        520,
        70
      ) && textHasUnnegatedDirectRequest(clause, paymentAction)
    );
  }

  function clauseHasDeliverySensitiveCompound(clause) {
    if (
      !/(?:parcel|package|delivery|redelivery|postage|courier|handling amount|colis|livraison|affranchissement|coursier|montant de manutention|paquete|entrega|reentrega|franqueo|mensajero|importe de manipulacion|paket|zustellung|porto|kurier|bearbeitungsbetrag)/u.test(
        clause
      )
    ) {
      return false;
    }
    const deliveryAction =
      /\b(?:pay|settle|transfer|enter|provide|re enter|use|submit|payez|reglez|transferez|saisissez|fournissez|ressaisissez|utilisez|pague|abone|transfiera|introduzca|facilite|vuelva a escribir|bezahlen sie|begleichen sie|uberweisen sie|tragen sie|geben sie|verwenden sie)\b/u;
    const cardCodeEntryRequest =
      /(?:\b(?:enter|provide|re enter|use|submit)\b|saisissez|fournissez|ajoutez|ajouter|ressaisissez|utilisez|introduzca|facilite|vuelva a escribir|tragen sie|geben sie|verwenden sie)(?: (?!(?:never|not|no|nunca|jamais|pas|nicht|niemals)\b)[\p{L}\p{N}]+){0,3} (?:card (?:security code|verification digits?|cvv)|cryptogramme de la carte|codigo de seguridad de la tarjeta|cvv|kartenprufziffer)/u;
    const feeAndCardCode =
      /(?:redelivery|second delivery|seconde livraison|reentrega|erneute zustellung)/u.test(
        clause
      ) &&
      /(?:card (?:security code|verification digits?|cvv)|cryptogramme de la carte|codigo de seguridad de la tarjeta|cvv|kartenprufziffer)/u.test(
        clause
      ) &&
      textHasUnnegatedDirectRequest(clause, cardCodeEntryRequest);
    const identityAndCardBundle =
      /(?:address|adresse|direccion|anschrift)/u.test(clause) &&
      /(?:date of birth|date de naissance|fecha de nacimiento|geburtsdatum)/u.test(
        clause
      ) &&
      /(?:card number|numero de carte|numero de tarjeta|kartennummer)/u.test(
        clause
      ) &&
      /(?:\bpin\b|code secret|karten pin)/u.test(clause);
    const failedPostageAndBankAccess =
      /(?:failed postage|rejected postage|affranchissement rejete|franqueo fallido|fehlgeschlagen(?:e|es|en)? porto)/u.test(
        clause
      ) &&
      /(?:online banking|banking credentials|acces bancaires?|acceso bancario|onlinebanking daten)/u.test(
        clause
      );
    const alternateHandlingTransfer =
      /(?:handling amount|montant (?:de )?(?:manutention|traitement)|importe de manipulacion|bearbeitungsbetrag)/u.test(
        clause
      ) &&
      /(?:alternate account|replacement account|compte (?:alternatif|de remplacement)|cuenta alternativa|ersatzkonto)/u.test(
        clause
      );
    const deliveryFeeAndPin =
      /(?:delivery fee|parcel fee|frais de livraison|frais du colis|tasa de entrega|tasa del paquete|zustellgebuhr|paketgebuhr)/u.test(
        clause
      ) &&
      /(?:card pin|pin de la carte|pin de la tarjeta|karten pin)/u.test(clause) &&
      /(?:release(?: [\p{L}\p{N}]+){0,3} parcel|liberer(?: [\p{L}\p{N}]+){0,3} colis|liberar(?: [\p{L}\p{N}]+){0,3} paquete|paket(?: [\p{L}\p{N}]+){0,3} freigeben)/u.test(
        clause
      );
    const underpaidPostageCardReturn =
      /(?:(?:postage|porto)(?: [\p{L}\p{N}]+){0,3} underpaid|underpaid(?: [\p{L}\p{N}]+){0,3} postage)/u.test(
        clause
      ) &&
      /(?:\bcard\b|credit card|debit card)/u.test(clause) &&
      /(?:(?:package|parcel)(?: [\p{L}\p{N}]+){0,5} returns?|returns?(?: [\p{L}\p{N}]+){0,5} (?:package|parcel)|sent back)/u.test(
        clause
      );
    return (
      (feeAndCardCode ||
        identityAndCardBundle ||
        failedPostageAndBankAccess ||
        alternateHandlingTransfer ||
        deliveryFeeAndPin ||
        underpaidPostageCardReturn) &&
      textHasUnnegatedDirectRequest(clause, deliveryAction)
    );
  }

  function clauseHasCallbackDisclosureCompound(clause) {
    if (
      !/(?:refund|callback|repayment|remboursement|rappel|reembolso|devolucion|llamada|erstattung|ruckruf)/u.test(
        clause
      )
    ) {
      return false;
    }
    const bankingCode =
      /(?:one time banking code|banking code|code(?: [\p{L}\p{N}]+){0,3} banking app|code bancaire a usage unique|codigo bancario de un solo uso|einmaligen bankcode)/u;
    const callbackCode =
      /(?:callback number|number in this message|numero de rappel|numero du message|numero de devolucion|numero del mensaje|ruckrufnummer|nummer in dieser nachricht)/u.test(
        clause
      ) &&
      bankingCode.test(clause);
    const numberedRefundCode =
      behavioralPatternMatches(clause, "phoneNumber") && bankingCode.test(clause);
    const helperSessionSecret =
      /(?:refund helper|repayment helper|assistant de remboursement|asistente de devolucion|erstattungshelfer)/u.test(
        clause
      ) &&
      /(?:session (?:identifier|id)|identifiant de session|identificador de sesion|sitzungskennung)/u.test(
        clause
      ) &&
      /(?:card pin|code de la carte|pin de la tarjeta|karten pin)/u.test(clause);
    const callbackAction =
      /\b(?:call|read|dictate|install|give|provide|tell|appelez|lisez|dictez|installez|donnez|fournissez|llame|lea|dicte|instale|dele|facilite|rufen sie|lesen sie|installieren sie|geben sie|nennen sie)\b/u;
    const codeDisclosureAction =
      /\b(?:read|dictate|give|provide|tell|lisez|dictez|donnez|fournissez|lea|dicte|dele|facilite|lesen sie|geben sie|nennen sie)\b/u;
    return (
      ((callbackCode || helperSessionSecret) &&
        textHasUnnegatedDirectRequest(clause, callbackAction)) ||
      (numberedRefundCode &&
        textHasUnnegatedDirectRequest(clause, codeDisclosureAction))
    );
  }

  function clauseHasQrSensitiveCompound(clause) {
    if (!/(?:\bqr\b|qr code|code qr|codigo qr)/u.test(clause)) {
      return false;
    }
    const qrPaymentSecret =
      /(?:qr destination|destination qr|destino qr|qr ziel)/u.test(clause) &&
      /(?:overdue amount|montant en retard|importe vencido|ruckstand)/u.test(clause) &&
      /(?:card pin|code secret de la carte|pin de la tarjeta|karten pin)/u.test(
        clause
      );
    const qrWalletRecovery =
      /(?:scan(?: [\p{L}\p{N}]+){0,4} (?:code|qr)|scannez(?: [\p{L}\p{N}]+){0,4} (?:code|qr)|escanee(?: [\p{L}\p{N}]+){0,4} (?:codigo|qr)|scannen sie(?: [\p{L}\p{N}]+){0,4} (?:code|qr))/u.test(
        clause
      ) &&
      /(?:connect(?: [\p{L}\p{N}]+){0,4} wallet|connectez(?: [\p{L}\p{N}]+){0,4} portefeuille|conecte(?: [\p{L}\p{N}]+){0,4} cartera|verbinden sie(?: [\p{L}\p{N}]+){0,4} wallet)/u.test(
        clause
      ) &&
      /(?:recovery (?:words?|phrase)|mots? de recuperation|phrase de recuperation|palabras? de recuperacion|frase de recuperacion|wiederherstellungsworter|wiederherstellungsphrase)/u.test(
        clause
      );
    const qrAction =
      /\b(?:use|pay|disclose|reveal|scan|connect|utilisez|payez|revelez|scannez|connectez|pague|revele|escanee|conecte|nutzen sie|zahlen sie|nennen sie|scannen sie|verbinden sie)\b/u;
    return (
      (qrPaymentSecret || qrWalletRecovery) &&
      textHasUnnegatedDirectRequest(clause, qrAction)
    );
  }

  function clauseHasQrSensitiveDisclosureCompound(clause) {
    if (!/(?:\bqr\b|qr code|code qr|codigo qr)/u.test(clause)) {
      return false;
    }
    const walletConnection =
      /(?:connect(?: [\p{L}\p{N}]+){0,4} (?:crypto |digital )?wallet|connectez(?: [\p{L}\p{N}]+){0,4} portefeuille|conecte(?: [\p{L}\p{N}]+){0,4} cartera|verbinden sie(?: [\p{L}\p{N}]+){0,4} wallet)/u;
    const recoveryDisclosure =
      /(?:\b(?:enter|reveal|provide|type|share|submit)\b|saisissez|revelez|fournissez|partagez|introduzca|revele|facilite|comparta|geben sie|nennen sie|teilen sie)(?: (?!(?:never|not|no|nunca|jamais|pas|nicht|niemals)\b)[\p{L}\p{N}]+){0,4} (?:recovery (?:words?|phrase)|mots? de recuperation|phrase de recuperation|palabras? de recuperacion|frase de recuperacion|wiederherstellungsworter|wiederherstellungsphrase)/u;
    return (
      walletConnection.test(clause) &&
      textHasUnnegatedDirectRequest(clause, recoveryDisclosure)
    );
  }

  function clauseHasRemoteControlCompound(clause) {
    if (
      !/(?:remote (?:support|control|session|tool)|technician|endpoint protection|unattended control|controle a distance|assistance a distance|technicien|protection du poste|controle permanent|control remoto|soporte remoto|tecnico|proteccion del equipo|control desatendido|fernsteuerung|fernwartung|techniker|endpunktschutz|unbeaufsichtigten zugriff)/u.test(
        clause
      )
    ) {
      return false;
    }
    const toolAndAccessCode =
      /(?:remote control tool|outil de controle a distance|herramienta de control remoto|fernsteuerungswerkzeug)/u.test(
        clause
      ) &&
      /(?:access code|code d?acces|codigo de acceso|zugangscode)/u.test(clause);
    const disabledProtectionSession =
      /(?:turn off|disable|desactivez|desactive|deshabilite|schalten sie)(?: [\p{L}\p{N}]+){0,5} (?:endpoint protection|protection du poste|proteccion del equipo|endpunktschutz)/u.test(
        clause
      ) &&
      /(?:install(?: [\p{L}\p{N}]+){0,4} viewer|installez(?: [\p{L}\p{N}]+){0,4} visualiseur|instale(?: [\p{L}\p{N}]+){0,4} visor|installieren sie(?: [\p{L}\p{N}]+){0,4} betrachter)/u.test(
        clause
      ) &&
      /(?:leave(?: [\p{L}\p{N}]+){0,4} session open|laissez(?: [\p{L}\p{N}]+){0,4} session ouverte|deje(?: [\p{L}\p{N}]+){0,4} sesion abierta|deje abierta(?: [\p{L}\p{N}]+){0,4} sesion|lassen sie(?: [\p{L}\p{N}]+){0,4} sitzung offen)/u.test(
        clause
      );
    const unattendedAndUnlocked =
      /(?:grant unattended control|accordez un controle permanent|conceda control desatendido|gewahren sie unbeaufsichtigten zugriff)/u.test(
        clause
      ) &&
      /(?:keep(?: [\p{L}\p{N}]+){0,6} unlocked|laissez(?: [\p{L}\p{N}]+){0,6} deverrouille|deje(?: [\p{L}\p{N}]+){0,6} desbloqueado|lassen sie(?: [\p{L}\p{N}]+){0,6} entsperrt)/u.test(
        clause
      );
    const remoteAction =
      /\b(?:download|send|disable|turn off|install|leave|grant|keep|telechargez|envoyez|desactivez|installez|laissez|accordez|descargue|envie|desactive|instale|deje|conceda|laden sie|senden sie|schalten sie|installieren sie|lassen sie|gewahren sie)\b/u;
    return (
      (toolAndAccessCode || disabledProtectionSession || unattendedAndUnlocked) &&
      textHasUnnegatedDirectRequest(clause, remoteAction)
    );
  }

  function clauseHasInvestmentSolicitationCompound(clause) {
    if (
      !/(?:cryptocurrency|crypto|wallet|return|trade|allocation|cryptomonnaie|portefeuille|rendement|operation privee|allocation|criptomoneda|cartera|rentabilidad|operacion privada|asignacion|kryptowahrung|geldborse|wallet|rendite|privaten geschaft|zuteilung)/u.test(
        clause
      )
    ) {
      return false;
    }
    const guaranteedDoubling =
      /(?:cryptocurrency|crypto|cryptomonnaie|criptomoneda|kryptowahrung)/u.test(
        clause
      ) &&
      /(?:guaranteed doubl|doublement garanti|duplicar[\p{L}]* con garanti|garantiert verdoppel)/u.test(
        clause
      );
    const walletRecoveryAllocation =
      /(?:wallet|portefeuille|cartera|geldborse)/u.test(clause) &&
      /(?:recovery phrase|phrase de recuperation|frase de recuperacion|wiederherstellungsphrase)/u.test(
        clause
      ) &&
      /(?:private allocation|allocation privee|asignacion privada|private zuteilung)/u.test(
        clause
      );
    const riskFreeDeposit =
      /(?:deposit today|deposez (?:aujourd hui|aujourdhui)|deposite hoy|zahlen sie heute)/u.test(
        clause
      ) &&
      /(?:risk free return|rendement sans risque|rentabilidad sin riesgo|risikofreie rendite)/u.test(
        clause
      );
    const borrowedPrivateTrade =
      /(?:borrow(?: [\p{L}\p{N}]+){0,4} entry amount|empruntez(?: [\p{L}\p{N}]+){0,4} mise (?:d entree|dentree)|pida prestado(?: [\p{L}\p{N}]+){0,4} importe inicial|leihen sie(?: [\p{L}\p{N}]+){0,4} einstiegsbetrag)/u.test(
        clause
      ) &&
      /(?:external page|page externe|pagina externa|externe seite)/u.test(clause) &&
      /(?:private trade|l?operation privee|operacion privada|privaten geschaft)/u.test(
        clause
      );
    const fundingAction =
      /\b(?:send|connect|provide|deposit|borrow|pay|envoyez|connectez|fournissez|deposez|empruntez|payez|envie|conecte|facilite|deposite|pida prestado|pague|senden sie|verbinden sie|geben sie|zahlen sie|leihen sie)\b/u;
    return (
      (guaranteedDoubling ||
        walletRecoveryAllocation ||
        riskFreeDeposit ||
        borrowedPrivateTrade) &&
      textHasUnnegatedDirectRequest(clause, fundingAction)
    );
  }

  function clauseHasAdvanceFeeSolicitationCompound(clause) {
    if (
      !/(?:grant|inheritance|prize|award|reward|lotter(?:y|ies)|subvention|heritage|gain|recompense|subvencion|herencia|premio|beca|zuschuss|erbschaft|gewinn)/u.test(
        clause
      )
    ) {
      return false;
    }
    const windfall =
      /(?:unrequested grant|surprise inheritance|prize|award|reward|(?:email|address|ticket)(?: [\p{L}\p{N}]+){0,3} won (?:the )?lottery|won (?:the )?lottery|subvention non sollicitee|heritage surprise|gain|recompense|subvencion no solicitada|herencia sorpresa|premio|unverlangte zuschuss|uberraschende erbschaft|gewinn)/u;
    const upfrontCostOrSecret =
      /(?:release (?:charge|fee)|processing fee|prize tax|upfront courier payment|courier(?: and)? tax fee|courier fee|tax fee|passport image|online banking credentials|frais de deblocage|frais de dossier|taxe du gain|coursier d avance|image du passeport|acces bancaires|cargo de liberacion|tasa de tramite|impuesto del premio|pago previo de mensajeria|imagen del pasaporte|acceso bancario|freigabegebuhr|bearbeitungsgebuhr|gewinnsteuer|kurier vorab|passbild|onlinebanking daten)/u;
    const claimAction =
      /(?:(?:pay|settle|send|transfer|provide|return)(?: [\p{L}\p{N}]+){0,7} (?:fee|charge|tax|courier payment|passport|identity|banking credentials|bank details|full details)|(?:payez|reglez|envoyez|transferez|communiquez|renvoyez)(?: [\p{L}\p{N}]+){0,7} (?:frais|taxe|coursier|passeport|identite|acces bancaires|coordonnees bancaires|informations completes)|(?:pague|abone|envie|transfiera|facilite|devuelva)(?: [\p{L}\p{N}]+){0,7} (?:cargo|tasa|impuesto|mensajeria|pasaporte|identidad|acceso bancario|datos bancarios|datos completos)|(?:zahlen sie|begleichen sie|senden sie|uberweisen sie|geben sie)(?: [\p{L}\p{N}]+){0,7} (?:gebuhr|steuer|gewinnsteuer|kurier|pass|identitat|onlinebanking daten|bankdaten|angaben))/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [windfall, upfrontCostOrSecret, claimAction],
        520,
        70
      ) && textHasUnnegatedDirectRequest(clause, claimAction)
    );
  }

  function clauseHasSextortionCompound(clause) {
    if (clauseHasNarrativeReviewContext(clause)) {
      return false;
    }
    if (
      !/(?:recording|video|camera|files|contacts|enregistrement|video|camera|fichiers|contacts|grabacion|video|camara|archivos|contactos|aufnahme|video|kamera|dateien|kontakte)/u.test(
        clause
      )
    ) {
      return false;
    }
    const allegedMedia =
      /(?:claimed|supposed|alleged|private recording|camera capture|video release|pretendu|suppose|allegue|enregistrement prive|capture de camera|diffusion de la video|supuesta|supuesto|alegad|grabacion privada|captura de la camara|publicacion del video|angeblich|behauptet|vermeintlich|private aufnahme|kameraaufnahme|videoveroffentlichung)/u;
    const extortionDemand =
      /(?:cryptocurrency|payment card details|pay within|gift vouchers|send (?:their )?codes|cryptomonnaie|donnees? de carte|payez sous|bons cadeaux|envoyez (?:leurs )?codes|criptomoneda|datos de tarjeta|pague en|vales regalo|envie los codigos|kryptowahrung|kartendaten|zahlen sie binnen|geschenkgutscheine|senden sie die codes)/u;
    const publicationThreat =
      /(?:sent to (?:your )?contacts|stop(?: [\p{L}\p{N}]+){0,4} (?:video )?release|tell nobody|files(?: [\p{L}\p{N}]+){0,4} published|envoi(?: [\p{L}\p{N}]+){0,6} contacts|arreter(?: [\p{L}\p{N}]+){0,5} video|ne parlez a personne|fichiers(?: [\p{L}\p{N}]+){0,4} publies|llegue a sus contactos|detener(?: [\p{L}\p{N}]+){0,5} video|no cuente a nadie|archivos(?: [\p{L}\p{N}]+){0,4} publicaran|publicaran(?: [\p{L}\p{N}]+){0,4} archivos|an ihre kontakte gesendet|videoveroffentlichung zu stoppen|niemandem|dateien(?: [\p{L}\p{N}]+){0,4} veroffentlicht)/u;
    const coerciveAction =
      /\b(?:transfer|reply|pay|buy|send|tell|transferez|repondez|payez|achetez|envoyez|parlez|transfiera|responda|pague|compre|envie|cuente|ubertragen sie|antworten sie|zahlen sie|kaufen sie|senden sie|erzahlen sie)\b/u;
    return (
      textHasBoundedPatternCombination(
        clause,
        [allegedMedia, extortionDemand, publicationThreat, coerciveAction],
        520,
        72
      ) && textHasUnnegatedDirectRequest(clause, coerciveAction)
    );
  }

  function clauseHasCustomsDiversionCompound(clause) {
    const seizureThreat =
      /(?:seizure penalty|penalite de saisie|sancion por incautacion|beschlagnahmestrafe)/u.test(
        clause
      ) &&
      /(?:through the link|par le lien|mediante el enlace|uber den link)/u.test(
        clause
      ) &&
      /(?:parcel is destroyed|destruction du colis|destruyan el paquete|paket vernichtet)/u.test(
        clause
      );
    const inspectionDiversion =
      /(?:inspection amount|montant de l?inspection|importe de inspeccion|prufbetrag)/u.test(
        clause
      ) &&
      /(?:alternate account|replacement account|compte de remplacement|cuenta alternativa|ersatzkonto)/u.test(
        clause
      );
    const customsAction =
      /\b(?:settle|transfer|wire|pay|reglez|virez|transferez|abone|transfiera|pague|begleichen sie|uberweisen sie|zahlen sie)\b/u;
    return (
      (seizureThreat || inspectionDiversion) &&
      textHasUnnegatedDirectRequest(clause, customsAction)
    );
  }

  function clauseHasDeletionSensitiveCompound(clause) {
    if (
      !/(?:account|files|deletion|erase|wiped|compte|fichiers|suppression|effacement|cuenta|archivos|borrado|borrar|konto|dateien|loschung|geloscht)/u.test(
        clause
      )
    ) {
      return false;
    }
    if (/(?:documentation|docs?|test fixture|test case|example|simulation)/u.test(clause)) {
      return false;
    }
    const credentialCardPreservation =
      /(?:form|formulaire|formulario|formular)/u.test(clause) &&
      /(?:credentials|acces|credenciales|zugangsdaten)/u.test(clause) &&
      /(?:card details|donnees? de carte|tarjeta|kartendaten)/u.test(clause) &&
      /(?:preserve|keep|conserver|conservar|behalten)/u.test(clause);
    const recoveryRemoteDeletion =
      /(?:recovery (?:application|app)|application de recuperation|aplicacion de recuperacion|wiederherstellungsanwendung)/u.test(
        clause
      ) &&
      /(?:remote control|controle distant|control remoto|fernzugriff)/u.test(clause) &&
      /(?:account (?:is|will be) wiped|effacement du compte|borrar la cuenta|konto geloscht)/u.test(
        clause
      );
    const deletionAction =
      /\b(?:open|enter|install|grant|provide|submit|ouvrez|saisissez|installez|accordez|fournissez|abra|introduzca|instale|conceda|facilite|offnen sie|tragen sie|installieren sie|erlauben sie|geben sie)\b/u;
    return (
      (credentialCardPreservation || recoveryRemoteDeletion) &&
      textHasUnnegatedDirectRequest(clause, deletionAction)
    );
  }

  function clauseHasExpandedSecretDisclosureRisk(clause) {
    const secretObject =
      /(?:password manager(?: [\p{L}\p{N}]+){0,3} export|export(?: [\p{L}\p{N}]+){0,4} password manager|(?:mailbox|corporate|administrator|banking|online bank) password|password|verification number|login number|one time (?:login |bank )?number|second factor value|account recovery answers?|recovery answers?|reset token|account login|online bank login|company card details|purchase validation number|card (?:pin|password|security digits?)|wallet seed words?|seed words?|control pin|export(?: [\p{L}\p{N}]+){0,4} gestionnaire de mots de passe|mot de passe(?: [\p{L}\p{N}]+){0,3} (?:messagerie|professionnel|administrateur|bancaire)|mot de passe|numero de verification|numero(?: [\p{L}\p{N}]+){0,3} connexion|numero a usage unique|valeur du second facteur|reponses?(?: [\p{L}\p{N}]+){0,4} recuperation|jeton de reinitialisation|acces(?: [\p{L}\p{N}]+){0,3} compte|acces bancaire|donnees? de la carte d entreprise|numero de validation d achat|code secret de la carte|cryptogramme de carte|mots? secrets? du portefeuille|code de controle|exportacion(?: [\p{L}\p{N}]+){0,4} gestor de contrasenas|contrasena(?: [\p{L}\p{N}]+){0,3} (?:correo|corporativa|administrador|bancaria)|contrasena|numero de verificacion|numero(?: [\p{L}\p{N}]+){0,3} acceso|numero de un solo uso|valor(?: [\p{L}\p{N}]+){0,3} segundo factor|respuestas?(?: [\p{L}\p{N}]+){0,4} recuperacion|token de restablecimiento|acceso(?: [\p{L}\p{N}]+){0,3} cuenta|acceso bancario|datos de la tarjeta empresarial|numero de validacion de compra|pin de la tarjeta|clave de la tarjeta|digitos de seguridad de la tarjeta|palabras? semilla(?: [\p{L}\p{N}]+){0,3} cartera|secreto de administrador|pin de control|export(?: [\p{L}\p{N}]+){0,4} passwortmanager|postfachpasswort|firmenpasswort|administratorpasswort|bankpasswort|passwort|prufnummer|anmeldenummer|einmalnummer|zweitfaktorwert|antworten?(?: [\p{L}\p{N}]+){0,4} kontowiederherstellung|rucksetz token|kontenanmeldung|onlinebanking anmeldung|firmenkartendaten|kaufprufnummer|karten pin|kartenpasswort|kartenprufziffer|seed worter(?: [\p{L}\p{N}]+){0,3} geldborse|administratorgeheimnis|steuerungs pin)/u;
    const disclosureAction =
      /(?:\b(?:reply|send|email|upload|share|provide|give|tell|dictate|disclose|return|transmit|submit)\b|repondez|envoyez|televersez|partagez|fournissez|donnez|dictez|revelez|renvoyez|transmettez|soumettez|responda|envie|cargue|comparta|facilite|proporcione|diga|dicte|revele|devuelva|transmita|presente|antworten sie|senden sie|mailen sie|laden sie(?: [\p{L}\p{N}]+){0,3} hoch|teilen sie|geben sie|nennen sie|ubertragen sie|ubermitteln sie)/u;
    const entryAction =
      /(?:\b(?:put|enter|write|type|record)\b|inscrivez|saisissez|ecrivez|entrez|escriba|introduzca|ingrese|anote|tragen sie|geben sie(?: [\p{L}\p{N}]+){0,2} ein)/u;
    const riskyEntrySurface =
      /(?:questionnaire|form|page|portal|linked|qr|square image|retention|purge|presale|claim|questionnaire|formulaire|page|portail|image carree|conservation|prevente|cuestionario|formulario|pagina|portal|imagen cuadrada|conservacion|preventa|fragebogen|formular|seite|portal|quadratische bild|aufbewahrung|vorverkauf)/u;
    const governedDisclosure = new RegExp(
      `(?:${disclosureAction.source})(?: (?!(?:never|not|no|nunca|jamais|pas|nicht|niemals|kein(?:e|en|em|er|es)?)\\b)[\\p{L}\\p{N}]+){0,16} (?:${secretObject.source})`,
      "u"
    );
    const governedEntry = new RegExp(
      `(?:${entryAction.source})(?: (?!(?:never|not|no|nunca|jamais|pas|nicht|niemals|kein(?:e|en|em|er|es)?)\\b)[\\p{L}\\p{N}]+){0,16} (?:${secretObject.source})`,
      "u"
    );
    const hasDisclosureRequest =
      textHasUnnegatedDirectRequest(clause, governedDisclosure) &&
      textHasUnnegatedPattern(clause, governedDisclosure);
    const hasEntryRequest =
      textHasUnnegatedDirectRequest(clause, governedEntry) &&
      textHasUnnegatedPattern(clause, governedEntry);
    return hasDisclosureRequest || (riskyEntrySurface.test(clause) && hasEntryRequest);
  }

  function clauseHasExpandedFinancialDiversionRisk(clause) {
    const directAction =
      /(?:\b(?:replace|change|send|wire|transfer|transmit|split|route|remit|email)\b|remplacez|changez|envoyez|virez|transferez|transmettez|repartissez|acheminez|cambie|sustituya|envie|transfiera|transmita|divida|reemplace|ersetzen sie|andern sie|senden sie|uberweisen sie|teilen sie|mailen sie)/u;
    const changedDestination =
      /(?:remittance destination|payment destination|substitute account|replacement account|destination du versement|compte de substitution|compte de remplacement|destino de la remesa|cuenta sustitutiva|cuenta de reemplazo|uberweisungsziel|ersatzkonto)/u;
    const approvalBypass =
      /(?:bypass|skip|without|contournez|sans|omita|sin|umgehen sie|ohne)(?: [\p{L}\p{N}]+){0,5} (?:dual approval|second approval|double validation|deuxieme validation|doble aprobacion|segunda aprobacion|doppelte freigabe|zweite freigabe)/u;
    const newBankCoordinates =
      /(?:new (?:routing|bank) coordinates|new bank details|nouvelles coordonnees|nouvelles coordonnees bancaires|nuevas coordenadas bancarias|nuevos datos bancarios|neuen bankkoordinaten|neue bankdaten)/u;
    const splitInvoice =
      /(?:split|repartissez|divida|teilen sie)(?: [\p{L}\p{N}]+){0,6} (?:invoice|facture|factura|rechnung)(?: [\p{L}\p{N}]+){0,8} (?:instant payment accounts?|comptes? de paiement instantane|cuentas? de pago instantaneo|sofortzahlungskonten)/u;
    const secretArrangement =
      /(?:keep(?: [\p{L}\p{N}]+){0,4} (?:secret|confidential)|gardez(?: [\p{L}\p{N}]+){0,4} secret|maintenga(?: [\p{L}\p{N}]+){0,4} secreto|halten sie(?: [\p{L}\p{N}]+){0,4} geheim)/u;
    const companyCardOrder =
      /(?:company card details|purchase validation number|donnees? de la carte d entreprise|numero de validation d achat|datos de la tarjeta empresarial|numero de validacion de compra|firmenkartendaten|kaufprufnummer)/u;
    const relation =
      (changedDestination.test(clause) &&
        /(?:balance|invoice|solde|facture|saldo|factura|betrag|rechnung)/u.test(clause)) ||
      (approvalBypass.test(clause) && newBankCoordinates.test(clause)) ||
      (splitInvoice.test(clause) && secretArrangement.test(clause)) ||
      companyCardOrder.test(clause);
    return relation && textHasUnnegatedDirectRequest(clause, directAction);
  }

  function clauseHasExpandedRefundDisclosureRisk(clause) {
    const refundContext =
      /(?:refund|reimbursement|repayment|callback|over refund|remboursement|rappel|trop rembourse|reembolso|reintegro|devolucion|llamada|erstattung|ruckzahlung|ruckruf)/u;
    const intermediary =
      /(?:caller|operator|agent|callback|call assistance|appelant|operateur|agent|rappel|aide telephonique|persona que llama|operador|agente|llamada|ayuda telefonica|anrufer|mitarbeiter|operator|ruckruf|anrufhilfe)/u;
    const bankSecret =
      /(?:one time (?:bank |login )?number|number(?: [\p{L}\p{N}]+){0,5} bank|account login|online banking|numero a usage unique|numero(?: [\p{L}\p{N}]+){0,5} banque|acces au compte|banque en ligne|numero de un solo uso|numero(?: [\p{L}\p{N}]+){0,5} banco|acceso a la cuenta|banca en linea|einmalnummer|prufnummer|kontoanmeldung|onlinebanking|fernansicht)/u;
    const remoteBanking =
      /(?:remote view(?: [\p{L}\p{N}]+){0,4} banking|vue distante(?: [\p{L}\p{N}]+){0,4} banque|vista remota(?: [\p{L}\p{N}]+){0,4} banca|fernansicht(?: [\p{L}\p{N}]+){0,4} onlinebanking)/u;
    const overRefundCrypto =
      /(?:(?:crypto|cryptocurrency|cryptomonnaie|criptomoneda|kryptowahrung)(?: [\p{L}\p{N}]+){0,12} (?:refund|remboursement|reembolso|ruckzahlung)(?: [\p{L}\p{N}]+){0,8} (?:too large|trop eleve|excesivo|zu hoch)|(?:refund|remboursement|reembolso|ruckzahlung)(?: [\p{L}\p{N}]+){0,8} (?:too large|trop eleve|excesivo|zu hoch)(?: [\p{L}\p{N}]+){0,12} (?:crypto|cryptocurrency|cryptomonnaie|criptomoneda|kryptowahrung))/u;
    const riskyObject = bankSecret.test(clause) || remoteBanking.test(clause) || overRefundCrypto.test(clause);
    const action =
      /(?:\b(?:request|call|ring|tell|dictate|disclose|install|grant|send|transfer|pay)\b|demandez|appelez|dictez|revelez|installez|accordez|envoyez|transferez|payez|solicite|llame|diga|dicte|revele|instale|conceda|envie|transfiera|pague|fordern sie|rufen sie|nennen sie|offenbaren sie|installieren sie|gewahren sie|senden sie|uberweisen sie|zahlen sie)/u;
    return (
      refundContext.test(clause) &&
      intermediary.test(clause) &&
      riskyObject &&
      textHasUnnegatedDirectRequest(clause, action)
    );
  }

  function clauseHasExpandedDelegatedRemoteRisk(clause) {
    const remoteObject =
      /(?:remote helper|remote operator|remote view|unattended connection|browser control extension|screen control|assistant distant|operateur(?: [\p{L}\p{N}]+){0,3} distant|vue distante|connexion permanente|controle du navigateur|controle d ecran|asistente remoto|operador remoto|vista remota|conexion desatendida|extension de control del navegador|control de pantalla|fernzugriffshelfer|fernoperator|fernansicht|unbeaufsichtigte verbindung|erweiterung zur browsersteuerung|bildschirmsteuerung)/u;
    const dangerousDetail =
      /(?:control pin|security agent|online banking|administrator secret|file access|overnight|code de controle|agent de securite|banque en ligne|secret administrateur|acces aux fichiers|pendant la nuit|pin de control|agente de seguridad|banca en linea|secreto de administrador|archivos accesibles|durante la noche|steuerungs pin|sicherheitsagent|onlinebanking|administratorgeheimnis|dateizugriff|uber nacht)/u;
    const action =
      /(?:\b(?:run|start|give|accept|switch off|turn off|install|grant|provide|keep|leave|enable)\b|lancez|demarrez|donnez|acceptez|coupez|desactivez|installez|accordez|fournissez|laissez|activez|ejecute|inicie|de|acepte|apague|desactive|instale|conceda|facilite|mantenga|deje|active|starten sie|nennen sie|geben sie|akzeptieren sie|schalten sie|installieren sie|gewahren sie|lassen sie|aktivieren sie)/u;
    return (
      remoteObject.test(clause) &&
      dangerousDetail.test(clause) &&
      textHasUnnegatedDirectRequest(clause, action)
    );
  }

  function clauseHasExpandedSquareQrRisk(clause) {
    const qrMarker =
      /(?:\bqr\b|square image|square symbol|code destination|image carree|symbole carre|destination du code|imagen cuadrada|simbolo cuadrado|destino del codigo|quadratische bild|quadratisches bild|quadratcode|zeichen|codeziel)/u;
    const secretOrProfile =
      /(?:password|second factor|recovery answers?|card pin|downloaded profile|mot de passe|second facteur|reponses? de recuperation|code secret de la carte|profil telecharge|contrasena|segundo factor|respuestas? de recuperacion|pin de la tarjeta|perfil descargado|passwort|zweitfaktor|wiederherstellungsantworten|karten pin|geladen(?:e|en|er|es)? profil)/u;
    const walletPayment =
      /(?:pay(?: [\p{L}\p{N}]+){0,7} code|authorize(?: [\p{L}\p{N}]+){0,7} (?:digital )?wallet|payez(?: [\p{L}\p{N}]+){0,7} code|autorisez(?: [\p{L}\p{N}]+){0,7} portefeuille|pague(?: [\p{L}\p{N}]+){0,7} codigo|autorice(?: [\p{L}\p{N}]+){0,7} cartera|zahlen sie(?: [\p{L}\p{N}]+){0,7} code|erlauben sie(?: [\p{L}\p{N}]+){0,7} geldborse)/u;
    const action =
      /\b(?:scan|open|use|enter|submit|install|disclose|pay|authorize|connect|scannez|ouvrez|utilisez|saisissez|transmettez|installez|donnez|payez|autorisez|connectez|escanee|abra|introduzca|envie|instale|revele|pague|autorice|conecte|scannen sie|offnen sie|nutzen sie|geben sie|installieren sie|nennen sie|zahlen sie|erlauben sie|verbinden sie)\b/u;
    return (
      qrMarker.test(clause) &&
      (secretOrProfile.test(clause) || walletPayment.test(clause)) &&
      textHasUnnegatedDirectRequest(clause, action)
    );
  }

  function clauseHasExpandedInvestmentOfferRisk(clause) {
    const investmentPromise =
      /(?:guaranteed (?:tripling|returns?)|no loss (?:automated )?fund|invitation only presale|private allocation|stablecoin|triplement garanti|fonds(?: [\p{L}\p{N}]+){0,3} sans perte|prevente sur invitation|allocation privee|jetons? stables?|triplicacion garantizada|fondo(?: [\p{L}\p{N}]+){0,3} sin perdidas|preventa solo por invitacion|asignacion privada|moneda estable|garantierte verdreifachung|automatisierten fonds(?: [\p{L}\p{N}]+){0,3} verlustfreiheit|privaten vorverkauf|private zuteilung|stablecoins?)/u;
    const fundingOrSecret =
      /(?:opening deposit|wallet seed words?|prepaid vouchers?|return(?: [\p{L}\p{N}]+){0,4} codes?|depot initial|mots? secrets? du portefeuille|bons? prepayes?|renvoyez(?: [\p{L}\p{N}]+){0,4} codes?|deposito inicial|palabras? semilla(?: [\p{L}\p{N}]+){0,3} cartera|vales? prepagados?|devuelva(?: [\p{L}\p{N}]+){0,4} codigos?|ersteinlage|seed worter(?: [\p{L}\p{N}]+){0,3} geldborse|guthabengutscheine|senden sie(?: [\p{L}\p{N}]+){0,4} codes?)/u;
    const action =
      /(?:\b(?:transfer|send|disclose|enter|purchase|buy|return|deposit|connect)\b|transferez|envoyez|revelez|saisissez|achetez|renvoyez|deposez|connectez|transfiera|envie|revele|introduzca|compre|devuelva|deposite|conecte|ubertragen sie|senden sie|offenbaren sie|geben sie|kaufen sie|einzahlen sie|verbinden sie)/u;
    return (
      investmentPromise.test(clause) &&
      (fundingOrSecret.test(clause) || clauseHasCryptoTransferRisk(clause)) &&
      textHasUnnegatedDirectRequest(clause, action)
    );
  }

  function clauseHasExpandedAdvanceFeeOfferRisk(clause) {
    const windfall =
      /(?:unentered lottery|lottery(?: [\p{L}\p{N}]+){0,4} did not enter|unexpected estate documents?|grant|award|prize|loterie(?: [\p{L}\p{N}]+){0,7} pas participe|documents successoraux inattendus|subvention|recompense|loteria(?: [\p{L}\p{N}]+){0,7} no participo|documentos hereditarios inesperados|ayuda|premio|nicht gespielten lotterie|unerwartete nachlassdokumente|zuschuss|gewinn)/u;
    const upfrontCostOrSecret =
      /(?:validation cost|courier clearance|card security digits|award tax|voucher codes?|frais de validation|dedouanement du coursier|cryptogramme de carte|taxe de recompense|codes? de bons?|coste de validacion|despacho de mensajeria|digitos de seguridad de la tarjeta|impuesto del premio|codigos? de vales?|prufkosten|kurierabfertigung|kartenprufziffern|gewinnsteuer|gutscheincodes)/u;
    const action =
      /(?:\b(?:wire|pay|share|provide|settle|send|transfer)\b|virez|payez|partagez|fournissez|reglez|envoyez|transferez|transfiera|pague|comparta|facilite|abone|envie|uberweisen sie|bezahlen sie|teilen sie|geben sie|begleichen sie|senden sie)/u;
    return (
      windfall.test(clause) &&
      upfrontCostOrSecret.test(clause) &&
      textHasUnnegatedDirectRequest(clause, action)
    );
  }

  function clauseHasExpandedMediaExtortionRisk(clause) {
    if (clauseHasNarrativeReviewContext(clause)) {
      return false;
    }
    const allegedMedia =
      /(?:private recordings?|alleged captures?|files?(?: [\p{L}\p{N}]+){0,6} address book|coercive media claim|enregistrements? prives?|captures? alleguees?|fichiers?(?: [\p{L}\p{N}]+){0,6} carnet d adresses|chantage(?: [\p{L}\p{N}]+){0,4} medias prives|grabaciones? privadas?|supuestas? capturas?|archivos?(?: [\p{L}\p{N}]+){0,6} libreta de contactos|chantaje(?: [\p{L}\p{N}]+){0,4} material privado|privat(?:e|en|er|es)? aufnahmen?|behauptet(?:e|en|er|es)? aufnahmen?|dateien?(?: [\p{L}\p{N}]+){0,6} adressbuch|erpressung(?: [\p{L}\p{N}]+){0,4} privaten medien)/u;
    const paymentObject =
      /(?:crypto|cryptocurrency|debit card information|vouchers?|wallet|funds|cryptomonnaie|donnees? de carte de debit|bons?|portefeuille|fonds|criptomoneda|informacion de la tarjeta de debito|vales?|cartera|fondos|kryptowahrung|debitkartendaten|gutscheine?|geldborse|geld)/u;
    const coerciveOutcome =
      /(?:silence|deleted|hide(?: [\p{L}\p{N}]+){0,4} transaction|address book(?: [\p{L}\p{N}]+){0,5} files|faire taire|supprimees|cachez(?: [\p{L}\p{N}]+){0,4} operation|carnet d adresses|silenciar|eliminar|oculte(?: [\p{L}\p{N}]+){0,4} operacion|libreta de contactos|zum schweigen|geloscht|verbergen sie(?: [\p{L}\p{N}]+){0,4} transaktion|adressbuch)/u;
    const action =
      /(?:\b(?:buy|send|pay|hide|connect|transfer)\b|achetez|envoyez|payez|cachez|connectez|virez|compre|envie|pague|oculte|conecte|transfiera|kaufen sie|senden sie|zahlen sie|verbergen sie|verbinden sie|ubertragen sie)/u;
    return (
      allegedMedia.test(clause) &&
      paymentObject.test(clause) &&
      coerciveOutcome.test(clause) &&
      textHasUnnegatedDirectRequest(clause, action)
    );
  }

  function clauseHasExpandedDeliverySensitiveRisk(clause) {
    const deliveryContext =
      /(?:consignment|warehouse|driver|delivery slot|dispatcher|parcel|shipment|envoi|entrepot|chauffeur|creneau|repartiteur|colis|envio|almacenaje|conductor|franja de entrega|distribuidor|paquete|sendung|lagerung|fahrer|termin|disposition|paket)/u;
    const riskyDetail =
      /(?:storage|insurance deposit|small card debit|one time number|identity document|online bank login|stockage|garantie d assurance|petit debit|numero a usage unique|piece d identite|acces bancaire|almacenaje|deposito de seguro|pequeno cargo|numero de un solo uso|documento de identidad|acceso bancario|lagerung|versicherungsleistung|kartenbelastung|einmalnummer|ausweisbild|onlinebanking anmeldung)/u;
    const action =
      /(?:\b(?:pay|provide|send|schedule|open|approve|return|wire|transfer)\b|reglez|donnez|envoyez|programmez|ouvrez|validez|renvoyez|virez|transferez|pague|facilite|envie|programe|abra|apruebe|devuelva|transfiera|bezahlen sie|geben sie|senden sie|planen sie|offnen sie|genehmigen sie|uberweisen sie)/u;
    return (
      deliveryContext.test(clause) &&
      riskyDetail.test(clause) &&
      textHasUnnegatedDirectRequest(clause, action)
    );
  }

  function clauseHasExpandedCustomsSensitiveRisk(clause) {
    const customsContext =
      /(?:customs|import|seizure|quarantine inspection|douane|importation|saisie|controle sanitaire|aduana|importacion|incautacion|inspeccion sanitaria|zoll|einfuhr|beschlagnahme|quarantaneprufung)/u;
    const riskyDetail =
      /(?:import bond|card password|online bank login|prepaid codes?|quarantine inspection charge|caution d importation|code de la carte|acces bancaire|codes? prepayes?|frais de controle sanitaire|fianza de importacion|clave de la tarjeta|acceso bancario|codigos? prepagados?|cargo de inspeccion sanitaria|importsicherheit|kartenpasswort|onlinebanking anmeldung|guthabencodes|quarantaneprufung)/u;
    const action =
      /(?:\b(?:pay|provide|send|buy|wire|transfer)\b|payez|fournissez|envoyez|achetez|virez|transferez|pague|facilite|envie|compre|transfiera|zahlen sie|geben sie|senden sie|kaufen sie|uberweisen sie)/u;
    return (
      customsContext.test(clause) &&
      riskyDetail.test(clause) &&
      textHasUnnegatedDirectRequest(clause, action)
    );
  }

  function clauseHasExpandedRetentionDeletionRisk(clause) {
    const destructiveState =
      /(?:retention|purge|preservation|countdown|stored files|conservation|purge|redevance de conservation|compte a rebours|fichiers stockes|conservacion|purga|tasa de conservacion|cuenta atras|archivos almacenados|aufbewahrung|loschung|erhaltungsabgabe|zahler|dateien)/u;
    const requestedRisk =
      /(?:password|security answers?|one time login number|administrator password|card pin|mot de passe|reponses? secretes?|numero de connexion a usage unique|mot de passe administrateur|code de carte|contrasena|respuestas? secretas?|numero de acceso de un solo uso|contrasena de administrador|pin de la tarjeta|passwort|sicherheitsantworten|einmalige anmeldenummer|administratorpasswort|karten pin)/u;
    const action =
      /(?:\b(?:enter|provide|reply|download|share|pay|submit)\b|saisissez|donnez|repondez|telechargez|communiquez|payez|envoyez|introduzca|facilite|responda|descargue|comparta|pague|escriba|geben sie|senden sie|laden sie|teilen sie|bezahlen sie)/u;
    return (
      destructiveState.test(clause) &&
      requestedRisk.test(clause) &&
      textHasUnnegatedDirectRequest(clause, action)
    );
  }

  function buildBehavioralSignals(actionableClauses, sourceClauses = actionableClauses) {
    const behavioralClauses = behavioralRiskClauses(actionableClauses);
    const clauses = boundedBehavioralContexts(behavioralClauses);
    const nearbyClauses = boundedNearbyClauseContexts(behavioralClauses);
    const unfilteredClauses = boundedBehavioralContexts(contentRiskClauses(sourceClauses));
    const signals = [];
    const add = (id, label, weight, evidence) => {
      if (!signals.some((signal) => signal.id === id)) {
        signals.push({ id, label, weight, matchCount: 1, phrases: [evidence] });
      }
    };
    const some = (predicate) => clauses.some(predicate);

    if (
      some(
        (clause) =>
          clauseHasHighRiskPaymentInstruction(clause) ||
          (behavioralPatternMatches(clause, "emergency") &&
            /(?:accepts? only|accepte uniquement|solo acepta|akzeptiert nur).*(?:money|argent|dinero|geld)/u.test(
              clause
            ))
      )
    ) {
      add("behavior-payment", "unusual payment request", 3, "payment action and payment method");
    }

    if (
      nearbyClauses.some(
        (clause) =>
          clauseHasBusinessPaymentDiversionRisk(clause) ||
          clauseHasPaymentDiversionCompound(clause) ||
          clauseHasExpandedFinancialDiversionRisk(clause) ||
          clauseHasSwiftPaymentDiversionRisk(clause) ||
          clauseHasPayrollDiversionRisk(clause)
      )
    ) {
      add(
        "behavior-business-payment",
        "business payment diversion",
        5,
        "business payment, beneficiary, escrow, or gift-card instruction"
      );
    }

    if (some((clause) => patternHasUnnegatedMatch(clause, "bankChange"))) {
      add("behavior-bank-change", "unexpected bank-detail change", 3, "new beneficiary or account");
    }

    if (some((clause) => patternHasUnnegatedMatch(clause, "secrecy"))) {
      add("behavior-secrecy", "secrecy or isolation pressure", 2, "request to hide or isolate the action");
    }

    const hasCredentialEntryRequest = behavioralClauses.some(
      (clause, index) =>
        !clauseHasProtectiveCredentialReview(clause) &&
        textHasUnnegatedDirectRequest(
          clause,
          BEHAVIOR_PATTERNS.credentialAction
        ) &&
        behavioralPatternMatches(clause, "credentialObject") &&
        (behavioralPatternMatches(clause, "riskySurface") ||
          behavioralPatternMatches(clause, "emergency") ||
          behavioralPatternMatches(
            behavioralClauses[index + 1] || "",
            "riskySurface"
          ))
    );
    if (hasCredentialEntryRequest) {
      add("behavior-credentials", "credential entry on a requested page", 5, "access secret and requested page");
    }

    if (
      unfilteredClauses.some((clause) =>
        clauseHasCredentialTransmissionRequest(clause) ||
        clauseHasExpandedSecretDisclosureRisk(clause)
      )
    ) {
      add(
        "behavior-credentials",
        "credential disclosure request",
        5,
        "request to transmit an access secret"
      );
    }

    if (
      contentRiskClauses(sourceClauses).some((clause) =>
        clauseHasSecretBundledForwardRequest(clause)
      )
    ) {
      add(
        "behavior-credentials",
        "credential disclosure request",
        5,
        "a forwarded message is bundled with a current access secret"
      );
    }

    if (
      behavioralClauses.some((clause) =>
        clauseHasCredentialExfiltrationCompound(clause)
      )
    ) {
      add(
        "behavior-credentials",
        "credential disclosure request",
        5,
        "direct request to disclose an access secret"
      );
    }

    if (some((clause) => clauseHasAuthenticatorCodeRequest(clause))) {
      add(
        "behavior-credentials",
        "authenticator-code disclosure request",
        5,
        "request to send a code from an authenticator"
      );
    }

    const hasCredentialFollowUp = sourceClauses.some(
      (clause, index) =>
        behavioralPatternMatches(clause, "credentialObject") &&
        sourceClauses
          .slice(index + 1, index + 3)
          .some((nextClause) => clauseHasCredentialFollowUpRequest(nextClause))
    );
    if (
      hasCredentialFollowUp ||
      some((clause) => clauseHasCredentialExceptionRequest(clause))
    ) {
      add(
        "behavior-credentials",
        "credential disclosure request",
        5,
        "a later instruction asks for the referenced secret"
      );
    }

    if (some((clause) => clauseHasMfaPushRequest(clause))) {
      add(
        "behavior-mfa-push",
        "unexpected MFA approval request",
        5,
        "request to approve an MFA push"
      );
    }

    if (some((clause) => clauseHasGiftCardEvidenceRequest(clause))) {
      add(
        "behavior-gift-card-evidence",
        "gift-card code or photo request",
        5,
        "request to send gift-card evidence"
      );
    }

    if (
      some(
        (clause) =>
          patternHasUnnegatedMatch(clause, "sensitiveAction") &&
          behavioralPatternMatches(clause, "sensitiveObject")
      )
    ) {
      add("behavior-personal-data", "sensitive personal-data request", 3, "identity or financial details");
    }

    if (
      some(
        (clause) =>
          /(?:refund|reimbursement|tax overpayment|remboursement|trop percu fiscal|reembolso|devolucion|exceso de impuestos|ruckzahlung|steuererstattung)/u.test(
            clause
          ) &&
          behavioralPatternMatches(clause, "riskySurface") &&
          behavioralPatternMatches(clause, "sensitiveObject")
      )
    ) {
      add("behavior-refund-form", "refund or payment form request", 3, "financial form and sensitive details");
    }

    const refundApprovalAction =
      /\b(?:approve|approuvez|apruebe|genehmigen sie)\b/u;
    const refundBankingSurface =
      /(?:mobile banking|banking app|application bancaire|demande bancaire|banca movil|aplicacion bancaria|banking anwendung|banking app)/u;
    const hasRefundClaim = some((clause) =>
      /(?:refund|reimbursement|tax overpayment|remboursement|trop percu fiscal|reembolso|devolucion|exceso de impuestos|ruckzahlung|steuererstattung)/u.test(
        clause
      )
    );
    if (
      hasRefundClaim &&
      some(
        (clause) =>
          (patternHasUnnegatedMatch(clause, "sensitiveAction") &&
            behavioralPatternMatches(clause, "sensitiveObject")) ||
          (refundBankingSurface.test(clause) &&
            textHasUnnegatedDirectRequest(clause, refundApprovalAction))
      )
    ) {
      add("behavior-refund-form", "refund or payment form request", 3, "refund approval or card details");
    }

    if (
      behavioralClauses.some(
        (clause) =>
          patternHasUnnegatedMatch(clause, "investment") &&
          (!/(?:seminar|education|webinar|course|training|compliance|scam|fraud awareness|discusse?s?|reviews?)/u.test(
            clause
          ) ||
            clauseHasUnnegatedMoneyAction(clause))
      ) ||
      nearbyClauses.some(
        (clause) =>
          clauseHasExpandedInvestmentRisk(clause) ||
          clauseHasInvestmentSolicitationCompound(clause) ||
          clauseHasExpandedInvestmentOfferRisk(clause)
      )
    ) {
      add("behavior-investment", "high-risk investment promise", 3, "returns, wallet, or withdrawal fee");
    }

    if (
      some(
        (clause) =>
          behavioralPatternMatches(clause, "jobScheme") &&
          clauseHasJobSchemeRisk(clause)
      )
    ) {
      add("behavior-job", "job or equipment-payment scheme", 3, "remote job payment pattern");
    }

    if (some((clause) => patternHasUnnegatedMatch(clause, "emergency"))) {
      add("behavior-emergency", "authority, medical, or deadline pressure", 3, "urgent consequence or emergency");
    }

    if (some((clause) => clauseHasAccountRestrictionRisk(clause))) {
      add(
        "behavior-account-restriction",
        "restricted account with a requested action",
        3,
        "account restriction and corrective action"
      );
    }

    if (nearbyClauses.some((clause) => clauseHasMailboxTakeoverRisk(clause))) {
      add(
        "behavior-mailbox-takeover",
        "mailbox takeover instruction",
        5,
        "login update or message-loss pressure"
      );
    }

    if (
      nearbyClauses.some(
        (clause) =>
          clauseHasAdvanceFeeWindfallRisk(clause) ||
          clauseHasExpandedAdvanceFeeRisk(clause) ||
          clauseHasAdvanceFeeSolicitationCompound(clause) ||
          clauseHasExpandedAdvanceFeeOfferRisk(clause)
      )
    ) {
      add(
        "behavior-advance-fee",
        "unexpected high-value windfall",
        3,
        "large cheque, transfer, policy, or lottery claim"
      );
    }

    if (
      boundedNearbyClauseContexts(contentRiskClauses(sourceClauses)).some(
        (clause) =>
          clauseHasDestructiveDeadlineRisk(clause) ||
          clauseHasAccountDeletionActionRisk(clause) ||
          clauseHasDeletionSensitiveCompound(clause) ||
          clauseHasExpandedRetentionDeletionRisk(clause)
      )
    ) {
      add(
        "behavior-data-deletion",
        "destructive deadline pressure",
        3,
        "files or account data threatened with deletion"
      );
    }

    if (nearbyClauses.some((clause) => clauseHasDestructiveSubscriptionRisk(clause))) {
      add(
        "behavior-subscription-loss",
        "destructive subscription pressure",
        3,
        "account, photos, or files threatened during renewal"
      );
    }

    if (nearbyClauses.some((clause) => clauseHasBrowserUpdateImpersonationRisk(clause))) {
      add(
        "behavior-browser-update",
        "browser update asks for an account change",
        3,
        "browser vulnerability tied to an account update"
      );
    }

    if (nearbyClauses.some((clause) => clauseHasAntivirusScareRisk(clause))) {
      add(
        "behavior-antivirus-scare",
        "antivirus infection scare",
        3,
        "infection claim tied to a license or subscription action"
      );
    }

    if (
      contextsHaveSextortionRisk(
        nearbyClauses.filter(
          (clause) =>
            !/(?:security newsletter|security awareness)(?: [\p{L}\p{N}]+){0,40} editorial corrections/u.test(
              clause
            )
        )
      ) ||
      nearbyClauses.some(
        (clause) =>
          !/(?:security newsletter|security awareness)(?: [\p{L}\p{N}]+){0,40} editorial corrections/u.test(
            clause
          ) &&
          (clauseHasExpandedSextortionRisk(clause) ||
            clauseHasSextortionCompound(clause) ||
            clauseHasExpandedMediaExtortionRisk(clause))
      )
    ) {
      add(
        "behavior-sextortion",
        "webcam extortion and crypto payment",
        5,
        "webcam publication threat and crypto payment destination"
      );
    }

    if (
      nearbyClauses.some(
        (clause) =>
          !/(?:customs training|training example)(?: [\p{L}\p{N}]+){0,40} workshop registration/u.test(
            clause
          ) &&
          (clauseHasDeliveryRisk(clause) ||
            clauseHasExpandedDeliveryRisk(clause) ||
            clauseHasDeliverySensitiveCompound(clause) ||
            clauseHasExpandedDeliverySensitiveRisk(clause))
      )
    ) {
      add("behavior-delivery", "delivery or customs action", 3, "parcel, customs, or redelivery");
    }

    if (
      nearbyClauses.some(
        (clause) =>
          !/(?:customs training|training example)(?: [\p{L}\p{N}]+){0,40} workshop registration/u.test(
            clause
          ) &&
          (clauseHasCustomsReleaseRisk(clause) ||
            clauseHasExpandedCustomsRisk(clause) ||
            clauseHasCustomsDiversionCompound(clause) ||
            clauseHasExpandedCustomsSensitiveRisk(clause))
      )
    ) {
      add(
        "behavior-customs-release",
        "customs-release payment pressure",
        3,
        "held parcel, import charge, and release action"
      );
    }

    if (
      unfilteredClauses.some(
        (clause) =>
          clauseHasCallbackRisk(clause) ||
          clauseHasExpandedCallbackRisk(clause) ||
          clauseHasCallbackDisclosureCompound(clause) ||
          clauseHasExpandedRefundDisclosureRisk(clause) ||
          (clauseHasUnnegatedAction(clause, [
            "call",
            "dial",
            "ring",
            "telephone",
            "appelez",
            "telephonez",
            "llame",
            "marque",
            "rufen sie"
          ]) &&
            behavioralPatternMatches(clause, "disputedCharge") &&
            behavioralPatternMatches(clause, "remoteAccess"))
      )
    ) {
      add("behavior-callback", "callback phishing instruction", 5, "phone number and disputed charge");
    }

    if (
      some(
        (clause) =>
          clauseHasExpandedRemoteAccessRisk(clause) ||
          clauseHasNamedRemoteToolHandoff(clause) ||
          clauseHasRemoteControlCompound(clause) ||
          clauseHasExpandedDelegatedRemoteRisk(clause) ||
          (clauseHasUnnegatedRemoteAccessInstruction(clause) &&
            (behavioralPatternMatches(clause, "callback") ||
              behavioralPatternMatches(clause, "credentialObject") ||
              behavioralPatternMatches(clause, "disputedCharge")))
      )
    ) {
      add("behavior-remote-access", "remote-access instruction", 5, "remote tool or session access");
    }

    if (some((clause) => behavioralPatternMatches(clause, "riskyAttachment"))) {
      add("behavior-attachment", "risky image or web attachment", 5, "HTML, image-only, or QR attachment");
    }

    if (
      nearbyClauses.some(
        (clause) =>
          (behavioralPatternMatches(clause, "qrAction") &&
            (clauseHasQrRisk(clause) || clauseHasExpandedQrRisk(clause))) ||
          clauseHasQrSensitiveDisclosureCompound(clause) ||
          clauseHasExpandedSquareQrRisk(clause)
      ) ||
      clauses.some(
        (clause) =>
          clauseHasQrSensitiveCompound(clause) ||
          clauseHasExpandedSquareQrRisk(clause)
      )
    ) {
      add("behavior-qr", "QR or camera action", 5, "QR code used to open a requested page");
    }

    return signals;
  }

  function trustedSenderContext(options) {
    const trustedSender = options && options.trustedSender;
    if (!trustedSender) {
      return null;
    }

    const brand = String(trustedSender.brand || "").trim();
    const senderDomain = normalizeDomain(trustedSender.senderDomain);
    if (!brand && !senderDomain) {
      return null;
    }

    return { brand, senderDomain };
  }

  function trustedPaymentNoticeMessage(sender) {
    const source = sender.senderDomain
      ? sender.brand
        ? `${sender.senderDomain}, a known ${sender.brand} domain`
        : `${sender.senderDomain}, a known sender domain`
      : sender.brand
        ? `a known ${sender.brand} domain`
        : "a known sender domain";
    return `This payment-related message comes from ${source}. Review the amount and recipient, and use your usual account page if anything feels off.`;
  }

  function trustedContentCheckMessage(sender, labels) {
    const source = sender.senderDomain
      ? sender.brand
        ? `${sender.senderDomain}, a known ${sender.brand} domain`
        : `${sender.senderDomain}, a known sender domain`
      : sender.brand
        ? `a known ${sender.brand} domain`
        : "a known sender domain";
    return `This message comes from ${source}, but it includes wording worth checking: ${labels}. Use your usual app or website if anything feels off.`;
  }

  function contentWarningMessage(labels, risks) {
    if (risks.hasPersonalInfo && risks.hasReward) {
      return `This message combines an unexpected reward with a request for personal details: ${labels}. Don't reply with personal details or contact the address in the message.`;
    }
    if (risks.hasPersonalInfo) {
      return `This message asks for personal details in a risky way: ${labels}. Don't reply with personal details until you check the sender another way.`;
    }
    if (risks.hasCredentials) {
      return `This message asks for sensitive access details: ${labels}. Don't enter passwords, security codes, or recovery details.`;
    }
    if (risks.hasDelivery || risks.hasPayment) {
      return `This message puts pressure on you: ${labels}. Don't use links in the message for delivery, payment, or login details.`;
    }

    return `This message puts pressure on you: ${labels}. Check another way before acting.`;
  }

  function analyzeContent(contentText, options = {}) {
    const rawText = String(contentText || "");
    const text = rawText.replace(/\s+/g, " ").trim();
    if (text.length < 8) {
      return {
        status: "unknown",
        severity: "none",
        score: 0,
        signals: [],
        message: "Not enough mail content to analyze."
      };
    }

    const fingerprint = fingerprintText(text);
    const signals = [];
    const seenEvidence = new Set();
    let score = 0;

    const normalizedText = normalizeSecurityText(text);
    const normalizedClauses = normalizedContentClauses(rawText);
    // Link destinations are analyzed separately by analyzeUrl/analyzeLink. Do
    // not let query-parameter words such as "page", "otpToken", or "confirm"
    // combine into a behavioral request that was never visible in the mail.
    const normalizedBehavioralClauses = normalizedContentClauses(
      rawText.replace(/https?:\/\/[^\s<>"']+/giu, " ")
    );
    // Keep awareness material from becoming a warning merely because it quotes
    // a scam. The exemption is clause-scoped and requires both an explicit
    // education frame and a protective instruction in that or the next clause,
    // so a later real request is still analyzed normally.
    const riskClauses = contentRiskClauses(normalizedClauses);
    const riskText = riskClauses.join(" ");
    const personalInfoRiskText = riskClauses
      .filter(
        (clause) =>
          !clauseIsRoutineInPersonIdentityCheck(clause) &&
          !PERSONAL_INFO_SAFETY_TERMS.some((term) => clause.includes(normalizeText(term)))
      )
      .join(" ");
    const paymentRiskText = riskClauses
      .filter(
        (clause, index) =>
          !containsAnyTerm(clause, PAYMENT_SAFETY_TERMS) &&
          !clauseHasNarrativeReviewContext(
            [clause, riskClauses[index + 1] || ""].join(" ")
          )
      )
      .join(" ");
    for (const group of contentGroupsWithNormalizedPhrases()) {
      const matchedPhrases = group.phrases
        .filter((phrase) =>
          contentHasSignalPhrase(
            riskText,
            riskClauses,
            personalInfoRiskText,
            paymentRiskText,
            group,
            phrase
          )
        )
        .map((phrase) => phrase.phrase)
        .filter((phrase) => !seenEvidence.has(normalizeText(phrase)));
      if (matchedPhrases.length === 0) {
        continue;
      }

      matchedPhrases.forEach((phrase) => seenEvidence.add(normalizeText(phrase)));
      // Several words from one topic are one piece of evidence, not several
      // independent risk signals (for example parcel + shipment + tracking).
      score += group.weight;
      signals.push({
        id: group.id,
        label: group.label,
        matchCount: matchedPhrases.length,
        phrases: matchedPhrases.slice(0, 3)
      });
    }

    const behavioralSignalEquivalents = {
      "behavior-account-restriction": "threat",
      "behavior-attachment": "attachment",
      "behavior-credentials": "credentials",
      "behavior-data-deletion": "data-loss",
      "behavior-delivery": "delivery",
      "behavior-payment": "payment",
      "behavior-personal-data": "personal-info",
      "behavior-secrecy": "secrecy"
    };
    const behavioralSignals = buildBehavioralSignals(
      contentRiskClauses(normalizedBehavioralClauses),
      normalizedBehavioralClauses
    );
    const compoundBehaviorIds = new Set(
      behavioralSignals.map((signal) => signal.id)
    );
    for (const behavioralSignal of behavioralSignals) {
      const equivalentId = behavioralSignalEquivalents[behavioralSignal.id];
      if (equivalentId && signals.some((signal) => signal.id === equivalentId)) {
        continue;
      }
      score += behavioralSignal.weight;
      signals.push({
        id: behavioralSignal.id,
        label: behavioralSignal.label,
        matchCount: behavioralSignal.matchCount,
        phrases: behavioralSignal.phrases,
        weight: behavioralSignal.weight
      });
    }

    const hasCredentials = signals.some(
      (signal) =>
        signal.id === "credentials" ||
        signal.id === "behavior-credentials" ||
        signal.id === "behavior-mailbox-takeover"
    );
    const hasUrgency = signals.some((signal) => signal.id === "urgency");
    const hasPayment = signals.some(
      (signal) =>
        signal.id === "payment" ||
        signal.id === "behavior-payment" ||
        signal.id === "behavior-business-payment" ||
        signal.id === "behavior-bank-change" ||
        signal.id === "behavior-refund-form" ||
        signal.id === "behavior-investment"
    );
    const hasIndependentPaymentDemand = signals.some(
      (signal) =>
        signal.id === "payment" ||
        signal.id === "behavior-payment" ||
        signal.id === "behavior-business-payment" ||
        signal.id === "behavior-refund-form"
    );
    const hasPersonalInfo = signals.some(
      (signal) => signal.id === "personal-info" || signal.id === "behavior-personal-data"
    );
    const hasThreat = signals.some(
      (signal) =>
        signal.id === "threat" ||
        signal.id === "behavior-sextortion" ||
        signal.id === "behavior-subscription-loss"
    );
    const hasDelivery = signals.some(
      (signal) =>
        signal.id === "delivery" ||
        signal.id === "behavior-delivery" ||
        signal.id === "behavior-customs-release"
    );
    const hasReward = signals.some(
      (signal) => signal.id === "reward" || signal.id === "behavior-advance-fee"
    );
    const hasDataLoss = signals.some(
      (signal) =>
        signal.id === "data-loss" || signal.id === "behavior-subscription-loss"
    );
    const hasAttachment = signals.some(
      (signal) => signal.id === "attachment" || signal.id === "behavior-attachment"
    );
    const hasImpersonation = signals.some((signal) => signal.id === "impersonation");
    const hasLinkPressure = signals.some((signal) => signal.id === "link-pressure");
    const hasSecrecy = signals.some(
      (signal) => signal.id === "secrecy" || signal.id === "behavior-secrecy"
    );
    const trustedSender = trustedSenderContext(options);
    const hasUnsafeInstruction = normalizedClauses.some(clauseHasUnsafeInstruction);
    const hasSecretExfiltration = normalizedClauses.some(
      (clause) =>
        behavioralPatternMatches(clause, "credentialObject") &&
        clauseHasUnnegatedAction(clause, CREDENTIAL_DISCLOSURE_TERMS) &&
        /(?:send|share|provide|paste|submit|reply|email|give|forward|copy|upload|envoy|partag|fourn|repond|senden|teilen|invia|condividi|envie|comparta)/u.test(
          clause
        )
    );
    const dangerousBehaviorIds = new Set([
      "behavior-bank-change",
      "behavior-business-payment",
      "behavior-callback",
      "behavior-investment",
      "behavior-remote-access",
      "behavior-secrecy"
    ]);
    const hasDangerousBehavior = signals.some((signal) => dangerousBehaviorIds.has(signal.id));
    const standaloneBehaviorIds = new Set([
      "behavior-advance-fee",
      "behavior-antivirus-scare",
      "behavior-attachment",
      "behavior-account-restriction",
      "behavior-bank-change",
      "behavior-business-payment",
      "behavior-browser-update",
      "behavior-callback",
      "behavior-credentials",
      "behavior-customs-release",
      "behavior-data-deletion",
      "behavior-delivery",
      "behavior-gift-card-evidence",
      "behavior-investment",
      "behavior-job",
      "behavior-mailbox-takeover",
      "behavior-mfa-push",
      "behavior-payment",
      "behavior-qr",
      "behavior-refund-form",
      "behavior-remote-access",
      "behavior-sextortion",
      "behavior-subscription-loss"
    ]);
    const hasStandaloneBehavioralRisk = [...compoundBehaviorIds].some((id) =>
      standaloneBehaviorIds.has(id)
    );
    const credentialSignal = signals.find((signal) => signal.id === "credentials");
    const personalInfoSignal = signals.find((signal) => signal.id === "personal-info");
    const hasPersonalInfoRequestAction = containsAnyTerm(
      personalInfoRiskText,
      PERSONAL_INFO_REQUEST_ACTION_TERMS
    );
    const hasHighRiskPersonalInfo = containsAnyTerm(
      personalInfoRiskText,
      HIGH_RISK_PERSONAL_INFO_TERMS
    );
    const hasDirectPersonalInfoRequest =
      Boolean(personalInfoSignal) &&
      hasPersonalInfoRequestAction &&
      (hasHighRiskPersonalInfo || personalInfoSignal.matchCount >= 3);
    const hasOnlyPaymentInfoCredential =
      Boolean(credentialSignal) &&
      credentialSignal.phrases.every((phrase) => paymentInfoCredentialPhrases().has(normalizeText(phrase)));
    const hasHighRiskPayment = signals.some(
      (signal) =>
        signal.id === "payment" &&
        signal.phrases.some((phrase) =>
          HIGH_RISK_PAYMENT_TERMS.includes(normalizeText(phrase))
        )
    );
    const highRiskPaymentPhrases = signals
      .filter((signal) => signal.id === "payment")
      .flatMap((signal) => signal.phrases)
      .filter((phrase) => HIGH_RISK_PAYMENT_TERMS.includes(normalizeText(phrase)));
    const hasOnlyCryptoHighRiskPayment =
      highRiskPaymentPhrases.length > 0 &&
      highRiskPaymentPhrases.every((phrase) =>
        ["bitcoin", "crypto", "usdt"].includes(normalizeText(phrase))
      );
    const hasCryptoTransferRisk =
      riskClauses.some(clauseHasCryptoTransferRisk) ||
      (riskText.length <= 520 && clauseHasCryptoTransferRisk(riskText));
    const hasPaymentAction = containsAnyTerm(paymentRiskText, PAYMENT_ACTION_TERMS);
    const hasReceiptContext = containsAnyTerm(normalizedText, PAYMENT_RECEIPT_TERMS);
    const hasDeliveryPressure = containsAnyTerm(normalizedText, DELIVERY_PRESSURE_TERMS);
    const isRoutineDeliveryClickOnly =
      hasDelivery &&
      hasLinkPressure &&
      !hasDeliveryPressure &&
      !compoundBehaviorIds.has("behavior-delivery") &&
      signals.every((signal) => ["delivery", "link-pressure"].includes(signal.id));
    const hasExpectedSafeFlow =
      Boolean(trustedSender) &&
      normalizedClauses.some((clause) => behavioralPatternMatches(clause, "safeFlow")) &&
      !hasUnsafeInstruction &&
      !hasUrgency &&
      !hasThreat &&
      !hasSecrecy &&
      !signals.some((signal) =>
        [
          "behavior-bank-change",
          "behavior-callback",
          "behavior-emergency",
          "behavior-investment",
          "behavior-job",
          "behavior-remote-access"
        ].includes(signal.id)
      );
    const hasRiskyCredentials = hasCredentials && (!hasExpectedSafeFlow || hasUnsafeInstruction);
    const hasRiskyDirectPersonalInfo = hasDirectPersonalInfoRequest && !hasExpectedSafeFlow;
    const strongRewardClaimCount = STRONG_REWARD_CLAIM_TERMS.filter((term) =>
      hasAlias(normalizedText, term)
    ).length;
    const hasStrongRewardClaim = hasReward && strongRewardClaimCount >= 2;
    const hasQrCredentialRisk = compoundBehaviorIds.has("behavior-qr");
    const hasHighRiskPaymentRequest =
      hasHighRiskPayment &&
      (!hasOnlyCryptoHighRiskPayment || hasCryptoTransferRisk) &&
      (hasPaymentAction || hasUrgency || hasLinkPressure || hasSecrecy) &&
      (!hasReceiptContext || hasUrgency || hasLinkPressure || hasSecrecy);
    const isWarning =
      (!isRoutineDeliveryClickOnly || Boolean(trustedSender)) &&
      (score >= 5 ||
      hasCredentials ||
      hasStandaloneBehavioralRisk ||
      hasHighRiskPaymentRequest ||
      hasDirectPersonalInfoRequest ||
      hasStrongRewardClaim ||
      (hasPersonalInfo && (hasReward || hasImpersonation)) ||
      (hasReward && hasImpersonation) ||
      (hasUrgency && (hasPayment || hasThreat)) ||
      (hasUrgency && hasDelivery) ||
      (hasDelivery && hasLinkPressure && hasDeliveryPressure) ||
      (hasPayment && hasThreat) ||
      (hasThreat && hasLinkPressure) ||
      (hasDataLoss && (hasUrgency || hasLinkPressure)) ||
      (hasAttachment && (hasUrgency || hasLinkPressure)));

    if (!isWarning) {
      return {
        status: "unknown",
        severity: "none",
        score,
        fingerprint,
        signals,
        message: "No strong phishing language detected in the mail content."
      };
    }

    const labels = signals.map((signal) => signal.label).slice(0, 3).join(", ");
    const hasCriticalAdversarialRelation =
      (hasUrgency && hasDelivery && hasLinkPressure) ||
      (hasUrgency && hasPayment && hasSecrecy) ||
      (hasPersonalInfo && hasReward && hasImpersonation) ||
      (hasDangerousBehavior &&
        (hasUrgency ||
          hasLinkPressure ||
          hasIndependentPaymentDemand ||
          hasCredentials ||
          hasSecrecy));
    const severity =
      hasCriticalAdversarialRelation
        ? "critical"
        : score >= 7 ||
            hasQrCredentialRisk ||
            hasRiskyCredentials ||
            hasHighRiskPaymentRequest ||
            (hasRiskyDirectPersonalInfo && hasHighRiskPersonalInfo) ||
            (hasUrgency && (hasPayment || hasThreat))
          ? "high"
          : "medium";
    const isTrustedSenderPaymentNotice =
      trustedSender &&
      severity === "medium" &&
      !hasHighRiskPaymentRequest &&
      !hasPersonalInfo &&
      (hasPayment || hasOnlyPaymentInfoCredential) &&
      (!hasCredentials || hasOnlyPaymentInfoCredential);
    const isSensitiveTrustedSenderRequest =
      hasSecretExfiltration ||
      hasDangerousBehavior ||
      (hasRiskyCredentials &&
        !hasExpectedSafeFlow &&
        (hasUrgency || hasThreat || hasLinkPressure || hasPayment)) ||
      hasHighRiskPaymentRequest ||
      (hasUrgency && hasPayment && hasThreat) ||
      (hasPersonalInfo && hasReward) ||
      (hasReward && hasImpersonation);
    const riskFlags = {
      dangerousBehavior: hasDangerousBehavior,
      expectedSafeFlow: hasExpectedSafeFlow,
      secretExfiltration: hasSecretExfiltration,
      unsafeInstruction: hasUnsafeInstruction,
      userInitiatedFlow: normalizedClauses.some((clause) =>
        /(?:you requested|reset was requested|request was made|vous avez demande|solicitaste|von ihnen angefordert)/u.test(
          clause
        )
      )
    };

    if (isTrustedSenderPaymentNotice) {
      return {
        status: "warning",
        severity: "low",
        context: "trusted-sender-payment",
        brand: trustedSender.brand || undefined,
        senderDomain: trustedSender.senderDomain || undefined,
        score,
        fingerprint,
        riskFlags,
        signals,
        message: trustedPaymentNoticeMessage(trustedSender)
      };
    }

    if (
      trustedSender &&
      hasExpectedSafeFlow &&
      !hasHighRiskPaymentRequest &&
      !hasThreat &&
      !hasSecrecy &&
      !signals.some((signal) =>
        ["behavior-callback", "behavior-investment", "behavior-job", "behavior-remote-access"].includes(
          signal.id
        )
      )
    ) {
      return {
        status: "warning",
        severity: "low",
        context: "expected-account-flow",
        brand: trustedSender?.brand || undefined,
        senderDomain: trustedSender?.senderDomain || undefined,
        score,
        fingerprint,
        riskFlags,
        signals,
        message:
          "This looks like an expected account step. Use the official app or a bookmark instead of following an unexpected message link."
      };
    }

    if (trustedSender && !isSensitiveTrustedSenderRequest) {
      return {
        status: "warning",
        severity:
          hasPersonalInfo || hasCredentials || severity === "high" || severity === "critical"
            ? "medium"
            : "low",
        context: "trusted-sender-content-check",
        brand: trustedSender.brand || undefined,
        senderDomain: trustedSender.senderDomain || undefined,
        score,
        fingerprint,
        riskFlags,
        signals,
        message: trustedContentCheckMessage(trustedSender, labels)
      };
    }

    return {
      status: "warning",
      severity,
      score,
      fingerprint,
      riskFlags,
      signals,
      message: contentWarningMessage(labels, {
        hasCredentials,
        hasDelivery,
        hasPayment,
        hasPersonalInfo,
        hasReward
      })
    };
  }

  function resultSeverityRank(result) {
    if (!result || result.status !== "warning") {
      return 0;
    }
    if (result.severity === "critical") {
      return 4;
    }
    if (result.severity === "high") {
      return 3;
    }
    if (result.severity === "medium") {
      return 2;
    }
    return 1;
  }

  function topMessageWarning(results) {
    return (
      (results || [])
        .filter((result) => result && result.status === "warning")
        .sort((first, second) => resultSeverityRank(second) - resultSeverityRank(first))[0] || null
    );
  }

  function reconcileMessageResults({ sender, links, content } = {}) {
    const senderResult = sender || null;
    const linkResults = Array.isArray(links) ? links.filter(Boolean) : [];
    const contentResult = content || null;
    let reconciledContent = contentResult;

    const trustedSender =
      senderResult &&
      senderResult.status === "trusted" &&
      senderResult.context !== "known-sender";
    const trustedLinks = linkResults.filter((result) => result.status === "trusted");
    const sameBrandTrustedLink = trustedLinks.some(
      (result) =>
        (senderResult?.brandId && result.brandId === senderResult.brandId) ||
        (senderResult?.brand && result.brand === senderResult.brand)
    );
    const everyLinkTrusted =
      linkResults.length > 0 &&
      linkResults.every((result) => result.status === "trusted") &&
      !linkResults.some((result) => result.selectionTruncated === true);
    const coherentOfficialMessage =
      Boolean(trustedSender) && sameBrandTrustedLink && everyLinkTrusted;

    if (
      coherentOfficialMessage &&
      contentResult?.status === "warning" &&
      contentResult.context !== "scan-incomplete" &&
      !contentResult.riskFlags?.dangerousBehavior &&
      !contentResult.riskFlags?.secretExfiltration
    ) {
      const signalIds = new Set((contentResult.signals || []).map((signal) => signal.id));
      const hasCredentials =
        signalIds.has("credentials") || signalIds.has("behavior-credentials");
      const hasPersonalInfo =
        signalIds.has("personal-info") || signalIds.has("behavior-personal-data");
      const canSoftenCredentialFlow =
        !hasCredentials ||
        contentResult.riskFlags?.userInitiatedFlow ||
        contentResult.riskFlags?.expectedSafeFlow;
      if (canSoftenCredentialFlow) {
        const severity =
          hasPersonalInfo || (hasCredentials && !contentResult.riskFlags?.expectedSafeFlow)
            ? "medium"
            : "low";
        reconciledContent = {
          ...contentResult,
          severity,
          context: "coherent-official-message",
          brandId: senderResult.brandId,
          brand: senderResult.brand,
          senderDomain: senderResult.senderDomain,
          message:
            severity === "medium"
              ? "This sensitive request uses a known sender domain and an official same-brand destination. Open the official app or site yourself if you did not expect it."
              : "The sender domain and destination match the same known service. Check that this matches an action you recently took."
        };
      }
    }

    const ordinarySenderNotice =
      senderResult?.context === "professional-sender-check" ||
      senderResult?.context === "common-tech-tld";
    const contextualLinkNotice = linkResults.some(
      (result) =>
        result.status === "warning" &&
        result.severity === "low" &&
        ["shortened-link", "public-hosting-link", "hosted-platform-link", "user-content-platform-link"].includes(
          result.context
        )
    );
    const contextualSenderNotice =
      senderResult?.status === "warning" &&
      senderResult.severity === "low" &&
      !ordinarySenderNotice;
    if (
      contentResult?.status !== "warning" &&
      Number(contentResult?.score || 0) >= 3 &&
      contextualLinkNotice &&
      contextualSenderNotice
    ) {
      reconciledContent = {
        ...contentResult,
        status: "warning",
        severity: "medium",
        context: "combined-message-risk",
        message:
          "Several weak clues occur together: a sensitive message, an unfamiliar sender pattern, and a destination whose owner is not visible. Verify it another way before acting."
      };
    }

    return {
      sender: senderResult,
      links: linkResults,
      content: reconciledContent,
      coherentOfficialMessage,
      top: topMessageWarning([senderResult, ...linkResults, reconciledContent])
    };
  }

  function analyzeMessage(message, rules) {
    const record = message && typeof message === "object" ? message : {};
    const activeRules = activeRuleList(rules);
    const sender = analyzeSender(record.sender || "", activeRules);
    const trustedSender =
      sender.status === "trusted" && sender.context !== "known-sender"
        ? {
            brandId: sender.brandId,
            brand: sender.brand,
            senderDomain: sender.senderDomain
          }
        : null;
    const linkRecords = Array.isArray(record.links) ? record.links : [];
    const links = linkRecords.map((link) =>
      typeof link === "string"
        ? analyzeUrl(link, activeRules)
        : analyzeLink(link?.text || "", link?.href || "", activeRules)
    );
    const body =
      record.content !== undefined
        ? record.content
        : [record.subject, record.body].filter(Boolean).join("\n");
    const content = analyzeContent(body || "", { trustedSender });
    return reconcileMessageResults({ sender, links, content });
  }

  function hasSuspiciousDomainShape(domain) {
    const normalized = normalizeDomain(domain);
    const allLabels = domainLabels(normalized);
    const labels = domainWithoutTld(normalized);
    const firstLabel = labels[0] || "";
    const root = rootDomain(normalized);
    const tld = domainTld(normalized);
    const hyphenCount = (normalized.match(/-/g) || []).length;
    const longestLabel = labels.reduce((longest, label) => Math.max(longest, label.length), 0);
    const hasSuspiciousMixedLabel = labels.some((label) => {
      const labelDigitCount = (label.match(/\d/g) || []).length;
      return /[a-z]/.test(label) && (labelDigitCount >= 3 || (labelDigitCount >= 2 && label.length >= 12));
    });

    return (
      isIpv4Address(normalized) ||
      HIGH_RISK_TLDS.has(tld) ||
      (tld && !/^[a-z]{2}$/.test(tld) && !STANDARD_TLDS.has(tld) && !COMMON_TECH_TLDS.has(tld)) ||
      normalized.length >= 50 ||
      root.length >= 36 ||
      allLabels.length >= 5 ||
      hyphenCount >= 2 ||
      labels.some((label) => (label.match(/-/g) || []).length >= 2) ||
      firstLabel.length >= 24 ||
      longestLabel >= 28 ||
      repeatedCharacterRun(normalized) ||
      labels.some((label) => looksMachineGeneratedLabel(label)) ||
      hasSuspiciousMixedLabel
    );
  }

  function explainSuspiciousDomainShape(domain) {
    const normalized = normalizeDomain(domain);
    const allLabels = domainLabels(normalized);
    const labels = domainWithoutTld(normalized);
    const root = rootDomain(normalized);
    const tld = domainTld(normalized);
    const hyphenCount = (normalized.match(/-/g) || []).length;
    const longestLabel = labels.reduce((longest, label) => Math.max(longest, label.length), 0);
    const hasSuspiciousMixedLabel = labels.some((label) => {
      const labelDigitCount = (label.match(/\d/g) || []).length;
      return /[a-z]/.test(label) && (labelDigitCount >= 3 || (labelDigitCount >= 2 && label.length >= 12));
    });

    if (isIpv4Address(normalized)) {
      return "uses a numeric IP address instead of a website domain";
    }
    if (normalized.includes("xn--")) {
      return "uses encoded international characters";
    }
    if (HIGH_RISK_TLDS.has(tld)) {
      return `uses the high-risk .${tld} extension`;
    }
    if (tld && !/^[a-z]{2}$/.test(tld) && !STANDARD_TLDS.has(tld) && !COMMON_TECH_TLDS.has(tld)) {
      return `uses the uncommon .${tld} extension`;
    }
    if (normalized.length >= 50) {
      return "has an unusually long domain";
    }
    if (root.length >= 36) {
      return "has an unusually long main domain";
    }
    if (allLabels.length >= 5) {
      return "has too many domain sections";
    }
    if (hyphenCount >= 2 || labels.some((label) => (label.match(/-/g) || []).length >= 2)) {
      return "uses too many hyphens";
    }
    if ((labels[0] || "").length >= 24 || longestLabel >= 28) {
      return "has an unusually long domain label";
    }
    if (hasSuspiciousMixedLabel) {
      return "mixes letters and numbers in a suspicious way";
    }
    if (labels.some((label) => looksMachineGeneratedLabel(label))) {
      return "looks machine-generated";
    }
    if (repeatedCharacterRun(normalized)) {
      return "contains repeated characters that look machine-generated";
    }

    return "has a suspicious domain shape";
  }

  function displayDomain(domain) {
    const normalized = normalizeDomain(domain);
    return normalized ? `${normalized.charAt(0).toUpperCase()}${normalized.slice(1)}` : "";
  }

  function professionalSenderCheckMessage(email, domain) {
    const readableDomain = displayDomain(domain);
    if (email && readableDomain) {
      return `Check that you know this sender: ${email} (${readableDomain}).`;
    }
    if (readableDomain) {
      return `Check that you know this sender: ${readableDomain}.`;
    }
    return "Verify you know the sender.";
  }

  function analyzeGenericDomainRisk(contextText, emailOrUrl, domain, kind) {
    if (!domain) {
      return null;
    }

    const normalized = normalizeDomain(domain);
    const localPart = String(emailOrUrl || "").includes("@")
      ? String(emailOrUrl).split("@")[0] || ""
      : "";
    const domainText = (kind === "sender" ? rootDomain(normalized) : normalized).replace(
      /\./g,
      " "
    );
    const hasSuspiciousDomainTerm = containsAnyTerm(domainText, SUSPICIOUS_TERMS);
    const hasOfficialIdentity =
      containsAnyTerm(contextText, GENERIC_IDENTITY_TERMS) ||
      containsAnyTerm(localPart, GENERIC_IDENTITY_TERMS);
    const shapeReason = hasSuspiciousDomainShape(normalized)
      ? explainSuspiciousDomainShape(normalized)
      : "";

    if (FREE_MAIL_DOMAINS.has(normalized) && hasOfficialIdentity) {
      return {
        severity: "high",
        message: `This ${kind} looks like a service team, but it uses a personal email address (${normalized}).`
      };
    }

    if (shapeReason) {
      const sensitivity = hasSuspiciousDomainTerm ? " and sensitive wording" : "";
      const isTldOnlyReason = /^uses the (?:uncommon|high-risk) \./.test(shapeReason);
      const isProfessionalSenderCheck = kind === "sender" && !hasSuspiciousDomainTerm && isTldOnlyReason;
      const root = rootDomain(normalized);
      const rootHasSuspiciousShape =
        root && root !== normalized && hasSuspiciousDomainShape(root);
      const isWeakSubdomainShape =
        root !== normalized &&
        !rootHasSuspiciousShape &&
        [
          "has an unusually long domain",
          "has too many domain sections",
          "uses too many hyphens",
          "has an unusually long domain label",
          "mixes letters and numbers in a suspicious way",
          "looks machine-generated",
          "contains repeated characters that look machine-generated"
        ].includes(shapeReason);
      const isLowConfidenceShape =
        isTldOnlyReason ||
        shapeReason === "uses encoded international characters" ||
        shapeReason === "has too many domain sections" ||
        isWeakSubdomainShape;
      const severity =
        hasSuspiciousDomainTerm || (kind === "link" && isIpv4Address(normalized))
          ? "high"
          : isLowConfidenceShape
            ? "low"
            : "medium";
      return {
        context: isProfessionalSenderCheck
          ? "professional-sender-check"
          : isLowConfidenceShape
            ? "unfamiliar-domain"
            : "generic-domain-risk",
        reason: shapeReason,
        severity,
        message: isProfessionalSenderCheck
          ? professionalSenderCheckMessage(String(emailOrUrl || ""), normalized)
          : isLowConfidenceShape
            ? `The ${kind} domain (${normalized}) ${shapeReason}. That detail alone does not mean it is unsafe.`
          : `The ${kind} domain (${normalized}) ${shapeReason}${sensitivity}.`
      };
    }

    const tld = domainTld(normalized);
    if (COMMON_TECH_TLDS.has(tld)) {
      if (hasSuspiciousDomainTerm) {
        return {
          context: "generic-domain-risk",
          reason: `uses the .${tld} extension`,
          severity: "high",
          message: `The ${kind} domain (${normalized}) uses the .${tld} extension and sensitive wording.`
        };
      }
      return {
        context: "common-tech-tld",
        reason: `uses the .${tld} extension`,
        severity: "low",
        message: `The ${kind} domain (${normalized}) uses the .${tld} extension, which is common for tech products.`
      };
    }

    if (hasSuspiciousDomainTerm && normalized.length >= 32) {
      return {
        severity: "high",
        message: `The ${kind} domain (${normalized}) is long and uses sensitive wording.`
      };
    }
    return null;
  }

  function findGenericDomainRisk(contextText, emailOrUrl, domain, kind) {
    const risk = analyzeGenericDomainRisk(contextText, emailOrUrl, domain, kind);
    return risk ? risk.message : null;
  }

  function findGenericRisk(senderText, senderEmail, senderDomain) {
    return findGenericDomainRisk(senderText, senderEmail, senderDomain, "sender");
  }

  function linkSelectionRisk(displayText, urlText, rules) {
    const activeRules = activeRuleList(rules);
    const activeScheme = activeLinkSchemeResult(urlText);
    if (activeScheme?.status === "warning") {
      return 20000;
    }

    const parsed = unwrapRedirectUrl(urlText);
    if (!parsed) {
      return 0;
    }
    const domain = parsed.hostname.replace(/^\[|\]$/g, "").replace(/\.$/, "").toLowerCase();
    if (parsed.username || parsed.password || isIpAddress(domain)) {
      return 19000;
    }

    const rawHostname = rawUrlHostname(urlText);
    const originalParsed = parseUrl(urlText);
    const originalHostname = originalParsed?.hostname
      ?.replace(/^\[|\]$/g, "")
      .replace(/\.$/, "")
      .toLowerCase();
    if (
      findUnicodeHomographRule(
        rawHostname || originalHostname,
        originalHostname || domain,
        activeRules
      )
    ) {
      return 18000;
    }

    const riskText = safeDecodePath(
      `${parsed.pathname || ""} ${parsed.search || ""} ${parsed.hash || ""}`
    );
    const linkSuggestsSensitiveAction =
      FAST_SENSITIVE_LINK_RE.test(`${riskText} ${domain.replace(/\./g, " ")}`) ||
      /(?:^|[^a-z0-9])checkout(?:[^a-z0-9]|$)/i.test(riskText);
    if (
      findLookalikeDomainBrand(domain, activeRules, {
        allowFuzzy: linkSuggestsSensitiveAction
      })
    ) {
      return 17000;
    }

    if (
      pseudoTldSensitiveDomain(domain) ||
      opaqueWorkflowDomain(domain, parsed.pathname || "")
    ) {
      return 16500;
    }

    const displayedDomains = extractDisplayedDomains(displayText);
    if (
      displayedDomains.some(
        (displayed) =>
          displayed &&
          !rootDomainsMatch(displayed, domain) &&
          !domainMatchesAllowed(domain, displayed)
      )
    ) {
      return 16000;
    }
    return 0;
  }

  function analyzeUrl(urlText, rules) {
    const activeRules = activeRuleList(rules);
    const cacheKey = String(urlText || "");
    return cachedAnalysis(activeRules, "urls", cacheKey, () => analyzeUrlUncached(urlText, activeRules));
  }

  function analyzeUrlUncached(urlText, activeRules) {
    const activeSchemeResult = activeLinkSchemeResult(urlText);
    if (activeSchemeResult) {
      return activeSchemeResult;
    }

    const parsed = unwrapRedirectUrl(urlText);

    if (!parsed) {
      return {
        status: "unknown",
        severity: "none",
        url: String(urlText || ""),
        urlDomain: "",
        message: "No readable link domain detected."
      };
    }

    const safeParsed = new URL(parsed.toString());
    const hasEmbeddedCredentials = Boolean(safeParsed.username || safeParsed.password);
    safeParsed.username = "";
    safeParsed.password = "";
    const url = safeParsed.toString();
    const domain = parsed.hostname.replace(/^\[|\]$/g, "").replace(/\.$/, "").toLowerCase();
    const rawHostname = rawUrlHostname(urlText);
    const originalParsed = parseUrl(urlText);
    const originalAsciiHostname = originalParsed
      ? originalParsed.hostname.replace(/^\[|\]$/g, "").replace(/\.$/, "").toLowerCase()
      : "";
    const homographMatch = findUnicodeHomographRule(
      rawHostname || originalAsciiHostname,
      originalAsciiHostname || domain,
      activeRules
    );
    const trustedRule = findTrustedDomainRule(domain, activeRules);
    const hostedPlatformRule = findHostedPlatformCustomerDomainRule(domain, activeRules);
    const userContentPlatformRule = findUserContentPlatformRule(domain, activeRules);
    const publicHostingProvider = findPublicHostingProvider(
      domain,
      parsed.pathname || "",
      parsed.search || "",
      parsed.hash || "",
      parsed.protocol || "",
      parsed.port || ""
    );
    const encodedPathSource = `${parsed.pathname || ""} ${parsed.search || ""} ${parsed.hash || ""}`;
    const staticOrSignatureAsset =
      isStaticAssetPath(parsed.pathname || "") ||
      isKnownPassiveAssetPath(
        domain,
        parsed.pathname || "",
        parsed.search || "",
        parsed.hash || "",
        parsed.protocol || "",
        parsed.port || ""
      ) ||
      /\/(?:mail-sig|proxy)(?:\/|$)/i.test(parsed.pathname || "");
    const pathRiskText = staticOrSignatureAsset
      ? ""
      : safeDecodePath(encodedPathSource);
    const rawPathRiskText = staticOrSignatureAsset
      ? ""
      : normalizeSecurityText(encodedPathSource.replace(/%[0-9a-f]{2}/gi, " "));
    const pathSuggestsSensitiveAction = containsAnyTerm(
      pathRiskText,
      [...SUSPICIOUS_TERMS, "checkout"]
    );
    const rawPathSuggestsSensitiveAction = containsAnyTerm(
      rawPathRiskText,
      [...SUSPICIOUS_TERMS, "checkout"]
    );
    const domainSuggestsSensitiveAction = containsAnyTerm(
      domain.replace(/\./g, " "),
      SUSPICIOUS_TERMS
    );
    const passiveStaticAsset =
      staticOrSignatureAsset && !domainSuggestsSensitiveAction;
    const linkSuggestsSensitiveAction = pathSuggestsSensitiveAction || domainSuggestsSensitiveAction;
    const publicHostingBaseDomain = publicHostingProvider
      ? (publicHostingProvider.domains || [])
          .map((providerDomain) => normalizeDomain(providerDomain))
          .filter((providerDomain) => domainMatchesAllowed(domain, providerDomain))
          .sort((first, second) => second.length - first.length)[0] || ""
      : "";
    const userContentBaseDomain = userContentPlatformRule
      ? (userContentPlatformRule.allowedDomains || [])
          .map((allowedDomain) => normalizeDomain(allowedDomain))
          .filter((allowedDomain) => domainMatchesAllowed(domain, allowedDomain))
          .sort((first, second) => second.length - first.length)[0] || ""
      : "";
    const sharedContentBrandMatch = staticOrSignatureAsset
      ? null
      : publicHostingProvider
      ? findHostedContentBrandMatch(
          domain,
          publicHostingBaseDomain,
          parsed.pathname || "",
          activeRules,
          undefined,
          true
        )
      : userContentPlatformRule
        ? findHostedContentBrandMatch(
            domain,
            userContentBaseDomain,
            parsed.pathname || "",
            activeRules,
            userContentPlatformRule.id,
            true
          )
        : null;
    const sharedContentSuggestsSensitiveAction =
      containsAnyTerm(
        pathRiskText,
        [...SHARED_CONTENT_SENSITIVE_TERMS, "checkout"]
      ) ||
      containsAnyTerm(domain.replace(/\./g, " "), SHARED_CONTENT_SENSITIVE_TERMS) ||
      Boolean(sharedContentBrandMatch);
    const lookalikeMatch = findLookalikeDomainBrand(domain, activeRules, {
      allowFuzzy: linkSuggestsSensitiveAction
    });
    const tooLongUrl = url.length >= 180;
    const encodedPathBrandMatch = /%[0-9a-f]{2}/i.test(encodedPathSource) && !staticOrSignatureAsset
      ? findHostedContentBrandMatch("", "", pathRiskText, activeRules, undefined, true)
      : null;
    const rawPathBrandMatch = encodedPathBrandMatch
      ? findHostedContentBrandMatch("", "", rawPathRiskText, activeRules, undefined, true)
      : null;
    const decodingIntroducesSensitiveAction =
      pathSuggestsSensitiveAction && !rawPathSuggestsSensitiveAction;
    const decodingIntroducesBrand =
      Boolean(encodedPathBrandMatch) &&
      (!rawPathBrandMatch || rawPathBrandMatch.rule.id !== encodedPathBrandMatch.rule.id);

    if (hasEmbeddedCredentials) {
      return {
        status: "warning",
        severity: "high",
        context: "userinfo-link",
        url,
        urlDomain: domain,
        allowedDomains: [],
        message: `This link hides ${domain} after an @ sign. Attackers use this format to make a different name look like the destination.`
      };
    }

    if (isIpAddress(domain)) {
      return {
        status: "warning",
        severity: "high",
        context: "ip-address-link",
        url,
        urlDomain: domain,
        allowedDomains: [],
        message: `This link goes directly to a numeric IP address (${domain}) instead of a recognizable website name.`
      };
    }

    if (homographMatch) {
      return {
        status: "warning",
        severity: "high",
        context: "unicode-lookalike-link",
        brandId: homographMatch.rule.id,
        brand: homographMatch.rule.name,
        url,
        urlDomain: domain,
        allowedDomains: homographMatch.rule.allowedDomains || [],
        message: `${homographMatch.rule.name} risk detected: the link uses lookalike Unicode letters, but the real domain is ${domain}.`
      };
    }

    if (
      !trustedRule &&
      /%[0-9a-f]{2}/i.test(encodedPathSource) &&
      (decodingIntroducesSensitiveAction || decodingIntroducesBrand)
    ) {
      return {
        status: "warning",
        severity: "high",
        context: "encoded-action-link",
        brandId: encodedPathBrandMatch?.rule?.id,
        brand: encodedPathBrandMatch?.rule?.name,
        url,
        urlDomain: domain,
        allowedDomains: encodedPathBrandMatch?.rule?.allowedDomains || [],
        message: encodedPathBrandMatch
          ? `This link hides the ${encodedPathBrandMatch.rule.name} name inside encoded URL text, but the real domain is ${domain}.`
          : `This link hides account, payment, or security wording inside encoded URL text on ${domain}.`
      };
    }

    if (publicHostingProvider) {
      const isPassiveInfrastructure = Boolean(publicHostingProvider.passiveInfrastructure);
      const isSensitiveHostedPage =
        !isPassiveInfrastructure && sharedContentSuggestsSensitiveAction;
      return {
        status: "warning",
        severity: isSensitiveHostedPage ? "high" : "low",
        context: isPassiveInfrastructure
          ? "shared-infrastructure-link"
          : "public-hosting-link",
        provider: publicHostingProvider.name,
        impersonatedBrand: sharedContentBrandMatch?.rule?.name,
        url,
        urlDomain: domain,
        allowedDomains: [],
        message: isPassiveInfrastructure
          ? `This link uses shared ${publicHostingProvider.name} (${domain}). That infrastructure does not verify who created the message or where a tracked link ultimately leads.`
          : isSensitiveHostedPage
          ? `This customer-created ${publicHostingProvider.name} page uses a brand name or account, payment, or security wording. The hosting domain does not verify who published it, so do not enter sensitive information unless you independently verified the page.`
          : `This link opens customer-created content hosted by ${publicHostingProvider.name} (${domain}). The hosting domain does not identify the publisher; this can be legitimate, so check that you expected it.`
      };
    }

    if (userContentPlatformRule) {
      const isSensitiveUserContent = sharedContentSuggestsSensitiveAction;
      return {
        status: "warning",
        severity: isSensitiveUserContent ? "high" : "low",
        context: "user-content-platform-link",
        provider: userContentPlatformRule.name,
        impersonatedBrand: sharedContentBrandMatch?.rule?.name,
        brandId: userContentPlatformRule.id,
        brand: userContentPlatformRule.name,
        url,
        urlDomain: domain,
        allowedDomains: userContentPlatformRule.allowedDomains || [],
        message: isSensitiveUserContent
          ? `This user-created ${userContentPlatformRule.name} page uses a brand name or account, payment, or security wording. The platform domain does not verify who published it, so do not enter sensitive information unless you independently verified the page.`
          : `This link opens user-created content on ${userContentPlatformRule.name} (${domain}). The platform domain does not identify the publisher; this can be legitimate, so check that you expected it.`
      };
    }

    if (trustedRule) {
      return {
        status: "trusted",
        severity: "none",
        brandId: trustedRule.id,
        brand: trustedRule.name,
        url,
        urlDomain: domain,
        allowedDomains: trustedRule.allowedDomains || [],
        message: `Domain matches the known ${trustedRule.name} list.`
      };
    }

    if (hostedPlatformRule) {
      return {
        status: "warning",
        severity: linkSuggestsSensitiveAction ? "high" : "low",
        context: "hosted-platform-link",
        brandId: hostedPlatformRule.id,
        brand: hostedPlatformRule.name,
        url,
        urlDomain: domain,
        allowedDomains: hostedPlatformRule.allowedDomains || [],
        message: linkSuggestsSensitiveAction
          ? `This page was made with ${hostedPlatformRule.name} and uses account, payment, or security wording. Anyone can publish there, so verify it another way before entering sensitive information.`
          : `This link opens a page made with ${hostedPlatformRule.name} (${domain}). Anyone can make pages there, but shared pages are common; open it only if you expected it.`
      };
    }

    if (lookalikeMatch) {
      const isExactBrandLabel = domainIsExactBrandLabel(domain, lookalikeMatch.rule);
      return {
        status: "warning",
        severity: passiveStaticAsset ? "low" : "high",
        context: passiveStaticAsset
          ? "static-asset-link"
          : isExactBrandLabel
            ? "unverified-brand-domain"
            : undefined,
        brandId: lookalikeMatch.rule.id,
        brand: lookalikeMatch.rule.name,
        url,
        urlDomain: domain,
        allowedDomains: lookalikeMatch.rule.allowedDomains || [],
        message: passiveStaticAsset
          ? `This is a static image or asset on ${domain}. Static assets can be legitimate and are not a safe place to enter information.`
          : isExactBrandLabel
            ? `${domain} uses the ${lookalikeMatch.rule.name} name, but it is not in the known ${lookalikeMatch.rule.name} domain list.`
            : `${lookalikeMatch.rule.name} risk detected: link domain looks like ${lookalikeMatch.rule.name}, but the link domain is ${domain}.`
      };
    }

    const genericRisk = analyzeGenericDomainRisk(url, url, domain, "link");
    const pseudoTldRisk = pseudoTldSensitiveDomain(domain);
    const workflowRisk = opaqueWorkflowDomain(domain, parsed.pathname || "");

    if (
      pseudoTldRisk &&
      (!genericRisk || !["high", "critical"].includes(genericRisk.severity))
    ) {
      return {
        status: "warning",
        severity: passiveStaticAsset ? "low" : "medium",
        context: passiveStaticAsset ? "static-asset-link" : "pseudo-tld-link",
        reason: "places a familiar-looking public suffix inside the real domain",
        url,
        urlDomain: domain,
        allowedDomains: [],
        message: passiveStaticAsset
          ? `This is a static image or asset on ${domain}. Static assets can be legitimate and are not a safe place to enter information.`
          : `The real registered domain is ${pseudoTldRisk.registrableDomain}, not ${pseudoTldRisk.apparentDomain}. The .${pseudoTldRisk.pseudoTld}- label can make the left side look like a different website.`
      };
    }

    if (
      workflowRisk &&
      (!genericRisk || !["high", "critical"].includes(genericRisk.severity))
    ) {
      return {
        status: "warning",
        severity: passiveStaticAsset ? "low" : "medium",
        context: passiveStaticAsset ? "static-asset-link" : "opaque-workflow-link",
        reason:
          workflowRisk.reason === "scheme-like-transfer"
            ? "uses https as a hostname label with an opaque transfer token"
            : "uses protected-workflow wording with an opaque destination token",
        url,
        urlDomain: domain,
        allowedDomains: [],
        message: passiveStaticAsset
          ? `This is a static image or asset on ${domain}. Static assets can be legitimate and are not a safe place to enter information.`
          : workflowRisk.reason === "scheme-like-transfer"
            ? `The hostname starts with https as a domain label, not as proof of who owns the site, and the file-transfer destination uses a long opaque token. Verify the request another way.`
            : `This unfamiliar protected-form or conference destination uses a long opaque token. Verify who sent the request before opening it.`
      };
    }

    if (isUrlShortenerDomain(domain)) {
      return {
        status: "warning",
        severity: "low",
        context: "shortened-link",
        url,
        urlDomain: domain,
        allowedDomains: [],
        message: `The link uses a URL shortener (${domain}), so Bye Bye Fishing cannot see the final destination. Short links can be legitimate; confirm that you expected it before opening.`
      };
    }

    if (genericRisk || tooLongUrl) {
      return {
        status: "warning",
        severity: passiveStaticAsset ? "low" : genericRisk ? genericRisk.severity : "low",
        context: passiveStaticAsset
          ? "static-asset-link"
          : genericRisk
            ? genericRisk.context
            : "long-link",
        reason: genericRisk ? genericRisk.reason : undefined,
        brand: trustedRule ? trustedRule.name : undefined,
        url,
        urlDomain: domain,
        allowedDomains: trustedRule ? trustedRule.allowedDomains || [] : [],
        message: passiveStaticAsset
          ? `This is a static image or asset on ${domain}. Static assets can be legitimate and are not a safe place to enter information.`
          : genericRisk
            ? genericRisk.message
            : `The link URL is unusually long (${url.length} characters). Signed and tracked links are often long, so this detail alone does not mean it is unsafe.`
      };
    }

    return {
      status: "unknown",
      severity: "none",
      url,
      urlDomain: domain,
      message: "No protected or suspicious link domain detected."
    };
  }

  function analyzeLink(displayText, href, rules) {
    const activeRules = activeRuleList(rules);
    const cacheKey = JSON.stringify([String(displayText || ""), String(href || "")]);
    return cachedAnalysis(activeRules, "links", cacheKey, () => analyzeLinkUncached(displayText, href, activeRules));
  }

  function analyzeLinkUncached(displayText, href, activeRules) {
    const result = analyzeUrl(href, activeRules);
    const parsed = unwrapRedirectUrl(href);
    const hrefDomain = parsed
      ? parsed.hostname.replace(/^\[|\]$/g, "").replace(/\.$/, "").toLowerCase()
      : result.urlDomain || "";
    const exactDisplayDomain = extractDisplayedDomain(displayText);
    const protectedDisplayDomain = extractDisplayedDomains(displayText).find((domain) =>
      findTrustedDomainRule(domain, activeRules)
    );
    const displayDomain = protectedDisplayDomain || exactDisplayDomain;
    const displayTrustedRule = displayDomain ? findTrustedDomainRule(displayDomain, activeRules) : null;
    const displayBrandMatch =
      displayDomain && !displayTrustedRule
        ? findLookalikeDomainBrand(displayDomain, activeRules, { allowFuzzy: true })
        : null;
    const hrefTrustedRule = hrefDomain ? findTrustedDomainRule(hrefDomain, activeRules) : null;
    const sameTrustedBrand =
      displayTrustedRule &&
      hrefTrustedRule &&
      displayTrustedRule.id === hrefTrustedRule.id;

    // If the real destination is already a recognized official brand link (e.g. linkedin.com)
    // and the displayed text isn't itself a recognized brand domain, don't manufacture a
    // high-severity "suspicious destination" warning over what's just confusing link text
    // (job titles, marketing copy, …). A mismatch between two *different* brand domains still warns.
    if (displayDomain && hrefDomain && result.status === "trusted" && !displayTrustedRule) {
      return { ...result, displayedDomain: displayDomain };
    }

    if (
      displayDomain &&
      hrefDomain &&
      !sameTrustedBrand &&
      !rootDomainsMatch(displayDomain, hrefDomain) &&
      !domainMatchesAllowed(hrefDomain, displayDomain)
    ) {
      const mismatchMessage = `The visible link says ${displayDomain}, but the real destination is ${hrefDomain}.`;
      if (result.status === "warning") {
        const underlyingSeverity =
          result.severity === "critical" ||
          (result.context === "public-hosting-link" && result.severity === "high")
            ? "critical"
            : result.severity === "high"
              ? "high"
              : displayTrustedRule || displayBrandMatch
                ? "high"
                : "medium";
        return {
          ...result,
          severity: underlyingSeverity,
          displayedDomain: displayDomain,
          message:
            underlyingSeverity === "critical"
              ? `${mismatchMessage} ${result.message}`
              : mismatchMessage
        };
      }

      return {
        status: "warning",
        severity: displayTrustedRule || displayBrandMatch ? "high" : "medium",
        url: parsed ? parsed.toString() : String(href || ""),
        urlDomain: hrefDomain,
        displayedDomain: displayDomain,
        allowedDomains: [],
        message: mismatchMessage
      };
    }

    return result;
  }

  function analyzeSender(senderText, rules) {
    const activeRules = activeRuleList(rules);
    const cacheKey = String(senderText || "");
    return cachedAnalysis(activeRules, "senders", cacheKey, () => analyzeSenderUncached(senderText, activeRules));
  }

  function analyzeSenderUncached(senderText, activeRules) {
    const senderEmails = [...new Set((String(senderText || "").match(EMAIL_GLOBAL_RE) || []).map((value) => value.toLowerCase()))];
    const senderDomains = [...new Set(senderEmails.map((value) => normalizeDomain(value)).filter(Boolean))];
    if (senderDomains.length > 1) {
      return {
        status: "warning",
        severity: "high",
        context: "ambiguous-sender",
        senderEmail: senderEmails[0] || "",
        senderDomain: senderDomains[0] || "",
        allowedDomains: [],
        message: `This sender field contains multiple different email domains (${senderDomains.join(", ")}). Verify the real From address before acting.`
      };
    }

    const email = extractEmail(senderText);
    const domain = normalizeDomain(email);
    const rawEmailDomain = email.includes("@") ? email.split("@").pop() : "";
    const homographMatch = findUnicodeHomographRule(
      rawEmailDomain || domain,
      domain,
      activeRules
    );
    if (homographMatch) {
      return {
        status: "warning",
        severity: "high",
        context: "unicode-lookalike-sender",
        brandId: homographMatch.rule.id,
        brand: homographMatch.rule.name,
        senderEmail: email,
        senderDomain: domain,
        allowedDomains: homographMatch.rule.allowedDomains || [],
        message: `${homographMatch.rule.name} risk detected: the sender uses lookalike Unicode letters, but the real domain is ${domain}.`
      };
    }

    const brandMatch = findClaimedBrand(senderText, email, domain, activeRules);
    const brand = brandMatch ? brandMatch.rule : null;

    if (!brand) {
      const hostedPlatformRule = findHostedPlatformCustomerDomainRule(domain, activeRules);
      if (hostedPlatformRule) {
        return {
        status: "warning",
        severity: "medium",
        brandId: hostedPlatformRule.id,
        brand: hostedPlatformRule.name,
        senderEmail: email,
        senderDomain: domain,
          allowedDomains: hostedPlatformRule.allowedDomains || [],
          message: `The sender uses a customer-hosted ${hostedPlatformRule.name} subdomain (${domain}). Hosted-site platforms can be used by anyone, so check the message carefully.`
        };
      }

      const genericRisk = analyzeGenericDomainRisk(senderText, email, domain, "sender");
      if (genericRisk) {
        return {
          status: "warning",
          severity: genericRisk.severity,
          context: genericRisk.context,
          reason: genericRisk.reason,
          senderEmail: email,
          senderDomain: domain,
          allowedDomains: [],
          message: genericRisk.message
        };
      }

      return {
        status: "unknown",
        severity: "none",
        senderEmail: email,
        senderDomain: domain,
        message: "No protected brand detected in the sender."
      };
    }

    if (!domain) {
      return {
        status: "warning",
        severity: "medium",
        brandId: brand.id,
        brand: brand.name,
        senderEmail: email,
        senderDomain: "",
        allowedDomains: brand.allowedDomains || [],
        message: `${brand.name} is mentioned, but Bye Bye Fishing could not read a sender email domain.`
      };
    }

    const isTrusted = domainMatchesTrustedSender(brand, domain);

    if (isTrusted) {
      return {
        status: "trusted",
        severity: "none",
        brandId: brand.id,
        brand: brand.name,
        senderEmail: email,
        senderDomain: domain,
        allowedDomains: brand.allowedDomains || [],
        message: `Sender domain matches the known ${brand.name} list; this does not verify the sender.`
      };
    }

    if (
      Array.isArray(brand.senderAliases) &&
      isPersonalMailboxDomain(domain) &&
      domainFallsUnderRuleDomain(brand, domain)
    ) {
      return {
        status: "warning",
        severity: "low",
        context: "dual-use-brand-mailbox",
        brandId: brand.id,
        brand: brand.name,
        senderEmail: email,
        senderDomain: domain,
        allowedDomains: brand.allowedDomains || [],
        message: `${domain} is associated with ${brand.name}, but it also provides personal mailboxes. The display name alone does not prove this came from the company.`
      };
    }

    const punycodeHint = domain.includes("xn--")
      ? " The domain uses an internationalized form, which can hide lookalike characters."
      : "";
    const shapeReason = hasSuspiciousDomainShape(domain) ? explainSuspiciousDomainShape(domain) : "";
    const suspiciousHint = shapeReason ? ` The sender domain also ${shapeReason}.` : "";
    const trustedExamples = (brand.allowedDomains || []).slice(0, 3).join(", ");

    return {
      status: "warning",
      severity: shapeReason ? "critical" : "high",
      brandId: brand.id,
      brand: brand.name,
      senderEmail: email,
      senderDomain: domain,
      allowedDomains: brand.allowedDomains || [],
      message: `This mentions ${brand.name}, but it came from ${domain}, which is not in the known ${brand.name} domains here${trustedExamples ? ` (${trustedExamples})` : ""}.${suspiciousHint}${punycodeHint} Don't use links in this message or share personal information.`
    };
  }

  function mergeUniqueValues(savedValues, defaultValues, normalizeValue) {
    const seen = new Set();
    const merged = [];

    for (const value of [...(savedValues || []), ...(defaultValues || [])]) {
      const normalized = normalizeValue ? normalizeValue(value) : String(value || "").trim();
      if (!normalized || seen.has(normalized)) {
        continue;
      }
      seen.add(normalized);
      merged.push(value);
    }

    return merged;
  }

  function mergeDefaultRuleUpdates(savedRules, baseRules) {
    if (!Array.isArray(savedRules) || !Array.isArray(baseRules)) {
      return Array.isArray(baseRules) ? baseRules : [];
    }

    const defaultsById = new Map(baseRules.map((rule) => [rule.id, rule]));
    const seenIds = new Set();
    const mergedRules = savedRules.map((savedRule) => {
      const defaultRule = savedRule && defaultsById.get(savedRule.id);
      if (!defaultRule) {
        return savedRule;
      }

      seenIds.add(savedRule.id);
      const merged = {
        ...defaultRule,
        ...savedRule,
        aliases: mergeUniqueValues(savedRule.aliases, defaultRule.aliases, normalizeText),
        allowedDomains: mergeUniqueValues(savedRule.allowedDomains, defaultRule.allowedDomains, normalizeDomain)
      };

      if (Array.isArray(savedRule.senderDomains) || Array.isArray(defaultRule.senderDomains)) {
        merged.senderDomains = mergeUniqueValues(
          savedRule.senderDomains,
          defaultRule.senderDomains,
          normalizeDomain
        );
      }

      if (Array.isArray(savedRule.senderAliases) || Array.isArray(defaultRule.senderAliases)) {
        merged.senderAliases = mergeUniqueValues(
          savedRule.senderAliases,
          defaultRule.senderAliases,
          normalizeText
        );
      }

      if (
        Array.isArray(savedRule.exactSenderAliases) ||
        Array.isArray(defaultRule.exactSenderAliases)
      ) {
        merged.exactSenderAliases = mergeUniqueValues(
          savedRule.exactSenderAliases,
          defaultRule.exactSenderAliases,
          (value) => String(value || "").trim()
        );
      }

      if (
        Array.isArray(savedRule.controlPlaneDomains) ||
        Array.isArray(defaultRule.controlPlaneDomains)
      ) {
        merged.controlPlaneDomains = mergeUniqueValues(
          savedRule.controlPlaneDomains,
          defaultRule.controlPlaneDomains,
          normalizeDomain
        );
      }

      return merged;
    });

    for (const defaultRule of baseRules) {
      if (!seenIds.has(defaultRule.id) && !savedRules.some((rule) => rule && rule.id === defaultRule.id)) {
        mergedRules.push(defaultRule);
      }
    }

    return mergedRules;
  }

  function cloneRules(rules) {
    return (Array.isArray(rules) ? rules : []).map((rule) => ({
      ...rule,
      aliases: [...(rule.aliases || [])],
      allowedDomains: [...(rule.allowedDomains || [])],
      ...(Array.isArray(rule.senderAliases) ? { senderAliases: [...rule.senderAliases] } : {}),
      ...(Array.isArray(rule.exactSenderAliases)
        ? { exactSenderAliases: [...rule.exactSenderAliases] }
        : {}),
      ...(Array.isArray(rule.senderDomains) ? { senderDomains: [...rule.senderDomains] } : {}),
      ...(Array.isArray(rule.controlPlaneDomains)
        ? { controlPlaneDomains: [...rule.controlPlaneDomains] }
        : {})
    }));
  }

  function findRuleIndexById(rules, ruleId) {
    return (Array.isArray(rules) ? rules : []).findIndex((rule) => rule && rule.id === ruleId);
  }

  function domainListHasDomain(domains, domain) {
    const normalized = normalizeDomain(domain);
    return (domains || []).some((value) => normalizeDomain(value) === normalized);
  }

  function addTrustedDomainToRule(rules, ruleId, domain, listName = "allowedDomains") {
    const normalized = normalizeDomain(domain);
    const nextRules = cloneRules(rules);
    const index = findRuleIndexById(nextRules, ruleId);
    const targetListName = listName === "senderDomains" ? "senderDomains" : "allowedDomains";

    if (!normalized || index === -1) {
      return nextRules;
    }

    const rule = nextRules[index];
    if (targetListName === "senderDomains" && !Array.isArray(rule.senderDomains)) {
      rule.senderDomains = [];
    }

    const domains = rule[targetListName] || [];
    if (!domainListHasDomain(domains, normalized)) {
      domains.push(normalized);
      domains.sort((first, second) => normalizeDomain(first).localeCompare(normalizeDomain(second)));
    }
    rule[targetListName] = domains;

    return nextRules;
  }

  function removeTrustedDomainFromRule(rules, ruleId, domain, listName = "allowedDomains") {
    const normalized = normalizeDomain(domain);
    const nextRules = cloneRules(rules);
    const index = findRuleIndexById(nextRules, ruleId);
    const targetListName = listName === "senderDomains" ? "senderDomains" : "allowedDomains";

    if (!normalized || index === -1) {
      return nextRules;
    }

    const rule = nextRules[index];
    const domains = rule[targetListName] || [];
    if (domains.length <= 1) {
      return nextRules;
    }

    rule[targetListName] = domains.filter((value) => normalizeDomain(value) !== normalized);
    return nextRules;
  }

  function validateRules(rules) {
    if (!Array.isArray(rules)) {
      return { ok: false, error: "Rules must be an array." };
    }

    const ids = new Set();

    for (const [index, rule] of rules.entries()) {
      if (!rule || typeof rule !== "object") {
        return { ok: false, error: `Rule ${index + 1} must be an object.` };
      }
      if (!rule.id || !rule.name) {
        return { ok: false, error: `Rule ${index + 1} needs an id and name.` };
      }
      if (ids.has(rule.id)) {
        return { ok: false, error: `Rule id ${rule.id} is duplicated.` };
      }
      ids.add(rule.id);
      if (!Array.isArray(rule.aliases) || !Array.isArray(rule.allowedDomains)) {
        return {
          ok: false,
          error: `Rule ${rule.id || index + 1} needs aliases and allowedDomains arrays.`
        };
      }
      if (rule.aliases.length === 0 || rule.allowedDomains.length === 0) {
        return {
          ok: false,
          error: `Rule ${rule.id} needs at least one alias and one trusted domain.`
        };
      }
      if (rule.allowedDomains.some((domain) => !normalizeDomain(domain))) {
        return {
          ok: false,
          error: `Rule ${rule.id} contains an invalid domain.`
        };
      }
      if (
        rule.senderAliases !== undefined &&
        (!Array.isArray(rule.senderAliases) || rule.senderAliases.some((alias) => !normalizeText(alias)))
      ) {
        return {
          ok: false,
          error: `Rule ${rule.id} contains an invalid sender alias list.`
        };
      }
      if (
        rule.exactSenderAliases !== undefined &&
        (!Array.isArray(rule.exactSenderAliases) ||
          rule.exactSenderAliases.some((alias) => !normalizeText(alias)))
      ) {
        return {
          ok: false,
          error: `Rule ${rule.id} contains an invalid exact sender alias list.`
        };
      }
      if (
        rule.senderDomains !== undefined &&
        (!Array.isArray(rule.senderDomains) || rule.senderDomains.some((domain) => !normalizeDomain(domain)))
      ) {
        return {
          ok: false,
          error: `Rule ${rule.id} contains an invalid sender domain list.`
        };
      }
      if (
        rule.brandLinkDomains !== undefined &&
        (!Array.isArray(rule.brandLinkDomains) ||
          rule.brandLinkDomains.some((domain) => !normalizeDomain(domain)))
      ) {
        return {
          ok: false,
          error: `Rule ${rule.id} contains an invalid brand link domain list.`
        };
      }
      if (rule.hostedPlatform !== undefined && typeof rule.hostedPlatform !== "boolean") {
        return {
          ok: false,
          error: `Rule ${rule.id} has an invalid hostedPlatform flag.`
        };
      }
      if (rule.userContentPlatform !== undefined && typeof rule.userContentPlatform !== "boolean") {
        return {
          ok: false,
          error: `Rule ${rule.id} has an invalid userContentPlatform flag.`
        };
      }
      if (
        rule.controlPlaneDomains !== undefined &&
        (!Array.isArray(rule.controlPlaneDomains) ||
          rule.controlPlaneDomains.some((domain) => !normalizeDomain(domain)))
      ) {
        return {
          ok: false,
          error: `Rule ${rule.id} contains an invalid control-plane domain list.`
        };
      }
      if (rule.matchSubdomains !== undefined && typeof rule.matchSubdomains !== "boolean") {
        return {
          ok: false,
          error: `Rule ${rule.id} has an invalid matchSubdomains flag.`
        };
      }
      if (rule.senderMatchSubdomains !== undefined && typeof rule.senderMatchSubdomains !== "boolean") {
        return {
          ok: false,
          error: `Rule ${rule.id} has an invalid senderMatchSubdomains flag.`
        };
      }
    }

    return { ok: true };
  }

  const api = {
    analyzeContent,
    analyzeLink,
    linkSelectionRisk,
    contentSelectionRisk,
    contentSelectionRiskPattern,
    analyzeMessage,
    analyzeSender,
    analyzeUrl,
    addTrustedDomainToRule,
    domainMatchesAllowed,
    extractEmail,
    mergeDefaultRuleUpdates,
    normalizeDomain,
    reconcileMessageResults,
    removeTrustedDomainFromRule,
    validateRules
  };

  global.ByeByeFishingDetector = api;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
