(function runByeByeFishingContentScript(global) {
  "use strict";

  const detector = global.ByeByeFishingDetector;
  const defaultRules = global.BYEBYEFISHING_DEFAULT_RULES || [];
  const rulesetVersion = global.BYEBYEFISHING_RULESET_VERSION || "0";
  const extensionApi = global.browser || global.chrome;
  const SVG_NS = "http://www.w3.org/2000/svg";
  const MESSAGE_BODY_SELECTORS = [
    ".a3s",
    "[aria-label*='Message body']",
    "[aria-label*='Corps du message']",
    "[data-testid='messageBody']",
    "[data-test-id='messageBody']",
    "[data-testid='message-content']",
    "[data-test-id='message-content']",
    "[data-testid='message-view-body-content']",
    "[data-test-id='message-view-body-content']",
    "[data-testid='message-view-body']",
    "[data-test-id='message-view-body']",
    "[data-message-id] [role='document']",
    ".message-content",
    ".mail-detail-content",
    ".mail-detail-body",
    ".mail-detail-pane [role='document']",
    ".message-part",
    ".message-htmlpart",
    "#messagebody",
    ".MsgBody",
    ".ZmMailMsgView"
  ];
  const MESSAGE_SCOPE_SELECTORS = [
    ".adn",
    "[data-message-id]",
    "[data-testid='conversation-message']",
    "[data-test-id='message']",
    "[data-testid='message']",
    "[data-testid='message-view']",
    "[data-test-id='message-view']",
    "[data-testid='message-view-item']",
    "[data-test-id='message-view-item']",
    "[data-test-id='message-item']",
    ".mail-detail",
    ".mail-detail-pane",
    "#messagecontent",
    "#messagebody",
    ".ZmMailMsgView"
  ];
  const MAIL_LIST_ROW_SELECTORS = [
    "div[role='main'] tr.zA",
    "div[role='main'] tr[jscontroller]",
    "div[role='main'] table[role='grid'] tr",
    "div[role='main'] .Cp tr",
    "div[role='main'] tr[role='row']",
    "div[role='main'] div[role='row']",
    "main tr[role='row']",
    "main div[role='row']",
    "main li[role='row']",
    "[data-testid='message-list-item']",
    "[data-test-id='message-list-item']",
    "[data-testid='conversation-list'] [role='row']",
    "[data-test-id='conversation-list'] [role='row']",
    ".mail-item",
    ".message-list-item",
    "tr.message",
    "tr.mail"
  ];
  const MAIL_LIST_SENDER_SELECTORS = [
    "span[email]",
    "[email]",
    "[data-email]",
    "[data-address]",
    "[title*='@']",
    "[aria-label*='@']",
    "[data-testid*='sender']",
    "[data-test-id*='sender']",
    "[data-testid*='from']",
    "[data-test-id*='from']",
    ".from a[href^='mailto:']",
    ".sender [title*='@']",
    ".mail-sender [title*='@']",
    ".addr[title*='@']"
  ];
  const state = {
    rules: defaultRules,
    showTrustedBadges: true,
    greenFlagSenderDomains: new Set(),
    trustedSenderSites: [],
    dismissedWarnings: new Set(),
    scanTimer: null,
    skipNextRuleChangeScan: false
  };

  if (!detector || !extensionApi?.storage) {
    return;
  }

  function storageGet(defaults) {
    const result = extensionApi.storage.sync.get(defaults);
    if (result && typeof result.then === "function") {
      return result;
    }

    return new Promise((resolve) => extensionApi.storage.sync.get(defaults, resolve));
  }

  function storageSet(values) {
    const result = extensionApi.storage.sync.set(values);
    if (result && typeof result.then === "function") {
      return result;
    }

    return new Promise((resolve) => extensionApi.storage.sync.set(values, resolve));
  }

  function normalizeGreenFlagSenderDomains(domains) {
    const normalizedDomains = new Set();
    if (!Array.isArray(domains)) {
      return normalizedDomains;
    }

    domains.forEach((domain) => {
      const normalized = detector.normalizeDomain(domain);
      if (normalized) {
        normalizedDomains.add(normalized);
      }
    });

    return normalizedDomains;
  }

  function normalizeTrustedSenderSites(records) {
    const normalizedRecords = [];
    const seen = new Set();
    if (!Array.isArray(records)) {
      return normalizedRecords;
    }

    records.forEach((record) => {
      if (!record || typeof record !== "object") {
        return;
      }

      const senderEmail = detector.extractEmail(record.senderEmail || "");
      const senderDomain = detector.normalizeDomain(record.senderDomain || senderEmail);
      const urlDomain = detector.normalizeDomain(record.urlDomain);
      if (!senderDomain || !urlDomain) {
        return;
      }

      const key = `${senderEmail}:${senderDomain}:${urlDomain}`;
      if (seen.has(key)) {
        return;
      }

      seen.add(key);
      normalizedRecords.push({ senderEmail, senderDomain, urlDomain });
    });

    return normalizedRecords.sort((first, second) =>
      `${first.senderDomain}:${first.urlDomain}`.localeCompare(`${second.senderDomain}:${second.urlDomain}`)
    );
  }

  function mergeSavedRules(rules) {
    const merged = detector.mergeDefaultRuleUpdates
      ? detector.mergeDefaultRuleUpdates(rules, defaultRules)
      : rules;
    return detector.validateRules(merged).ok ? merged : defaultRules;
  }

  async function loadSettings() {
    const saved = await storageGet({
      byebyefishingRules: defaultRules,
      byebyefishingRulesCustom: false,
      byebyefishingRulesVersion: "",
      byebyefishingShowTrustedBadges: true,
      byebyefishingGreenFlagSenderDomains: [],
      byebyefishingTrustedSenderSites: []
    });

    const validation = detector.validateRules(saved.byebyefishingRules);
    const shouldUseSavedRules =
      validation.ok && (saved.byebyefishingRulesCustom || saved.byebyefishingRulesVersion === rulesetVersion);
    state.rules = shouldUseSavedRules ? mergeSavedRules(saved.byebyefishingRules) : defaultRules;
    state.showTrustedBadges = saved.byebyefishingShowTrustedBadges !== false;
    state.greenFlagSenderDomains = normalizeGreenFlagSenderDomains(saved.byebyefishingGreenFlagSenderDomains);
    state.trustedSenderSites = normalizeTrustedSenderSites(saved.byebyefishingTrustedSenderSites);
  }

  function isVisibleElement(element) {
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function normalizeUiText(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function visibleText(element) {
    return (element.innerText || element.textContent || "").replace(/\s+/g, " ").trim();
  }

  function isRecipientMetadataCandidate(element) {
    const label = normalizeUiText(visibleText(element));
    const title = normalizeUiText(element.getAttribute("title") || element.getAttribute("aria-label"));
    const recipientLabels = new Set(["a moi", "moi", "to me", "me", "for me", "pour moi", "para mi"]);

    return recipientLabels.has(label) || recipientLabels.has(title);
  }

  function messageScopeFor(element) {
    const scope = element.closest(MESSAGE_SCOPE_SELECTORS.join(","));
    return scope instanceof HTMLElement ? scope : element;
  }

  function collectMessageScopes(contentCandidates) {
    const seen = new Set();
    const scopes = [];

    for (const candidate of contentCandidates) {
      const scope = messageScopeFor(candidate.element);
      if (seen.has(scope) || !isVisibleElement(scope)) {
        continue;
      }
      seen.add(scope);
      scopes.push(scope);
    }

    return scopes.slice(0, 6);
  }

  function candidateText(element) {
    const parts = [
      element.getAttribute("name"),
      element.getAttribute("email"),
      element.getAttribute("data-email"),
      element.getAttribute("data-address"),
      element.getAttribute("title"),
      element.getAttribute("aria-label"),
      element.getAttribute("href"),
      visibleText(element)
    ].filter(Boolean);

    return parts.join(" ");
  }

  function isReadableSenderCandidate(element) {
    return (
      element instanceof HTMLElement &&
      isVisibleElement(element) &&
      !isRecipientMetadataCandidate(element) &&
      candidateText(element).includes("@")
    );
  }

  function collectSenderCandidates(scopes) {
    const selectors = [
      "[email]",
      "[data-email]",
      "[data-address]",
      "[title*='@']",
      "[aria-label*='@']",
      "[data-testid*='sender']",
      "[data-test-id*='sender']",
      "[data-testid*='from']",
      "[data-test-id*='from']",
      "a[href^='mailto:']"
    ];

    const seen = new Set();
    const candidates = [];

    for (const scope of scopes) {
      scope.querySelectorAll(selectors.join(",")).forEach((element) => {
        if (!(element instanceof HTMLElement) || seen.has(element)) {
          return;
        }
        seen.add(element);

        if (!isReadableSenderCandidate(element)) {
          return;
        }

        candidates.push({ element, text: candidateText(element) });
      });
    }

    return candidates;
  }

  function collectLinkCandidates(scopes) {
    const seen = new Set();
    const candidates = [];

    for (const scope of scopes) {
      scope.querySelectorAll("a[href]").forEach((element) => {
        if (!(element instanceof HTMLAnchorElement)) {
          return;
        }

        const href = element.href || element.getAttribute("href") || "";
        if (!/^https?:\/\//i.test(href) || seen.has(href)) {
          return;
        }
        seen.add(href);

        if (!isVisibleElement(element)) {
          return;
        }

        candidates.push({
          element,
          href,
          text: (element.innerText || element.textContent || "").replace(/\s+/g, " ").trim()
        });
      });
    }

    return candidates.slice(0, 30);
  }

  function collectContentCandidates() {
    const seen = new Set();
    const candidates = [];

    document.querySelectorAll(MESSAGE_BODY_SELECTORS.join(",")).forEach((element) => {
      if (!(element instanceof HTMLElement) || seen.has(element) || element.closest(".byebyefishing-warning")) {
        return;
      }
      seen.add(element);

      const text = (element.innerText || element.textContent || "").replace(/\s+/g, " ").trim();
      if (!isVisibleElement(element) || text.length < 40 || text.length > 20000) {
        return;
      }

      candidates.push({ element, text });
    });

    return candidates.slice(0, 6);
  }

  function collectMailListSenderCandidates() {
    const seenRows = new Set();
    const seenElements = new Set();
    const candidates = [];

    function addRowCandidate(row) {
      if (!(row instanceof HTMLElement) || seenRows.has(row) || !isVisibleElement(row)) {
        return;
      }
      seenRows.add(row);

      let senderElement = null;
      for (const selector of MAIL_LIST_SENDER_SELECTORS) {
        const element = row.querySelector(selector);
        if (!(element instanceof HTMLElement) || seenElements.has(element) || !isReadableSenderCandidate(element)) {
          continue;
        }

        const text = candidateText(element);
        senderElement = element;
        break;
      }

      if (!senderElement) {
        return;
      }

      seenElements.add(senderElement);
      candidates.push({ element: senderElement, text: candidateText(senderElement) });
    }

    document.querySelectorAll(MAIL_LIST_ROW_SELECTORS.join(",")).forEach(addRowCandidate);

    const main = document.querySelector("div[role='main'], main");
    if (main instanceof HTMLElement) {
      main.querySelectorAll(MAIL_LIST_SENDER_SELECTORS.join(",")).forEach((element) => {
        if (!(element instanceof HTMLElement) || seenElements.has(element) || !isReadableSenderCandidate(element)) {
          return;
        }

        const text = candidateText(element);
        const row = element.closest("tr.zA, tr[role='row'], div[role='row']");
        if (!(row instanceof HTMLElement)) {
          return;
        }

        seenElements.add(element);
        seenRows.add(row);
        candidates.push({ element, text });
      });
    }

    return candidates.slice(0, 80);
  }

  function warningRank(result) {
    if (result.severity === "critical") {
      return 4;
    }
    if (result.severity === "high") {
      return 3;
    }
    if (result.severity === "medium") {
      return 2;
    }
    return result.status === "warning" ? 1 : 0;
  }

  function warningTiePriority(result) {
    if (result.context === "hosted-platform-link") {
      return 2;
    }
    if (result.urlDomain) {
      return 1;
    }
    if (result.context === "professional-sender-check") {
      return -1;
    }
    return 0;
  }

  function shouldReplaceGlobalWarning(candidate, current) {
    if (!shouldRenderGlobalWarning(candidate)) {
      return false;
    }
    if (!current) {
      return true;
    }

    const candidateRank = warningRank(candidate);
    const currentRank = warningRank(current);
    if (candidateRank !== currentRank) {
      return candidateRank > currentRank;
    }

    return warningTiePriority(candidate) > warningTiePriority(current);
  }

  function severityLabel(severity) {
    if (severity === "critical") {
      return "Strong stop";
    }
    if (severity === "high") {
      return "Verify first";
    }
    if (severity === "medium") {
      return "Worth checking";
    }
    return "Heads up";
  }

  function warningTitle(result) {
    if (result.context === "trusted-sender-payment") {
      return "Money moment";
    }
    if (result.context === "hosted-platform-link") {
      return "Shared page check";
    }
    if (result.context === "professional-sender-check") {
      return "Verify this sender";
    }
    if (result.urlDomain && result.severity === "critical") {
      return "Stop: suspicious link";
    }
    if (result.urlDomain && result.severity === "high") {
      return "Suspicious link";
    }
    if (result.urlDomain) {
      return "Unusual link";
    }
    if (result.severity === "critical") {
      return "Stop and check this first";
    }
    if (result.severity === "high") {
      return "Verify before acting";
    }
    if (result.severity === "medium") {
      return "Verify before acting";
    }
    return "Safety note";
  }

  function trustedSenderContext(result) {
    if (result.status !== "trusted" || result.context === "known-sender") {
      return null;
    }

    return {
      brand: result.brand || "",
      senderDomain: result.senderDomain || ""
    };
  }

  function displaySenderDomain(domain) {
    const normalized = detector.normalizeDomain(domain);
    return normalized ? `${normalized.charAt(0).toUpperCase()}${normalized.slice(1)}` : "";
  }

  function isNumericAddress(value) {
    return /^\d{1,3}(?:\.\d{1,3}){3}$/.test(String(value || "").trim());
  }

  function senderDomainIsGreenFlagged(senderDomain) {
    const normalized = detector.normalizeDomain(senderDomain);
    if (!normalized || state.greenFlagSenderDomains.size === 0) {
      return false;
    }

    return [...state.greenFlagSenderDomains].some((greenFlaggedDomain) =>
      detector.domainMatchesAllowed(normalized, greenFlaggedDomain)
    );
  }

  function withGreenFlagSenderResult(result) {
    const sender = senderIdentityFromResult(result);
    if (
      result.status !== "warning" ||
      (!senderDomainIsGreenFlagged(result.senderDomain) && !senderIsKnownFromTrustedSite(sender))
    ) {
      return result;
    }

    return {
      ...result,
      status: "trusted",
      severity: "none",
      context: "known-sender",
      allowedDomains: [],
      message: `Known sender domain: ${result.senderDomain}.`
    };
  }

  function senderIdentityFromResult(result) {
    const senderEmail = detector.extractEmail(result?.senderEmail || "");
    const senderDomain = detector.normalizeDomain(result?.senderDomain || senderEmail);
    if (!senderDomain) {
      return null;
    }

    return { senderEmail, senderDomain };
  }

  function senderSiteRecordMatches(record, sender, urlDomain) {
    const normalizedUrlDomain = detector.normalizeDomain(urlDomain);
    if (!record || !sender || !normalizedUrlDomain) {
      return false;
    }

    const senderMatches = record.senderEmail
      ? record.senderEmail === sender.senderEmail
      : detector.domainMatchesAllowed(sender.senderDomain, record.senderDomain);
    return senderMatches && detector.domainMatchesAllowed(normalizedUrlDomain, record.urlDomain);
  }

  function senderIsKnownFromTrustedSite(sender) {
    if (!sender) {
      return false;
    }

    return state.trustedSenderSites.some((record) =>
      record.senderEmail
        ? record.senderEmail === sender.senderEmail
        : detector.domainMatchesAllowed(sender.senderDomain, record.senderDomain)
    );
  }

  function withTrustedSenderSiteResult(result, sender) {
    const urlDomain = detector.normalizeDomain(result?.urlDomain);
    if (
      result.status !== "warning" ||
      result.context !== "hosted-platform-link" ||
      result.displayedDomain ||
      !urlDomain ||
      !sender
    ) {
      return result;
    }

    const trustedSite = state.trustedSenderSites.find((record) =>
      senderSiteRecordMatches(record, sender, urlDomain)
    );
    if (!trustedSite) {
      return result;
    }

    return {
      ...result,
      severity: "low",
      context: "trusted-sender-site",
      senderEmail: sender.senderEmail,
      senderDomain: sender.senderDomain,
      message: `${urlDomain} is a known hosted site for ${sender.senderEmail || sender.senderDomain}. Still check unexpected payment, login, or file requests.`
    };
  }

  function canRememberSenderWarning(result) {
    return result.context === "professional-sender-check" && Boolean(detector.normalizeDomain(result.senderDomain));
  }

  async function rememberKnownSenderDomain(senderDomain) {
    const normalized = detector.normalizeDomain(senderDomain);
    if (!normalized) {
      return;
    }

    state.greenFlagSenderDomains.add(normalized);
    await storageSet({
      byebyefishingGreenFlagSenderDomains: [...state.greenFlagSenderDomains].sort()
    });
    removeGlobalWarning();
    scheduleScan();
  }

  function ruleForResult(result) {
    if (!result?.brandId) {
      return null;
    }

    return state.rules.find((rule) => rule.id === result.brandId) || null;
  }

  function domainListNameForSenderTrust(rule) {
    return Array.isArray(rule?.senderDomains) ? "senderDomains" : "allowedDomains";
  }

  function canTrustSenderDomain(result) {
    return Boolean(
      result?.status === "warning" &&
        result.brandId &&
        !result.urlDomain &&
        detector.normalizeDomain(result.senderDomain) &&
        ruleForResult(result)
    );
  }

  function canTrustSiteForSender(result) {
    return Boolean(
      result?.status === "warning" &&
        result.context === "hosted-platform-link" &&
        detector.normalizeDomain(result.urlDomain) &&
        detector.normalizeDomain(result.senderDomain)
    );
  }

  async function saveRules(rules) {
    const validation = detector.validateRules(rules);
    if (!validation.ok) {
      throw new Error(validation.error || "Trusted-domain rules are invalid.");
    }

    state.rules = rules;
    state.skipNextRuleChangeScan = true;
    await storageSet({
      byebyefishingRules: rules,
      byebyefishingRulesCustom: true,
      byebyefishingRulesVersion: rulesetVersion
    });
  }

  async function trustSenderDomainForResult(result) {
    const domain = detector.normalizeDomain(result.senderDomain);
    const rule = ruleForResult(result);
    if (!domain || !rule || !detector.addTrustedDomainToRule) {
      return null;
    }

    const previousRules = state.rules;
    const listName = domainListNameForSenderTrust(rule);
    const nextRules = detector.addTrustedDomainToRule(state.rules, rule.id, domain, listName);
    await saveRules(nextRules);

    return { domain, previousRules };
  }

  async function undoTrustRules(previousRules) {
    if (!previousRules) {
      return;
    }

    await saveRules(previousRules);
    scheduleScan();
  }

  async function trustSiteForSender(result) {
    const sender = senderIdentityFromResult(result);
    const urlDomain = detector.normalizeDomain(result.urlDomain);
    if (!sender || !urlDomain) {
      return null;
    }

    const previousSites = state.trustedSenderSites;
    const nextSites = normalizeTrustedSenderSites([
      ...state.trustedSenderSites,
      {
        senderEmail: sender.senderEmail,
        senderDomain: sender.senderDomain,
        urlDomain
      }
    ]);

    state.trustedSenderSites = nextSites;
    await storageSet({
      byebyefishingTrustedSenderSites: nextSites
    });

    return { sender, urlDomain, previousSites };
  }

  async function undoTrustedSenderSites(previousSites) {
    state.trustedSenderSites = normalizeTrustedSenderSites(previousSites);
    await storageSet({
      byebyefishingTrustedSenderSites: state.trustedSenderSites
    });
    scheduleScan();
  }

  function showTrustSuccess(controls, message, previousRules) {
    controls.textContent = "";

    const status = document.createElement("span");
    status.className = "byebyefishing-warning__saved";
    status.textContent = message;

    const undo = document.createElement("button");
    undo.type = "button";
    undo.className = "byebyefishing-warning__secondary-action";
    undo.textContent = "Undo";
    undo.addEventListener("click", () => {
      undo.disabled = true;
      undoTrustRules(previousRules).catch(() => {
        undo.disabled = false;
      });
    });

    const done = document.createElement("button");
    done.type = "button";
    done.className = "byebyefishing-warning__secondary-action";
    done.textContent = "Done";
    done.addEventListener("click", () => {
      removeGlobalWarning();
      scheduleScan();
    });

    controls.append(status, undo, done);
  }

  function showSiteTrustSuccess(controls, message, previousSites) {
    controls.textContent = "";

    const status = document.createElement("span");
    status.className = "byebyefishing-warning__saved";
    status.textContent = message;

    const undo = document.createElement("button");
    undo.type = "button";
    undo.className = "byebyefishing-warning__secondary-action";
    undo.textContent = "Undo";
    undo.addEventListener("click", () => {
      undo.disabled = true;
      undoTrustedSenderSites(previousSites).catch(() => {
        undo.disabled = false;
      });
    });

    const done = document.createElement("button");
    done.type = "button";
    done.className = "byebyefishing-warning__secondary-action";
    done.textContent = "Done";
    done.addEventListener("click", () => {
      removeGlobalWarning();
      scheduleScan();
    });

    controls.append(status, undo, done);
  }

  function renderTrustConfirmation(controls, result) {
    const existing = controls.querySelector(".byebyefishing-warning__confirm");
    if (existing) {
      existing.remove();
      return;
    }

    const domain = detector.normalizeDomain(result.senderDomain);
    const confirm = document.createElement("div");
    confirm.className = "byebyefishing-warning__confirm";

    const copy = document.createElement("p");
    copy.textContent = `Add ${domain} only after you checked it really belongs to ${result.brand}. Future mail from this domain will feel familiar for that brand.`;

    const actions = document.createElement("div");
    actions.className = "byebyefishing-warning__confirm-actions";

    const trust = document.createElement("button");
    trust.type = "button";
    trust.className = "byebyefishing-warning__danger-action";
    trust.textContent = "I checked it";
    trust.addEventListener("click", () => {
      trust.disabled = true;
      trustSenderDomainForResult(result)
        .then((saved) => {
          if (saved) {
            showTrustSuccess(controls, `Saved. ${saved.domain} is now familiar for ${result.brand}.`, saved.previousRules);
          }
        })
        .catch(() => {
          trust.disabled = false;
        });
    });

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "byebyefishing-warning__secondary-action";
    cancel.textContent = "Cancel";
    cancel.addEventListener("click", () => confirm.remove());

    actions.append(trust, cancel);
    confirm.append(copy, actions);
    controls.append(confirm);
  }

  function renderRememberSenderConfirmation(controls, senderDomain) {
    const existing = controls.querySelector(".byebyefishing-warning__confirm");
    if (existing) {
      existing.remove();
      return;
    }

    const domain = detector.normalizeDomain(senderDomain);
    const confirm = document.createElement("div");
    confirm.className = "byebyefishing-warning__confirm";

    const copy = document.createElement("p");
    copy.textContent = `Remember ${domain} as a sender you know. This only hides the new-sender note; it does not mark the domain as an official brand.`;

    const actions = document.createElement("div");
    actions.className = "byebyefishing-warning__confirm-actions";

    const remember = document.createElement("button");
    remember.type = "button";
    remember.className = "byebyefishing-warning__danger-action";
    remember.textContent = "Remember this sender";
    remember.addEventListener("click", () => {
      remember.disabled = true;
      rememberKnownSenderDomain(domain).catch(() => {
        remember.disabled = false;
      });
    });

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "byebyefishing-warning__secondary-action";
    cancel.textContent = "Cancel";
    cancel.addEventListener("click", () => confirm.remove());

    actions.append(remember, cancel);
    confirm.append(copy, actions);
    controls.append(confirm);
  }

  function renderTrustSiteConfirmation(controls, result) {
    const existing = controls.querySelector(".byebyefishing-warning__confirm");
    if (existing) {
      existing.remove();
      return;
    }

    const sender = result.senderEmail || result.senderDomain;
    const urlDomain = detector.normalizeDomain(result.urlDomain);
    const confirm = document.createElement("div");
    confirm.className = "byebyefishing-warning__confirm";

    const copy = document.createElement("p");
    copy.textContent = `Use this only if you know ${sender} and expected ${urlDomain}. Next time, Bye bye Fishing will show a small note for this page and still pause for passwords, payments, codes, or urgent requests.`;

    const actions = document.createElement("div");
    actions.className = "byebyefishing-warning__confirm-actions";

    const trust = document.createElement("button");
    trust.type = "button";
    trust.className = "byebyefishing-warning__danger-action";
    trust.textContent = "Remember this page";
    trust.addEventListener("click", () => {
      trust.disabled = true;
      trustSiteForSender(result)
        .then((saved) => {
          if (saved) {
            showSiteTrustSuccess(
              controls,
              `Saved. ${saved.urlDomain} is now familiar for ${saved.sender.senderEmail || saved.sender.senderDomain}.`,
              saved.previousSites
            );
          }
        })
        .catch(() => {
          trust.disabled = false;
        });
    });

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "byebyefishing-warning__secondary-action";
    cancel.textContent = "Cancel";
    cancel.addEventListener("click", () => confirm.remove());

    actions.append(trust, cancel);
    confirm.append(copy, actions);
    controls.append(confirm);
  }

  function svgElement(name, attributes) {
    const element = document.createElementNS(SVG_NS, name);
    Object.entries(attributes || {}).forEach(([key, value]) => {
      element.setAttribute(key, String(value));
    });
    return element;
  }

  function createBrandIcon() {
    const mark = document.createElement("span");
    mark.className = "byebyefishing-warning__brand-icon";
    mark.setAttribute("aria-hidden", "true");

    const svg = svgElement("svg", {
      viewBox: "0 0 128 128",
      focusable: "false"
    });

    svg.append(
      svgElement("path", {
        d: "M17 45 39 64 17 83c17-2 28-9 28-19S34 47 17 45Z",
        fill: "#ff8e43"
      }),
      svgElement("path", {
        d: "M38 64c0-17 16-30 36-30 24 0 40 14 40 30S98 94 74 94c-20 0-36-13-36-30Z",
        fill: "#ffbe48"
      }),
      svgElement("path", {
        d: "M57 47 70 29l10 21M61 80l11 19 10-20",
        fill: "#ff8e43"
      }),
      svgElement("path", {
        d: "M89 49c-5 9-5 21-1 30",
        fill: "none",
        stroke: "#ef7e35",
        "stroke-width": 5,
        "stroke-linecap": "round"
      }),
      svgElement("circle", {
        cx: 84,
        cy: 56,
        r: 7,
        fill: "#fff"
      }),
      svgElement("circle", {
        cx: 87,
        cy: 56,
        r: 3,
        fill: "#0f2b3a"
      }),
      svgElement("path", {
        d: "M72 67c7 9 18 9 25 0",
        fill: "none",
        stroke: "#0f2b3a",
        "stroke-width": 4,
        "stroke-linecap": "round"
      })
    );

    mark.append(svg);
    return mark;
  }

  function warningDetail(result, allowed) {
    if (result.context === "trusted-sender-payment") {
      return result.senderDomain
        ? `Familiar sender: ${result.senderDomain}`
        : "The sender matches the familiar list.";
    }
    if (result.context === "hosted-platform-link") {
      return result.urlDomain ? `Shared page: ${result.urlDomain}` : "Open it only if you expected this page.";
    }
    if (result.context === "professional-sender-check") {
      return result.reason ? `Why: sender domain ${result.reason}.` : "Check that you recognize the sender.";
    }
    if (result.urlDomain) {
      return isNumericAddress(result.urlDomain)
        ? `Destination is a numeric IP address: ${result.urlDomain}`
        : `Destination: ${result.urlDomain}`;
    }

    if (result.severity === "critical") {
      return allowed
        ? `Official or familiar domains we know: ${allowed}`
        : "You can use the official app or contact the sender another way.";
    }

    return allowed ? `Familiar examples: ${allowed}` : "Check that this message matches what you expected.";
  }

  function warningActionText(result) {
    if (result.context === "trusted-sender-payment") {
      return "Recommendation: pay only if this matches an action you started.";
    }
    if (result.context === "hosted-platform-link") {
      return "Recommendation: avoid passwords, codes, or payment details on this page.";
    }
    if (result.context === "professional-sender-check") {
      return "Recommendation: verify the sender before replying, opening files, or following links.";
    }
    if (result.severity === "critical") {
      return "Strong recommendation: do not click, pay, or enter personal info here. Use the official app or type the website address yourself.";
    }
    if (result.severity === "high") {
      return "Strong recommendation: verify another way before clicking or paying.";
    }
    if (result.urlDomain) {
      return "Recommendation: do not use this link for login, payment, or personal details. Open the site directly if needed.";
    }
    return "Recommendation: take a quiet second before acting.";
  }

  function warningVerdict(result) {
    if (result.context === "trusted-sender-payment") {
      return "The sender looks familiar, but this asks for money or account access.";
    }
    if (result.context === "hosted-platform-link") {
      return result.brand
        ? `This page was made with ${result.brand}, where anyone can create a page.`
        : "This page was made with a public website builder.";
    }
    if (result.context === "professional-sender-check") {
      return result.reason ? `This sender ${result.reason}.` : "This sender is new to the safety list.";
    }
    if (result.urlDomain && isNumericAddress(result.urlDomain)) {
      return "This link uses a numeric IP address instead of a normal website name.";
    }
    if (result.urlDomain && result.severity === "high") {
      return "This link has a suspicious destination.";
    }
    if (result.urlDomain) {
      return "This link goes somewhere unusual.";
    }
    if (result.brand && result.senderDomain && result.severity === "critical") {
      return `This does not look like official ${result.brand} mail.`;
    }
    if (result.brand && result.urlDomain && result.severity === "critical") {
      return `This does not look like ${result.brand}'s familiar site.`;
    }
    if (result.severity === "critical") {
      return "This message has several common unsafe signals.";
    }
    if (result.severity === "high") {
      return "Something here deserves a quick check.";
    }
    return warningTitle(result);
  }

  function warningContextText(result) {
    if (result.context === "professional-sender-check") {
      return "";
    }
    if (result.context === "hosted-platform-link") {
      const sender = result.senderEmail || result.senderDomain;
      return sender
        ? ` Open it only if you expected it from ${sender}.`
        : " Open it only if you expected it.";
    }

    const message = result.message || "";
    return message
      .replace(/^Likely phishing:\s*/i, "")
      .replace(/\s*Do not click links, pay, or enter personal information\.$/i, "")
      .replace(/\s*Do not click links or enter delivery\/payment information\.$/i, "")
      .trim();
  }

  function warningKey(result) {
    return `${result.brand || "generic"}:${result.senderDomain || result.urlDomain || result.score || "unknown"}`;
  }

  function removeGlobalWarning() {
    document.querySelectorAll(".byebyefishing-warning").forEach((node) => node.remove());
  }

  function warningSignature(result) {
    const allowed = (result.allowedDomains || []).slice(0, 4).join(", ");
    return [
      warningKey(result),
      result.severity || "low",
      result.context || "",
      result.reason || "",
      warningTitle(result),
      result.message || "",
      allowed
    ].join("\n");
  }

  function renderWarning(result) {
    const key = warningKey(result);
    if (state.dismissedWarnings.has(key)) {
      removeGlobalWarning();
      return;
    }

    let banner = document.querySelector(".byebyefishing-warning");
    const signature = warningSignature(result);
    if (banner?.dataset.byebyefishingSignature === signature) {
      return;
    }

    if (!banner) {
      banner = document.createElement("aside");
      banner.setAttribute("role", "alert");
      document.documentElement.appendChild(banner);
    }
    banner.className = `byebyefishing-warning byebyefishing-warning--${result.severity || "low"}`;
    banner.dataset.byebyefishingSignature = signature;

    const allowed = (result.allowedDomains || []).slice(0, 4).join(", ");
    banner.innerHTML = "";

    const content = document.createElement("div");
    content.className = "byebyefishing-warning__content";

    const header = document.createElement("div");
    header.className = "byebyefishing-warning__header";

    const heading = document.createElement("div");
    heading.className = "byebyefishing-warning__heading";

    const meta = document.createElement("div");
    meta.className = "byebyefishing-warning__meta";

    const brandName = document.createElement("span");
    brandName.className = "byebyefishing-warning__brand-name";
    brandName.textContent = "Bye bye Fishing";

    const pill = document.createElement("span");
    pill.className = "byebyefishing-warning__pill";
    pill.textContent = severityLabel(result.severity);

    const title = document.createElement("strong");
    title.textContent = warningTitle(result);
    meta.append(brandName, pill);
    heading.append(meta, title);
    header.append(createBrandIcon(), heading);

    const message = document.createElement("p");
    message.className = "byebyefishing-warning__message";

    const verdict = document.createElement("strong");
    verdict.className = "byebyefishing-warning__verdict";
    verdict.textContent = warningVerdict(result);

    const contextText = warningContextText(result);
    if (contextText) {
      const context = document.createElement("span");
      context.textContent = ` ${contextText}`;
      message.append(verdict, context);
    } else {
      message.append(verdict);
    }

    const action = document.createElement("strong");
    action.className = "byebyefishing-warning__action";
    action.textContent = warningActionText(result);

    const detail = document.createElement("span");
    detail.textContent = warningDetail(result, allowed);

    const controls = document.createElement("div");
    controls.className = "byebyefishing-warning__controls";
    if (canTrustSiteForSender(result)) {
      const trustSite = document.createElement("button");
      trustSite.type = "button";
      trustSite.className = "byebyefishing-warning__trust-domain";
      trustSite.textContent = "I expected this page";
      trustSite.title = `Remember ${detector.normalizeDomain(result.urlDomain)} for ${
        result.senderEmail || result.senderDomain
      }`;
      trustSite.addEventListener("click", () => renderTrustSiteConfirmation(controls, result));
      controls.append(trustSite);
    }

    if (canTrustSenderDomain(result)) {
      const senderDomain = detector.normalizeDomain(result.senderDomain);
      const trustSender = document.createElement("button");
      trustSender.type = "button";
      trustSender.className = "byebyefishing-warning__trust-domain";
      trustSender.textContent = "I know this sender";
      trustSender.title = `Remember ${displaySenderDomain(senderDomain)} for ${result.brand}`;
      trustSender.setAttribute(
        "aria-label",
        `Remember familiar sender ${displaySenderDomain(senderDomain)} for ${result.brand}`
      );
      trustSender.addEventListener("click", () => renderTrustConfirmation(controls, result));
      controls.append(trustSender);
    }

    if (canRememberSenderWarning(result)) {
      const senderDomain = detector.normalizeDomain(result.senderDomain);
      const rememberSender = document.createElement("button");
      rememberSender.type = "button";
      rememberSender.className = "byebyefishing-warning__trust-domain";
      rememberSender.textContent = "Looks familiar";
      rememberSender.title = `Remember this sender note for ${displaySenderDomain(senderDomain)}`;
      rememberSender.setAttribute(
        "aria-label",
        `Remember ${displaySenderDomain(senderDomain)} as familiar`
      );
      rememberSender.addEventListener("click", () => renderRememberSenderConfirmation(controls, senderDomain));
      controls.append(rememberSender);
    }

    const close = document.createElement("button");
    close.type = "button";
    close.className = "byebyefishing-warning__close";
    close.setAttribute("aria-label", "Dismiss Bye bye Fishing note");
    close.textContent = "x";
    close.addEventListener("click", () => {
      state.dismissedWarnings.add(key);
      banner.remove();
    });

    content.append(header, message, action, detail);
    if (controls.childElementCount > 0) {
      content.append(controls);
    }
    banner.append(content, close);
  }

  function badgeInfo(result) {
    if (result.status === "trusted") {
      return { label: "trusted", tone: "trusted" };
    }
    if (result.status === "warning" && (result.severity === "critical" || result.severity === "high")) {
      return { label: "check", tone: "high-risk" };
    }
    if (result.status === "warning" && result.severity === "low") {
      return { label: "notice", tone: "notice" };
    }
    if (result.status === "warning") {
      return { label: "review", tone: "risk" };
    }
    return { label: "new", tone: "unknown" };
  }

  function badgeSignature(result) {
    const info = badgeInfo(result);
    return [info.tone, info.label, result.message || ""].join("\n");
  }

  function renderStatusBadge(element, result, seenBadges) {
    if (!state.showTrustedBadges && result.status !== "warning") {
      return;
    }

    const info = badgeInfo(result);
    const signature = badgeSignature(result);
    let badge = element.nextElementSibling;
    if (!(badge instanceof HTMLElement) || !badge.classList.contains("byebyefishing-badge")) {
      badge = document.createElement("span");
      element.insertAdjacentElement("afterend", badge);
    }

    if (badge.dataset.byebyefishingSignature !== signature) {
      badge.className = `byebyefishing-badge byebyefishing-badge--${info.tone}`;
      badge.title = result.message;
      badge.textContent = info.label;
      badge.dataset.byebyefishingSignature = signature;
    }
    seenBadges.add(badge);
  }

  function reconcileBadges(seenBadges) {
    document.querySelectorAll(".byebyefishing-badge").forEach((badge) => {
      if (!seenBadges.has(badge)) {
        badge.remove();
      }
    });
  }

  function shouldRenderDetailBadge(result) {
    return result.status === "warning";
  }

  function shouldRenderGlobalWarning(result) {
    return result.status === "warning" && result.context !== "trusted-sender-site";
  }

  function scanMailListBadges(seenBadges) {
    for (const candidate of collectMailListSenderCandidates()) {
      const result = withGreenFlagSenderResult(detector.analyzeSender(candidate.text, state.rules));
      renderStatusBadge(candidate.element, result, seenBadges);
    }
  }

  function scanPage() {
    const seenBadges = new Set();
    const contentCandidates = collectContentCandidates();
    const messageScopes = collectMessageScopes(contentCandidates);
    let firstWarning = null;
    const trustedSenderByScope = new Map();
    const senderByScope = new Map();

    if (messageScopes.length === 0) {
      scanMailListBadges(seenBadges);
      reconcileBadges(seenBadges);
      removeGlobalWarning();
      return;
    }

    for (const scope of messageScopes) {
      for (const candidate of collectSenderCandidates([scope])) {
        const result = withGreenFlagSenderResult(detector.analyzeSender(candidate.text, state.rules));
        const senderIdentity = senderIdentityFromResult(result);
        if (senderIdentity && !senderByScope.has(scope)) {
          senderByScope.set(scope, senderIdentity);
        }
        const trustedSender = trustedSenderContext(result);
        if (trustedSender && !trustedSenderByScope.has(scope)) {
          trustedSenderByScope.set(scope, trustedSender);
        }
        if (shouldReplaceGlobalWarning(result, firstWarning)) {
          firstWarning = result;
        }
        renderStatusBadge(candidate.element, result, seenBadges);
      }
    }

    for (const scope of messageScopes) {
      for (const candidate of collectLinkCandidates([scope])) {
        const sender = senderByScope.get(scope) || null;
        const analyzed = detector.analyzeLink
          ? detector.analyzeLink(candidate.text, candidate.href, state.rules)
          : detector.analyzeUrl(candidate.href, state.rules);
        const result = withTrustedSenderSiteResult(
          {
            ...analyzed,
            senderEmail: sender?.senderEmail || "",
            senderDomain: sender?.senderDomain || ""
          },
          sender
        );
        if (shouldReplaceGlobalWarning(result, firstWarning)) {
          firstWarning = result;
        }
        if (shouldRenderDetailBadge(result)) {
          renderStatusBadge(candidate.element, result, seenBadges);
        }
      }
    }

    for (const candidate of contentCandidates) {
      const scope = messageScopeFor(candidate.element);
      const trustedSender = trustedSenderByScope.get(scope) || null;
      const result = detector.analyzeContent(candidate.text, { trustedSender });
      if (shouldReplaceGlobalWarning(result, firstWarning)) {
        firstWarning = result;
      }
      if (shouldRenderDetailBadge(result)) {
        renderStatusBadge(candidate.element, result, seenBadges);
      }
    }

    reconcileBadges(seenBadges);
    if (firstWarning) {
      renderWarning(firstWarning);
    } else {
      removeGlobalWarning();
    }
  }

  function scheduleScan() {
    clearTimeout(state.scanTimer);
    state.scanTimer = setTimeout(scanPage, 250);
  }

  function isExtensionNode(node) {
    return node instanceof Element && Boolean(node.closest(".byebyefishing-badge, .byebyefishing-warning"));
  }

  function shouldScheduleFromMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return false;
    }
    if (mutation.type === "attributes") {
      return true;
    }

    const changedNodes = [...mutation.addedNodes, ...mutation.removedNodes];
    const elementNodes = changedNodes.filter((node) => node instanceof Element);
    if (elementNodes.length > 0) {
      return elementNodes.some((node) => !isExtensionNode(node));
    }

    return changedNodes.some((node) => node.textContent && node.textContent.trim());
  }

  function shouldScheduleFromMutations(mutations) {
    return mutations.some(shouldScheduleFromMutation);
  }

  async function start() {
    await loadSettings();
    scanPage();

    const observer = new MutationObserver((mutations) => {
      if (shouldScheduleFromMutations(mutations)) {
        scheduleScan();
      }
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["email", "title", "aria-label", "href"]
    });

    extensionApi.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "sync") {
        return;
      }

      if (changes.byebyefishingRules?.newValue) {
        const validation = detector.validateRules(changes.byebyefishingRules.newValue);
        state.rules = validation.ok ? mergeSavedRules(changes.byebyefishingRules.newValue) : defaultRules;
      }
      if (changes.byebyefishingShowTrustedBadges) {
        state.showTrustedBadges = changes.byebyefishingShowTrustedBadges.newValue !== false;
      }
      if (changes.byebyefishingGreenFlagSenderDomains) {
        state.greenFlagSenderDomains = normalizeGreenFlagSenderDomains(
          changes.byebyefishingGreenFlagSenderDomains.newValue
        );
      }
      if (changes.byebyefishingTrustedSenderSites) {
        state.trustedSenderSites = normalizeTrustedSenderSites(changes.byebyefishingTrustedSenderSites.newValue);
      }
      if (state.skipNextRuleChangeScan) {
        state.skipNextRuleChangeScan = false;
        return;
      }
      scheduleScan();
    });
  }

  start().catch(() => {
    state.rules = defaultRules;
    scanPage();
  });
})(typeof globalThis !== "undefined" ? globalThis : this);
