(function runOptions(global) {
  "use strict";

  const extensionApi = global.browser || global.chrome;
  const MAX_RENDERED_BRANDS = 120;
  const defaultRules = global.BYEBYEFISHING_DEFAULT_RULES || [];
  const rulesetVersion = global.BYEBYEFISHING_RULESET_VERSION || "0";
  const detector = global.ByeByeFishingDetector;
  const state = {
    rules: defaultRules,
    selectedRuleId: defaultRules[0]?.id || "",
    greenFlagSenderDomains: [],
    trustedSenderSites: []
  };
  let statusTimer = 0;

  const ruleStorageDefaults = {
    byebyefishingRules: null,
    byebyefishingRulesCustom: false,
    byebyefishingRulesVersion: ""
  };

  function storageAreaGet(area, defaults) {
    if (global.browser) {
      return area.get(defaults);
    }

    return new Promise((resolve, reject) => {
      area.get(defaults, (values) => {
        const error = extensionApi.runtime?.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve(values);
      });
    });
  }

  function storageAreaSet(area, values) {
    if (global.browser) {
      return area.set(values);
    }

    return new Promise((resolve, reject) => {
      area.set(values, () => {
        const error = extensionApi.runtime?.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve();
      });
    });
  }

  function localStorageGet(defaults) {
    return storageAreaGet(extensionApi.storage.local, defaults);
  }

  function localStorageSet(values) {
    return storageAreaSet(extensionApi.storage.local, values);
  }

  function formatRules(rules) {
    return JSON.stringify(rules, null, 2);
  }

  function showStatus(message, isError = false) {
    const status = document.getElementById("status");
    global.clearTimeout(statusTimer);
    status.textContent = message;
    status.classList.toggle("error", isError);
    if (!isError) {
      statusTimer = global.setTimeout(() => {
        status.textContent = "";
      }, 4000);
    }
  }

  function mergeSavedRules(rules) {
    const merged = detector.mergeDefaultRuleUpdates
      ? detector.mergeDefaultRuleUpdates(rules, defaultRules)
      : rules;
    return detector.validateRules(merged).ok ? merged : defaultRules;
  }

  async function loadRuleRecord() {
    return localStorageGet(ruleStorageDefaults);
  }

  function normalizedGreenFlagSenderDomains(domains) {
    const normalizedDomains = new Set();
    if (!Array.isArray(domains)) {
      return [];
    }

    domains.forEach((domain) => {
      const normalized = detector.normalizeDomain(domain);
      if (normalized) {
        normalizedDomains.add(normalized);
      }
    });

    return [...normalizedDomains].sort();
  }

  function normalizedTrustedSenderSites(records) {
    const normalizedRecords = [];
    const seen = new Set();
    if (!Array.isArray(records)) {
      return normalizedRecords;
    }

    records.forEach((record) => {
      if (!record || typeof record !== "object") {
        return;
      }

      const senderEmail = detector.extractEmail(record.senderEmail || "");
      const senderDomain = detector.normalizeDomain(record.senderDomain || senderEmail);
      const urlDomain = detector.normalizeDomain(record.urlDomain);
      if (!senderDomain || !urlDomain) {
        return;
      }

      const key = `${senderEmail}:${senderDomain}:${urlDomain}`;
      if (seen.has(key)) {
        return;
      }
      seen.add(key);
      normalizedRecords.push({ senderEmail, senderDomain, urlDomain });
    });

    return normalizedRecords.sort((first, second) =>
      `${first.senderDomain}:${first.urlDomain}`.localeCompare(`${second.senderDomain}:${second.urlDomain}`)
    );
  }

  function categoryLabel(category) {
    return String(category || "Other")
      .replace(/-/g, " ")
      .replace(/\b\w/g, (letter) => letter.toUpperCase());
  }

  function renderGreenFlags(domains) {
    const list = document.getElementById("greenFlagList");
    const clearButton = document.getElementById("clearGreenFlags");
    document.getElementById("senderCount").textContent = domains.length.toLocaleString();
    list.textContent = "";

    if (domains.length === 0) {
      const item = document.createElement("li");
      item.className = "empty";
      item.textContent = "No remembered senders yet.";
      list.append(item);
      clearButton.disabled = true;
      return;
    }

    domains.forEach((domain) => {
      const item = document.createElement("li");
      const code = document.createElement("code");
      code.textContent = domain;

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "remove-domain";
      remove.textContent = "Remove";
      remove.setAttribute("aria-label", `Remove remembered sender domain ${domain}`);
      remove.addEventListener("click", () => removeGreenFlagDomain(domain));

      item.append(code, remove);
      list.append(item);
    });
    clearButton.disabled = false;
  }

  function trustedSenderSiteLabel(record) {
    return `${record.urlDomain} for ${record.senderEmail || record.senderDomain}`;
  }

  function focusAfterListRemoval(listId, removedIndex) {
    const list = document.getElementById(listId);
    const removeButtons = [...list.querySelectorAll(".remove-domain")];
    const nextButton = removeButtons[Math.min(removedIndex, removeButtons.length - 1)];
    if (nextButton) {
      nextButton.focus();
      return;
    }

    list.tabIndex = -1;
    list.focus();
  }

  function renderTrustedSenderSites(records) {
    const list = document.getElementById("trustedSenderSiteList");
    const clearButton = document.getElementById("clearTrustedSenderSites");
    document.getElementById("pageCount").textContent = records.length.toLocaleString();
    list.textContent = "";

    if (records.length === 0) {
      const item = document.createElement("li");
      item.className = "empty";
      item.textContent = "No remembered shared pages yet.";
      list.append(item);
      clearButton.disabled = true;
      return;
    }

    records.forEach((record) => {
      const item = document.createElement("li");
      const code = document.createElement("code");
      code.textContent = trustedSenderSiteLabel(record);

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "remove-domain";
      remove.textContent = "Remove";
      remove.setAttribute("aria-label", `Remove remembered shared page ${trustedSenderSiteLabel(record)}`);
      remove.addEventListener("click", () => removeTrustedSenderSite(record));

      item.append(code, remove);
      list.append(item);
    });
    clearButton.disabled = false;
  }

  function filteredRules() {
    const query = document.getElementById("brandSearch").value.trim().toLowerCase();
    if (!query) {
      return state.rules;
    }

    return state.rules.filter((rule) => {
      const searchable = [
        rule.name,
        rule.category,
        ...(rule.aliases || []),
        ...(rule.allowedDomains || []),
        ...(rule.senderDomains || [])
      ].join(" ").toLowerCase();
      return searchable.includes(query);
    });
  }

  function renderBrandList(options = {}) {
    const list = document.getElementById("brandList");
    const summary = document.getElementById("brandListSummary");
    const rules = filteredRules();
    const renderedRules = rules.slice(0, MAX_RENDERED_BRANDS);
    document.getElementById("brandCount").textContent = state.rules.length.toLocaleString();
    const shouldFocusSelected = options.focusSelected === true;
    let selectedButton = null;
    list.textContent = "";
    summary.textContent = rules.length > renderedRules.length
      ? `Showing the first ${renderedRules.length} of ${rules.length} matches. Search to narrow the list.`
      : `Showing ${rules.length} of ${state.rules.length} brands.`;

    if (!rules.some((rule) => rule.id === state.selectedRuleId) && rules[0]) {
      state.selectedRuleId = rules[0].id;
    }

    if (rules.length === 0) {
      const empty = document.createElement("p");
      empty.className = "muted";
      empty.textContent = "No matching brands.";
      list.append(empty);
      return;
    }

    renderedRules.forEach((rule) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `brand-item${rule.id === state.selectedRuleId ? " is-selected" : ""}`;
      button.setAttribute("aria-pressed", rule.id === state.selectedRuleId ? "true" : "false");
      button.setAttribute("aria-controls", "brandEditor");
      button.textContent = rule.name;
      if (rule.id === state.selectedRuleId) {
        selectedButton = button;
      }

      const meta = document.createElement("span");
      const domainCount = (rule.allowedDomains || []).length;
      meta.textContent = `${categoryLabel(rule.category)} · ${domainCount} ${domainCount === 1 ? "domain" : "domains"}`;
      button.append(meta);

      button.addEventListener("click", () => {
        state.selectedRuleId = rule.id;
        renderBrandList({ focusSelected: true });
        renderBrandEditor();
        if (global.matchMedia?.("(max-width: 760px)").matches) {
          const editor = document.getElementById("brandEditor");
          const reduceMotion = global.matchMedia("(prefers-reduced-motion: reduce)").matches;
          editor.focus({ preventScroll: true });
          editor.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "start" });
        }
      });

      list.append(button);
    });

    if (shouldFocusSelected) {
      selectedButton?.focus();
    }
  }

  async function saveRules(rules, message) {
    const validation = detector.validateRules(rules);
    if (!validation.ok) {
      showStatus(validation.error, true);
      return false;
    }

    try {
      await localStorageSet({
        byebyefishingRules: rules,
        byebyefishingRulesCustom: true,
        byebyefishingRulesVersion: rulesetVersion
      });
    } catch (error) {
      document.getElementById("rulesJson").value = formatRules(state.rules);
      showStatus("Could not save the safety list. Your previous list is still in use.", true);
      return false;
    }

    state.rules = rules;
    document.getElementById("rulesJson").value = formatRules(rules);
    showStatus(message || "Saved. Open webmail tabs will update automatically.");
    return true;
  }

  async function addDomain(ruleId, inputId, listName) {
    const input = document.getElementById(inputId);
    const domain = detector.normalizeDomain(input.value);
    if (!domain) {
      showStatus("Enter a readable domain, such as example.com.", true);
      return;
    }

    const nextRules = detector.addTrustedDomainToRule(state.rules, ruleId, domain, listName);
    if (await saveRules(nextRules, `${domain} added.`)) {
      input.value = "";
      renderBrandList();
      renderBrandEditor();
      document.getElementById(inputId)?.focus();
    }
  }

  async function removeDomain(ruleId, domain, listName) {
    const nextRules = detector.removeTrustedDomainFromRule(state.rules, ruleId, domain, listName);
    if (nextRules === state.rules) {
      showStatus("Each brand needs at least one trusted domain.", true);
      return;
    }

    if (await saveRules(nextRules, `${domain} removed.`)) {
      renderBrandList();
      renderBrandEditor();
      document.getElementById(listName === "senderDomains" ? "senderDomainInput" : "allowedDomainInput")?.focus();
    }
  }

  function renderDomainPanel(rule, config) {
    const panel = document.createElement("section");
    panel.className = "domain-panel";

    const heading = document.createElement("h3");
    heading.textContent = config.title;

    const help = document.createElement("p");
    help.className = "muted";
    help.textContent = config.help;

    const list = document.createElement("ul");
    list.className = "domain-list with-actions";

    const domains = rule[config.listName] || [];
    domains.forEach((domain) => {
      const item = document.createElement("li");
      const code = document.createElement("code");
      code.textContent = domain;

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "remove-domain";
      remove.textContent = "Remove";
      remove.setAttribute("aria-label", `Remove ${domain} from ${rule.name}`);
      remove.disabled = domains.length <= 1;
      remove.addEventListener("click", () => removeDomain(rule.id, domain, config.listName));

      item.append(code, remove);
      list.append(item);
    });

    const add = document.createElement("div");
    add.className = "add-domain";

    const input = document.createElement("input");
    input.id = config.inputId;
    input.type = "text";
    input.placeholder = "example.com";
    input.autocomplete = "off";
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        addDomain(rule.id, config.inputId, config.listName);
      }
    });

    const inputLabel = document.createElement("label");
    inputLabel.htmlFor = config.inputId;
    inputLabel.textContent = `${config.buttonText} for ${rule.name}`;

    const button = document.createElement("button");
    button.type = "button";
    button.textContent = config.buttonText;
    button.addEventListener("click", () => addDomain(rule.id, config.inputId, config.listName));

    add.append(inputLabel, input, button);
    panel.append(heading, help, list, add);
    return panel;
  }

  function renderBrandEditor() {
    const editor = document.getElementById("brandEditor");
    const visibleRules = filteredRules();
    const rule = visibleRules.find((candidate) => candidate.id === state.selectedRuleId) || visibleRules[0] || null;
    editor.textContent = "";

    if (!rule) {
      const empty = document.createElement("p");
      empty.className = "muted";
      empty.textContent = visibleRules.length === 0
        ? "No matching brand. Change or clear your search to keep editing."
        : "Choose a brand to manage its known addresses.";
      editor.append(empty);
      return;
    }

    const summary = document.createElement("div");
    summary.className = "brand-summary";

    const title = document.createElement("h2");
    title.textContent = rule.name;

    const meta = document.createElement("p");
    meta.className = "muted";
    meta.textContent = `${categoryLabel(rule.category)} · Aliases: ${(rule.aliases || []).slice(0, 5).join(", ")}`;

    summary.append(title, meta);

    const allowedPanel = renderDomainPanel(rule, {
      title: Array.isArray(rule.senderDomains) ? "Known websites and links" : "Known web and email addresses",
      help: Array.isArray(rule.senderDomains)
        ? "Links to these addresses are treated as familiar. Email senders are managed separately below."
        : "Email senders and links at these addresses are treated as familiar for this brand.",
      inputId: "allowedDomainInput",
      listName: "allowedDomains",
      buttonText: "Add domain"
    });

    editor.append(summary, allowedPanel);

    if (Array.isArray(rule.senderDomains)) {
      editor.append(
        renderDomainPanel(rule, {
          title: "Known email senders",
          help: "Mail claiming this brand looks familiar only when it comes from one of these addresses.",
          inputId: "senderDomainInput",
          listName: "senderDomains",
          buttonText: "Add sender"
        })
      );
    }
  }

  async function loadRules() {
    let loaded;
    try {
      loaded = await loadRuleRecord();
    } catch (error) {
      state.rules = defaultRules;
      state.selectedRuleId = defaultRules[0]?.id || "";
      document.getElementById("rulesJson").value = formatRules(defaultRules);
      renderBrandList();
      renderBrandEditor();
      showStatus("Could not read the saved safety list. Friendly defaults are in use for now.", true);
      return;
    }

    const saved = loaded;
    const storedRules = Array.isArray(saved.byebyefishingRules) ? saved.byebyefishingRules : defaultRules;
    const validation = detector.validateRules(storedRules);
    const shouldUseSavedRules =
      validation.ok && (saved.byebyefishingRulesCustom || saved.byebyefishingRulesVersion === rulesetVersion);
    state.rules = shouldUseSavedRules
      ? saved.byebyefishingRulesCustom
        ? storedRules
        : mergeSavedRules(storedRules)
      : defaultRules;
    state.selectedRuleId = state.rules[0]?.id || "";
    document.getElementById("rulesJson").value = formatRules(state.rules);
    renderBrandList();
    renderBrandEditor();

    const shouldRefreshLocalRecord = !validation.ok || saved.byebyefishingRulesVersion !== rulesetVersion;
    if (shouldRefreshLocalRecord) {
      try {
        await localStorageSet({
          byebyefishingRules: state.rules,
          byebyefishingRulesCustom: shouldUseSavedRules && saved.byebyefishingRulesCustom === true,
          byebyefishingRulesVersion: rulesetVersion
        });
      } catch (error) {
        showStatus("The safety list loaded, but device storage could not be updated. Try saving again.", true);
        return;
      }
    }

    if (!validation.ok) {
      showStatus("Saved rules were invalid, defaults loaded.", true);
    } else if (saved.byebyefishingRulesCustom) {
      showStatus("Loaded your custom family safety list.");
    } else if (saved.byebyefishingRulesVersion !== rulesetVersion) {
      showStatus("Loaded the updated friendly defaults.");
    } else {
      showStatus("Loaded the default family safety list.");
    }
  }

  async function saveRulesJson() {
    const textarea = document.getElementById("rulesJson");
    let parsed;

    try {
      parsed = JSON.parse(textarea.value);
    } catch (error) {
      showStatus(`Invalid JSON: ${error.message}`, true);
      return;
    }

    if (await saveRules(parsed, "Saved JSON rules.")) {
      renderBrandList();
      renderBrandEditor();
    }
  }

  async function resetRules() {
    if (!global.confirm("Restore the default brand and domain list? Your custom rule edits will be replaced.")) {
      return;
    }

    try {
      await localStorageSet({
        byebyefishingRules: defaultRules,
        byebyefishingRulesCustom: false,
        byebyefishingRulesVersion: rulesetVersion
      });
    } catch (error) {
      showStatus("Could not restore the defaults. Your current safety list is unchanged.", true);
      return;
    }

    state.rules = defaultRules;
    state.selectedRuleId = defaultRules[0]?.id || "";
    document.getElementById("brandSearch").value = "";
    document.getElementById("rulesJson").value = formatRules(defaultRules);
    renderBrandList();
    renderBrandEditor();
    showStatus("Defaults restored.");
  }

  async function loadGreenFlags() {
    try {
      const saved = await localStorageGet({
        byebyefishingGreenFlagSenderDomains: []
      });
      state.greenFlagSenderDomains = normalizedGreenFlagSenderDomains(saved.byebyefishingGreenFlagSenderDomains);
      renderGreenFlags(state.greenFlagSenderDomains);
    } catch (error) {
      state.greenFlagSenderDomains = [];
      renderGreenFlags([]);
      showStatus("Could not load remembered senders.", true);
    }
  }

  async function clearGreenFlags() {
    if (
      state.greenFlagSenderDomains.length > 0 &&
      !global.confirm("Remove every remembered sender domain? Sender-only checks may appear again.")
    ) {
      return;
    }
    try {
      await localStorageSet({
        byebyefishingGreenFlagSenderDomains: []
      });
    } catch (error) {
      showStatus("Could not clear remembered senders. Nothing was changed.", true);
      return;
    }
    state.greenFlagSenderDomains = [];
    renderGreenFlags([]);
    showStatus("Remembered senders cleared.");
  }

  async function removeGreenFlagDomain(domain) {
    const normalized = detector.normalizeDomain(domain);
    const removedIndex = state.greenFlagSenderDomains.findIndex(
      (value) => detector.normalizeDomain(value) === normalized
    );
    const nextDomains = state.greenFlagSenderDomains.filter((value) => detector.normalizeDomain(value) !== normalized);
    try {
      await localStorageSet({
        byebyefishingGreenFlagSenderDomains: nextDomains
      });
    } catch (error) {
      showStatus(`Could not remove ${normalized}. Nothing was changed.`, true);
      return;
    }
    state.greenFlagSenderDomains = nextDomains;
    renderGreenFlags(nextDomains);
    focusAfterListRemoval("greenFlagList", Math.max(0, removedIndex));
    showStatus(`${normalized} removed from remembered senders.`);
  }

  async function loadTrustedSenderSites() {
    try {
      const saved = await localStorageGet({ byebyefishingTrustedSenderSites: [] });
      state.trustedSenderSites = normalizedTrustedSenderSites(
        saved.byebyefishingTrustedSenderSites
      );
      renderTrustedSenderSites(state.trustedSenderSites);
    } catch (error) {
      state.trustedSenderSites = [];
      renderTrustedSenderSites([]);
      showStatus("Could not load remembered shared pages.", true);
    }
  }

  async function saveTrustedSenderSites(records, message) {
    const nextRecords = normalizedTrustedSenderSites(records);
    try {
      await localStorageSet({
        byebyefishingTrustedSenderSites: nextRecords
      });
    } catch (error) {
      showStatus("Could not update remembered shared pages. Nothing was changed.", true);
      return false;
    }

    state.trustedSenderSites = nextRecords;
    renderTrustedSenderSites(nextRecords);
    showStatus(message);
    return true;
  }

  async function removeTrustedSenderSite(recordToRemove) {
    const keyToRemove = trustedSenderSiteLabel(recordToRemove);
    const removedIndex = state.trustedSenderSites.findIndex(
      (record) => trustedSenderSiteLabel(record) === keyToRemove
    );
    const nextRecords = state.trustedSenderSites.filter(
      (record) => trustedSenderSiteLabel(record) !== keyToRemove
    );
    if (await saveTrustedSenderSites(nextRecords, `${keyToRemove} removed.`)) {
      focusAfterListRemoval("trustedSenderSiteList", Math.max(0, removedIndex));
    }
  }

  async function clearTrustedSenderSites() {
    if (
      state.trustedSenderSites.length > 0 &&
      !global.confirm("Remove every remembered sender-and-page pairing? Shared-page checks may appear again.")
    ) {
      return;
    }
    await saveTrustedSenderSites([], "Remembered shared pages cleared.");
  }

  document.getElementById("brandSearch").addEventListener("input", () => {
    renderBrandList();
    renderBrandEditor();
  });
  document.getElementById("saveRulesJson").addEventListener("click", saveRulesJson);
  document.getElementById("resetRules").addEventListener("click", resetRules);
  document.getElementById("clearGreenFlags").addEventListener("click", clearGreenFlags);
  document.getElementById("clearTrustedSenderSites").addEventListener("click", clearTrustedSenderSites);

  async function init() {
    await loadRules();
    await Promise.all([loadGreenFlags(), loadTrustedSenderSites()]);
  }

  init().catch(() => {
    showStatus("Could not finish loading the options page. Reload it to try again.", true);
  });
})(typeof globalThis !== "undefined" ? globalThis : this);
