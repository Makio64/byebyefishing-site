(function exposeScanPolicy(global) {
  "use strict";

  const LIMITS = Object.freeze({
    bodyTextCharacters: 20000,
    bodySamplesPerBody: 2,
    // Four selected bodies can each retain a representative sample and a
    // risk-prioritized digest. Keeping the scope budget at that full 4 x 2
    // prevents earlier quoted bodies from hiding a later long-message plan.
    bodySamplesPerMessage: 8,
    messageScopes: 12,
    linksPerMessage: 48
  });
  const OMITTED_TEXT_MARKER = "\n[...]\n";
  const BALANCED_BODY_CHUNKS = 5;
  const REPRESENTATIVE_BODY_CHARACTERS = 8000;
  const RISK_WINDOW_CHARACTERS = 512;
  const RISK_CONTEXT_BEFORE_CHARACTERS = 320;
  const RISK_CONTEXT_AFTER_CHARACTERS = 400;
  const FINGERPRINT_BODY_DOMAIN = 0x62e2ac13;
  const FINGERPRINT_SCOPE_DOMAIN = 0x91c6d7b5;
  const ACTIVE_LINK_RE =
    /^(?:javascript:|vbscript:|data:\s*(?:text\/html|application\/xhtml\+xml|image\/svg\+xml)(?:[;,]|$))/i;
  const HTTP_LINK_RE = /^https?:\/\//i;
  const PROTOCOL_RELATIVE_LINK_RE = /^\/\//;
  const RISK_WORD_RE =
    /\b(?:accounts?|anydesk|auth|authenticator|backups?|banks?|beneficiar(?:y|ies)|billing|bitcoin|call|cancellation|charges?|claims?|codes?|confidential|confirm|credentials?|crypto|deposit|gift cards?|guaranteed|install|invoices?|login|mfa|otp|passwords?|payments?|photos?|phrases?|pictures?|quietly|recover|refunds?|reset|secure|security|seed|signin|support|suspend|teamviewer|transfers?|unlock|urgent|usdt|verify|wallets?|wire|withdrawal|authentification|beneficiaire|carte cadeau|code de securite|mot de passe|portefeuille|transfert|autenticador|beneficiario|codigo|contrasena|fotos?|transferencia|monedero|authenticator|empfanger|gutscheine?|passwort|sicherheitscode|uberweisung)\b|(?:cancellation\s+desk|remote\s+access|reply\s+only|weekly\s+returns?|withdrawal\s+fee|bons?\s+de\s+jeu|cartes?\s+cadeaux?|b[eé]n[eé]ficiaires?|c[oó]digos?|contrase(?:n|ñ)as?|tarjetas?\s+de\s+regalo|empf[aä]nger|passw(?:o|ö)rt(?:er)?|[uü]berweisungen?)|p[@a]ssw[0o]rd|pass\s*[-/\\\s]\s*word|verifi\s*[-/\\\s]\s*cation|p(?:[\s._-]+)a(?:[\s._-]+)s(?:[\s._-]+)s(?:[\s._-]+)w(?:[\s._-]+)o(?:[\s._-]+)r(?:[\s._-]+)d|[o0](?:[\s._-]+)t(?:[\s._-]+)p/iu;
  const STRONG_BODY_RISK_RE =
    /(?:anydesk|authenticator|backup|beneficiary|bitcoin|cancellation|charges?|confidential|credential|crypto|deposit|gift cards?|guaranteed|install|mfa|otp|password|passcode|photos?|quietly|remote\s+access|reply\s+only|seed|teamviewer|usdt|wallet|weekly\s+returns?|wire|withdrawal|authentification|b[eé]n[eé]ficiaire|cartes?\s+cadeaux?|code de securite|mot de passe|portefeuille|autenticador|beneficiario|c[oó]digos?|contrase(?:n|ñ)a|fotos?|monedero|empf[aä]nger|gutscheine?|passw(?:o|ö)rt|sicherheitscode|[uü]berweisung|bons?\s+de\s+jeu|tarjetas?\s+de\s+regalo|p[@a]ssw[0o]rd|pass\s*[-/\\\s]\s*word|verifi\s*[-/\\\s]\s*cation|p(?:[\s._-]+)a(?:[\s._-]+)s(?:[\s._-]+)s(?:[\s._-]+)w(?:[\s._-]+)o(?:[\s._-]+)r(?:[\s._-]+)d|[o0](?:[\s._-]+)t(?:[\s._-]+)p)/iu;
  const GIFT_CARD_EVIDENCE_BODY_RE =
    /(?:buy|purchase|ach[eè]t[\p{L}]*|compr[\p{L}]*|kauf[\p{L}]*)(?:[\s\S]{0,140})(?:gift\s*cards?|gaming\s*vouchers?|bons?\s+de\s+jeu|cartes?\s+cadeaux?|tarjetas?\s+de\s+regalo|spielgutscheine?|gutscheine?)(?:[\s\S]{0,140})(?:send|share|reply|forward|upload|envoi[\p{L}]*|partag[\p{L}]*|env[ií][\p{L}]*|compart[\p{L}]*|send[\p{L}]*|teil[\p{L}]*)(?:[\s\S]{0,80})(?:photos?|pictures?|images?|codes?|pins?|fotos?)/iu;
  const GIFT_CARD_COMPONENT_RE =
    /(?:gift\s*cards?|gaming\s*vouchers?|bons?\s+de\s+jeu|cartes?\s+cadeaux?|tarjetas?\s+de\s+regalo|spielgutscheine?|gutscheine?|photos?|pictures?|images?|codes?|pins?|fotos?)/iu;
  const SPACED_SECRET_BODY_RE =
    /(?:p(?:[\s._-]+)a(?:[\s._-]+)s(?:[\s._-]+)s(?:[\s._-]+)w(?:[\s._-]+)o(?:[\s._-]+)r(?:[\s._-]+)d|[o0](?:[\s._-]+)t(?:[\s._-]+)p)/iu;
  const HIGH_RISK_TLDS = new Set([
    "click",
    "club",
    "gq",
    "icu",
    "info",
    "link",
    "loan",
    "lol",
    "mom",
    "quest",
    "review",
    "shop",
    "site",
    "support",
    "top",
    "work",
    "xyz"
  ]);

  function fingerprintSeeds() {
    const seeds = new Uint32Array(2);
    try {
      if (global.crypto && typeof global.crypto.getRandomValues === "function") {
        global.crypto.getRandomValues(seeds);
      } else {
        seeds[0] = Math.floor(Math.random() * 0x100000000);
        seeds[1] = Math.floor(Math.random() * 0x100000000);
      }
    } catch (_error) {
      seeds[0] = Math.floor(Math.random() * 0x100000000);
      seeds[1] = Math.floor(Math.random() * 0x100000000);
    }
    return Object.freeze([seeds[0] >>> 0, seeds[1] >>> 0]);
  }

  // Dismissals are in-memory for one content-script lifetime. A matching
  // per-lifetime seed prevents mail content from precomputing useful checksum
  // collisions and avoids a stable cross-session body identifier.
  const FINGERPRINT_SEEDS = fingerprintSeeds();

  function finiteNumber(value, fallback) {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
  }

  function selectionLimit(options, fallback) {
    const requested =
      typeof options === "number"
        ? options
        : options && typeof options === "object"
          ? options.limit
          : undefined;
    return Math.max(0, Math.floor(finiteNumber(requested, fallback)));
  }

  function boundedBodyText(value, maxCharacters = LIMITS.bodyTextCharacters) {
    const text = String(value || "");
    const limit = Math.max(0, Math.floor(finiteNumber(maxCharacters, LIMITS.bodyTextCharacters)));
    if (text.length <= limit) {
      return text;
    }
    if (limit === 0) {
      return "";
    }

    const chunkCount = Math.max(
      2,
      Math.min(BALANCED_BODY_CHUNKS, Math.floor((limit + OMITTED_TEXT_MARKER.length) / (OMITTED_TEXT_MARKER.length + 1)))
    );
    const markerCount = chunkCount - 1;
    const payloadCharacters = limit - markerCount * OMITTED_TEXT_MARKER.length;
    if (payloadCharacters < chunkCount) {
      const headLength = Math.ceil(limit / 2);
      return text.slice(0, headLength) + text.slice(text.length - (limit - headLength));
    }

    const omittedCharacters = text.length - payloadCharacters;
    const baseChunkLength = Math.floor(payloadCharacters / chunkCount);
    const extraChunkCharacters = payloadCharacters % chunkCount;
    const baseGapLength = Math.floor(omittedCharacters / markerCount);
    const extraGapCharacters = omittedCharacters % markerCount;
    const chunks = [];
    let offset = 0;

    for (let index = 0; index < chunkCount; index += 1) {
      const chunkLength = baseChunkLength + (index < extraChunkCharacters ? 1 : 0);
      chunks.push(text.slice(offset, offset + chunkLength));
      offset += chunkLength;
      if (index < markerCount) {
        offset += baseGapLength + (index < extraGapCharacters ? 1 : 0);
      }
    }

    return chunks.join(OMITTED_TEXT_MARKER);
  }

  function globalMatcher(pattern) {
    const flags = pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`;
    return new RegExp(pattern.source, flags);
  }

  function boundedTextFingerprint(value, purpose = "message-body") {
    const text = String(value || "");
    const isScope = purpose === "message-scope";
    const domain = isScope
      ? FINGERPRINT_SCOPE_DOMAIN
      : FINGERPRINT_BODY_DOMAIN;
    let firstHash = (FINGERPRINT_SEEDS[0] ^ domain ^ text.length) >>> 0;
    let secondHash =
      (FINGERPRINT_SEEDS[1] ^ ~domain ^ text.length) >>> 0;

    for (let index = 0; index < text.length; index += 1) {
      const code = text.charCodeAt(index);
      firstHash = Math.imul(firstHash ^ code, 16777619);
      secondHash = Math.imul(secondHash ^ code, 2246822519);
      secondHash = ((secondHash << 13) | (secondHash >>> 19)) >>> 0;
    }

    // Constant-size, local-only identity for dismissal scoping. The body text
    // itself is never retained in metrics or extension storage.
    return [
      isScope ? "s1" : "b1",
      text.length.toString(36),
      (firstHash >>> 0).toString(36),
      (secondHash >>> 0).toString(36)
    ].join(":");
  }

  function bodyRiskMatcher() {
    const detector = global.ByeByeFishingDetector;
    if (
      detector &&
      typeof detector.contentSelectionRiskPattern === "function" &&
      typeof detector.contentSelectionRisk === "function"
    ) {
      const detectorPattern = detector.contentSelectionRiskPattern();
      if (detectorPattern instanceof RegExp && detectorPattern.source) {
        return {
          detector,
          matcher: new RegExp(
            `(?<detectorRisk>${detectorPattern.source})|(?:${RISK_WORD_RE.source})`,
            "giu"
          )
        };
      }
    }
    return { detector: null, matcher: globalMatcher(RISK_WORD_RE) };
  }

  function bodyTextSamplePlan(value, options = {}) {
    const text = String(value || "");
    const maxCharacters = Math.max(
      1,
      Math.floor(finiteNumber(options.maxCharacters, LIMITS.bodyTextCharacters))
    );
    const maxSamples = Math.max(
      1,
      Math.floor(finiteNumber(options.maxSamples, LIMITS.bodySamplesPerBody))
    );
    const metrics = {
      inputCharacters: text.length,
      maxCharacters,
      maxSamples,
      patternPasses: 0,
      charactersPatternScanned: 0,
      contextPatternChecks: 0,
      riskMatchesExamined: 0,
      riskBucketsStored: 0,
      riskWindowBudget: 0,
      riskWindowsSelected: 0,
      riskBucketsOmitted: 0,
      riskSamplingSaturated: false,
      saturatedRiskScore: 0,
      saturatedRiskBucketCount: 0,
      highestOmittedRiskScore: 0,
      highestOmittedRiskBucketCount: 0,
      fullTextFingerprint: boundedTextFingerprint(text, "message-body"),
      outputCharacters: 0
    };

    function finish(samples) {
      const boundedSamples = samples.slice(0, maxSamples);
      metrics.outputCharacters = boundedSamples.reduce(
        (total, sample) => total + sample.length,
        0
      );
      return {
        samples: boundedSamples,
        metrics: Object.freeze({ ...metrics })
      };
    }

    if (text.length <= maxCharacters) {
      return finish([text]);
    }
    const representativeLimit = Math.min(
      maxCharacters,
      REPRESENTATIVE_BODY_CHARACTERS
    );
    const samples = [boundedBodyText(text, representativeLimit)];
    if (maxSamples === 1 || representativeLimit >= maxCharacters) {
      return finish(samples);
    }

    const riskDigestLimit = maxCharacters - representativeLimit;
    const riskBuckets = new Map();

    function updateRiskEntryScore(entry, score, start, end) {
      if (score > entry.score) {
        entry.score = score;
        entry.bestStart = start;
        entry.bestEnd = end;
        return;
      }
      if (score === entry.score) {
        entry.bestStart = Math.min(entry.bestStart, start);
        entry.bestEnd = Math.max(entry.bestEnd, end);
      }
    }

    function recordRiskCandidate(match, score, options = {}) {
      metrics.riskMatchesExamined += 1;
      const matchIndex = match.index || 0;
      const matchLength = Math.max(1, match[0].length);
      const matchEnd = matchIndex + matchLength;
      const bucket = Math.floor(matchIndex / RISK_WINDOW_CHARACTERS);
      let entry = riskBuckets.get(bucket);
      if (!entry) {
        entry = {
          bucket,
          score: 0,
          bestStart: matchIndex,
          bestEnd: matchEnd,
          detectorStart: Number.POSITIVE_INFINITY,
          detectorEnd: Number.NEGATIVE_INFINITY,
          needsDetectorContext: false,
          needsGiftCardContext: false
        };
        riskBuckets.set(bucket, entry);
      }
      updateRiskEntryScore(entry, score, matchIndex, matchEnd);
      if (options.detector) {
        entry.needsDetectorContext = true;
        entry.detectorStart = Math.min(entry.detectorStart, matchIndex);
        entry.detectorEnd = Math.max(entry.detectorEnd, matchEnd);
      }
      entry.needsGiftCardContext =
        entry.needsGiftCardContext || Boolean(options.giftCard);
    }

    function riskWindowStart(entry) {
      const span = Math.max(1, entry.bestEnd - entry.bestStart);
      const padding = Math.max(0, RISK_WINDOW_CHARACTERS - span);
      return Math.max(
        0,
        Math.min(
          Math.max(0, text.length - RISK_WINDOW_CHARACTERS),
          entry.bestStart - Math.floor(padding / 2)
        )
      );
    }

    const riskMatcher = bodyRiskMatcher();
    metrics.patternPasses += 1;
    for (const match of text.matchAll(riskMatcher.matcher)) {
      const score = Math.max(
        SPACED_SECRET_BODY_RE.test(match[0])
          ? 4
          : STRONG_BODY_RISK_RE.test(match[0])
            ? 2
            : 1
      );
      recordRiskCandidate(match, score, {
        detector: Boolean(riskMatcher.detector && match.groups?.detectorRisk),
        giftCard: GIFT_CARD_COMPONENT_RE.test(match[0])
      });
    }

    // Context scoring can be substantially more expensive than the single
    // global matcher pass. Evaluate each 512-character bucket at most once,
    // even when a repeated benign term (for example "support") appears
    // thousands of times inside it.
    for (const entry of riskBuckets.values()) {
      if (!entry.needsDetectorContext && !entry.needsGiftCardContext) {
        entry.start = riskWindowStart(entry);
        continue;
      }
      const bucketStart = entry.bucket * RISK_WINDOW_CHARACTERS;
      const bucketEnd = Math.min(
        text.length,
        bucketStart + RISK_WINDOW_CHARACTERS
      );
      const contextStart = Math.max(
        0,
        bucketStart - RISK_CONTEXT_BEFORE_CHARACTERS
      );
      const contextEnd = Math.min(
        text.length,
        bucketEnd + RISK_CONTEXT_AFTER_CHARACTERS
      );
      const context = text.slice(contextStart, contextEnd);
      metrics.contextPatternChecks += 1;
      metrics.charactersPatternScanned += context.length;

      if (entry.needsGiftCardContext) {
        const evidenceMatch = GIFT_CARD_EVIDENCE_BODY_RE.exec(context);
        if (evidenceMatch) {
          const evidenceStart = contextStart + (evidenceMatch.index || 0);
          updateRiskEntryScore(
            entry,
            4,
            evidenceStart,
            evidenceStart + evidenceMatch[0].length
          );
        }
      }
      if (entry.needsDetectorContext) {
        const detectorScore =
          riskMatcher.detector.contentSelectionRisk(context);
        updateRiskEntryScore(
          entry,
          detectorScore,
          entry.detectorStart,
          entry.detectorEnd
        );
      }
      entry.start = riskWindowStart(entry);
    }
    metrics.charactersPatternScanned += text.length * metrics.patternPasses;
    metrics.riskBucketsStored = riskBuckets.size;

    const riskEntries = [...riskBuckets.values()].sort(
      (first, second) => first.start - second.start
    );
    const windowBudget = Math.max(
      1,
      Math.floor(
        (riskDigestLimit + OMITTED_TEXT_MARKER.length) /
          (RISK_WINDOW_CHARACTERS + OMITTED_TEXT_MARKER.length)
      )
    );
    metrics.riskWindowBudget = windowBudget;
    const riskScoreCounts = new Map();
    for (const entry of riskEntries) {
      riskScoreCounts.set(
        entry.score,
        (riskScoreCounts.get(entry.score) || 0) + 1
      );
    }
    const saturatedTier = [...riskScoreCounts.entries()]
      .filter(([_score, count]) => count > windowBudget)
      .sort((first, second) => second[0] - first[0])[0];
    if (saturatedTier) {
      // Metadata only: saturation means deterministic bounded sampling cannot
      // retain every same-priority candidate. It is not a phishing verdict.
      metrics.riskSamplingSaturated = true;
      metrics.saturatedRiskScore = saturatedTier[0];
      metrics.saturatedRiskBucketCount = saturatedTier[1];
    }
    const selectedRiskEntries = new Set();

    function selectBalanced(entries, count) {
      for (const index of balancedIndexes(
        entries.length,
        Math.min(entries.length, count)
      )) {
        if (selectedRiskEntries.size >= windowBudget) {
          break;
        }
        selectedRiskEntries.add(entries[index]);
      }
    }

    const highEntries = riskEntries.filter((entry) => entry.score >= 3);
    selectBalanced(highEntries, Math.ceil(windowBudget * 0.5));
    const strongEntries = riskEntries.filter((entry) => entry.score >= 2);
    selectBalanced(strongEntries, Math.ceil(windowBudget * 0.75));
    selectBalanced(riskEntries, windowBudget);

    if (selectedRiskEntries.size < windowBudget) {
      riskEntries
        .slice()
        .sort(
          (first, second) =>
            second.score - first.score || first.start - second.start
        )
        .forEach((entry) => {
          if (selectedRiskEntries.size < windowBudget) {
            selectedRiskEntries.add(entry);
          }
        });
    }

    const omittedRiskEntries = riskEntries.filter(
      (entry) => !selectedRiskEntries.has(entry)
    );
    metrics.highestOmittedRiskScore = omittedRiskEntries.reduce(
      (highestScore, entry) => Math.max(highestScore, entry.score),
      0
    );
    metrics.highestOmittedRiskBucketCount = omittedRiskEntries.filter(
      (entry) => entry.score === metrics.highestOmittedRiskScore
    ).length;

    const riskWindows = [...selectedRiskEntries]
      .sort((first, second) => first.start - second.start)
      .map((entry) =>
        text.slice(entry.start, entry.start + RISK_WINDOW_CHARACTERS)
    );
    metrics.riskWindowsSelected = riskWindows.length;
    metrics.riskBucketsOmitted = Math.max(
      0,
      riskEntries.length - riskWindows.length
    );
    if (riskWindows.length > 0) {
      samples.push(
        riskWindows.join(OMITTED_TEXT_MARKER).slice(0, riskDigestLimit)
      );
    }

    return finish(samples);
  }

  function bodyTextSamples(value, options = {}) {
    return bodyTextSamplePlan(value, options).samples;
  }

  function candidateOrder(candidate, fallback) {
    return finiteNumber(candidate && (candidate.order ?? candidate.index), fallback);
  }

  function candidateIsCurrent(candidate) {
    return Boolean(
      candidate &&
        (candidate.isCurrent ||
          candidate.current ||
          candidate.isActive ||
          candidate.active ||
          candidate.isSelected ||
          candidate.selected)
    );
  }

  function candidateIsLatest(candidate) {
    return Boolean(candidate && (candidate.isLatest || candidate.latest));
  }

  function candidateViewportDistance(candidate) {
    if (!candidate) {
      return Number.POSITIVE_INFINITY;
    }
    if (candidate.inViewport || candidate.isInViewport) {
      return 0;
    }
    return Math.max(
      0,
      finiteNumber(
        candidate.viewportDistance ?? candidate.distanceToViewport,
        Number.POSITIVE_INFINITY
      )
    );
  }

  function candidateRecency(candidate) {
    if (!candidate) {
      return Number.NEGATIVE_INFINITY;
    }
    const value = candidate.timestamp ?? candidate.recency ?? candidate.date;
    if (value instanceof Date) {
      return value.getTime();
    }
    if (typeof value === "string") {
      const parsed = Date.parse(value);
      return Number.isFinite(parsed) ? parsed : Number.NEGATIVE_INFINITY;
    }
    return finiteNumber(value, Number.NEGATIVE_INFINITY);
  }

  function balancedIndexes(length, count) {
    if (length <= 0 || count <= 0) {
      return [];
    }
    if (count === 1) {
      return [length - 1];
    }

    const indexes = [];
    for (let slot = 0; slot < count; slot += 1) {
      indexes.push(Math.round((slot * (length - 1)) / (count - 1)));
    }
    return [...new Set(indexes)];
  }

  function selectMessageCandidates(candidates, options) {
    const source = Array.isArray(candidates) ? candidates : [];
    const limit = selectionLimit(options, LIMITS.messageScopes);
    if (limit === 0 || source.length === 0) {
      return [];
    }
    if (source.length <= limit) {
      return source.slice();
    }

    const entries = source.map((candidate, index) => ({
      candidate,
      index,
      order: candidateOrder(candidate, index),
      current: candidateIsCurrent(candidate),
      latest: candidateIsLatest(candidate),
      viewportDistance: candidateViewportDistance(candidate),
      recency: candidateRecency(candidate)
    }));
    const selected = new Set();

    function add(entry) {
      if (entry && selected.size < limit) {
        selected.add(entry.index);
      }
    }

    entries
      .filter((entry) => entry.current)
      .sort(
        (first, second) =>
          first.viewportDistance - second.viewportDistance ||
          second.recency - first.recency ||
          second.order - first.order
      )
      .forEach(add);

    entries
      .filter((entry) => entry.latest)
      .sort((first, second) => second.recency - first.recency || second.order - first.order)
      .forEach(add);

    const newestByTimestamp = entries
      .filter((entry) => Number.isFinite(entry.recency))
      .sort((first, second) => second.recency - first.recency || second.order - first.order)[0];
    add(newestByTimestamp);
    add(entries[entries.length - 1]);

    const viewportQuota = Math.max(2, Math.floor(limit / 3));
    entries
      .filter((entry) => Number.isFinite(entry.viewportDistance))
      .sort(
        (first, second) =>
          first.viewportDistance - second.viewportDistance ||
          second.order - first.order
      )
      .slice(0, viewportQuota)
      .forEach(add);

    add(entries[0]);
    for (const index of balancedIndexes(entries.length, limit)) {
      add(entries[index]);
    }

    entries
      .slice()
      .sort(
        (first, second) =>
          Number(second.current) - Number(first.current) ||
          Number(second.latest) - Number(first.latest) ||
          first.viewportDistance - second.viewportDistance ||
          second.recency - first.recency ||
          second.order - first.order
      )
      .forEach(add);

    return entries
      .filter((entry) => selected.has(entry.index))
      .sort((first, second) => first.index - second.index)
      .map((entry) => entry.candidate);
  }

  function normalizedLinkText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function isActiveLinkTarget(value) {
    return ACTIVE_LINK_RE.test(String(value || "").trim());
  }

  function preferredLinkHref(rawHref, resolvedHref) {
    const raw = String(rawHref || "").trim();
    const resolved = String(resolvedHref || "").trim();

    if (isActiveLinkTarget(raw) || HTTP_LINK_RE.test(raw)) {
      return raw;
    }
    if (PROTOCOL_RELATIVE_LINK_RE.test(raw) && HTTP_LINK_RE.test(resolved)) {
      const scheme = resolved.slice(0, resolved.indexOf(":") + 1);
      return `${scheme}${raw}`;
    }
    if (isActiveLinkTarget(resolved) || HTTP_LINK_RE.test(resolved)) {
      return resolved;
    }
    return raw || resolved;
  }

  function isScannableLinkTarget(rawHref, resolvedHref) {
    const href = preferredLinkHref(rawHref, resolvedHref);
    return HTTP_LINK_RE.test(href) || isActiveLinkTarget(href);
  }

  function parseHttpUrl(value) {
    const href = String(value || "").trim();
    if (!HTTP_LINK_RE.test(href)) {
      return null;
    }
    try {
      return new URL(href);
    } catch (_error) {
      return null;
    }
  }

  function displayedHostname(text) {
    const value = normalizedLinkText(text);
    const match = value.match(
      /(?:https?:\/\/|www\.)?((?:[\p{L}\p{N}-]+\.)+[\p{L}]{2,63})(?::\d+)?(?:[/?#\s]|$)/iu
    );
    if (!match) {
      return "";
    }
    try {
      return new URL(`https://${match[1]}`).hostname.toLowerCase().replace(/\.$/, "");
    } catch (_error) {
      return match[1].toLowerCase().replace(/\.$/, "");
    }
  }

  function relatedHostnames(first, second) {
    return (
      first === second ||
      first.endsWith(`.${second}`) ||
      second.endsWith(`.${first}`)
    );
  }

  function linkRiskScore(candidate) {
    if (!candidate) {
      return 0;
    }
    const rawHref = String(candidate.rawHref ?? candidate.href ?? "");
    const resolvedHref = String(candidate.resolvedHref ?? candidate.href ?? "");
    const href = preferredLinkHref(rawHref, resolvedHref);
    const text = normalizedLinkText(candidate.text);
    const combined = `${text} ${href}`;
    let score = Math.max(0, finiteNumber(candidate.detectorRisk, 0));

    if (/^(?:javascript|vbscript):/i.test(href)) {
      score += 1200;
    } else if (
      /^data:\s*(?:text\/html|application\/xhtml\+xml|image\/svg\+xml)/i.test(href)
    ) {
      score += 1100;
    }
    if (/[^\u0000-\u007f]/.test(rawHref)) {
      score += 360;
    }
    if (/xn--/i.test(href)) {
      score += 300;
    }
    if (/%(?:00|0d|0a|2e|2f|3a|40|5c)/i.test(href)) {
      score += 180;
    }
    if (RISK_WORD_RE.test(combined)) {
      score += 140;
    }
    if (href.length > 240) {
      score += 60;
    }

    const parsed = parseHttpUrl(href);
    if (parsed) {
      const hostname = parsed.hostname.toLowerCase().replace(/^\[|\]$/g, "").replace(/\.$/, "");
      if (parsed.username || parsed.password) {
        score += 440;
      }
      if (/^(?:\d{1,3}\.){3}\d{1,3}$/.test(hostname) || hostname.includes(":")) {
        score += 320;
      }
      const tld = hostname.split(".").pop();
      if (HIGH_RISK_TLDS.has(tld)) {
        score += 100;
      }
      const shownHostname = displayedHostname(text);
      if (shownHostname && !relatedHostnames(shownHostname, hostname)) {
        score += 700;
      }
    }

    return score;
  }

  function normalizeLinkCandidate(candidate, index) {
    const rawHref = String(candidate && (candidate.rawHref ?? candidate.href) || "").trim();
    const resolvedHref = String(candidate && (candidate.resolvedHref ?? candidate.href) || "").trim();
    return {
      ...(candidate || {}),
      rawHref,
      resolvedHref,
      href: preferredLinkHref(rawHref, resolvedHref),
      text: normalizedLinkText(candidate && candidate.text),
      order: candidateOrder(candidate, index)
    };
  }

  function selectLinkCandidates(candidates, options) {
    const source = Array.isArray(candidates) ? candidates : [];
    const limit = selectionLimit(options, LIMITS.linksPerMessage);
    if (limit === 0 || source.length === 0) {
      return [];
    }

    const seen = new Set();
    const entries = [];
    source.forEach((candidate, index) => {
      const normalized = normalizeLinkCandidate(candidate, index);
      if (!isScannableLinkTarget(normalized.rawHref, normalized.resolvedHref)) {
        return;
      }
      const identityHref = normalized.resolvedHref || normalized.href;
      const identity = `${identityHref}\u0000${normalized.text.toLocaleLowerCase()}`;
      if (seen.has(identity)) {
        return;
      }
      seen.add(identity);
      entries.push({
        candidate: normalized,
        index,
        risk: linkRiskScore(normalized)
      });
    });

    if (entries.length <= limit) {
      return entries.map((entry) => ({
        ...entry.candidate,
        selectionTruncated: false,
        totalLinkCandidates: entries.length
      }));
    }

    const selected = new Set();
    function add(entry) {
      if (entry && selected.size < limit) {
        selected.add(entry.index);
      }
    }

    add(entries[0]);
    add(entries[entries.length - 1]);

    entries
      .filter((entry) => isActiveLinkTarget(entry.candidate.href))
      .sort((first, second) => second.risk - first.risk || first.index - second.index)
      .forEach(add);

    const riskQuota = Math.max(2, Math.ceil(limit * 0.65));
    entries
      .filter((entry) => entry.risk > 0)
      .slice()
      .sort((first, second) => second.risk - first.risk || first.index - second.index)
      .slice(0, riskQuota)
      .forEach(add);

    for (const index of balancedIndexes(entries.length, limit)) {
      add(entries[index]);
    }

    entries
      .slice()
      .sort((first, second) => second.risk - first.risk || first.index - second.index)
      .forEach(add);

    return entries
      .filter((entry) => selected.has(entry.index))
      .sort((first, second) => first.index - second.index)
      .map((entry) => ({
        ...entry.candidate,
        selectionTruncated: true,
        totalLinkCandidates: entries.length
      }));
  }

  const api = Object.freeze({
    LIMITS,
    bodyTextSamplePlan,
    bodyTextSamples,
    boundedTextFingerprint,
    boundedBodyText,
    isActiveLinkTarget,
    isScannableLinkTarget,
    linkRiskScore,
    preferredLinkHref,
    selectLinkCandidates,
    selectMessageCandidates
  });

  global.ByeByeFishingScanPolicy = api;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
