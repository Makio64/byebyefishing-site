# Packaged threat intelligence

Bye Bye Fishing checks exact URL fingerprints against a packaged snapshot of PhishTank's verified, online phishing database before applying trusted-domain or heuristic rules. A known Google Docs URL can therefore warn without treating every document on Google Docs as phishing.

PhishTank is operated by Cisco Talos. Its [developer documentation](https://www.phishtank.org/developer_info.php) provides downloadable databases for local detection, and its [FAQ](https://www.phishtank.org/faq.php) permits commercial and noncommercial API use. The data remains attributed to PhishTank and its contributors. This is third-party threat data, not an endorsement or a guarantee.

The build takes every valid verified/online record, hashes the complete normalized HTTP(S) URL with SHA-256, deduplicates and sorts the fingerprints. No benchmark labels or message text participate in the build. Runtime matching preserves the scheme, path, query and fragment; it never promotes an entry to a domain-wide block. A match is evidence that the exact destination was in that dated snapshot; no match is not a safety verdict.

All lookups run on the device. Email text, destinations and their hashes are never uploaded. The extension does not download executable code, query an API, or visit suspect destinations. The source snapshot hash and timestamp are recorded in `audit/threat-feed-2026-09-22-31499ea543eb.json`; subsequent imports create separate dated audit records. Raw feed URLs are not bundled; only exact fingerprints and attribution metadata are.

## Maintenance

Run `npm run update:threats` before a release, then rebuild and validate the packages. The importer downloads only the public compressed feed, enforces size/schema limits, requires a source timestamp no older than three days, and replaces the output atomically. Respect PhishTank's unauthenticated download limits; recurring automation requires a registered application key and is not configured here.

For a locally retained source snapshot: `node tools/update-threat-feed.js --input /path/to/online-valid.json --source-updated-at 2026-09-22T09:22:09Z`. Rebuilding from the same snapshot and source timestamp produces identical data bytes. A failed update leaves the previous packaged data intact.

The list expires after 30 days. Expired entries stop producing reputation verdicts; heuristic checks continue and the popup asks the user to update the extension. Distribute updated packages regularly. This conservative policy avoids treating a removed or reclaimed destination as permanently malicious, but an expired package loses reputation coverage.

Feed providers can make mistakes. Warnings identify their source and date. False positives can be reported through [PhishTank's reporting guidance](https://www.phishtank.org/faq.php). No automatic reports are sent.
