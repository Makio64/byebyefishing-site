(function runOptions(global) {
  "use strict";

  const extensionApi = global.browser || global.chrome;
  const defaultRules = global.BYEBYEFISHING_DEFAULT_RULES || [];
  const rulesetVersion = global.BYEBYEFISHING_RULESET_VERSION || "0";
  const detector = global.ByeByeFishingDetector;
  const state = {
    rules: defaultRules,
    selectedRuleId: defaultRules[0]?.id || "",
    greenFlagSenderDomains: [],
    trustedSenderSites: []
  };

  function storageGet(defaults) {
    const result = extensionApi.storage.sync.get(defaults);
    if (result && typeof result.then === "function") {
      return result;
    }
    return new Promise((resolve) => extensionApi.storage.sync.get(defaults, resolve));
  }

  function storageSet(values) {
    const result = extensionApi.storage.sync.set(values);
    if (result && typeof result.then === "function") {
      return result;
    }
    return new Promise((resolve) => extensionApi.storage.sync.set(values, resolve));
  }

  function formatRules(rules) {
    return JSON.stringify(rules, null, 2);
  }

  function showStatus(message, isError = false) {
    const status = document.getElementById("status");
    status.textContent = message;
    status.classList.toggle("error", isError);
  }

  function mergeSavedRules(rules) {
    const merged = detector.mergeDefaultRuleUpdates
      ? detector.mergeDefaultRuleUpdates(rules, defaultRules)
      : rules;
    return detector.validateRules(merged).ok ? merged : defaultRules;
  }

  function selectedRule() {
    return state.rules.find((rule) => rule.id === state.selectedRuleId) || state.rules[0] || null;
  }

  function normalizedGreenFlagSenderDomains(domains) {
    const normalizedDomains = new Set();
    if (!Array.isArray(domains)) {
      return [];
    }

    domains.forEach((domain) => {
      const normalized = detector.normalizeDomain(domain);
      if (normalized) {
        normalizedDomains.add(normalized);
      }
    });

    return [...normalizedDomains].sort();
  }

  function normalizedTrustedSenderSites(records) {
    const normalizedRecords = [];
    const seen = new Set();
    if (!Array.isArray(records)) {
      return normalizedRecords;
    }

    records.forEach((record) => {
      if (!record || typeof record !== "object") {
        return;
      }

      const senderEmail = detector.extractEmail(record.senderEmail || "");
      const senderDomain = detector.normalizeDomain(record.senderDomain || senderEmail);
      const urlDomain = detector.normalizeDomain(record.urlDomain);
      if (!senderDomain || !urlDomain) {
        return;
      }

      const key = `${senderEmail}:${senderDomain}:${urlDomain}`;
      if (seen.has(key)) {
        return;
      }
      seen.add(key);
      normalizedRecords.push({ senderEmail, senderDomain, urlDomain });
    });

    return normalizedRecords.sort((first, second) =>
      `${first.senderDomain}:${first.urlDomain}`.localeCompare(`${second.senderDomain}:${second.urlDomain}`)
    );
  }

  function categoryLabel(category) {
    return String(category || "Other")
      .replace(/-/g, " ")
      .replace(/\b\w/g, (letter) => letter.toUpperCase());
  }

  function renderGreenFlags(domains) {
    const list = document.getElementById("greenFlagList");
    const clearButton = document.getElementById("clearGreenFlags");
    list.textContent = "";

    if (domains.length === 0) {
      const item = document.createElement("li");
      item.className = "empty";
      item.textContent = "No remembered senders yet.";
      list.append(item);
      clearButton.disabled = true;
      return;
    }

    domains.forEach((domain) => {
      const item = document.createElement("li");
      const code = document.createElement("code");
      code.textContent = domain;

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "remove-domain";
      remove.textContent = "Remove";
      remove.addEventListener("click", () => removeGreenFlagDomain(domain));

      item.append(code, remove);
      list.append(item);
    });
    clearButton.disabled = false;
  }

  function trustedSenderSiteLabel(record) {
    return `${record.urlDomain} for ${record.senderEmail || record.senderDomain}`;
  }

  function renderTrustedSenderSites(records) {
    const list = document.getElementById("trustedSenderSiteList");
    const clearButton = document.getElementById("clearTrustedSenderSites");
    list.textContent = "";

    if (records.length === 0) {
      const item = document.createElement("li");
      item.className = "empty";
      item.textContent = "No remembered shared pages yet.";
      list.append(item);
      clearButton.disabled = true;
      return;
    }

    records.forEach((record) => {
      const item = document.createElement("li");
      const code = document.createElement("code");
      code.textContent = trustedSenderSiteLabel(record);

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "remove-domain";
      remove.textContent = "Remove";
      remove.addEventListener("click", () => removeTrustedSenderSite(record));

      item.append(code, remove);
      list.append(item);
    });
    clearButton.disabled = false;
  }

  function filteredRules() {
    const query = document.getElementById("brandSearch").value.trim().toLowerCase();
    if (!query) {
      return state.rules;
    }

    return state.rules.filter((rule) => {
      const searchable = [
        rule.name,
        rule.category,
        ...(rule.aliases || []),
        ...(rule.allowedDomains || []),
        ...(rule.senderDomains || [])
      ].join(" ").toLowerCase();
      return searchable.includes(query);
    });
  }

  function renderBrandList() {
    const list = document.getElementById("brandList");
    const rules = filteredRules();
    list.textContent = "";

    if (!rules.some((rule) => rule.id === state.selectedRuleId) && rules[0]) {
      state.selectedRuleId = rules[0].id;
    }

    if (rules.length === 0) {
      const empty = document.createElement("p");
      empty.className = "muted";
      empty.textContent = "No matching brands.";
      list.append(empty);
      return;
    }

    rules.slice(0, 120).forEach((rule) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `brand-item${rule.id === state.selectedRuleId ? " is-selected" : ""}`;
      button.setAttribute("role", "option");
      button.setAttribute("aria-selected", rule.id === state.selectedRuleId ? "true" : "false");
      button.textContent = rule.name;

      const meta = document.createElement("span");
      meta.textContent = `${categoryLabel(rule.category)} · ${(rule.allowedDomains || []).length} domains`;
      button.append(meta);

      button.addEventListener("click", () => {
        state.selectedRuleId = rule.id;
        renderBrandList();
        renderBrandEditor();
      });

      list.append(button);
    });
  }

  async function saveRules(rules, message) {
    const validation = detector.validateRules(rules);
    if (!validation.ok) {
      showStatus(validation.error, true);
      return false;
    }

    state.rules = rules;
    await storageSet({
      byebyefishingRules: rules,
      byebyefishingRulesCustom: true,
      byebyefishingRulesVersion: rulesetVersion
    });
    document.getElementById("rulesJson").value = formatRules(rules);
    showStatus(message || "Saved. Open webmail tabs will update automatically.");
    return true;
  }

  async function addDomain(ruleId, inputId, listName) {
    const input = document.getElementById(inputId);
    const domain = detector.normalizeDomain(input.value);
    if (!domain) {
      showStatus("Enter a readable domain, such as example.com.", true);
      return;
    }

    const nextRules = detector.addTrustedDomainToRule(state.rules, ruleId, domain, listName);
    if (await saveRules(nextRules, `${domain} added.`)) {
      input.value = "";
      renderBrandList();
      renderBrandEditor();
    }
  }

  async function removeDomain(ruleId, domain, listName) {
    const nextRules = detector.removeTrustedDomainFromRule(state.rules, ruleId, domain, listName);
    if (nextRules === state.rules) {
      showStatus("Each brand needs at least one trusted domain.", true);
      return;
    }

    if (await saveRules(nextRules, `${domain} removed.`)) {
      renderBrandList();
      renderBrandEditor();
    }
  }

  function renderDomainPanel(rule, config) {
    const panel = document.createElement("section");
    panel.className = "domain-panel";

    const heading = document.createElement("h3");
    heading.textContent = config.title;

    const help = document.createElement("p");
    help.className = "muted";
    help.textContent = config.help;

    const list = document.createElement("ul");
    list.className = "domain-list with-actions";

    const domains = rule[config.listName] || [];
    domains.forEach((domain) => {
      const item = document.createElement("li");
      const code = document.createElement("code");
      code.textContent = domain;

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "remove-domain";
      remove.textContent = "Remove";
      remove.disabled = domains.length <= 1;
      remove.addEventListener("click", () => removeDomain(rule.id, domain, config.listName));

      item.append(code, remove);
      list.append(item);
    });

    const add = document.createElement("div");
    add.className = "add-domain";

    const input = document.createElement("input");
    input.id = config.inputId;
    input.type = "text";
    input.placeholder = "example.com";
    input.autocomplete = "off";
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        addDomain(rule.id, config.inputId, config.listName);
      }
    });

    const button = document.createElement("button");
    button.type = "button";
    button.textContent = config.buttonText;
    button.addEventListener("click", () => addDomain(rule.id, config.inputId, config.listName));

    add.append(input, button);
    panel.append(heading, help, list, add);
    return panel;
  }

  function renderBrandEditor() {
    const editor = document.getElementById("brandEditor");
    const rule = selectedRule();
    editor.textContent = "";

    if (!rule) {
      const empty = document.createElement("p");
      empty.className = "muted";
      empty.textContent = "Choose a brand to manage its known addresses.";
      editor.append(empty);
      return;
    }

    const summary = document.createElement("div");
    summary.className = "brand-summary";

    const title = document.createElement("h2");
    title.textContent = rule.name;

    const meta = document.createElement("p");
    meta.className = "muted";
    meta.textContent = `${categoryLabel(rule.category)} · Aliases: ${(rule.aliases || []).slice(0, 5).join(", ")}`;

    summary.append(title, meta);

    const allowedPanel = renderDomainPanel(rule, {
      title: Array.isArray(rule.senderDomains) ? "Known websites and links" : "Known web and email addresses",
      help: Array.isArray(rule.senderDomains)
        ? "Links to these addresses are treated as familiar. Email senders are managed separately below."
        : "Email senders and links at these addresses are treated as familiar for this brand.",
      inputId: "allowedDomainInput",
      listName: "allowedDomains",
      buttonText: "Add domain"
    });

    editor.append(summary, allowedPanel);

    if (Array.isArray(rule.senderDomains)) {
      editor.append(
        renderDomainPanel(rule, {
          title: "Known email senders",
          help: "Mail claiming this brand looks familiar only when it comes from one of these addresses.",
          inputId: "senderDomainInput",
          listName: "senderDomains",
          buttonText: "Add sender"
        })
      );
    }
  }

  async function loadRules() {
    const saved = await storageGet({
      byebyefishingRules: defaultRules,
      byebyefishingRulesCustom: false,
      byebyefishingRulesVersion: ""
    });
    const validation = detector.validateRules(saved.byebyefishingRules);
    const shouldUseSavedRules =
      validation.ok && (saved.byebyefishingRulesCustom || saved.byebyefishingRulesVersion === rulesetVersion);
    state.rules = shouldUseSavedRules ? mergeSavedRules(saved.byebyefishingRules) : defaultRules;
    state.selectedRuleId = state.rules[0]?.id || "";
    document.getElementById("rulesJson").value = formatRules(state.rules);
    renderBrandList();
    renderBrandEditor();

    if (!validation.ok) {
      showStatus("Saved rules were invalid, defaults loaded.", true);
    } else if (saved.byebyefishingRulesCustom) {
      showStatus("Loaded your custom family safety list.");
    } else if (saved.byebyefishingRulesVersion !== rulesetVersion) {
      showStatus("Loaded the updated friendly defaults.");
    } else {
      showStatus("Loaded the default family safety list.");
    }
  }

  async function saveRulesJson() {
    const textarea = document.getElementById("rulesJson");
    let parsed;

    try {
      parsed = JSON.parse(textarea.value);
    } catch (error) {
      showStatus(`Invalid JSON: ${error.message}`, true);
      return;
    }

    if (await saveRules(parsed, "Saved JSON rules.")) {
      renderBrandList();
      renderBrandEditor();
    }
  }

  async function resetRules() {
    state.rules = defaultRules;
    state.selectedRuleId = defaultRules[0]?.id || "";
    await storageSet({
      byebyefishingRules: defaultRules,
      byebyefishingRulesCustom: false,
      byebyefishingRulesVersion: rulesetVersion
    });
    document.getElementById("brandSearch").value = "";
    document.getElementById("rulesJson").value = formatRules(defaultRules);
    renderBrandList();
    renderBrandEditor();
    showStatus("Defaults restored.");
  }

  async function loadGreenFlags() {
    const saved = await storageGet({
      byebyefishingGreenFlagSenderDomains: []
    });
    state.greenFlagSenderDomains = normalizedGreenFlagSenderDomains(saved.byebyefishingGreenFlagSenderDomains);
    renderGreenFlags(state.greenFlagSenderDomains);
  }

  async function clearGreenFlags() {
    await storageSet({
      byebyefishingGreenFlagSenderDomains: []
    });
    state.greenFlagSenderDomains = [];
    renderGreenFlags([]);
    showStatus("Remembered senders cleared.");
  }

  async function removeGreenFlagDomain(domain) {
    const normalized = detector.normalizeDomain(domain);
    const nextDomains = state.greenFlagSenderDomains.filter((value) => detector.normalizeDomain(value) !== normalized);
    await storageSet({
      byebyefishingGreenFlagSenderDomains: nextDomains
    });
    state.greenFlagSenderDomains = nextDomains;
    renderGreenFlags(nextDomains);
    showStatus(`${normalized} removed from remembered senders.`);
  }

  async function loadTrustedSenderSites() {
    const saved = await storageGet({
      byebyefishingTrustedSenderSites: []
    });
    state.trustedSenderSites = normalizedTrustedSenderSites(saved.byebyefishingTrustedSenderSites);
    renderTrustedSenderSites(state.trustedSenderSites);
  }

  async function saveTrustedSenderSites(records, message) {
    state.trustedSenderSites = normalizedTrustedSenderSites(records);
    await storageSet({
      byebyefishingTrustedSenderSites: state.trustedSenderSites
    });
    renderTrustedSenderSites(state.trustedSenderSites);
    showStatus(message);
  }

  async function removeTrustedSenderSite(recordToRemove) {
    const keyToRemove = trustedSenderSiteLabel(recordToRemove);
    const nextRecords = state.trustedSenderSites.filter(
      (record) => trustedSenderSiteLabel(record) !== keyToRemove
    );
    await saveTrustedSenderSites(nextRecords, `${keyToRemove} removed.`);
  }

  async function clearTrustedSenderSites() {
    await saveTrustedSenderSites([], "Remembered shared pages cleared.");
  }

  document.getElementById("brandSearch").addEventListener("input", () => {
    renderBrandList();
    renderBrandEditor();
  });
  document.getElementById("saveRulesJson").addEventListener("click", saveRulesJson);
  document.getElementById("resetRules").addEventListener("click", resetRules);
  document.getElementById("clearGreenFlags").addEventListener("click", clearGreenFlags);
  document.getElementById("clearTrustedSenderSites").addEventListener("click", clearTrustedSenderSites);
  loadRules();
  loadGreenFlags();
  loadTrustedSenderSites();
})(typeof globalThis !== "undefined" ? globalThis : this);
