(function runPopup(global) {
  "use strict";

  const extensionApi = global.browser || global.chrome;
  const defaultRules = global.BYEBYEFISHING_DEFAULT_RULES || [];
  const rulesetVersion = global.BYEBYEFISHING_RULESET_VERSION || "0";
  const detector = global.ByeByeFishingDetector;
  const ruleStorageDefaults = {
    byebyefishingRules: null,
    byebyefishingRulesCustom: false,
    byebyefishingRulesVersion: ""
  };

  function storageAreaGet(area, defaults) {
    if (global.browser) {
      return area.get(defaults);
    }

    return new Promise((resolve, reject) => {
      area.get(defaults, (values) => {
        const error = extensionApi.runtime?.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve(values);
      });
    });
  }

  function storageAreaSet(area, values) {
    if (global.browser) {
      return area.set(values);
    }

    return new Promise((resolve, reject) => {
      area.set(values, () => {
        const error = extensionApi.runtime?.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve();
      });
    });
  }

  function storageGet(defaults) {
    return storageAreaGet(extensionApi.storage.sync, defaults);
  }

  function storageSet(values) {
    return storageAreaSet(extensionApi.storage.sync, values);
  }

  function localStorageGet(defaults) {
    return storageAreaGet(extensionApi.storage.local, defaults);
  }

  function localStorageSet(values) {
    return storageAreaSet(extensionApi.storage.local, values);
  }

  function mergeSavedRules(rules) {
    const merged = detector.mergeDefaultRuleUpdates
      ? detector.mergeDefaultRuleUpdates(rules, defaultRules)
      : rules;
    return detector.validateRules(merged).ok ? merged : defaultRules;
  }

  function showStatus(message, isError = false) {
    const status = document.getElementById("popupStatus");
    status.textContent = message;
    status.classList.toggle("error", isError);
  }

  async function loadRules() {
    let saved = null;
    let source = "local";

    try {
      const localRecord = await localStorageGet(ruleStorageDefaults);
      if (Array.isArray(localRecord.byebyefishingRules)) {
        saved = localRecord;
      }
    } catch (error) {
      // Legacy sync storage remains a read-only compatibility fallback.
      source = "sync";
    }

    if (!saved) {
      source = "sync";
      saved = await storageGet(ruleStorageDefaults);
    }

    const storedRules = Array.isArray(saved.byebyefishingRules) ? saved.byebyefishingRules : defaultRules;
    const validation = detector.validateRules(storedRules);
    const shouldUseSavedRules =
      validation.ok && (saved.byebyefishingRulesCustom || saved.byebyefishingRulesVersion === rulesetVersion);
    const rules = shouldUseSavedRules
      ? saved.byebyefishingRulesCustom
        ? storedRules
        : mergeSavedRules(storedRules)
      : defaultRules;

    const shouldRefreshLocalRecord =
      source === "sync" || !validation.ok || saved.byebyefishingRulesVersion !== rulesetVersion;
    if (shouldRefreshLocalRecord) {
      try {
        await localStorageSet({
          byebyefishingRules: rules,
          byebyefishingRulesCustom: shouldUseSavedRules && saved.byebyefishingRulesCustom === true,
          byebyefishingRulesVersion: rulesetVersion
        });
      } catch (error) {
        showStatus("The safety list loaded, but device storage could not be updated.", true);
      }
    }

    return rules;
  }

  function bindSetting(checkbox, key) {
    checkbox.addEventListener("change", async () => {
      const requestedValue = checkbox.checked;
      checkbox.disabled = true;
      try {
        await storageSet({ [key]: requestedValue });
        showStatus("Preference saved.");
      } catch (error) {
        checkbox.checked = !requestedValue;
        showStatus("Could not save that preference. Your previous choice is still in use.", true);
      } finally {
        checkbox.disabled = false;
      }
    });
  }

  async function init() {
    const checkbox = document.getElementById("trustedBadges");
    const informationalCheckbox = document.getElementById("informationalNotices");
    const ruleCount = document.getElementById("ruleCount");
    const ruleVersion = document.getElementById("ruleVersion");
    const openOptions = document.getElementById("openOptions");
    let saved = {
      byebyefishingShowTrustedBadges: true,
      byebyefishingShowInformationalNotices: false
    };
    let rules = defaultRules;

    try {
      saved = await storageGet(saved);
    } catch (error) {
      showStatus("Could not load synced preferences. Device defaults are shown.", true);
    }

    try {
      rules = await loadRules();
    } catch (error) {
      showStatus("Could not load the saved safety list. Friendly defaults are shown.", true);
    }

    checkbox.checked = saved.byebyefishingShowTrustedBadges !== false;
    informationalCheckbox.checked = saved.byebyefishingShowInformationalNotices === true;
    ruleCount.textContent = `${rules.length.toLocaleString()} recognized brands`;
    ruleVersion.textContent = `Safety list ${rulesetVersion} · stored on this device`;

    bindSetting(checkbox, "byebyefishingShowTrustedBadges");
    bindSetting(informationalCheckbox, "byebyefishingShowInformationalNotices");
    checkbox.disabled = false;
    informationalCheckbox.disabled = false;

    openOptions.addEventListener("click", () => {
      if (extensionApi.runtime.openOptionsPage) {
        extensionApi.runtime.openOptionsPage();
      }
    });
  }

  init().catch(() => {
    showStatus("Could not finish loading the popup. Close and reopen it to try again.", true);
  });
})(typeof globalThis !== "undefined" ? globalThis : this);
