(function runPopup(global) {
  "use strict";

  const extensionApi = global.browser || global.chrome;
  const defaultRules = global.BYEBYEFISHING_DEFAULT_RULES || [];
  const rulesetVersion = global.BYEBYEFISHING_RULESET_VERSION || "0";
  const detector = global.ByeByeFishingDetector;
  const CONSENT_VERSION = 1;
  const ruleStorageDefaults = {
    byebyefishingRules: null,
    byebyefishingRulesCustom: false,
    byebyefishingRulesVersion: ""
  };

  function storageAreaGet(area, defaults) {
    if (global.browser) {
      return area.get(defaults);
    }

    return new Promise((resolve, reject) => {
      area.get(defaults, (values) => {
        const error = extensionApi.runtime?.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve(values);
      });
    });
  }

  function storageAreaSet(area, values) {
    if (global.browser) {
      return area.set(values);
    }

    return new Promise((resolve, reject) => {
      area.set(values, () => {
        const error = extensionApi.runtime?.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve();
      });
    });
  }

  function localStorageGet(defaults) {
    return storageAreaGet(extensionApi.storage.local, defaults);
  }

  function localStorageSet(values) {
    return storageAreaSet(extensionApi.storage.local, values);
  }

  function mergeSavedRules(rules) {
    const merged = detector.mergeDefaultRuleUpdates
      ? detector.mergeDefaultRuleUpdates(rules, defaultRules)
      : rules;
    return detector.validateRules(merged).ok ? merged : defaultRules;
  }

  function showStatus(message, isError = false) {
    const status = document.getElementById("popupStatus");
    status.textContent = message;
    status.classList.toggle("error", isError);
  }

  async function loadRules() {
    const saved = await localStorageGet(ruleStorageDefaults);

    const storedRules = Array.isArray(saved.byebyefishingRules) ? saved.byebyefishingRules : defaultRules;
    const validation = detector.validateRules(storedRules);
    const shouldUseSavedRules =
      validation.ok && (saved.byebyefishingRulesCustom || saved.byebyefishingRulesVersion === rulesetVersion);
    const rules = shouldUseSavedRules
      ? saved.byebyefishingRulesCustom
        ? storedRules
        : mergeSavedRules(storedRules)
      : defaultRules;

    const shouldRefreshLocalRecord = !validation.ok || saved.byebyefishingRulesVersion !== rulesetVersion;
    if (shouldRefreshLocalRecord) {
      try {
        await localStorageSet({
          byebyefishingRules: rules,
          byebyefishingRulesCustom: shouldUseSavedRules && saved.byebyefishingRulesCustom === true,
          byebyefishingRulesVersion: rulesetVersion
        });
      } catch (error) {
        showStatus("The safety list loaded, but device storage could not be updated.", true);
      }
    }

    return rules;
  }

  function bindSetting(checkbox, key) {
    checkbox.addEventListener("change", async () => {
      const requestedValue = checkbox.checked;
      checkbox.disabled = true;
      try {
        await localStorageSet({ [key]: requestedValue });
        showStatus("Preference saved.");
      } catch (error) {
        checkbox.checked = !requestedValue;
        showStatus("Could not save that preference. Your previous choice is still in use.", true);
      } finally {
        checkbox.disabled = false;
      }
    });
  }

  async function init() {
    const checkbox = document.getElementById("trustedBadges");
    const informationalCheckbox = document.getElementById("informationalNotices");
    const ruleCount = document.getElementById("ruleCount");
    const ruleVersion = document.getElementById("ruleVersion");
    const openOptions = document.getElementById("openOptions");
    const openPrivacySetup = document.getElementById("openPrivacySetup");
    const protectionTitle = document.getElementById("protection-title");
    const protectionCopy = document.getElementById("protection-copy");
    let saved = {
      byebyefishingShowTrustedBadges: true,
      byebyefishingShowInformationalNotices: false,
      byebyefishingPrivacyConsentVersion: 0
    };
    let rules = defaultRules;

    try {
      saved = await localStorageGet(saved);
    } catch (error) {
      showStatus("Could not load preferences. Device defaults are shown.", true);
    }

    try {
      rules = await loadRules();
    } catch (error) {
      showStatus("Could not load the saved safety list. Friendly defaults are shown.", true);
    }

    checkbox.checked = saved.byebyefishingShowTrustedBadges !== false;
    informationalCheckbox.checked = saved.byebyefishingShowInformationalNotices === true;
    const protectionEnabled = saved.byebyefishingPrivacyConsentVersion >= CONSENT_VERSION;
    protectionTitle.textContent = protectionEnabled ? "Protection is ready" : "Protection is paused";
    protectionCopy.textContent = protectionEnabled
      ? "Supported webmail is checked automatically."
      : "Finish the privacy setup before webmail is checked.";
    openPrivacySetup.hidden = protectionEnabled;
    ruleCount.textContent = `${rules.length.toLocaleString()} recognized brands`;
    ruleVersion.textContent = `Safety list ${rulesetVersion} · stored on this device`;
    const threatStatus = document.getElementById("threatStatus");
    const threatFeed = global.ByeByeFishingReputation?.status();
    if (threatStatus) {
      threatStatus.textContent = threatFeed?.state === "current"
        ? `Known phishing links · updated ${threatFeed.generatedAt.slice(0,10)}`
        : "Known-link list is out of date or unavailable. Update the extension; message checks still run.";
      threatStatus.classList.toggle("error", threatFeed?.state !== "current");
    }

    bindSetting(checkbox, "byebyefishingShowTrustedBadges");
    bindSetting(informationalCheckbox, "byebyefishingShowInformationalNotices");
    checkbox.disabled = false;
    informationalCheckbox.disabled = false;

    openOptions.addEventListener("click", () => {
      if (extensionApi.runtime.openOptionsPage) {
        extensionApi.runtime.openOptionsPage();
      }
    });

    openPrivacySetup.addEventListener("click", () => {
      const onboardingUrl = extensionApi.runtime.getURL("onboarding.html");
      if (extensionApi.tabs?.create) {
        extensionApi.tabs.create({ url: onboardingUrl });
      } else {
        global.open(onboardingUrl);
      }
    });
  }

  init().catch(() => {
    showStatus("Could not finish loading the popup. Close and reopen it to try again.", true);
  });
})(typeof globalThis !== "undefined" ? globalThis : this);
