(function exposeDetector(global) {
  "use strict";

  const EMAIL_RE = /[A-Z0-9._%+-]+@([A-Z0-9.-]+\.[A-Z]{2,63})/i;
  const EMAIL_GLOBAL_RE = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,63}/gi;
  const ANGLE_EMAIL_RE = /<\s*([^<>@\s]+@[^<>@\s]+)\s*>/i;
  const TOKEN_SPLIT_RE = /[^\p{L}\p{N}]+/gu;
  const HIGH_RISK_TLDS = new Set([
    "beauty",
    "bond",
    "cam",
    "click",
    "club",
    "country",
    "cyou",
    "gq",
    "icu",
    "info",
    "kim",
    "loan",
    "lol",
    "mom",
    "mov",
    "party",
    "quest",
    "rest",
    "review",
    "run",
    "sbs",
    "services",
    "shop",
    "site",
    "skin",
    "space",
    "support",
    "tk",
    "top",
    "trade",
    "vip",
    "wang",
    "win",
    "work",
    "world",
    "xyz",
    "zip",
    "zone"
  ]);
  const STANDARD_TLDS = new Set([
    "com",
    "org",
    "net",
    "edu",
    "gov",
    "mil",
    "int",
    "fr",
    "eu",
    "be",
    "ch",
    "ca",
    "us",
    "uk",
    "de",
    "es",
    "it",
    "nl",
    "se",
    "no",
    "dk",
    "fi",
    "ie",
    "pt",
    "at",
    "lu",
    "pl",
    "cz",
    "sk",
    "si",
    "hr",
    "hu",
    "ro",
    "bg",
    "gr",
    "ee",
    "lv",
    "lt",
    "is",
    "au",
    "nz",
    "jp",
    "kr",
    "sg",
    "hk",
    "tw",
    "in",
    "br",
    "mx",
    "ar",
    "cl",
    "za",
    "ma",
    "tn",
    "il",
    "ae"
  ]);
  const FREE_MAIL_DOMAINS = new Set([
    "gmail.com",
    "googlemail.com",
    "outlook.com",
    "hotmail.com",
    "hotmail.fr",
    "live.com",
    "live.fr",
    "msn.com",
    "outlook.fr",
    "yahoo.com",
    "yahoo.fr",
    "yahoo.co.uk",
    "yahoo.de",
    "yahoo.es",
    "yahoo.it",
    "ymail.com",
    "rocketmail.com",
    "aol.com",
    "icloud.com",
    "me.com",
    "proton.me",
    "protonmail.com",
    "pm.me",
    "gmx.com",
    "gmx.fr",
    "gmx.net",
    "gmx.de",
    "gmx.at",
    "gmx.ch",
    "web.de",
    "t-online.de",
    "freenet.de",
    "mail.com",
    "europe.com",
    "mailo.com",
    "mailo.fr",
    "mailo.eu",
    "netcourrier.com",
    "tuta.com",
    "tutanota.com",
    "tutanota.de",
    "tutamail.com",
    "fastmail.com",
    "fastmail.fm",
    "mailbox.org",
    "posteo.de",
    "yandex.com",
    "yandex.ru",
    "zoho.com",
    "zoho.eu",
    "zohomail.com",
    "zohomail.eu",
    "seznam.cz",
    "wp.pl",
    "o2.pl",
    "onet.pl",
    "interia.pl",
    "libero.it",
    "virgilio.it",
    "laposte.net",
    "orange.fr",
    "wanadoo.fr",
    "bbox.fr",
    "free.fr",
    "neuf.fr",
    "sfr.fr"
  ]);
  const URL_SHORTENER_DOMAINS = new Set([
    "bit.ly",
    "tinyurl.com",
    "t.co",
    "goo.gl",
    "ow.ly",
    "buff.ly",
    "rebrand.ly",
    "cutt.ly",
    "shorturl.at",
    "tiny.cc",
    "is.gd",
    "s.id",
    "lnkd.in",
    "amzn.to",
    "fb.me",
    "bitly.com",
    "rb.gy"
  ]);
  const PUBLIC_HOSTING_DOMAINS = [
    {
      name: "Google Cloud Storage",
      domains: ["storage.googleapis.com", "storage.cloud.google.com", "googleusercontent.com"]
    },
    {
      name: "Amazon S3",
      domains: ["s3.amazonaws.com", "amazonaws.com"]
    },
    {
      name: "Microsoft Azure Blob Storage",
      domains: ["blob.core.windows.net", "web.core.windows.net"]
    },
    {
      name: "Cloudflare Pages",
      domains: ["pages.dev"]
    },
    {
      name: "GitHub Pages",
      domains: ["github.io"]
    },
    {
      name: "Netlify",
      domains: ["netlify.app"]
    },
    {
      name: "Vercel",
      domains: ["vercel.app"]
    }
  ];
  const SUSPICIOUS_TERMS = [
    "account",
    "alerte",
    "auth",
    "billing",
    "blocked",
    "carte",
    "claim",
    "colis",
    "confirm",
    "delivery",
    "facture",
    "finance",
    "gift",
    "grant",
    "impots",
    "invoice",
    "livraison",
    "login",
    "password",
    "pay",
    "payment",
    "refund",
    "remboursement",
    "reset",
    "secure",
    "security",
    "signin",
    "support",
    "tax",
    "tracking",
    "unlock",
    "update",
    "validation",
    "verify",
    "wallet"
  ];
  const DELIVERY_TERMS = [
    "access point",
    "centre logistique",
    "colis",
    "confirmation de livraison",
    "confirmation requise",
    "confirmer ma livraison",
    "confirmer vos informations",
    "creneau de livraison",
    "customs",
    "delivery confirmation",
    "delivery slot",
    "douane",
    "en attente",
    "expediteur",
    "informations de livraison",
    "livraison",
    "logistique",
    "package awaiting",
    "parcel",
    "retard",
    "shipment",
    "suivi",
    "tracking"
  ];
  const DISPLAYED_DOMAIN_RE = /(?:https?:\/\/)?(?:www\.)?([a-z0-9][a-z0-9.-]*\.[a-z]{2,63})/i;
  const REDIRECT_PARAMS = ["url", "u", "q", "target", "to", "redirect", "redirect_url"];
  const KNOWN_REDIRECT_HOSTS = new Set([
    "www.google.com",
    "google.com",
    "l.facebook.com",
    "lm.facebook.com",
    "m.facebook.com",
    "safelinks.protection.outlook.com",
    "nam12.safelinks.protection.outlook.com",
    "eur01.safelinks.protection.outlook.com"
  ]);
  const GENERIC_IDENTITY_TERMS = [
    "admin",
    "assistance",
    "billing",
    "customer service",
    "helpdesk",
    "invoice",
    "payment",
    "security",
    "service client",
    "support",
    "team",
    "verification",
    "finance",
    "grant"
  ];
  const CONTENT_SIGNAL_GROUPS = [
    {
      id: "credentials",
      weight: 4,
      label: "credential or security-code request",
      phrases: [
        "confirm your password",
        "confirmer votre mot de passe",
        "bestatigen sie ihr passwort",
        "conferma la password",
        "confirme su contrasena",
        "confirme sua senha",
        "verify your account",
        "verifier votre compte",
        "verifizieren sie ihr konto",
        "verifica il tuo account",
        "verifique su cuenta",
        "verifique sua conta",
        "validate your account",
        "valider votre compte",
        "update your payment information",
        "mettre a jour vos informations",
        "confirm your identity",
        "confirmer votre identite",
        "enter your security code",
        "saisissez votre code",
        "code de securite",
        "sicherheitscode",
        "codice di sicurezza",
        "codigo de seguridad",
        "codigo de seguranca",
        "подтвердите пароль",
        "подтвердите учетную запись",
        "код безопасности",
        "パスワードを確認",
        "アカウントを確認",
        "セキュリティコード",
        "確認コード",
        "确认您的密码",
        "验证您的账户",
        "安全码",
        "输入验证码",
        "अपना पासवर्ड पुष्टि करें",
        "अपना खाता सत्यापित करें",
        "सुरक्षा कोड",
        "أكد كلمة المرور",
        "تحقق من حسابك",
        "رمز الأمان",
        "আপনার পাসওয়ার্ড নিশ্চিত করুন",
        "আপনার অ্যাকাউন্ট যাচাই করুন",
        "নিরাপত্তা কোড",
        "اپنا پاس ورڈ تصدیق کریں",
        "اپنا اکاؤنٹ تصدیق کریں",
        "سیکیورٹی کوڈ",
        "one time code",
        "verification code",
        "2fa code",
        "seed phrase",
        "recovery phrase",
        "private key",
        "api key",
        "access token"
      ]
    },
    {
      id: "personal-info",
      weight: 3,
      label: "personal information request",
      phrases: [
        "send your information",
        "send your details",
        "full name",
        "first and last name",
        "phone number",
        "telephone number",
        "home address",
        "occupation",
        "reference number",
        "date of birth",
        "envoyez vos informations",
        "nom et prenom",
        "numero de telephone",
        "adresse personnelle",
        "envoyer vos informations",
        "senden sie ihre informationen",
        "ihre informationen",
        "vor und nachname",
        "telefonnummer",
        "adresse",
        "beruf",
        "referenznummer",
        "invia le tue informazioni",
        "nome e cognome",
        "numero di telefono",
        "professione",
        "numero di riferimento",
        "envie su informacion",
        "nombre y apellido",
        "numero de telefono",
        "ocupacion",
        "numero de referencia",
        "envie suas informacoes",
        "nome completo",
        "numero de telefone",
        "profissao",
        "numero de referencia",
        "отправьте ваши данные",
        "имя и фамилия",
        "номер телефона",
        "адрес",
        "профессия",
        "регистрационный номер",
        "情報を送信",
        "氏名",
        "電話番号",
        "住所",
        "職業",
        "参照番号",
        "发送您的信息",
        "姓名",
        "电话号码",
        "地址",
        "职业",
        "参考编号",
        "अपनी जानकारी भेजें",
        "पूरा नाम",
        "फोन नंबर",
        "पता",
        "पेशा",
        "संदर्भ संख्या",
        "أرسل معلوماتك",
        "الاسم الكامل",
        "رقم الهاتف",
        "العنوان",
        "المهنة",
        "رقم المرجع",
        "আপনার তথ্য পাঠান",
        "পূর্ণ নাম",
        "ফোন নম্বর",
        "ঠিকানা",
        "পেশা",
        "রেফারেন্স নম্বর",
        "اپنی معلومات بھیجیں",
        "پورا نام",
        "فون نمبر",
        "پتہ",
        "پیشہ",
        "حوالہ نمبر"
      ]
    },
    {
      id: "urgency",
      weight: 3,
      label: "urgent action pressure",
      phrases: [
        "urgent",
        "immediate action required",
        "action required",
        "act now",
        "within 24 hours",
        "within 48 hours",
        "last chance",
        "final notice",
        "dernier rappel",
        "derniere relance",
        "action requise",
        "sous 24h",
        "sous 48h",
        "immediatement",
        "aujourd hui",
        "sans delai",
        "dringend",
        "aktion erforderlich",
        "innerhalb von 24 stunden",
        "letzte mahnung",
        "urgente",
        "azione richiesta",
        "entro 24 ore",
        "ultimo avviso",
        "accion requerida",
        "en 24 horas",
        "ultimo aviso",
        "acao necessaria",
        "em 24 horas",
        "срочно",
        "требуется действие",
        "в течение 24 часов",
        "последнее уведомление",
        "緊急",
        "至急",
        "24時間以内",
        "最終通知",
        "紧急",
        "立即行动",
        "24小时内",
        "最后通知",
        "तुरंत",
        "कार्रवाई आवश्यक",
        "24 घंटे के भीतर",
        "अंतिम सूचना",
        "عاجل",
        "إجراء مطلوب",
        "خلال 24 ساعة",
        "الإشعار الأخير",
        "জরুরি",
        "পদক্ষেপ প্রয়োজন",
        "২৪ ঘন্টার মধ্যে",
        "শেষ বিজ্ঞপ্তি",
        "فوری",
        "کارروائی ضروری",
        "24 گھنٹوں کے اندر",
        "آخری نوٹس"
      ]
    },
    {
      id: "payment",
      weight: 3,
      label: "payment or money demand",
      phrases: [
        "pay now",
        "payment required",
        "payment failed",
        "unpaid invoice",
        "outstanding invoice",
        "wire transfer",
        "bank transfer",
        "gift card",
        "apple gift card",
        "amazon gift card",
        "steam card",
        "western union",
        "moneygram",
        "change of bank details",
        "new bank details",
        "payer maintenant",
        "paiement requis",
        "paiement refuse",
        "facture impayee",
        "regulariser",
        "virement bancaire",
        "nouvelles coordonnees bancaires",
        "rib",
        "iban",
        "carte bancaire",
        "frais de livraison",
        "taxes douanieres",
        "amende",
        "peage",
        "stationnement",
        "douane",
        "crypto",
        "bitcoin",
        "usdt",
        "remboursement",
        "jetzt bezahlen",
        "zahlung erforderlich",
        "zahlung abgelehnt",
        "bankuberweisung",
        "geschenkkarte",
        "paga ora",
        "pagamento richiesto",
        "pagamento rifiutato",
        "bonifico bancario",
        "carta regalo",
        "pagar ahora",
        "pago requerido",
        "pago rechazado",
        "transferencia bancaria",
        "tarjeta regalo",
        "pague agora",
        "pagamento necessario",
        "pagamento recusado",
        "transferencia bancaria",
        "cartao presente",
        "оплатите сейчас",
        "требуется оплата",
        "платеж отклонен",
        "банковский перевод",
        "подарочная карта",
        "今すぐ支払",
        "支払いが必要",
        "支払いに失敗",
        "銀行振込",
        "ギフトカード",
        "立即付款",
        "需要付款",
        "付款失败",
        "银行转账",
        "礼品卡",
        "अभी भुगतान करें",
        "भुगतान आवश्यक",
        "भुगतान विफल",
        "बैंक हस्तांतरण",
        "गिफ्ट कार्ड",
        "ادفع الآن",
        "الدفع مطلوب",
        "فشل الدفع",
        "تحويل مصرفي",
        "بطاقة هدايا",
        "এখনই পেমেন্ট করুন",
        "পেমেন্ট প্রয়োজন",
        "পেমেন্ট ব্যর্থ",
        "ব্যাংক ট্রান্সফার",
        "গিফট কার্ড",
        "ابھی ادائیگی کریں",
        "ادائیگی ضروری",
        "ادائیگی ناکام",
        "بینک ٹرانسفر",
        "گفٹ کارڈ"
      ]
    },
    {
      id: "threat",
      weight: 3,
      label: "account threat",
      phrases: [
        "account suspended",
        "account locked",
        "account blocked",
        "your access will be disabled",
        "service interruption",
        "legal action",
        "late penalty",
        "compte suspendu",
        "compte bloque",
        "acces bloque",
        "carte bloquee",
        "service suspendu",
        "penalite",
        "poursuites",
        "mise en demeure",
        "konto gesperrt",
        "zugang wird deaktiviert",
        "account sospeso",
        "account bloccato",
        "accesso disabilitato",
        "cuenta suspendida",
        "cuenta bloqueada",
        "acceso deshabilitado",
        "conta suspensa",
        "conta bloqueada",
        "acesso desativado",
        "учетная запись заблокирована",
        "аккаунт заблокирован",
        "доступ будет отключен",
        "アカウントが停止",
        "アカウントがロック",
        "アクセスが無効",
        "账户已暂停",
        "账户被锁定",
        "访问将被禁用",
        "खाता निलंबित",
        "खाता बंद",
        "आपकी पहुंच बंद",
        "تم تعليق الحساب",
        "تم قفل الحساب",
        "سيتم تعطيل الوصول",
        "অ্যাকাউন্ট স্থগিত",
        "অ্যাকাউন্ট লক",
        "অ্যাক্সেস বন্ধ",
        "اکاؤنٹ معطل",
        "اکاؤنٹ بند",
        "رسائی بند"
      ]
    },
    {
      id: "link-pressure",
      weight: 2,
      label: "click-through pressure",
      phrases: [
        "click here",
        "click the link",
        "open the attachment",
        "download the document",
        "scan the qr code",
        "call this number",
        "contact support immediately",
        "cliquez ici",
        "cliquez sur le lien",
        "ouvrez la piece jointe",
        "telechargez le document",
        "scannez le qr code",
        "appelez ce numero",
        "contactez le support",
        "confirmez maintenant",
        "confirmer ma livraison",
        "je confirme mes informations",
        "suivez ce lien",
        "connectez vous",
        "klicken sie hier",
        "klicken sie auf den link",
        "laden sie das dokument herunter",
        "rufen sie diese nummer an",
        "clicca qui",
        "clicca sul link",
        "scarica il documento",
        "chiama questo numero",
        "haga clic aqui",
        "haga clic en el enlace",
        "descargue el documento",
        "llame a este numero",
        "clique aqui",
        "clique no link",
        "baixe o documento",
        "ligue para este numero",
        "нажмите здесь",
        "перейдите по ссылке",
        "скачайте документ",
        "позвоните по этому номеру",
        "ここをクリック",
        "リンクをクリック",
        "書類をダウンロード",
        "この番号に電話",
        "点击这里",
        "点击链接",
        "下载文件",
        "拨打此号码",
        "यहां क्लिक करें",
        "लिंक पर क्लिक करें",
        "दस्तावेज डाउनलोड करें",
        "इस नंबर पर कॉल करें",
        "اضغط هنا",
        "انقر على الرابط",
        "قم بتنزيل المستند",
        "اتصل بهذا الرقم",
        "এখানে ক্লিক করুন",
        "লিঙ্কে ক্লিক করুন",
        "ডকুমেন্ট ডাউনলোড করুন",
        "এই নম্বরে কল করুন",
        "یہاں کلک کریں",
        "لنک پر کلک کریں",
        "دستاویز ڈاؤن لوڈ کریں",
        "اس نمبر پر کال کریں"
      ]
    },
    {
      id: "delivery",
      weight: 3,
      label: "delivery or parcel pressure",
      phrases: DELIVERY_TERMS
    },
    {
      id: "reward",
      weight: 2,
      label: "unexpected reward",
      phrases: [
        "you have won",
        "claim your prize",
        "gift card",
        "free reward",
        "received a grant",
        "grant of",
        "grant",
        "vous avez gagne",
        "reclamez votre prix",
        "carte cadeau",
        "cadeau gratuit",
        "loterie",
        "subvention",
        "vous avez recu une subvention",
        "sie haben gewonnen",
        "erhalten haben",
        "zuschuss",
        "gewinn",
        "preis beanspruchen",
        "hai vinto",
        "richiedi il premio",
        "sovvenzione",
        "contributo",
        "hai ricevuto una sovvenzione",
        "ha ganado",
        "reclame su premio",
        "subvencion",
        "recibido una subvencion",
        "voce ganhou",
        "resgate seu premio",
        "bolsa",
        "subsidio",
        "recebeu uma bolsa",
        "вы выиграли",
        "получили грант",
        "грант",
        "получить приз",
        "当選しました",
        "賞金",
        "助成金",
        "給付金",
        "助成金を受け取り",
        "您已中奖",
        "领取奖金",
        "补助金",
        "获得补助金",
        "आप जीत गए",
        "इनाम प्राप्त करें",
        "अनुदान",
        "आपको अनुदान मिला",
        "لقد فزت",
        "اطلب جائزتك",
        "منحة",
        "تلقيت منحة",
        "আপনি জিতেছেন",
        "পুরস্কার দাবি করুন",
        "অনুদান",
        "আপনি অনুদান পেয়েছেন",
        "آپ جیت گئے",
        "انعام حاصل کریں",
        "گرانٹ",
        "آپ کو گرانٹ ملی"
      ]
    },
    {
      id: "attachment",
      weight: 2,
      label: "suspicious attachment pressure",
      phrases: [
        "password protected zip",
        "encrypted attachment",
        "open the invoice attached",
        "see attached invoice",
        "piece jointe chiffree",
        "archive zip protegee",
        "ouvrez la facture jointe",
        "facture en piece jointe"
      ]
    },
    {
      id: "impersonation",
      weight: 3,
      label: "authority or support impersonation",
      phrases: [
        "technical support",
        "fraud department",
        "security department",
        "tax office",
        "customs office",
        "service fraude",
        "service securite",
        "service des impots",
        "service douane",
        "support technique",
        "adresse e mail officielle",
        "initiative fmi ue",
        "imf",
        "imf eu initiative",
        "joint imf eu initiative",
        "iwf",
        "eu initiative",
        "iwf eu initiative",
        "internationaler wahrungsfonds",
        "official email address",
        "offizielle e mail adresse",
        "supporto tecnico",
        "dipartimento frodi",
        "ufficio delle imposte",
        "indirizzo email ufficiale",
        "iniziativa fmi ue",
        "soporte tecnico",
        "departamento de fraude",
        "oficina de impuestos",
        "direccion de correo oficial",
        "iniciativa fmi ue",
        "suporte tecnico",
        "departamento de fraude",
        "secretaria da receita",
        "endereco de email oficial",
        "iniciativa fmi ue",
        "техническая поддержка",
        "отдел мошенничества",
        "налоговая служба",
        "официальный адрес электронной почты",
        "инициатива мвф ес",
        "テクニカルサポート",
        "詐欺対策部門",
        "税務署",
        "公式メールアドレス",
        "技術支持",
        "欺诈部门",
        "税务局",
        "官方电子邮件地址",
        "国际货币基金组织",
        "欧盟倡议",
        "तकनीकी सहायता",
        "धोखाधड़ी विभाग",
        "कर कार्यालय",
        "आधिकारिक ईमेल पता",
        "आईएमएफ ईयू पहल",
        "الدعم الفني",
        "قسم الاحتيال",
        "مكتب الضرائب",
        "البريد الإلكتروني الرسمي",
        "صندوق النقد الدولي",
        "مبادرة الاتحاد الأوروبي",
        "প্রযুক্তিগত সহায়তা",
        "প্রতারণা বিভাগ",
        "কর অফিস",
        "সরকারি ইমেইল ঠিকানা",
        "আইএমএফ ইইউ উদ্যোগ",
        "تکنیکی مدد",
        "فراڈ ڈیپارٹمنٹ",
        "ٹیکس آفس",
        "سرکاری ای میل پتہ",
        "آئی ایم ایف ای یو اقدام"
      ]
    },
    {
      id: "secrecy",
      weight: 2,
      label: "secrecy pressure",
      phrases: [
        "do not tell anyone",
        "confidential request",
        "keep this confidential",
        "ne dites rien",
        "demande confidentielle",
        "gardez cela confidentiel"
      ]
    }
  ];
  const PAYMENT_INFO_CREDENTIAL_PHRASES = new Set([
    "update your payment information"
  ]);
  const LOOKALIKE_MAP = new Map([
    ["0", "o"],
    ["1", "l"],
    ["3", "e"],
    ["4", "a"],
    ["5", "s"],
    ["7", "t"],
    ["@", "a"],
    ["$", "s"]
  ]);

  function stripAccents(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
  }

  function normalizeText(value) {
    return stripAccents(value)
      .toLowerCase()
      .replace(/[\u2019']/g, "")
      .replace(TOKEN_SPLIT_RE, " ")
      .trim();
  }

  function normalizeLoose(value) {
    return normalizeText(value)
      .replace(/[013457@$]/g, (char) => LOOKALIKE_MAP.get(char) || char)
      .replace(/rn/g, "m")
      .replace(/vv/g, "w")
      .replace(/cl/g, "d")
      .replace(/\s+/g, "");
  }

  function normalizeDomain(value) {
    const raw = String(value || "")
      .trim()
      .replace(/^mailto:/i, "")
      .replace(/[<>()\[\],;:]+$/g, "")
      .replace(/^[<>()\[\],;:]+/g, "")
      .replace(/\.$/, "")
      .toLowerCase();

    if (!raw) {
      return "";
    }

    const domain = raw.includes("@") ? raw.split("@").pop() : raw;
    try {
      if (/^[a-z][a-z0-9+.-]*:\/\//i.test(domain)) {
        return new URL(domain).hostname.replace(/\.$/, "").toLowerCase();
      }
      return new URL(`https://${domain}`).hostname.replace(/\.$/, "").toLowerCase();
    } catch (_error) {
      return domain.replace(/[^a-z0-9.-]/g, "");
    }
  }

  function isIpv4Address(domain) {
    const normalized = String(domain || "").trim();
    if (!/^\d{1,3}(?:\.\d{1,3}){3}$/.test(normalized)) {
      return false;
    }

    return normalized.split(".").every((part) => Number(part) >= 0 && Number(part) <= 255);
  }

  function parseUrl(value) {
    const raw = String(value || "").trim();
    if (!raw || /^(mailto|tel|sms|javascript|data|blob):/i.test(raw)) {
      return null;
    }

    try {
      return new URL(raw);
    } catch (_error) {
      try {
        return new URL(`https://${raw}`);
      } catch (__error) {
        return null;
      }
    }
  }

  function unwrapRedirectUrl(url) {
    let current = parseUrl(url);
    const seen = new Set();

    for (let depth = 0; depth < 3 && current; depth += 1) {
      const key = current.toString();
      if (seen.has(key)) {
        break;
      }
      seen.add(key);

      const hostname = current.hostname.toLowerCase();
      if (!KNOWN_REDIRECT_HOSTS.has(hostname) && !hostname.endsWith(".safelinks.protection.outlook.com")) {
        break;
      }

      const nested = REDIRECT_PARAMS
        .map((param) => current.searchParams.get(param))
        .find((value) => value && /^https?:\/\//i.test(value));

      if (!nested) {
        break;
      }

      current = parseUrl(nested);
    }

    return current;
  }

  function extractEmail(value) {
    const text = String(value || "");
    const angleMatch = text.match(ANGLE_EMAIL_RE);
    if (angleMatch) {
      return angleMatch[1].toLowerCase();
    }

    const match = text.match(EMAIL_RE);
    return match ? match[0].toLowerCase() : "";
  }

  function stripEmailAddresses(value) {
    return String(value || "")
      .replace(EMAIL_GLOBAL_RE, " ")
      .replace(/[<>]/g, " ");
  }

  function domainMatchesAllowed(senderDomain, allowedDomain) {
    const sender = normalizeDomain(senderDomain);
    const allowed = normalizeDomain(allowedDomain);
    return sender === allowed || sender.endsWith(`.${allowed}`);
  }

  function domainMatchesAllowedForRule(rule, domain, allowedDomain) {
    const normalized = normalizeDomain(domain);
    const allowed = normalizeDomain(allowedDomain);
    if (!normalized || !allowed) {
      return false;
    }
    if (rule.matchSubdomains === false) {
      return normalized === allowed;
    }
    return domainMatchesAllowed(normalized, allowed);
  }

  function domainFallsUnderRuleDomain(rule, domain) {
    return (rule.allowedDomains || []).some((allowedDomain) => domainMatchesAllowed(domain, allowedDomain));
  }

  function isPersonalMailboxDomain(domain) {
    const normalized = normalizeDomain(domain);
    return FREE_MAIL_DOMAINS.has(normalized);
  }

  function trustedSenderDomainsForRule(rule) {
    const domains = Array.isArray(rule.senderDomains) ? rule.senderDomains : rule.allowedDomains || [];
    return domains.filter((domain) => !isPersonalMailboxDomain(domain));
  }

  function domainMatchesTrustedSender(rule, senderDomain) {
    return trustedSenderDomainsForRule(rule).some((allowedDomain) => {
      if (Array.isArray(rule.senderDomains)) {
        if (rule.senderMatchSubdomains !== false && !rule.hostedPlatform) {
          return domainMatchesAllowed(senderDomain, allowedDomain);
        }

        const normalized = normalizeDomain(senderDomain);
        const allowed = normalizeDomain(allowedDomain);
        return normalized === allowed;
      }

      return domainMatchesAllowedForRule(rule, senderDomain, allowedDomain);
    });
  }

  function domainMatchesTrustedLink(rule, domain) {
    return (rule.allowedDomains || []).some((allowedDomain) =>
      domainMatchesAllowedForRule(rule, domain, allowedDomain)
    );
  }

  function isHostedPlatformCustomerDomain(rule, domain) {
    return Boolean(
      rule.hostedPlatform &&
      domainFallsUnderRuleDomain(rule, domain) &&
      !domainMatchesTrustedLink(rule, domain)
    );
  }

  function domainLabels(domain) {
    return normalizeDomain(domain).split(".").filter(Boolean);
  }

  function domainTld(domain) {
    const labels = domainLabels(domain);
    return labels.length ? labels[labels.length - 1] : "";
  }

  function rootDomain(domain) {
    const labels = domainLabels(domain);
    return labels.length >= 2 ? labels.slice(-2).join(".") : labels.join(".");
  }

  function rootDomainsMatch(firstDomain, secondDomain) {
    return rootDomain(firstDomain) === rootDomain(secondDomain);
  }

  function isUrlShortenerDomain(domain) {
    const normalized = normalizeDomain(domain);
    return URL_SHORTENER_DOMAINS.has(normalized) || URL_SHORTENER_DOMAINS.has(rootDomain(normalized));
  }

  function findPublicHostingProvider(domain) {
    const normalized = normalizeDomain(domain);
    return PUBLIC_HOSTING_DOMAINS.find((provider) =>
      provider.domains.some((providerDomain) => domainMatchesAllowed(normalized, providerDomain))
    );
  }

  function extractDisplayedDomain(value) {
    const match = String(value || "").toLowerCase().match(DISPLAYED_DOMAIN_RE);
    return match ? normalizeDomain(match[1]) : "";
  }

  function domainWithoutTld(domain) {
    const labels = domainLabels(domain);
    return labels.length > 1 ? labels.slice(0, -1) : labels;
  }

  function labelCandidates(domain) {
    const labels = domainWithoutTld(domain);
    const candidates = new Set();

    for (const label of labels) {
      candidates.add(label);
      const parts = normalizeText(label).split(/\s+/).filter(Boolean);
      for (const part of parts) {
        candidates.add(part);
      }
      if (parts.length > 1) {
        candidates.add(parts.join(""));
        for (let index = 0; index < parts.length - 1; index += 1) {
          candidates.add(`${parts[index]}${parts[index + 1]}`);
        }
      }

      const stripped = stripSuspiciousEdgeTerms(parts.join(""));
      if (stripped) {
        candidates.add(stripped);
      }
    }

    if (labels.length > 1) {
      candidates.add(labels.join(""));
      for (let index = 0; index < labels.length - 1; index += 1) {
        candidates.add(`${labels[index]}${labels[index + 1]}`);
      }
    }

    return [...candidates]
      .map((candidate) => normalizeLoose(candidate))
      .filter((candidate) => candidate.length >= 4);
  }

  function stripSuspiciousEdgeTerms(value) {
    let result = normalizeLoose(value);
    let changed = true;

    while (changed && result.length >= 4) {
      changed = false;
      for (const term of SUSPICIOUS_TERMS) {
        const looseTerm = normalizeLoose(term);
        if (looseTerm.length < 4 || looseTerm.length >= result.length) {
          continue;
        }
        if (result.startsWith(looseTerm)) {
          result = result.slice(looseTerm.length);
          changed = true;
        }
        if (result.endsWith(looseTerm)) {
          result = result.slice(0, -looseTerm.length);
          changed = true;
        }
      }
    }

    return result;
  }

  function compactDomain(domain) {
    return normalizeLoose(domainWithoutTld(domain).join(""));
  }

  function repeatedCharacterRun(value) {
    const match = String(value || "").match(/([a-z0-9])\1{4,}/i);
    return Boolean(match);
  }

  function looksMachineGeneratedLabel(label) {
    const value = String(label || "").replace(/[^a-z0-9]/gi, "").toLowerCase();
    if (value.length < 14) {
      return false;
    }

    const digitCount = (value.match(/\d/g) || []).length;
    const vowelCount = (value.match(/[aeiou]/g) || []).length;
    const consonantRuns = value.match(/[bcdfghjklmnpqrstvwxyz]{6,}/g) || [];

    return digitCount >= 3 || vowelCount <= 2 || consonantRuns.length > 0;
  }

  function hasAlias(value, alias) {
    const text = normalizeText(value);
    const looseText = normalizeLoose(value);
    const normalizedAlias = normalizeText(alias);
    const looseAlias = normalizeLoose(alias);

    if (!normalizedAlias) {
      return false;
    }

    const wordPattern = new RegExp(`(^|\\s)${escapeRegExp(normalizedAlias)}($|\\s)`);
    const canUseLooseSubstring = looseAlias.length >= 4;
    return wordPattern.test(text) || (canUseLooseSubstring && looseText.includes(looseAlias));
  }

  function levenshteinDistance(a, b) {
    if (a === b) {
      return 0;
    }
    if (!a) {
      return b.length;
    }
    if (!b) {
      return a.length;
    }

    const previous = Array.from({ length: b.length + 1 }, (_value, index) => index);
    const current = Array.from({ length: b.length + 1 }, () => 0);

    for (let i = 1; i <= a.length; i += 1) {
      current[0] = i;
      for (let j = 1; j <= b.length; j += 1) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        current[j] = Math.min(
          previous[j] + 1,
          current[j - 1] + 1,
          previous[j - 1] + cost
        );
      }
      previous.splice(0, previous.length, ...current);
    }

    return previous[b.length];
  }

  function maxAliasDistance(alias) {
    if (alias.length < 5) {
      return 0;
    }
    if (alias.length <= 6) {
      return 1;
    }
    if (alias.length <= 10) {
      return 2;
    }
    return 3;
  }

  function isLikelyAliasLookalike(candidate, alias) {
    const looseCandidate = normalizeLoose(candidate);
    const looseAlias = normalizeLoose(alias);

    if (looseAlias.length < 5 || looseCandidate.length < 4) {
      return false;
    }
    if (looseCandidate === looseAlias || looseCandidate.includes(looseAlias)) {
      return true;
    }

    const distanceLimit = maxAliasDistance(looseAlias);
    if (distanceLimit === 0) {
      return false;
    }

    if (Math.abs(looseCandidate.length - looseAlias.length) <= distanceLimit) {
      return levenshteinDistance(looseCandidate, looseAlias) <= distanceLimit;
    }

    return false;
  }

  function isKnownBenignLookalike(candidate, alias) {
    const looseCandidate = normalizeLoose(candidate);
    const looseAlias = normalizeLoose(alias);

    return (
      (looseAlias === "calendly" && looseCandidate === "calendar") ||
      (looseAlias === "gmail" && (looseCandidate === "email" || looseCandidate === "mail"))
    );
  }

  function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function findClaimedBrand(senderText, senderEmail, senderDomain, rules) {
    const displayText = stripEmailAddresses(senderText);
    const localPart = senderEmail.split("@")[0] || "";
    const senderUsesHostedPlatform = findHostedPlatformCustomerDomainRule(senderDomain, rules);

    const exactMatch = rules.find((rule) => {
      const aliases = rule.aliases || [];
      const domainIsTrustedForRule = domainMatchesTrustedSender(rule, senderDomain);
      const searchableParts = [displayText, localPart];
      if (!domainIsTrustedForRule && !isPersonalMailboxDomain(senderDomain) && !senderUsesHostedPlatform) {
        searchableParts.push(senderDomain.replace(/\./g, " "));
      }

      return aliases.some((alias) => searchableParts.some((part) => hasAlias(part, alias)));
    });

    if (exactMatch) {
      return {
        rule: exactMatch,
        reason: "brand name appears in the sender"
      };
    }

    const trustedDomainRule = findTrustedSenderDomainRule(senderDomain, rules);
    if (trustedDomainRule) {
      return {
        rule: trustedDomainRule,
        reason: "sender domain matches the trusted list"
      };
    }

    return findLookalikeDomainBrand(senderDomain, rules);
  }

  function findLookalikeDomainBrand(senderDomain, rules) {
    if (!senderDomain) {
      return null;
    }
    if (findTrustedDomainRule(senderDomain, rules) || findHostedPlatformCustomerDomainRule(senderDomain, rules)) {
      return null;
    }

    const candidates = labelCandidates(senderDomain);
    const compact = compactDomain(senderDomain);

    for (const rule of rules) {
      if (domainMatchesTrustedLink(rule, senderDomain)) {
        continue;
      }

      const aliases = rule.aliases || [];
      for (const alias of aliases) {
        const looseAlias = normalizeLoose(alias);
        if (looseAlias.length < 5) {
          continue;
        }

        const candidateMatches = candidates.some(
          (candidate) =>
            !isKnownBenignLookalike(candidate, looseAlias) &&
            isLikelyAliasLookalike(candidate, looseAlias)
        );
        const compactMatches =
          !isKnownBenignLookalike(compact, looseAlias) &&
          isLikelyAliasLookalike(compact, looseAlias);

        if (candidateMatches || compactMatches) {
          return {
            rule,
            reason: `sender domain looks like ${rule.name}`
          };
        }
      }
    }

    return null;
  }

  function findTrustedDomainRule(domain, rules) {
    return rules.find((rule) => domainMatchesTrustedLink(rule, domain));
  }

  function findTrustedSenderDomainRule(domain, rules) {
    return rules.find((rule) => domainMatchesTrustedSender(rule, domain));
  }

  function findHostedPlatformCustomerDomainRule(domain, rules) {
    return rules.find((rule) => isHostedPlatformCustomerDomain(rule, domain));
  }

  function containsAnyTerm(value, terms) {
    const text = normalizeText(value);
    return terms.some((term) => hasAlias(text, term));
  }

  function contentHasPhrase(text, phrase) {
    const normalizedText = normalizeText(text);
    const normalizedPhrase = normalizeText(phrase);
    if (!normalizedPhrase) {
      return false;
    }

    return normalizedText.includes(normalizedPhrase);
  }

  function trustedSenderContext(options) {
    const trustedSender = options && options.trustedSender;
    if (!trustedSender) {
      return null;
    }

    const brand = String(trustedSender.brand || "").trim();
    const senderDomain = normalizeDomain(trustedSender.senderDomain);
    if (!brand && !senderDomain) {
      return null;
    }

    return { brand, senderDomain };
  }

  function trustedPaymentNoticeMessage(sender) {
    const source = sender.senderDomain
      ? `${sender.senderDomain}, which is in your familiar sender list`
      : sender.brand
        ? `${sender.brand}'s familiar sender list`
        : "a familiar sender";
    return `This payment-related message comes from ${source}. Review the amount and recipient, and use your usual account page if anything feels off.`;
  }

  function contentWarningMessage(labels, risks) {
    if (risks.hasPersonalInfo && risks.hasReward) {
      return `This message combines an unexpected reward with a request for personal details: ${labels}. Don't reply with personal details or contact the address in the message.`;
    }
    if (risks.hasPersonalInfo) {
      return `This message asks for personal details in a risky way: ${labels}. Don't reply with personal details until you check the sender another way.`;
    }
    if (risks.hasCredentials) {
      return `This message asks for sensitive access details: ${labels}. Don't enter passwords, security codes, or recovery details.`;
    }
    if (risks.hasDelivery || risks.hasPayment) {
      return `This message puts pressure on you: ${labels}. Don't use links in the message for delivery, payment, or login details.`;
    }

    return `This message puts pressure on you: ${labels}. Check another way before acting.`;
  }

  function analyzeContent(contentText, options = {}) {
    const text = String(contentText || "").replace(/\s+/g, " ").trim();
    if (text.length < 20) {
      return {
        status: "unknown",
        severity: "none",
        score: 0,
        signals: [],
        message: "Not enough mail content to analyze."
      };
    }

    const signals = [];
    let score = 0;

    for (const group of CONTENT_SIGNAL_GROUPS) {
      const matchedPhrases = group.phrases.filter((phrase) => contentHasPhrase(text, phrase));
      if (matchedPhrases.length === 0) {
        continue;
      }

      score += group.weight + Math.min(2, matchedPhrases.length - 1);
      signals.push({
        id: group.id,
        label: group.label,
        phrases: matchedPhrases.slice(0, 3)
      });
    }

    const hasCredentials = signals.some((signal) => signal.id === "credentials");
    const hasUrgency = signals.some((signal) => signal.id === "urgency");
    const hasPayment = signals.some((signal) => signal.id === "payment");
    const hasPersonalInfo = signals.some((signal) => signal.id === "personal-info");
    const hasThreat = signals.some((signal) => signal.id === "threat");
    const hasDelivery = signals.some((signal) => signal.id === "delivery");
    const hasReward = signals.some((signal) => signal.id === "reward");
    const hasImpersonation = signals.some((signal) => signal.id === "impersonation");
    const hasLinkPressure = signals.some((signal) => signal.id === "link-pressure");
    const trustedSender = trustedSenderContext(options);
    const credentialSignal = signals.find((signal) => signal.id === "credentials");
    const hasOnlyPaymentInfoCredential =
      Boolean(credentialSignal) &&
      credentialSignal.phrases.every((phrase) => PAYMENT_INFO_CREDENTIAL_PHRASES.has(normalizeText(phrase)));
    const hasHighRiskPayment = signals.some(
      (signal) =>
        signal.id === "payment" &&
        signal.phrases.some((phrase) =>
          ["bitcoin", "crypto", "gift card", "moneygram", "usdt", "western union", "wire transfer"].includes(
            normalizeText(phrase)
          )
        )
    );
    const isWarning =
      score >= 5 ||
      hasCredentials ||
      hasHighRiskPayment ||
      (hasPersonalInfo && (hasReward || hasImpersonation)) ||
      (hasReward && hasImpersonation) ||
      (hasUrgency && (hasPayment || hasThreat)) ||
      (hasUrgency && hasDelivery) ||
      (hasDelivery && hasLinkPressure) ||
      (hasPayment && hasThreat);

    if (!isWarning) {
      return {
        status: "unknown",
        severity: "none",
        score,
        signals,
        message: "No strong phishing language detected in the mail content."
      };
    }

    const labels = signals.map((signal) => signal.label).slice(0, 3).join(", ");
    const isTrustedSenderPaymentNotice =
      trustedSender &&
      !hasHighRiskPayment &&
      !hasPersonalInfo &&
      (hasPayment || hasOnlyPaymentInfoCredential) &&
      (!hasCredentials || hasOnlyPaymentInfoCredential);

    if (isTrustedSenderPaymentNotice) {
      return {
        status: "warning",
        severity: "low",
        context: "trusted-sender-payment",
        brand: trustedSender.brand || undefined,
        senderDomain: trustedSender.senderDomain || undefined,
        score,
        signals,
        message: trustedPaymentNoticeMessage(trustedSender)
      };
    }

    return {
      status: "warning",
      severity:
        score >= 9 || (hasUrgency && hasDelivery && hasLinkPressure)
          ? "critical"
          : score >= 7 || hasCredentials || hasHighRiskPayment
            ? "high"
            : "medium",
      score,
      signals,
      message: contentWarningMessage(labels, {
        hasCredentials,
        hasDelivery,
        hasPayment,
        hasPersonalInfo,
        hasReward
      })
    };
  }

  function hasSuspiciousDomainShape(domain) {
    const normalized = normalizeDomain(domain);
    const allLabels = domainLabels(normalized);
    const labels = domainWithoutTld(normalized);
    const firstLabel = labels[0] || "";
    const root = rootDomain(normalized);
    const tld = domainTld(normalized);
    const hyphenCount = (normalized.match(/-/g) || []).length;
    const digitCount = (normalized.match(/\d/g) || []).length;
    const longestLabel = labels.reduce((longest, label) => Math.max(longest, label.length), 0);

    return (
      isIpv4Address(normalized) ||
      normalized.includes("xn--") ||
      HIGH_RISK_TLDS.has(tld) ||
      (tld && !STANDARD_TLDS.has(tld)) ||
      normalized.length >= 50 ||
      root.length >= 36 ||
      allLabels.length >= 5 ||
      hyphenCount >= 2 ||
      labels.some((label) => (label.match(/-/g) || []).length >= 2) ||
      firstLabel.length >= 24 ||
      longestLabel >= 28 ||
      digitCount >= 4 ||
      repeatedCharacterRun(normalized) ||
      labels.some((label) => looksMachineGeneratedLabel(label)) ||
      labels.some((label) => /\d/.test(label) && /[a-z]/.test(label))
    );
  }

  function explainSuspiciousDomainShape(domain) {
    const normalized = normalizeDomain(domain);
    const allLabels = domainLabels(normalized);
    const labels = domainWithoutTld(normalized);
    const root = rootDomain(normalized);
    const tld = domainTld(normalized);
    const hyphenCount = (normalized.match(/-/g) || []).length;
    const digitCount = (normalized.match(/\d/g) || []).length;
    const longestLabel = labels.reduce((longest, label) => Math.max(longest, label.length), 0);

    if (isIpv4Address(normalized)) {
      return "uses a numeric IP address instead of a website domain";
    }
    if (normalized.includes("xn--")) {
      return "uses encoded international characters";
    }
    if (HIGH_RISK_TLDS.has(tld)) {
      return `uses the high-risk .${tld} extension`;
    }
    if (tld && !STANDARD_TLDS.has(tld)) {
      return `uses the uncommon .${tld} extension`;
    }
    if (normalized.length >= 50) {
      return "has an unusually long domain";
    }
    if (root.length >= 36) {
      return "has an unusually long main domain";
    }
    if (allLabels.length >= 5) {
      return "has too many domain sections";
    }
    if (hyphenCount >= 2 || labels.some((label) => (label.match(/-/g) || []).length >= 2)) {
      return "uses too many hyphens";
    }
    if ((labels[0] || "").length >= 24 || longestLabel >= 28) {
      return "has an unusually long domain label";
    }
    if (digitCount >= 4 || labels.some((label) => /\d/.test(label) && /[a-z]/.test(label))) {
      return "mixes letters and numbers in a suspicious way";
    }
    if (labels.some((label) => looksMachineGeneratedLabel(label))) {
      return "looks machine-generated";
    }
    if (repeatedCharacterRun(normalized)) {
      return "contains repeated characters that look machine-generated";
    }

    return "has a suspicious domain shape";
  }

  function displayDomain(domain) {
    const normalized = normalizeDomain(domain);
    return normalized ? `${normalized.charAt(0).toUpperCase()}${normalized.slice(1)}` : "";
  }

  function professionalSenderCheckMessage(email, domain) {
    const readableDomain = displayDomain(domain);
    if (email && readableDomain) {
      return `Check that you know this sender: ${email} (${readableDomain}).`;
    }
    if (readableDomain) {
      return `Check that you know this sender: ${readableDomain}.`;
    }
    return "Verify you know the sender.";
  }

  function analyzeGenericDomainRisk(contextText, emailOrUrl, domain, kind) {
    if (!domain) {
      return null;
    }

    const normalized = normalizeDomain(domain);
    const localPart = String(emailOrUrl || "").includes("@")
      ? String(emailOrUrl).split("@")[0] || ""
      : "";
    const domainText = normalized.replace(/\./g, " ");
    const hasSuspiciousTerm =
      containsAnyTerm(domainText, SUSPICIOUS_TERMS) ||
      containsAnyTerm(localPart, SUSPICIOUS_TERMS) ||
      containsAnyTerm(contextText, SUSPICIOUS_TERMS);
    const hasOfficialIdentity =
      containsAnyTerm(contextText, GENERIC_IDENTITY_TERMS) ||
      containsAnyTerm(localPart, GENERIC_IDENTITY_TERMS);
    const shapeReason = hasSuspiciousDomainShape(normalized)
      ? explainSuspiciousDomainShape(normalized)
      : "";

    if (FREE_MAIL_DOMAINS.has(normalized) && hasOfficialIdentity) {
      return {
        severity: "high",
        message: `This ${kind} looks like a service team, but it uses a personal email address (${normalized}).`
      };
    }

    if (shapeReason) {
      const sensitivity = hasSuspiciousTerm ? " and sensitive wording" : "";
      const isProfessionalSenderCheck = kind === "sender" && !hasSuspiciousTerm && /^uses the uncommon \./.test(shapeReason);
      return {
        context: isProfessionalSenderCheck ? "professional-sender-check" : "generic-domain-risk",
        reason: shapeReason,
        severity: hasSuspiciousTerm || (kind === "link" && isIpv4Address(normalized)) ? "high" : "medium",
        message: isProfessionalSenderCheck
          ? professionalSenderCheckMessage(String(emailOrUrl || ""), normalized)
          : `The ${kind} domain (${normalized}) ${shapeReason}${sensitivity}.`
      };
    }

    if (hasSuspiciousTerm && normalized.length >= 32) {
      return {
        severity: "high",
        message: `The ${kind} domain (${normalized}) is long and uses sensitive wording.`
      };
    }

    return null;
  }

  function findGenericDomainRisk(contextText, emailOrUrl, domain, kind) {
    const risk = analyzeGenericDomainRisk(contextText, emailOrUrl, domain, kind);
    return risk ? risk.message : null;
  }

  function findGenericRisk(senderText, senderEmail, senderDomain) {
    return findGenericDomainRisk(senderText, senderEmail, senderDomain, "sender");
  }

  function analyzeUrl(urlText, rules) {
    const activeRules = Array.isArray(rules) ? rules : [];
    const parsed = unwrapRedirectUrl(urlText);

    if (!parsed) {
      return {
        status: "unknown",
        severity: "none",
        url: String(urlText || ""),
        urlDomain: "",
        message: "No readable link domain detected."
      };
    }

    const url = parsed.toString();
    const domain = normalizeDomain(parsed.hostname);
    const trustedRule = findTrustedDomainRule(domain, activeRules);
    const hostedPlatformRule = findHostedPlatformCustomerDomainRule(domain, activeRules);
    const publicHostingProvider = findPublicHostingProvider(domain);
    const lookalikeMatch = findLookalikeDomainBrand(domain, activeRules);
    const tooLongUrl = url.length >= 180;

    if (publicHostingProvider) {
      return {
        status: "warning",
        severity: "critical",
        url,
        urlDomain: domain,
        allowedDomains: [],
        message: `Likely phishing: the link opens ${publicHostingProvider.name} (${domain}), a public hosting service that anyone can use. Do not enter delivery, payment, or login information there.`
      };
    }

    if (trustedRule) {
      return {
        status: "trusted",
        severity: "none",
        brand: trustedRule.name,
        url,
        urlDomain: domain,
        allowedDomains: trustedRule.allowedDomains || [],
        message: `${trustedRule.name} link is in your familiar list.`
      };
    }

    if (hostedPlatformRule) {
      return {
        status: "warning",
        severity: "medium",
        context: "hosted-platform-link",
        brandId: hostedPlatformRule.id,
        brand: hostedPlatformRule.name,
        url,
        urlDomain: domain,
        allowedDomains: hostedPlatformRule.allowedDomains || [],
        message: `This link opens a page made with ${hostedPlatformRule.name} (${domain}). Anyone can make pages there, so open it only if you expected it.`
      };
    }

    if (lookalikeMatch) {
      return {
        status: "warning",
        severity: "high",
        brand: lookalikeMatch.rule.name,
        url,
        urlDomain: domain,
        allowedDomains: lookalikeMatch.rule.allowedDomains || [],
        message: `${lookalikeMatch.rule.name} risk detected: link domain looks like ${lookalikeMatch.rule.name}, but the link domain is ${domain}.`
      };
    }

    const genericRisk = analyzeGenericDomainRisk(url, url, domain, "link");

    if (isUrlShortenerDomain(domain)) {
      return {
        status: "warning",
        severity: "high",
        url,
        urlDomain: domain,
        allowedDomains: [],
        message: `The link uses a URL shortener (${domain}), which hides the final destination.`
      };
    }

    if (genericRisk || tooLongUrl) {
      return {
        status: "warning",
        severity: genericRisk ? genericRisk.severity : "high",
        context: genericRisk ? genericRisk.context : undefined,
        reason: genericRisk ? genericRisk.reason : undefined,
        brand: trustedRule ? trustedRule.name : undefined,
        url,
        urlDomain: domain,
        allowedDomains: trustedRule ? trustedRule.allowedDomains || [] : [],
        message: genericRisk
          ? genericRisk.message
          : `The link URL is unusually long (${url.length} characters), which can hide the real destination.`
      };
    }

    return {
      status: "unknown",
      severity: "none",
      url,
      urlDomain: domain,
      message: "No protected or suspicious link domain detected."
    };
  }

  function analyzeLink(displayText, href, rules) {
    const activeRules = Array.isArray(rules) ? rules : [];
    const result = analyzeUrl(href, rules);
    const parsed = unwrapRedirectUrl(href);
    const hrefDomain = parsed ? normalizeDomain(parsed.hostname) : result.urlDomain || "";
    const displayDomain = extractDisplayedDomain(displayText);
    const displayTrustedRule = displayDomain ? findTrustedDomainRule(displayDomain, activeRules) : null;
    const hrefTrustedRule = hrefDomain ? findTrustedDomainRule(hrefDomain, activeRules) : null;
    const sameTrustedBrand =
      displayTrustedRule &&
      hrefTrustedRule &&
      displayTrustedRule.id === hrefTrustedRule.id;

    if (
      displayDomain &&
      hrefDomain &&
      !sameTrustedBrand &&
      !rootDomainsMatch(displayDomain, hrefDomain) &&
      !domainMatchesAllowed(hrefDomain, displayDomain)
    ) {
      const mismatchMessage = `The visible link says ${displayDomain}, but the real destination is ${hrefDomain}.`;
      if (result.status === "warning") {
        const severity = result.severity === "critical" ? "critical" : "high";
        return {
          ...result,
          severity,
          displayedDomain: displayDomain,
          message:
            severity === "critical"
              ? `${mismatchMessage} ${result.message}`
              : mismatchMessage
        };
      }

      return {
        status: "warning",
        severity: "high",
        url: parsed ? parsed.toString() : String(href || ""),
        urlDomain: hrefDomain,
        displayedDomain: displayDomain,
        allowedDomains: [],
        message: mismatchMessage
      };
    }

    return result;
  }

  function analyzeSender(senderText, rules) {
    const activeRules = Array.isArray(rules) ? rules : [];
    const email = extractEmail(senderText);
    const domain = normalizeDomain(email);
    const brandMatch = findClaimedBrand(senderText, email, domain, activeRules);
    const brand = brandMatch ? brandMatch.rule : null;

    if (!brand) {
      const hostedPlatformRule = findHostedPlatformCustomerDomainRule(domain, activeRules);
      if (hostedPlatformRule) {
        return {
        status: "warning",
        severity: "medium",
        brandId: hostedPlatformRule.id,
        brand: hostedPlatformRule.name,
        senderEmail: email,
        senderDomain: domain,
          allowedDomains: hostedPlatformRule.allowedDomains || [],
          message: `The sender uses a customer-hosted ${hostedPlatformRule.name} subdomain (${domain}). Hosted-site platforms can be used by anyone, so check the message carefully.`
        };
      }

      const genericRisk = analyzeGenericDomainRisk(senderText, email, domain, "sender");
      if (genericRisk) {
        return {
          status: "warning",
          severity: genericRisk.severity,
          context: genericRisk.context,
          reason: genericRisk.reason,
          senderEmail: email,
          senderDomain: domain,
          allowedDomains: [],
          message: genericRisk.message
        };
      }

      return {
        status: "unknown",
        severity: "none",
        senderEmail: email,
        senderDomain: domain,
        message: "No protected brand detected in the sender."
      };
    }

    if (!domain) {
      return {
        status: "warning",
        severity: "medium",
        brandId: brand.id,
        brand: brand.name,
        senderEmail: email,
        senderDomain: "",
        allowedDomains: brand.allowedDomains || [],
        message: `${brand.name} is mentioned, but Bye bye Fishing could not read a sender email domain.`
      };
    }

    const isTrusted = domainMatchesTrustedSender(brand, domain);

    if (isTrusted) {
      return {
        status: "trusted",
        severity: "none",
        brandId: brand.id,
        brand: brand.name,
        senderEmail: email,
        senderDomain: domain,
        allowedDomains: brand.allowedDomains || [],
        message: `${brand.name} sender address is in your familiar list.`
      };
    }

    const punycodeHint = domain.includes("xn--")
      ? " The domain uses an internationalized form, which can hide lookalike characters."
      : "";
    const shapeReason = hasSuspiciousDomainShape(domain) ? explainSuspiciousDomainShape(domain) : "";
    const suspiciousHint = shapeReason ? ` The sender domain also ${shapeReason}.` : "";
    const trustedExamples = (brand.allowedDomains || []).slice(0, 3).join(", ");

    return {
      status: "warning",
      severity: shapeReason ? "critical" : "high",
      brandId: brand.id,
      brand: brand.name,
      senderEmail: email,
      senderDomain: domain,
      allowedDomains: brand.allowedDomains || [],
      message: `This mentions ${brand.name}, but it came from ${domain}, which is not in the known ${brand.name} domains here${trustedExamples ? ` (${trustedExamples})` : ""}.${suspiciousHint}${punycodeHint} Don't use links in this message or share personal information.`
    };
  }

  function mergeUniqueValues(savedValues, defaultValues, normalizeValue) {
    const seen = new Set();
    const merged = [];

    for (const value of [...(savedValues || []), ...(defaultValues || [])]) {
      const normalized = normalizeValue ? normalizeValue(value) : String(value || "").trim();
      if (!normalized || seen.has(normalized)) {
        continue;
      }
      seen.add(normalized);
      merged.push(value);
    }

    return merged;
  }

  function mergeDefaultRuleUpdates(savedRules, baseRules) {
    if (!Array.isArray(savedRules) || !Array.isArray(baseRules)) {
      return Array.isArray(baseRules) ? baseRules : [];
    }

    const defaultsById = new Map(baseRules.map((rule) => [rule.id, rule]));
    const seenIds = new Set();
    const mergedRules = savedRules.map((savedRule) => {
      const defaultRule = savedRule && defaultsById.get(savedRule.id);
      if (!defaultRule) {
        return savedRule;
      }

      seenIds.add(savedRule.id);
      const merged = {
        ...defaultRule,
        ...savedRule,
        aliases: mergeUniqueValues(savedRule.aliases, defaultRule.aliases, normalizeText),
        allowedDomains: mergeUniqueValues(savedRule.allowedDomains, defaultRule.allowedDomains, normalizeDomain)
      };

      if (Array.isArray(savedRule.senderDomains) || Array.isArray(defaultRule.senderDomains)) {
        merged.senderDomains = mergeUniqueValues(
          savedRule.senderDomains,
          defaultRule.senderDomains,
          normalizeDomain
        );
      }

      return merged;
    });

    for (const defaultRule of baseRules) {
      if (!seenIds.has(defaultRule.id) && !savedRules.some((rule) => rule && rule.id === defaultRule.id)) {
        mergedRules.push(defaultRule);
      }
    }

    return mergedRules;
  }

  function cloneRules(rules) {
    return (Array.isArray(rules) ? rules : []).map((rule) => ({
      ...rule,
      aliases: [...(rule.aliases || [])],
      allowedDomains: [...(rule.allowedDomains || [])],
      ...(Array.isArray(rule.senderDomains) ? { senderDomains: [...rule.senderDomains] } : {})
    }));
  }

  function findRuleIndexById(rules, ruleId) {
    return (Array.isArray(rules) ? rules : []).findIndex((rule) => rule && rule.id === ruleId);
  }

  function domainListHasDomain(domains, domain) {
    const normalized = normalizeDomain(domain);
    return (domains || []).some((value) => normalizeDomain(value) === normalized);
  }

  function addTrustedDomainToRule(rules, ruleId, domain, listName = "allowedDomains") {
    const normalized = normalizeDomain(domain);
    const nextRules = cloneRules(rules);
    const index = findRuleIndexById(nextRules, ruleId);
    const targetListName = listName === "senderDomains" ? "senderDomains" : "allowedDomains";

    if (!normalized || index === -1) {
      return nextRules;
    }

    const rule = nextRules[index];
    if (targetListName === "senderDomains" && !Array.isArray(rule.senderDomains)) {
      rule.senderDomains = [];
    }

    const domains = rule[targetListName] || [];
    if (!domainListHasDomain(domains, normalized)) {
      domains.push(normalized);
      domains.sort((first, second) => normalizeDomain(first).localeCompare(normalizeDomain(second)));
    }
    rule[targetListName] = domains;

    return nextRules;
  }

  function removeTrustedDomainFromRule(rules, ruleId, domain, listName = "allowedDomains") {
    const normalized = normalizeDomain(domain);
    const nextRules = cloneRules(rules);
    const index = findRuleIndexById(nextRules, ruleId);
    const targetListName = listName === "senderDomains" ? "senderDomains" : "allowedDomains";

    if (!normalized || index === -1) {
      return nextRules;
    }

    const rule = nextRules[index];
    const domains = rule[targetListName] || [];
    if (domains.length <= 1) {
      return nextRules;
    }

    rule[targetListName] = domains.filter((value) => normalizeDomain(value) !== normalized);
    return nextRules;
  }

  function validateRules(rules) {
    if (!Array.isArray(rules)) {
      return { ok: false, error: "Rules must be an array." };
    }

    const ids = new Set();

    for (const [index, rule] of rules.entries()) {
      if (!rule || typeof rule !== "object") {
        return { ok: false, error: `Rule ${index + 1} must be an object.` };
      }
      if (!rule.id || !rule.name) {
        return { ok: false, error: `Rule ${index + 1} needs an id and name.` };
      }
      if (ids.has(rule.id)) {
        return { ok: false, error: `Rule id ${rule.id} is duplicated.` };
      }
      ids.add(rule.id);
      if (!Array.isArray(rule.aliases) || !Array.isArray(rule.allowedDomains)) {
        return {
          ok: false,
          error: `Rule ${rule.id || index + 1} needs aliases and allowedDomains arrays.`
        };
      }
      if (rule.aliases.length === 0 || rule.allowedDomains.length === 0) {
        return {
          ok: false,
          error: `Rule ${rule.id} needs at least one alias and one trusted domain.`
        };
      }
      if (rule.allowedDomains.some((domain) => !normalizeDomain(domain))) {
        return {
          ok: false,
          error: `Rule ${rule.id} contains an invalid domain.`
        };
      }
      if (
        rule.senderDomains !== undefined &&
        (!Array.isArray(rule.senderDomains) || rule.senderDomains.some((domain) => !normalizeDomain(domain)))
      ) {
        return {
          ok: false,
          error: `Rule ${rule.id} contains an invalid sender domain list.`
        };
      }
      if (rule.hostedPlatform !== undefined && typeof rule.hostedPlatform !== "boolean") {
        return {
          ok: false,
          error: `Rule ${rule.id} has an invalid hostedPlatform flag.`
        };
      }
      if (rule.matchSubdomains !== undefined && typeof rule.matchSubdomains !== "boolean") {
        return {
          ok: false,
          error: `Rule ${rule.id} has an invalid matchSubdomains flag.`
        };
      }
      if (rule.senderMatchSubdomains !== undefined && typeof rule.senderMatchSubdomains !== "boolean") {
        return {
          ok: false,
          error: `Rule ${rule.id} has an invalid senderMatchSubdomains flag.`
        };
      }
    }

    return { ok: true };
  }

  const api = {
    analyzeContent,
    analyzeLink,
    analyzeSender,
    analyzeUrl,
    addTrustedDomainToRule,
    domainMatchesAllowed,
    extractEmail,
    mergeDefaultRuleUpdates,
    normalizeDomain,
    removeTrustedDomainFromRule,
    validateRules
  };

  global.ByeByeFishingDetector = api;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
