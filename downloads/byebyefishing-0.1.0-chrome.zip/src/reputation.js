(function exposeReputation(global) {
  "use strict";

  // Exact URL fingerprints only. No remote lookups, host-wide blocking, or
  // probabilistic membership filter. SHA-256 is used as an index, not a signature.
  const K = new Uint32Array([
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
  ]);
  const rotate = (x,n) => (x >>> n) | (x << (32-n));

  function sha256(text) {
    const source = new TextEncoder().encode(text);
    const bytes = new Uint8Array(Math.ceil((source.length + 9) / 64) * 64);
    bytes.set(source); bytes[source.length] = 128;
    const view = new DataView(bytes.buffer);
    view.setUint32(bytes.length - 8, Math.floor(source.length / 0x20000000));
    view.setUint32(bytes.length - 4, (source.length * 8) >>> 0);
    const h = new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
    const w = new Uint32Array(64);
    for (let offset=0; offset<bytes.length; offset+=64) {
      for (let i=0;i<16;i++) w[i]=view.getUint32(offset+i*4);
      for (let i=16;i<64;i++) {
        const a=w[i-15],b=w[i-2];
        w[i]=w[i-16]+(rotate(a,7)^rotate(a,18)^(a>>>3))+w[i-7]+(rotate(b,17)^rotate(b,19)^(b>>>10));
      }
      let [a,b,c,d,e,f,g,j]=h;
      for(let i=0;i<64;i++) {
        const t1=(j+(rotate(e,6)^rotate(e,11)^rotate(e,25))+((e&f)^(~e&g))+K[i]+w[i])>>>0;
        const t2=((rotate(a,2)^rotate(a,13)^rotate(a,22))+((a&b)^(a&c)^(b&c)))>>>0;
        j=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;
      }
      [a,b,c,d,e,f,g,j].forEach((value,i)=>{h[i]=(h[i]+value)>>>0;});
    }
    return Array.from(h, n=>n.toString(16).padStart(8,"0")).join("");
  }

  function canonicalUrl(value) {
    if(typeof value !== "string" || value.length > 8192) return "";
    try {
      // Feeds sometimes retain HTML entity escaping from an href. Do not drop
      // queries, fragments, paths, or schemes: those can identify different users.
      const url = new URL(value.trim().replace(/&amp;/gi,"&"));
      if(!["http:","https:"].includes(url.protocol) || !url.hostname) return "";
      url.hostname=url.hostname.replace(/\.$/,"");
      return url.href;
    } catch { return ""; }
  }

  function createMatcher(feed, now=Date.now) {
    const hashes = typeof feed?.hashes === "string" ? feed.hashes : "";
    const generated=Date.parse(feed?.generatedAt),expires=Date.parse(feed?.expiresAt);
    const valid=feed?.schema===1 && feed?.algorithm==="sha256-url-v1" &&
      Number.isInteger(feed?.count) && feed.count>0 && feed.count<=500000 &&
      hashes.length===feed.count*64 && !/[^0-9a-f]/.test(hashes) &&
      Number.isFinite(generated) && Number.isFinite(expires) && expires>generated && expires-generated<=30*86400000;
    // Cache fingerprints, never dated verdicts, and bound memory on long sessions.
    const cache=new Map();
    function status() {
      const time=now();
      return {state:!valid?"unavailable":time<generated-300000?"unavailable":time>=expires?"expired":"current",
        generatedAt:valid?feed.generatedAt:null,expiresAt:valid?feed.expiresAt:null,count:valid?feed.count:0,source:"PhishTank"};
    }
    function lookup(value) {
      if(status().state!=="current") return null;
      const url=canonicalUrl(value);
      if(!url) return null;
      let digest=cache.get(url);
      if(!digest) {
        digest=sha256(url);
        if(cache.size>=2048) cache.delete(cache.keys().next().value);
        cache.set(url,digest);
      }
      let low=0,high=feed.count-1;
      while(low<=high) {
        const mid=(low+high)>>>1, key=hashes.slice(mid*64,(mid+1)*64);
        if(key===digest) return {url,source:"PhishTank",updatedAt:feed.generatedAt,match:"exact-url"};
        if(key<digest) low=mid+1; else high=mid-1;
      }
      return null;
    }
    return Object.freeze({lookup,status});
  }

  let bundled;
  function matcher() {
    if(!bundled) {
      const feed = typeof module!=="undefined" && module.exports
        ? require("./threat-feed.js") : global.BYEBYEFISHING_THREAT_FEED;
      bundled=createMatcher(feed);
    }
    return bundled;
  }
  const api=Object.freeze({canonicalUrl,sha256,createMatcher,lookup:value=>matcher().lookup(value),status:()=>matcher().status()});
  global.ByeByeFishingReputation=api;
  if(typeof module!=="undefined" && module.exports) module.exports=api;
})(typeof globalThis!=="undefined"?globalThis:this);
