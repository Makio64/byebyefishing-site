(function runByeByeFishingContentScript(global) {
  "use strict";

  const detector = global.ByeByeFishingDetector;
  const defaultRules = global.BYEBYEFISHING_DEFAULT_RULES || [];
  const rulesetVersion = global.BYEBYEFISHING_RULESET_VERSION || "0";
  const extensionApi = global.browser || global.chrome;
  const MESSAGE_BODY_SELECTORS = [
    ".a3s",
    "[aria-label*='Message body']",
    "[aria-label*='Corps du message']",
    "[data-testid='messageBody']",
    "[data-test-id='messageBody']",
    "[data-testid='message-content']",
    "[data-test-id='message-content']",
    "[data-testid='message-view-body-content']",
    "[data-test-id='message-view-body-content']",
    "[data-testid='message-view-body']",
    "[data-test-id='message-view-body']",
    "[data-message-id] [role='document']",
    ".message-content",
    ".mail-detail-content",
    ".mail-detail-body",
    ".mail-detail-pane [role='document']",
    ".message-part",
    ".message-htmlpart",
    "#messagebody",
    ".MsgBody",
    ".ZmMailMsgView"
  ];
  const MESSAGE_SCOPE_SELECTORS = [
    ".adn",
    "[data-message-id]",
    "[data-testid='conversation-message']",
    "[data-test-id='message']",
    "[data-testid='message']",
    "[data-testid='message-view']",
    "[data-test-id='message-view']",
    "[data-testid='message-view-item']",
    "[data-test-id='message-view-item']",
    "[data-test-id='message-item']",
    ".mail-detail",
    ".mail-detail-pane",
    "#messagecontent",
    "#messagebody",
    ".ZmMailMsgView"
  ];
  const MAIL_LIST_ROW_SELECTORS = [
    "div[role='main'] tr.zA",
    "div[role='main'] tr[jscontroller]",
    "div[role='main'] table[role='grid'] tr",
    "div[role='main'] .Cp tr",
    "div[role='main'] tr[role='row']",
    "div[role='main'] div[role='row']",
    "main tr[role='row']",
    "main div[role='row']",
    "main li[role='row']",
    "[data-testid='message-list-item']",
    "[data-test-id='message-list-item']",
    "[data-testid='conversation-list'] [role='row']",
    "[data-test-id='conversation-list'] [role='row']",
    ".mail-item",
    ".message-list-item",
    "tr.message",
    "tr.mail"
  ];
  const MAIL_LIST_SENDER_SELECTORS = [
    "span[email]",
    "[email]",
    "[data-email]",
    "[data-address]",
    "[title*='@']",
    "[aria-label*='@']",
    "[data-testid*='sender']",
    "[data-test-id*='sender']",
    "[data-testid*='from']",
    "[data-test-id*='from']",
    ".from a[href^='mailto:']",
    ".sender [title*='@']",
    ".mail-sender [title*='@']",
    ".addr[title*='@']"
  ];
  const state = {
    rules: defaultRules,
    showTrustedBadges: true,
    greenFlagSenderDomains: new Set(),
    trustedSenderSites: [],
    dismissedWarnings: new Set(),
    badgeTooltip: null,
    activeBadge: null,
    scanTimer: null,
    skipNextRuleChangeScan: false
  };
  const BADGE_SOURCE_MARK = "🐟";

  if (!detector || !extensionApi?.storage) {
    return;
  }

  function storageGet(defaults) {
    const result = extensionApi.storage.sync.get(defaults);
    if (result && typeof result.then === "function") {
      return result;
    }

    return new Promise((resolve) => extensionApi.storage.sync.get(defaults, resolve));
  }

  function storageSet(values) {
    const result = extensionApi.storage.sync.set(values);
    if (result && typeof result.then === "function") {
      return result;
    }

    return new Promise((resolve) => extensionApi.storage.sync.set(values, resolve));
  }

  function normalizeGreenFlagSenderDomains(domains) {
    const normalizedDomains = new Set();
    if (!Array.isArray(domains)) {
      return normalizedDomains;
    }

    domains.forEach((domain) => {
      const normalized = detector.normalizeDomain(domain);
      if (normalized) {
        normalizedDomains.add(normalized);
      }
    });

    return normalizedDomains;
  }

  function normalizeTrustedSenderSites(records) {
    const normalizedRecords = [];
    const seen = new Set();
    if (!Array.isArray(records)) {
      return normalizedRecords;
    }

    records.forEach((record) => {
      if (!record || typeof record !== "object") {
        return;
      }

      const senderEmail = detector.extractEmail(record.senderEmail || "");
      const senderDomain = detector.normalizeDomain(record.senderDomain || senderEmail);
      const urlDomain = detector.normalizeDomain(record.urlDomain);
      if (!senderDomain || !urlDomain) {
        return;
      }

      const key = `${senderEmail}:${senderDomain}:${urlDomain}`;
      if (seen.has(key)) {
        return;
      }

      seen.add(key);
      normalizedRecords.push({ senderEmail, senderDomain, urlDomain });
    });

    return normalizedRecords.sort((first, second) =>
      `${first.senderDomain}:${first.urlDomain}`.localeCompare(`${second.senderDomain}:${second.urlDomain}`)
    );
  }

  function mergeSavedRules(rules) {
    const merged = detector.mergeDefaultRuleUpdates
      ? detector.mergeDefaultRuleUpdates(rules, defaultRules)
      : rules;
    return detector.validateRules(merged).ok ? merged : defaultRules;
  }

  async function loadSettings() {
    const saved = await storageGet({
      byebyefishingRules: defaultRules,
      byebyefishingRulesCustom: false,
      byebyefishingRulesVersion: "",
      byebyefishingShowTrustedBadges: true,
      byebyefishingGreenFlagSenderDomains: [],
      byebyefishingTrustedSenderSites: []
    });

    const validation = detector.validateRules(saved.byebyefishingRules);
    const shouldUseSavedRules =
      validation.ok && (saved.byebyefishingRulesCustom || saved.byebyefishingRulesVersion === rulesetVersion);
    state.rules = shouldUseSavedRules ? mergeSavedRules(saved.byebyefishingRules) : defaultRules;
    state.showTrustedBadges = saved.byebyefishingShowTrustedBadges !== false;
    state.greenFlagSenderDomains = normalizeGreenFlagSenderDomains(saved.byebyefishingGreenFlagSenderDomains);
    state.trustedSenderSites = normalizeTrustedSenderSites(saved.byebyefishingTrustedSenderSites);
  }

  function isVisibleElement(element) {
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function normalizeUiText(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function visibleText(element) {
    return (element.innerText || element.textContent || "").replace(/\s+/g, " ").trim();
  }

  function isRecipientMetadataCandidate(element) {
    const label = normalizeUiText(visibleText(element));
    const title = normalizeUiText(element.getAttribute("title") || element.getAttribute("aria-label"));
    const recipientLabels = new Set(["a moi", "moi", "to me", "me", "for me", "pour moi", "para mi"]);

    return recipientLabels.has(label) || recipientLabels.has(title);
  }

  function messageScopeFor(element) {
    const scope = element.closest(MESSAGE_SCOPE_SELECTORS.join(","));
    return scope instanceof HTMLElement ? scope : element;
  }

  function collectMessageScopes(contentCandidates) {
    const seen = new Set();
    const scopes = [];

    for (const candidate of contentCandidates) {
      const scope = messageScopeFor(candidate.element);
      if (seen.has(scope) || !isVisibleElement(scope)) {
        continue;
      }
      seen.add(scope);
      scopes.push(scope);
    }

    return scopes.slice(0, 6);
  }

  function candidateText(element) {
    const parts = [
      element.getAttribute("name"),
      element.getAttribute("email"),
      element.getAttribute("data-email"),
      element.getAttribute("data-address"),
      element.getAttribute("title"),
      element.getAttribute("aria-label"),
      element.getAttribute("href"),
      visibleText(element)
    ].filter(Boolean);

    return parts.join(" ");
  }

  function isReadableSenderCandidate(element) {
    return (
      element instanceof HTMLElement &&
      isVisibleElement(element) &&
      !isRecipientMetadataCandidate(element) &&
      candidateText(element).includes("@")
    );
  }

  function collectSenderCandidates(scopes) {
    const selectors = [
      "[email]",
      "[data-email]",
      "[data-address]",
      "[title*='@']",
      "[aria-label*='@']",
      "[data-testid*='sender']",
      "[data-test-id*='sender']",
      "[data-testid*='from']",
      "[data-test-id*='from']",
      "a[href^='mailto:']"
    ];

    const seen = new Set();
    const candidates = [];

    for (const scope of scopes) {
      scope.querySelectorAll(selectors.join(",")).forEach((element) => {
        if (!(element instanceof HTMLElement) || seen.has(element)) {
          return;
        }
        seen.add(element);

        if (!isReadableSenderCandidate(element)) {
          return;
        }

        candidates.push({ element, text: candidateText(element) });
      });
    }

    return candidates;
  }

  function collectLinkCandidates(scopes) {
    const seen = new Set();
    const candidates = [];

    for (const scope of scopes) {
      scope.querySelectorAll("a[href]").forEach((element) => {
        if (!(element instanceof HTMLAnchorElement)) {
          return;
        }

        const href = element.href || element.getAttribute("href") || "";
        if (!/^https?:\/\//i.test(href) || seen.has(href)) {
          return;
        }
        seen.add(href);

        if (!isVisibleElement(element)) {
          return;
        }

        candidates.push({
          element,
          href,
          text: (element.innerText || element.textContent || "").replace(/\s+/g, " ").trim()
        });
      });
    }

    return candidates.slice(0, 30);
  }

  function collectContentCandidates() {
    const seen = new Set();
    const candidates = [];

    document.querySelectorAll(MESSAGE_BODY_SELECTORS.join(",")).forEach((element) => {
      if (!(element instanceof HTMLElement) || seen.has(element) || element.closest(".byebyefishing-warning")) {
        return;
      }
      seen.add(element);

      const text = (element.innerText || element.textContent || "").replace(/\s+/g, " ").trim();
      if (!isVisibleElement(element) || text.length < 40 || text.length > 20000) {
        return;
      }

      candidates.push({ element, text });
    });

    return candidates.slice(0, 6);
  }

  function collectMailListSenderCandidates() {
    const seenRows = new Set();
    const seenElements = new Set();
    const candidates = [];

    function addRowCandidate(row) {
      if (!(row instanceof HTMLElement) || seenRows.has(row) || !isVisibleElement(row)) {
        return;
      }
      seenRows.add(row);

      let senderElement = null;
      for (const selector of MAIL_LIST_SENDER_SELECTORS) {
        const element = row.querySelector(selector);
        if (!(element instanceof HTMLElement) || seenElements.has(element) || !isReadableSenderCandidate(element)) {
          continue;
        }

        const text = candidateText(element);
        senderElement = element;
        break;
      }

      if (!senderElement) {
        return;
      }

      seenElements.add(senderElement);
      candidates.push({ element: senderElement, text: candidateText(senderElement) });
    }

    document.querySelectorAll(MAIL_LIST_ROW_SELECTORS.join(",")).forEach(addRowCandidate);

    const main = document.querySelector("div[role='main'], main");
    if (main instanceof HTMLElement) {
      main.querySelectorAll(MAIL_LIST_SENDER_SELECTORS.join(",")).forEach((element) => {
        if (!(element instanceof HTMLElement) || seenElements.has(element) || !isReadableSenderCandidate(element)) {
          return;
        }

        const text = candidateText(element);
        const row = element.closest("tr.zA, tr[role='row'], div[role='row']");
        if (!(row instanceof HTMLElement)) {
          return;
        }

        seenElements.add(element);
        seenRows.add(row);
        candidates.push({ element, text });
      });
    }

    return candidates.slice(0, 80);
  }

  function warningRank(result) {
    if (result.severity === "critical") {
      return 4;
    }
    if (result.severity === "high") {
      return 3;
    }
    if (result.severity === "medium") {
      return 2;
    }
    return result.status === "warning" ? 1 : 0;
  }

  function warningTiePriority(result) {
    if (result.context === "hosted-platform-link") {
      return 2;
    }
    if (result.urlDomain) {
      return 1;
    }
    if (result.context === "professional-sender-check") {
      return -1;
    }
    return 0;
  }

  function shouldReplaceGlobalWarning(candidate, current) {
    if (!shouldRenderGlobalWarning(candidate)) {
      return false;
    }
    if (!current) {
      return true;
    }

    const candidateRank = warningRank(candidate);
    const currentRank = warningRank(current);
    if (candidateRank !== currentRank) {
      return candidateRank > currentRank;
    }

    return warningTiePriority(candidate) > warningTiePriority(current);
  }

  function severityLabel(severity) {
    if (severity === "critical") {
      return "Likely phishing";
    }
    if (severity === "high") {
      return "High risk";
    }
    if (severity === "medium") {
      return "Check carefully";
    }
    return "Notice";
  }

  function warningTitle(result) {
    if (result.context === "trusted-sender-payment") {
      return "Money moment";
    }
    if (result.context === "trusted-sender-content-check") {
      return "Check this official message";
    }
    if (result.context === "trusted-sender-link-check") {
      return "Double-check this link";
    }
    if (result.context === "hosted-platform-link") {
      return "Shared page check";
    }
    if (result.context === "professional-sender-check") {
      return "Verify this sender";
    }
    if (result.urlDomain && result.severity === "critical") {
      return "Pause before opening this link";
    }
    if (result.urlDomain && result.severity === "high") {
      return "Check this link first";
    }
    if (result.urlDomain) {
      return "Unusual link";
    }
    if (result.severity === "critical") {
      return "Pause before acting";
    }
    if (result.severity === "high") {
      return "Verify before acting";
    }
    if (result.severity === "medium") {
      return "Verify before acting";
    }
    return "Check before acting";
  }

  function trustedSenderContext(result) {
    if (result.status !== "trusted" || result.context === "known-sender") {
      return null;
    }

    return {
      brandId: result.brandId || "",
      brand: result.brand || "",
      senderDomain: result.senderDomain || ""
    };
  }

  function displaySenderDomain(domain) {
    const normalized = detector.normalizeDomain(domain);
    return normalized ? `${normalized.charAt(0).toUpperCase()}${normalized.slice(1)}` : "";
  }

  function isNumericAddress(value) {
    return /^\d{1,3}(?:\.\d{1,3}){3}$/.test(String(value || "").trim());
  }

  function senderLabel(result) {
    return result.senderEmail || result.senderDomain || "this sender";
  }

  function createInlineEntity(text, tone = "sender") {
    const entity = document.createElement("span");
    entity.className = `byebyefishing-warning__entity byebyefishing-warning__entity--${tone}`;
    entity.textContent = text;
    return entity;
  }

  function senderDomainIsGreenFlagged(senderDomain) {
    const normalized = detector.normalizeDomain(senderDomain);
    if (!normalized || state.greenFlagSenderDomains.size === 0) {
      return false;
    }

    return [...state.greenFlagSenderDomains].some((greenFlaggedDomain) =>
      detector.domainMatchesAllowed(normalized, greenFlaggedDomain)
    );
  }

  function withGreenFlagSenderResult(result) {
    const sender = senderIdentityFromResult(result);
    if (
      result.status !== "warning" ||
      result.brandId ||
      (!senderDomainIsGreenFlagged(result.senderDomain) && !senderIsKnownFromTrustedSite(sender))
    ) {
      return result;
    }

    return {
      ...result,
      status: "trusted",
      severity: "none",
      context: "known-sender",
      allowedDomains: [],
      message: `Sender you know: ${result.senderDomain}.`
    };
  }

  function senderIdentityFromResult(result) {
    const senderEmail = detector.extractEmail(result?.senderEmail || "");
    const senderDomain = detector.normalizeDomain(result?.senderDomain || senderEmail);
    if (!senderDomain) {
      return null;
    }

    return { senderEmail, senderDomain };
  }

  function senderSiteRecordMatches(record, sender, urlDomain) {
    const normalizedUrlDomain = detector.normalizeDomain(urlDomain);
    if (!record || !sender || !normalizedUrlDomain) {
      return false;
    }

    const senderMatches = record.senderEmail
      ? record.senderEmail === sender.senderEmail
      : detector.domainMatchesAllowed(sender.senderDomain, record.senderDomain);
    return senderMatches && detector.domainMatchesAllowed(normalizedUrlDomain, record.urlDomain);
  }

  function senderIsKnownFromTrustedSite(sender) {
    if (!sender) {
      return false;
    }

    return state.trustedSenderSites.some((record) =>
      record.senderEmail
        ? record.senderEmail === sender.senderEmail
        : detector.domainMatchesAllowed(sender.senderDomain, record.senderDomain)
    );
  }

  function withTrustedSenderSiteResult(result, sender) {
    const urlDomain = detector.normalizeDomain(result?.urlDomain);
    const canUseSenderSiteMemory =
      result.context === "hosted-platform-link" ||
      (result.context === "generic-domain-risk" && result.severity !== "critical");
    if (
      result.status !== "warning" ||
      !canUseSenderSiteMemory ||
      result.displayedDomain ||
      !urlDomain ||
      !sender
    ) {
      return result;
    }

    const trustedSite = state.trustedSenderSites.find((record) =>
      senderSiteRecordMatches(record, sender, urlDomain)
    );
    if (!trustedSite) {
      return result;
    }

    return {
      ...result,
      severity: "low",
      context: "trusted-sender-site",
      senderEmail: sender.senderEmail,
      senderDomain: sender.senderDomain,
      message: `${urlDomain} is remembered for ${sender.senderEmail || sender.senderDomain}. Bye bye Fishing will still warn about unexpected payment, login, code, or personal-information requests.`
    };
  }

  function withTrustedSenderLinkCheckResult(result, trustedSender) {
    const urlDomain = detector.normalizeDomain(result?.urlDomain);
    const sameTrustedBrand =
      result?.brandId &&
      trustedSender?.brandId &&
      result.brandId === trustedSender.brandId;
    const isSameBrandShortcut =
      result?.context === "unverified-brand-domain" &&
      sameTrustedBrand;
    const isOrdinaryUnusualLink =
      result?.context === "generic-domain-risk" &&
      result.severity === "medium";
    if (
      result?.status !== "warning" ||
      (!isSameBrandShortcut && !isOrdinaryUnusualLink) ||
      result.displayedDomain ||
      result.severity === "critical" ||
      !urlDomain ||
      !trustedSender
    ) {
      return result;
    }

    const senderName = trustedSender.brand || trustedSender.senderDomain || "this sender";
    const message = isSameBrandShortcut
      ? `${urlDomain} is not in the trusted ${senderName} domain list. Double-check that you expected this link before using it.`
      : `${urlDomain} looks unusual, but the sender is an official ${senderName} sender. Double-check that you expected this link before using it.`;
    return {
      ...result,
      severity: "low",
      context: "trusted-sender-link-check",
      trustedSenderBrand: trustedSender.brand || "",
      trustedSenderDomain: trustedSender.senderDomain || "",
      message
    };
  }

  function canRememberSenderWarning(result) {
    return Boolean(
      !result.brandId &&
        !result.urlDomain &&
        detector.normalizeDomain(result.senderDomain) &&
        (result.context === "professional-sender-check" || result.context === "generic-domain-risk")
    );
  }

  async function rememberKnownSenderDomain(senderDomain) {
    const normalized = detector.normalizeDomain(senderDomain);
    if (!normalized) {
      return;
    }

    state.greenFlagSenderDomains.add(normalized);
    await storageSet({
      byebyefishingGreenFlagSenderDomains: [...state.greenFlagSenderDomains].sort()
    });
    removeGlobalWarning();
    scheduleScan();
  }

  function ruleForResult(result) {
    if (!result?.brandId) {
      return null;
    }

    return state.rules.find((rule) => rule.id === result.brandId) || null;
  }

  function domainListNameForSenderTrust(rule) {
    return Array.isArray(rule?.senderDomains) ? "senderDomains" : "allowedDomains";
  }

  function canTrustSenderDomain(result) {
    return Boolean(
      result?.status === "warning" &&
        result.brandId &&
        !result.urlDomain &&
        detector.normalizeDomain(result.senderDomain) &&
        ruleForResult(result)
    );
  }

  function canTrustSiteForSender(result) {
    return Boolean(
      result?.status === "warning" &&
        (result.context === "hosted-platform-link" ||
          (result.context === "generic-domain-risk" && result.severity !== "critical")) &&
        !result.displayedDomain &&
        detector.normalizeDomain(result.urlDomain) &&
        detector.normalizeDomain(result.senderDomain)
    );
  }

  async function saveRules(rules) {
    const validation = detector.validateRules(rules);
    if (!validation.ok) {
      throw new Error(validation.error || "Trusted-domain rules are invalid.");
    }

    state.rules = rules;
    state.skipNextRuleChangeScan = true;
    await storageSet({
      byebyefishingRules: rules,
      byebyefishingRulesCustom: true,
      byebyefishingRulesVersion: rulesetVersion
    });
  }

  async function trustSenderDomainForResult(result) {
    const domain = detector.normalizeDomain(result.senderDomain);
    const rule = ruleForResult(result);
    if (!domain || !rule || !detector.addTrustedDomainToRule) {
      return null;
    }

    const previousRules = state.rules;
    const listName = domainListNameForSenderTrust(rule);
    const nextRules = detector.addTrustedDomainToRule(state.rules, rule.id, domain, listName);
    await saveRules(nextRules);

    return { domain, previousRules };
  }

  async function undoTrustRules(previousRules) {
    if (!previousRules) {
      return;
    }

    await saveRules(previousRules);
    scheduleScan();
  }

  async function trustSiteForSender(result) {
    const sender = senderIdentityFromResult(result);
    const urlDomain = detector.normalizeDomain(result.urlDomain);
    if (!sender || !urlDomain) {
      return null;
    }

    const previousSites = state.trustedSenderSites;
    const nextSites = normalizeTrustedSenderSites([
      ...state.trustedSenderSites,
      {
        senderEmail: sender.senderEmail,
        senderDomain: sender.senderDomain,
        urlDomain
      }
    ]);

    state.trustedSenderSites = nextSites;
    await storageSet({
      byebyefishingTrustedSenderSites: nextSites
    });

    return { sender, urlDomain, previousSites };
  }

  async function undoTrustedSenderSites(previousSites) {
    state.trustedSenderSites = normalizeTrustedSenderSites(previousSites);
    await storageSet({
      byebyefishingTrustedSenderSites: state.trustedSenderSites
    });
    scheduleScan();
  }

  function showTrustSuccess(controls, message, previousRules) {
    controls.textContent = "";

    const status = document.createElement("span");
    status.className = "byebyefishing-warning__saved";
    status.textContent = message;

    const undo = document.createElement("button");
    undo.type = "button";
    undo.className = "byebyefishing-warning__secondary-action";
    undo.textContent = "Undo";
    undo.addEventListener("click", () => {
      undo.disabled = true;
      undoTrustRules(previousRules).catch(() => {
        undo.disabled = false;
      });
    });

    const done = document.createElement("button");
    done.type = "button";
    done.className = "byebyefishing-warning__secondary-action";
    done.textContent = "Done";
    done.addEventListener("click", () => {
      removeGlobalWarning();
      scheduleScan();
    });

    controls.append(status, undo, done);
  }

  function showSiteTrustSuccess(controls, message, previousSites) {
    controls.textContent = "";

    const status = document.createElement("span");
    status.className = "byebyefishing-warning__saved";
    status.textContent = message;

    const undo = document.createElement("button");
    undo.type = "button";
    undo.className = "byebyefishing-warning__secondary-action";
    undo.textContent = "Undo";
    undo.addEventListener("click", () => {
      undo.disabled = true;
      undoTrustedSenderSites(previousSites).catch(() => {
        undo.disabled = false;
      });
    });

    const done = document.createElement("button");
    done.type = "button";
    done.className = "byebyefishing-warning__secondary-action";
    done.textContent = "Done";
    done.addEventListener("click", () => {
      removeGlobalWarning();
      scheduleScan();
    });

    controls.append(status, undo, done);
  }

  function renderTrustConfirmation(controls, result) {
    const existing = controls.querySelector(".byebyefishing-warning__confirm");
    if (existing) {
      existing.remove();
      return;
    }

    const domain = detector.normalizeDomain(result.senderDomain);
    const confirm = document.createElement("div");
    confirm.className = "byebyefishing-warning__confirm";

    const copy = document.createElement("p");
    copy.textContent = `Trust ${domain} for ${result.brand} only after you checked it through the app, website, or another source you know. Future mail from this address will look familiar for that brand.`;

    const actions = document.createElement("div");
    actions.className = "byebyefishing-warning__confirm-actions";

    const trust = document.createElement("button");
    trust.type = "button";
    trust.className = "byebyefishing-warning__danger-action";
    trust.textContent = "I checked it";
    trust.addEventListener("click", () => {
      trust.disabled = true;
      trustSenderDomainForResult(result)
        .then((saved) => {
          if (saved) {
            showTrustSuccess(controls, `Saved. ${saved.domain} is now familiar for ${result.brand}.`, saved.previousRules);
          }
        })
        .catch(() => {
          trust.disabled = false;
        });
    });

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "byebyefishing-warning__secondary-action";
    cancel.textContent = "Cancel";
    cancel.addEventListener("click", () => confirm.remove());

    actions.append(trust, cancel);
    confirm.append(copy, actions);
    controls.append(confirm);
  }

  function renderRememberSenderConfirmation(controls, senderDomain) {
    const existing = controls.querySelector(".byebyefishing-warning__confirm");
    if (existing) {
      existing.remove();
      return;
    }

    const domain = detector.normalizeDomain(senderDomain);
    const confirm = document.createElement("div");
    confirm.className = "byebyefishing-warning__confirm";

    const copy = document.createElement("p");
    copy.textContent = `Remember ${domain} only if you know this sender and expected this message. Bye bye Fishing will stop showing this sender check for ${domain}, but it will still warn about known brands, passwords, payments, codes, or personal information.`;

    const actions = document.createElement("div");
    actions.className = "byebyefishing-warning__confirm-actions";

    const remember = document.createElement("button");
    remember.type = "button";
    remember.className = "byebyefishing-warning__danger-action";
    remember.textContent = "Remember this sender";
    remember.addEventListener("click", () => {
      remember.disabled = true;
      rememberKnownSenderDomain(domain).catch(() => {
        remember.disabled = false;
      });
    });

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "byebyefishing-warning__secondary-action";
    cancel.textContent = "Cancel";
    cancel.addEventListener("click", () => confirm.remove());

    actions.append(remember, cancel);
    confirm.append(copy, actions);
    controls.append(confirm);
  }

  function renderTrustSiteConfirmation(controls, result) {
    const existing = controls.querySelector(".byebyefishing-warning__confirm");
    if (existing) {
      existing.remove();
      return;
    }

    const sender = result.senderEmail || result.senderDomain;
    const urlDomain = detector.normalizeDomain(result.urlDomain);
    const confirm = document.createElement("div");
    confirm.className = "byebyefishing-warning__confirm";

    const copy = document.createElement("p");
    copy.textContent = `Use this only if you know ${sender} and expected links to ${urlDomain}. Bye bye Fishing will remember this link only for this sender, and will still warn about passwords, payments, codes, personal information, misleading links, or messages that pretend to be known brands.`;

    const actions = document.createElement("div");
    actions.className = "byebyefishing-warning__confirm-actions";

    const trust = document.createElement("button");
    trust.type = "button";
    trust.className = "byebyefishing-warning__danger-action";
    trust.textContent = "Remember this link";
    trust.addEventListener("click", () => {
      trust.disabled = true;
      trustSiteForSender(result)
        .then((saved) => {
          if (saved) {
            showSiteTrustSuccess(
              controls,
              `Saved. ${saved.urlDomain} is now familiar for ${saved.sender.senderEmail || saved.sender.senderDomain}.`,
              saved.previousSites
            );
          }
        })
        .catch(() => {
          trust.disabled = false;
        });
    });

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "byebyefishing-warning__secondary-action";
    cancel.textContent = "Cancel";
    cancel.addEventListener("click", () => confirm.remove());

    actions.append(trust, cancel);
    confirm.append(copy, actions);
    controls.append(confirm);
  }

  function warningDetail(result, allowed) {
    if (result.context === "trusted-sender-payment") {
      return result.senderDomain
        ? `Official sender: ${result.senderDomain}`
        : result.brand
          ? `Official ${result.brand} sender.`
          : "Official sender.";
    }
    if (result.context === "trusted-sender-content-check") {
      return result.senderDomain
        ? `Official sender: ${result.senderDomain}`
        : result.brand
          ? `Official ${result.brand} sender.`
          : "Official sender.";
    }
    if (result.context === "trusted-sender-link-check") {
      return result.urlDomain ? `Destination: ${result.urlDomain}` : "Use it only if you expected this link.";
    }
    if (result.context === "hosted-platform-link") {
      return result.urlDomain ? `Shared page: ${result.urlDomain}` : "Open it only if you expected this page.";
    }
    if (result.context === "professional-sender-check") {
      return result.reason ? `Why: the address ${result.reason}.` : "Check that you recognize the sender.";
    }
    if (result.urlDomain) {
      return isNumericAddress(result.urlDomain)
        ? `Destination is a numeric IP address: ${result.urlDomain}`
        : `Destination: ${result.urlDomain}`;
    }

    if (result.severity === "critical") {
      return allowed
        ? `Known domains in your safety list: ${allowed}`
        : "You can use the official app or contact the sender another way.";
    }

    return allowed ? `Known examples: ${allowed}` : "Check that this message matches what you expected.";
  }

  function warningActionText(result) {
    if (result.context === "trusted-sender-payment") {
      return "Pay only if this matches something you just did.";
    }
    if (result.context === "trusted-sender-content-check") {
      return "Use your usual app or website if anything feels off.";
    }
    if (result.context === "trusted-sender-link-check") {
      return "Use it only if this destination matches what you expected.";
    }
    if (result.context === "hosted-platform-link") {
      return "Avoid passwords, codes, or payment details on this page.";
    }
    if (result.context === "professional-sender-check") {
      return "Check the sender before replying, opening files, or following links.";
    }
    if (result.severity === "critical") {
      return "To stay safe, don't use links in the email. Open the official app or website yourself.";
    }
    if (result.severity === "high") {
      return "Check another way before clicking or paying.";
    }
    if (result.urlDomain) {
      return "Don't use this link for login, payment, or personal details. Open the site directly if needed.";
    }
    return "Check another way before acting.";
  }

  function warningVerdict(result) {
    if (result.context === "trusted-sender-payment") {
      return "The sender looks familiar, but this asks for money or account access.";
    }
    if (result.context === "trusted-sender-content-check") {
      return "The sender is trusted, but the message includes safety-sensitive wording.";
    }
    if (result.context === "trusted-sender-link-check") {
      return "The sender looks familiar, but this destination is not on the trusted domain list.";
    }
    if (result.context === "hosted-platform-link") {
      return result.brand
        ? `This page was made with ${result.brand}, where anyone can create a page.`
        : "This page was made with a public website builder.";
    }
    if (result.context === "professional-sender-check") {
      return result.reason
        ? `This sender address ${result.reason}.`
        : `${senderLabel(result)} needs a quick check.`;
    }
    if (result.context === "generic-domain-risk" && result.senderDomain && !result.urlDomain) {
      return result.message && /sensitive wording/i.test(result.message)
        ? "This sender address looks unusual, and the message uses sensitive wording."
        : "This sender address looks unusual.";
    }
    if (result.urlDomain && isNumericAddress(result.urlDomain)) {
      return "This link uses a numeric IP address instead of a normal website name.";
    }
    if (result.urlDomain && result.severity === "critical") {
      return "This link can be used to fake delivery, payment, or login pages.";
    }
    if (result.urlDomain && result.severity === "high") {
      return "This link has a suspicious destination.";
    }
    if (result.urlDomain) {
      return "This link goes somewhere unusual.";
    }
    if (result.brand && result.senderDomain && result.severity === "critical") {
      return `This looks like it may be from ${result.brand}, but email addresses can be faked.`;
    }
    if (result.brand && result.urlDomain && result.severity === "critical") {
      return `This does not look like ${result.brand}'s familiar site.`;
    }
    if (result.severity === "critical") {
      return "This message looks risky.";
    }
    if (result.severity === "high") {
      return "This message has risky signs.";
    }
    return warningTitle(result);
  }

  function appendProfessionalSenderVerdict(verdict, result) {
    if (!result.reason) {
      verdict.textContent = `${senderLabel(result)} needs a quick check.`;
      return;
    }

    const extensionMatch = result.reason.match(/^(uses the uncommon )(\.[a-z0-9-]+ extension)$/i);
    verdict.append("This sender address ");
    if (extensionMatch) {
      verdict.append(extensionMatch[1], createInlineEntity(extensionMatch[2], "reason"), ".");
      return;
    }

    verdict.append(createInlineEntity(result.reason, "reason"), ".");
  }

  function appendWarningContext(message, result, contextText) {
    if (result.context === "professional-sender-check") {
      message.append(" Sender: ", createInlineEntity(senderLabel(result), "sender"), ".");
      return;
    }

    if (result.brand && result.senderDomain) {
      message.append(" It came from ", createInlineEntity(result.senderDomain, "sender"), ".");
      return;
    }

    message.append(contextText.startsWith(" ") ? contextText : ` ${contextText}`);
  }

  function warningContextText(result) {
    if (result.context === "professional-sender-check") {
      return "Sender:";
    }
    if (result.context === "hosted-platform-link") {
      const sender = result.senderEmail || result.senderDomain;
      return sender
        ? ` Open it only if you expected it from ${sender}.`
        : " Open it only if you expected it.";
    }
    if (result.brand && result.senderDomain) {
      return "It came from:";
    }

    const message = (result.message || "")
      .replace(/^Likely phishing:\s*/i, "")
      .replace(/^the\b/, "The")
      .replace(/\s*Do not enter delivery, payment, or login information there\.$/i, "")
      .replace(/\s*Do not click links, pay, or enter personal information\.$/i, "")
      .replace(/\s*Do not click links or enter delivery\/payment information\.$/i, "")
      .replace(/\s*Don't use links in this message or share personal information\.$/i, "")
      .replace(/\s*Don't use links in the message for delivery, payment, or login details\.$/i, "")
      .trim();
    return message;
  }

  function warningKey(result) {
    return `${result.brand || "generic"}:${result.senderDomain || result.urlDomain || result.score || "unknown"}`;
  }

  function removeGlobalWarning() {
    document.querySelectorAll(".byebyefishing-warning").forEach((node) => node.remove());
  }

  function warningSignature(result) {
    const allowed = (result.allowedDomains || []).slice(0, 4).join(", ");
    return [
      warningKey(result),
      result.severity || "low",
      result.context || "",
      result.reason || "",
      warningTitle(result),
      result.message || "",
      allowed
    ].join("\n");
  }

  function renderWarning(result) {
    const key = warningKey(result);
    if (state.dismissedWarnings.has(key)) {
      removeGlobalWarning();
      return;
    }

    let banner = document.querySelector(".byebyefishing-warning");
    const signature = warningSignature(result);
    if (banner?.dataset.byebyefishingSignature === signature) {
      return;
    }

    if (!banner) {
      banner = document.createElement("aside");
      banner.setAttribute("role", "alert");
      document.documentElement.appendChild(banner);
    }
    banner.className = `byebyefishing-warning byebyefishing-warning--${result.severity || "low"}`;
    banner.dataset.byebyefishingSignature = signature;

    const allowed = (result.allowedDomains || []).slice(0, 4).join(", ");
    banner.innerHTML = "";

    const content = document.createElement("div");
    content.className = "byebyefishing-warning__content";

    const header = document.createElement("div");
    header.className = "byebyefishing-warning__header";

    const heading = document.createElement("div");
    heading.className = "byebyefishing-warning__heading";

    const title = document.createElement("strong");
    title.textContent = warningTitle(result);
    heading.append(title);
    header.append(heading);

    const message = document.createElement("p");
    message.className = "byebyefishing-warning__message";

    const verdict = document.createElement("strong");
    verdict.className = "byebyefishing-warning__verdict";
    if (result.context === "professional-sender-check") {
      appendProfessionalSenderVerdict(verdict, result);
    } else {
      verdict.textContent = warningVerdict(result);
    }

    const contextText = warningContextText(result);
    if (contextText) {
      const context = document.createElement("span");
      appendWarningContext(context, result, contextText);
      message.append(verdict, context);
    } else {
      message.append(verdict);
    }

    const action = document.createElement("strong");
    action.className = "byebyefishing-warning__action";
    action.textContent = warningActionText(result);

    const detail = document.createElement("span");
    detail.textContent = warningDetail(result, allowed);

    const controls = document.createElement("div");
    controls.className = "byebyefishing-warning__controls";
    if (canTrustSiteForSender(result)) {
      const trustSite = document.createElement("button");
      trustSite.type = "button";
      trustSite.className = "byebyefishing-warning__trust-domain";
      trustSite.textContent = "I expected this link from this sender";
      trustSite.title = `Remember ${detector.normalizeDomain(result.urlDomain)} for ${
        result.senderEmail || result.senderDomain
      }`;
      trustSite.addEventListener("click", () => renderTrustSiteConfirmation(controls, result));
      controls.append(trustSite);
    }

    if (canTrustSenderDomain(result)) {
      const senderDomain = detector.normalizeDomain(result.senderDomain);
      const trustSender = document.createElement("button");
      trustSender.type = "button";
      trustSender.className = "byebyefishing-warning__trust-domain";
      trustSender.textContent = "Trust this sender";
      trustSender.title = `Remember ${displaySenderDomain(senderDomain)} for ${result.brand}`;
      trustSender.setAttribute(
        "aria-label",
        `Trust ${displaySenderDomain(senderDomain)} for ${result.brand}`
      );
      trustSender.addEventListener("click", () => renderTrustConfirmation(controls, result));
      controls.append(trustSender);
    }

    if (canRememberSenderWarning(result)) {
      const senderDomain = detector.normalizeDomain(result.senderDomain);
      const rememberSender = document.createElement("button");
      rememberSender.type = "button";
      rememberSender.className = "byebyefishing-warning__trust-domain";
      rememberSender.textContent = "This is a sender I know";
      rememberSender.title = `Remember checks for ${displaySenderDomain(senderDomain)}`;
      rememberSender.setAttribute(
        "aria-label",
        `Remember ${displaySenderDomain(senderDomain)} as a sender you know`
      );
      rememberSender.addEventListener("click", () => renderRememberSenderConfirmation(controls, senderDomain));
      controls.append(rememberSender);
    }

    const close = document.createElement("button");
    close.type = "button";
    close.className = "byebyefishing-warning__close";
    close.setAttribute("aria-label", "Dismiss safety note");
    close.textContent = "x";
    close.addEventListener("click", () => {
      state.dismissedWarnings.add(key);
      banner.remove();
    });

    content.append(header, message, action, detail);
    if (controls.childElementCount > 0) {
      content.append(controls);
    }
    banner.append(content, close);
  }

  function badgeInfo(result) {
    if (result.status === "trusted") {
      return { label: "trusted", tone: "trusted" };
    }
    if (result.context === "trusted-sender-content-check" || result.context === "trusted-sender-link-check") {
      return { label: "double check", tone: "risk" };
    }
    if (result.status === "warning" && (result.severity === "critical" || result.severity === "high")) {
      return { label: "high risk", tone: "high-risk" };
    }
    if (result.status === "warning") {
      return { label: "risk", tone: "risk" };
    }
    return null;
  }

  function badgeSignature(result) {
    const info = badgeInfo(result);
    if (!info) {
      return "";
    }
    return [info.tone, info.label, result.message || ""].join("\n");
  }

  function ensureBadgeTooltip() {
    if (state.badgeTooltip?.isConnected) {
      return state.badgeTooltip;
    }

    const tooltip = document.createElement("div");
    tooltip.id = "byebyefishing-badge-tooltip";
    tooltip.className = "byebyefishing-badge-tooltip";
    tooltip.setAttribute("role", "tooltip");
    document.body.append(tooltip);
    state.badgeTooltip = tooltip;
    return tooltip;
  }

  function positionBadgeTooltip(badge, tooltip) {
    const badgeRect = badge.getBoundingClientRect();
    const tooltipRect = tooltip.getBoundingClientRect();
    const spacing = 6;
    const padding = 8;
    const maxLeft = window.innerWidth - tooltipRect.width - padding;
    const centeredLeft = badgeRect.left + badgeRect.width / 2 - tooltipRect.width / 2;
    const left = Math.max(padding, Math.min(centeredLeft, maxLeft));
    let top = badgeRect.bottom + spacing;

    if (top + tooltipRect.height + padding > window.innerHeight) {
      top = Math.max(padding, badgeRect.top - tooltipRect.height - spacing);
    }

    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;
  }

  function showBadgeTooltip(badge) {
    const detail = badge.dataset.byebyefishingDetail || "";
    if (!detail) {
      if (state.activeBadge === badge) {
        hideBadgeTooltip();
      }
      return;
    }

    const tooltip = ensureBadgeTooltip();
    tooltip.textContent = "";
    tooltip.append(document.createTextNode(detail));
    if (badge.dataset.byebyefishingSourceMark === "true") {
      const source = document.createElement("span");
      source.className = "byebyefishing-badge-tooltip__source";
      source.setAttribute("aria-hidden", "true");
      source.textContent = BADGE_SOURCE_MARK;
      tooltip.append(source);
    }
    tooltip.classList.remove("byebyefishing-badge-tooltip--visible");
    positionBadgeTooltip(badge, tooltip);
    tooltip.classList.add("byebyefishing-badge-tooltip--visible");
    badge.setAttribute("aria-describedby", tooltip.id);
    state.activeBadge = badge;
  }

  function hideBadgeTooltip() {
    if (state.activeBadge) {
      state.activeBadge.removeAttribute("aria-describedby");
    }
    state.activeBadge = null;
    state.badgeTooltip?.classList.remove("byebyefishing-badge-tooltip--visible");
  }

  function syncBadgeTooltipPosition() {
    if (!state.activeBadge?.isConnected || !state.badgeTooltip?.isConnected) {
      hideBadgeTooltip();
      return;
    }

    positionBadgeTooltip(state.activeBadge, state.badgeTooltip);
  }

  function bindBadgeTooltip(badge) {
    if (badge.dataset.byebyefishingTooltipBound === "true") {
      return;
    }

    badge.dataset.byebyefishingTooltipBound = "true";
    badge.addEventListener("mouseenter", () => showBadgeTooltip(badge));
    badge.addEventListener("mouseleave", hideBadgeTooltip);
    badge.addEventListener("focus", () => showBadgeTooltip(badge));
    badge.addEventListener("blur", hideBadgeTooltip);
  }

  function shouldShowBadgeSourceMark(info) {
    return info.tone === "risk" || info.tone === "high-risk";
  }

  function renderBadgeContent(badge, info) {
    badge.textContent = "";
    badge.append(document.createTextNode(info.label));

    if (!shouldShowBadgeSourceMark(info)) {
      return;
    }

    const source = document.createElement("span");
    source.className = "byebyefishing-badge__source";
    source.setAttribute("aria-hidden", "true");
    source.textContent = BADGE_SOURCE_MARK;
    badge.append(source);
  }

  function renderStatusBadge(element, result, seenBadges) {
    if (!state.showTrustedBadges && result.status !== "warning") {
      return;
    }

    const info = badgeInfo(result);
    if (!info) {
      return;
    }
    const signature = badgeSignature(result);
    let badge = element.nextElementSibling;
    if (!(badge instanceof HTMLElement) || !badge.classList.contains("byebyefishing-badge")) {
      badge = document.createElement("span");
      element.insertAdjacentElement("afterend", badge);
    }

    if (badge.dataset.byebyefishingSignature !== signature) {
      badge.className = `byebyefishing-badge byebyefishing-badge--${info.tone}`;
      badge.removeAttribute("title");
      renderBadgeContent(badge, info);
      badge.dataset.byebyefishingDetail = result.message || "";
      badge.dataset.byebyefishingSourceMark = shouldShowBadgeSourceMark(info) ? "true" : "false";
      badge.setAttribute("aria-label", result.message ? `${info.label}: ${result.message}` : info.label);
      if (result.message) {
        badge.tabIndex = 0;
      } else {
        badge.removeAttribute("tabindex");
      }
      badge.dataset.byebyefishingSignature = signature;
    }
    bindBadgeTooltip(badge);
    if (state.activeBadge === badge) {
      showBadgeTooltip(badge);
    }
    seenBadges.add(badge);
  }

  function reconcileBadges(seenBadges) {
    document.querySelectorAll(".byebyefishing-badge").forEach((badge) => {
      if (!seenBadges.has(badge)) {
        if (state.activeBadge === badge) {
          hideBadgeTooltip();
        }
        badge.remove();
      }
    });
  }

  function shouldRenderDetailBadge(result) {
    return result.status === "warning";
  }

  function shouldRenderGlobalWarning(result) {
    return (
      result.status === "warning" &&
      result.context !== "trusted-sender-site" &&
      result.context !== "trusted-sender-link-check"
    );
  }

  function scanMailListBadges(seenBadges) {
    for (const candidate of collectMailListSenderCandidates()) {
      const result = withGreenFlagSenderResult(detector.analyzeSender(candidate.text, state.rules));
      renderStatusBadge(candidate.element, result, seenBadges);
    }
  }

  function scanPage() {
    const seenBadges = new Set();
    const contentCandidates = collectContentCandidates();
    const messageScopes = collectMessageScopes(contentCandidates);
    let firstWarning = null;
    const trustedSenderByScope = new Map();
    const senderByScope = new Map();

    if (messageScopes.length === 0) {
      scanMailListBadges(seenBadges);
      reconcileBadges(seenBadges);
      removeGlobalWarning();
      return;
    }

    for (const scope of messageScopes) {
      for (const candidate of collectSenderCandidates([scope])) {
        const result = withGreenFlagSenderResult(detector.analyzeSender(candidate.text, state.rules));
        const senderIdentity = senderIdentityFromResult(result);
        if (senderIdentity && !senderByScope.has(scope)) {
          senderByScope.set(scope, senderIdentity);
        }
        const trustedSender = trustedSenderContext(result);
        if (trustedSender && !trustedSenderByScope.has(scope)) {
          trustedSenderByScope.set(scope, trustedSender);
        }
        if (shouldReplaceGlobalWarning(result, firstWarning)) {
          firstWarning = result;
        }
        renderStatusBadge(candidate.element, result, seenBadges);
      }
    }

    for (const scope of messageScopes) {
      for (const candidate of collectLinkCandidates([scope])) {
        const sender = senderByScope.get(scope) || null;
        const trustedSender = trustedSenderByScope.get(scope) || null;
        const analyzed = detector.analyzeLink
          ? detector.analyzeLink(candidate.text, candidate.href, state.rules)
          : detector.analyzeUrl(candidate.href, state.rules);
        const result = withTrustedSenderLinkCheckResult(
          withTrustedSenderSiteResult(
            {
              ...analyzed,
              senderEmail: sender?.senderEmail || "",
              senderDomain: sender?.senderDomain || ""
            },
            sender
          ),
          trustedSender
        );
        if (shouldReplaceGlobalWarning(result, firstWarning)) {
          firstWarning = result;
        }
        if (shouldRenderDetailBadge(result)) {
          renderStatusBadge(candidate.element, result, seenBadges);
        }
      }
    }

    for (const candidate of contentCandidates) {
      const scope = messageScopeFor(candidate.element);
      const trustedSender = trustedSenderByScope.get(scope) || null;
      const result = detector.analyzeContent(candidate.text, { trustedSender });
      if (shouldReplaceGlobalWarning(result, firstWarning)) {
        firstWarning = result;
      }
      if (shouldRenderDetailBadge(result)) {
        renderStatusBadge(candidate.element, result, seenBadges);
      }
    }

    reconcileBadges(seenBadges);
    if (firstWarning) {
      renderWarning(firstWarning);
    } else {
      removeGlobalWarning();
    }
  }

  function scheduleScan() {
    clearTimeout(state.scanTimer);
    state.scanTimer = setTimeout(scanPage, 250);
  }

  function isExtensionNode(node) {
    return (
      node instanceof Element &&
      Boolean(node.closest(".byebyefishing-badge, .byebyefishing-badge-tooltip, .byebyefishing-warning"))
    );
  }

  function shouldScheduleFromMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return false;
    }
    if (mutation.type === "attributes") {
      return true;
    }

    const changedNodes = [...mutation.addedNodes, ...mutation.removedNodes];
    const elementNodes = changedNodes.filter((node) => node instanceof Element);
    if (elementNodes.length > 0) {
      return elementNodes.some((node) => !isExtensionNode(node));
    }

    return changedNodes.some((node) => node.textContent && node.textContent.trim());
  }

  function shouldScheduleFromMutations(mutations) {
    return mutations.some(shouldScheduleFromMutation);
  }

  async function start() {
    await loadSettings();
    scanPage();

    const observer = new MutationObserver((mutations) => {
      if (shouldScheduleFromMutations(mutations)) {
        scheduleScan();
      }
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["email", "title", "aria-label", "href"]
    });

    window.addEventListener("resize", syncBadgeTooltipPosition);
    window.addEventListener("scroll", syncBadgeTooltipPosition, true);

    extensionApi.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "sync") {
        return;
      }

      if (changes.byebyefishingRules?.newValue) {
        const validation = detector.validateRules(changes.byebyefishingRules.newValue);
        state.rules = validation.ok ? mergeSavedRules(changes.byebyefishingRules.newValue) : defaultRules;
      }
      if (changes.byebyefishingShowTrustedBadges) {
        state.showTrustedBadges = changes.byebyefishingShowTrustedBadges.newValue !== false;
      }
      if (changes.byebyefishingGreenFlagSenderDomains) {
        state.greenFlagSenderDomains = normalizeGreenFlagSenderDomains(
          changes.byebyefishingGreenFlagSenderDomains.newValue
        );
      }
      if (changes.byebyefishingTrustedSenderSites) {
        state.trustedSenderSites = normalizeTrustedSenderSites(changes.byebyefishingTrustedSenderSites.newValue);
      }
      if (state.skipNextRuleChangeScan) {
        state.skipNextRuleChangeScan = false;
        return;
      }
      scheduleScan();
    });
  }

  start().catch(() => {
    state.rules = defaultRules;
    scanPage();
  });
})(typeof globalThis !== "undefined" ? globalThis : this);
