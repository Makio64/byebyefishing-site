(function runByeByeFishingContentScript(global) {
  "use strict";

  const detector = global.ByeByeFishingDetector;
  const scanPolicy = global.ByeByeFishingScanPolicy;
  const defaultRules = global.BYEBYEFISHING_DEFAULT_RULES || [];
  const rulesetVersion = global.BYEBYEFISHING_RULESET_VERSION || "0";
  const extensionApi = global.browser || global.chrome;
  const MESSAGE_BODY_SELECTORS = [
    ".a3s",
    "[aria-label*='Message body']",
    "[aria-label*='Corps du message']",
    "[data-testid='messageBody']",
    "[data-test-id='messageBody']",
    "[data-testid='message-content']",
    "[data-test-id='message-content']",
    "[data-testid='message-view-body-content']",
    "[data-test-id='message-view-body-content']",
    "[data-testid='message-view-body']",
    "[data-test-id='message-view-body']",
    "[data-message-id] [role='document']",
    ".message-content",
    ".mail-detail-content",
    ".mail-detail-body",
    ".mail-detail-pane [role='document']",
    ".message-part",
    ".message-htmlpart",
    "#messagebody",
    ".MsgBody",
    ".ZmMailMsgView"
  ];
  const MESSAGE_BODY_SELECTOR = MESSAGE_BODY_SELECTORS.join(",");
  const SUBJECT_SELECTORS = [
    "h2.hP",
    "[data-testid*='subject']",
    "[data-test-id*='subject']",
    "[aria-label^='Subject']",
    "[aria-label^='Objet']",
    ".message-subject",
    ".mail-subject",
    ".ZmMailMsgSubject"
  ];
  const SUBJECT_SELECTOR = SUBJECT_SELECTORS.join(",");
  const MESSAGE_SCOPE_SELECTORS = [
    ".adn",
    "[data-message-id]",
    "[data-testid='conversation-message']",
    "[data-test-id='message']",
    "[data-testid='message']",
    "[data-testid='message-view']",
    "[data-test-id='message-view']",
    "[data-testid='message-view-item']",
    "[data-test-id='message-view-item']",
    "[data-test-id='message-item']",
    ".mail-detail",
    ".mail-detail-pane",
    "#messagecontent",
    "#messagebody",
    ".ZmMailMsgView"
  ];
  const MESSAGE_SCOPE_SELECTOR = MESSAGE_SCOPE_SELECTORS.join(",");
  const MAIL_LIST_ROW_SELECTORS = [
    "div[role='main'] tr.zA",
    "div[role='main'] tr[jscontroller]",
    "div[role='main'] table[role='grid'] tr",
    "div[role='main'] .Cp tr",
    "div[role='main'] tr[role='row']",
    "div[role='main'] div[role='row']",
    "main tr[role='row']",
    "main div[role='row']",
    "main li[role='row']",
    "[data-testid='message-list-item']",
    "[data-test-id='message-list-item']",
    "[data-testid='conversation-list'] [role='row']",
    "[data-test-id='conversation-list'] [role='row']",
    ".mail-item",
    ".message-list-item",
    "tr.message",
    "tr.mail"
  ];
  const MAIL_LIST_ROW_SELECTOR = MAIL_LIST_ROW_SELECTORS.join(",");
  const MAIL_LIST_SENDER_SELECTORS = [
    "span[email]",
    "[email]",
    "[data-email]",
    "[data-address]",
    "[title*='@']",
    "[aria-label*='@']",
    "[data-testid*='sender']",
    "[data-test-id*='sender']",
    "[data-testid*='from']",
    "[data-test-id*='from']",
    ".from a[href^='mailto:']",
    ".sender [title*='@']",
    ".mail-sender [title*='@']",
    ".addr[title*='@']"
  ];
  const MAIL_LIST_SENDER_SELECTOR = MAIL_LIST_SENDER_SELECTORS.join(",");
  const SENDER_CANDIDATE_SELECTORS = [
    "[email]",
    "[data-email]",
    "[data-address]",
    "[title*='@']",
    "[aria-label*='@']",
    "[data-testid*='sender']",
    "[data-test-id*='sender']",
    "[data-testid*='from']",
    "[data-test-id*='from']",
    "a[href^='mailto:']"
  ];
  const SENDER_CANDIDATE_SELECTOR = SENDER_CANDIDATE_SELECTORS.join(",");
  const EXPLICIT_SENDER_SELECTOR = [
    "[data-testid*='sender']",
    "[data-test-id*='sender']",
    "[data-testid*='from']",
    "[data-test-id*='from']",
    ".from",
    ".sender",
    ".mail-sender",
    ".gD[email]",
    ".ZmEmailAddress"
  ].join(",");
  const state = {
    rules: defaultRules,
    rulesCustom: false,
    privacyConsentGranted: false,
    showTrustedBadges: true,
    showInformationalNotices: false,
    greenFlagSenderDomains: new Set(),
    trustedSenderSites: [],
    dismissedWarnings: new Set(),
    ownedElements: new Set(),
    messageScopeIds: new WeakMap(),
    nextMessageScopeId: 1,
    badgeTooltip: null,
    activeBadge: null,
    nextWarningConfirmationId: 1,
    scanTimer: null,
    skipNextRuleChangeScan: false,
    skipNextMemoryChangeScan: false
  };
  const BADGE_SOURCE_MARK = "🐟";
  const INLINE_WARNING_ID = "byebyefishing-inline-warning";
  const MAX_INLINE_HIGHLIGHTS = 24;
  const MAX_BODIES_PER_MESSAGE = 4;
  const MAX_LINK_DISPLAY_CHARACTERS = 512;
  const MAX_LINK_IMAGE_LABELS = 8;
  const MAX_RENDERED_DETAIL_BADGES = 80;

  if (!detector || !scanPolicy || !extensionApi?.storage) {
    return;
  }

  function ownElement(element) {
    state.ownedElements.add(element);
    return element;
  }

  function isOwnedExtensionNode(node) {
    if (!(node instanceof Element)) {
      return false;
    }
    for (let current = node; current; current = current.parentElement) {
      if (state.ownedElements.has(current)) {
        return true;
      }
    }
    return false;
  }

  function ownedElementsMatching(selector) {
    const matches = [];
    for (const element of state.ownedElements) {
      if (!element.isConnected) {
        state.ownedElements.delete(element);
        continue;
      }
      if (element.matches(selector)) {
        matches.push(element);
      }
    }
    return matches;
  }

  function storageAreaGet(area, defaults) {
    if (global.browser) {
      return area.get(defaults);
    }

    return new Promise((resolve, reject) => {
      area.get(defaults, (values) => {
        const error = extensionApi.runtime?.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve(values);
      });
    });
  }

  function storageAreaSet(area, values) {
    if (global.browser) {
      return area.set(values);
    }

    return new Promise((resolve, reject) => {
      area.set(values, () => {
        const error = extensionApi.runtime?.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve();
      });
    });
  }

  function localStorageGet(defaults) {
    return storageAreaGet(extensionApi.storage.local, defaults);
  }

  function localStorageSet(values) {
    return storageAreaSet(extensionApi.storage.local, values);
  }

  function normalizeGreenFlagSenderDomains(domains) {
    const normalizedDomains = new Set();
    if (!Array.isArray(domains)) {
      return normalizedDomains;
    }

    domains.forEach((domain) => {
      const normalized = detector.normalizeDomain(domain);
      if (normalized) {
        normalizedDomains.add(normalized);
      }
    });

    return normalizedDomains;
  }

  function normalizeTrustedSenderSites(records) {
    const normalizedRecords = [];
    const seen = new Set();
    if (!Array.isArray(records)) {
      return normalizedRecords;
    }

    records.forEach((record) => {
      if (!record || typeof record !== "object") {
        return;
      }

      const senderEmail = detector.extractEmail(record.senderEmail || "");
      const senderDomain = detector.normalizeDomain(record.senderDomain || senderEmail);
      const urlDomain = detector.normalizeDomain(record.urlDomain);
      if (!senderDomain || !urlDomain) {
        return;
      }

      const key = `${senderEmail}:${senderDomain}:${urlDomain}`;
      if (seen.has(key)) {
        return;
      }

      seen.add(key);
      normalizedRecords.push({ senderEmail, senderDomain, urlDomain });
    });

    return normalizedRecords.sort((first, second) =>
      `${first.senderDomain}:${first.urlDomain}`.localeCompare(`${second.senderDomain}:${second.urlDomain}`)
    );
  }

  function mergeSavedRules(rules) {
    const merged = detector.mergeDefaultRuleUpdates
      ? detector.mergeDefaultRuleUpdates(rules, defaultRules)
      : rules;
    return detector.validateRules(merged).ok ? merged : defaultRules;
  }

  async function loadSettings() {
    const localDefaults = {
      byebyefishingRules: null,
      byebyefishingRulesCustom: false,
      byebyefishingRulesVersion: "",
      byebyefishingShowTrustedBadges: true,
      byebyefishingShowInformationalNotices: false,
      byebyefishingPrivacyConsentVersion: 0,
      byebyefishingGreenFlagSenderDomains: [],
      byebyefishingTrustedSenderSites: []
    };
    const saved = await localStorageGet(localDefaults).catch(() => localDefaults);
    const storedRules = saved.byebyefishingRules || defaultRules;
    const storedCustom = saved.byebyefishingRulesCustom;
    const storedVersion = saved.byebyefishingRulesVersion;
    const validation = detector.validateRules(storedRules);
    const shouldUseSavedRules =
      validation.ok && (storedCustom || storedVersion === rulesetVersion);
    state.rulesCustom = Boolean(shouldUseSavedRules && storedCustom);
    state.rules = shouldUseSavedRules
      ? state.rulesCustom
        ? storedRules
        : mergeSavedRules(storedRules)
      : defaultRules;
    state.showTrustedBadges = saved.byebyefishingShowTrustedBadges !== false;
    state.showInformationalNotices = saved.byebyefishingShowInformationalNotices === true;
    state.privacyConsentGranted = saved.byebyefishingPrivacyConsentVersion >= 1;
    state.greenFlagSenderDomains = normalizeGreenFlagSenderDomains(saved.byebyefishingGreenFlagSenderDomains);
    state.trustedSenderSites = normalizeTrustedSenderSites(saved.byebyefishingTrustedSenderSites);
  }

  function isVisibleElement(element) {
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function viewportDistance(element) {
    const rect = element.getBoundingClientRect();
    const viewportHeight = global.innerHeight || document.documentElement?.clientHeight || 0;
    if (rect.bottom >= 0 && rect.top <= viewportHeight) {
      return 0;
    }
    return rect.bottom < 0 ? Math.abs(rect.bottom) : Math.max(0, rect.top - viewportHeight);
  }

  function isCurrentMessageElement(element) {
    const currentSelector = [
      "[aria-current='true']",
      "[aria-selected='true']",
      "[data-current='true']",
      "[data-selected='true']",
      "[data-active='true']",
      ".is-current",
      ".is-selected"
    ].join(",");
    const activeElement = document.activeElement;
    return Boolean(
      element.matches(currentSelector) ||
        element.closest(currentSelector) ||
        (activeElement instanceof Element && element.contains(activeElement))
    );
  }

  function messageSelectionMetadata(element, order) {
    return {
      element,
      order,
      isCurrent: isCurrentMessageElement(element),
      viewportDistance: viewportDistance(element)
    };
  }

  function normalizeUiText(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function visibleText(element) {
    return (element.innerText || element.textContent || "").replace(/\s+/g, " ").trim();
  }

  function subjectTextForScope(scope) {
    const localCandidates = [...scope.querySelectorAll(SUBJECT_SELECTOR)];
    const candidates =
      localCandidates.length > 0
        ? localCandidates
        : [...document.querySelectorAll(SUBJECT_SELECTOR)].filter(
            (element) => !element.closest(MAIL_LIST_ROW_SELECTOR)
          );
    const seen = new Set();
    const subjects = [];

    for (const element of candidates) {
      if (
        !(element instanceof HTMLElement) ||
        !isVisibleElement(element) ||
        isOwnedExtensionNode(element)
      ) {
        continue;
      }
      const text = visibleText(element).slice(0, 600);
      const normalized = normalizeUiText(text);
      if (
        text.length < 3 ||
        ["subject", "objet"].includes(normalized) ||
        seen.has(normalized)
      ) {
        continue;
      }
      seen.add(normalized);
      subjects.push(text);
      if (subjects.length >= 2) {
        break;
      }
    }

    return subjects.join("\n");
  }

  function isRecipientMetadataCandidate(element) {
    const label = normalizeUiText(visibleText(element));
    const title = normalizeUiText(element.getAttribute("title") || element.getAttribute("aria-label"));
    const recipientLabels = new Set(["a moi", "moi", "to me", "me", "for me", "pour moi", "para mi"]);

    return recipientLabels.has(label) || recipientLabels.has(title);
  }

  function messageScopeFor(element) {
    const scope = element.closest(MESSAGE_SCOPE_SELECTOR);
    return scope instanceof HTMLElement ? scope : element;
  }

  function messageScopeKey(scope, fingerprint) {
    const hostId = [
      scope.getAttribute("data-message-id"),
      scope.getAttribute("data-testid"),
      scope.getAttribute("data-test-id"),
      scope.id
    ].find(Boolean);
    if (!state.messageScopeIds.has(scope)) {
      state.messageScopeIds.set(scope, state.nextMessageScopeId++);
    }
    return `${hostId || "message"}:view-${state.messageScopeIds.get(scope)}:${fingerprint || "no-content"}`;
  }

  function collectMessageScopes(contentCandidates) {
    const seen = new Set();
    const scopeCandidates = [];

    for (const [order, candidate] of contentCandidates.entries()) {
      const scope = messageScopeFor(candidate.element);
      if (seen.has(scope) || !isVisibleElement(scope)) {
        continue;
      }
      seen.add(scope);
      scopeCandidates.push(messageSelectionMetadata(scope, order));
    }

    return scanPolicy
      .selectMessageCandidates(scopeCandidates)
      .map((candidate) => candidate.element);
  }

  function candidateText(element) {
    const parts = [...new Set([
      element.getAttribute("name"),
      element.getAttribute("email"),
      element.getAttribute("data-email"),
      element.getAttribute("data-address"),
      element.getAttribute("title"),
      element.getAttribute("aria-label"),
      element.getAttribute("href"),
      visibleText(element)
    ].filter(Boolean))];

    return parts.join(" ");
  }

  function isReadableSenderCandidate(element) {
    return (
      element instanceof HTMLElement &&
      isVisibleElement(element) &&
      !isRecipientMetadataCandidate(element) &&
      candidateText(element).includes("@")
    );
  }

  function collectSenderCandidates(scopes) {
    const candidates = [];

    for (const scope of scopes) {
      const seen = new Set();
      let order = 0;
      scope.querySelectorAll(SENDER_CANDIDATE_SELECTOR).forEach((element) => {
        if (
          !(element instanceof HTMLElement) ||
          seen.has(element) ||
          isOwnedExtensionNode(element) ||
          element.closest(MESSAGE_BODY_SELECTOR)
        ) {
          return;
        }
        seen.add(element);

        if (!isReadableSenderCandidate(element)) {
          return;
        }

        const explicitSender = Boolean(element.matches(EXPLICIT_SENDER_SELECTOR) || element.closest(EXPLICIT_SENDER_SELECTOR));
        const structuredAddress = Boolean(
          element.getAttribute("email") ||
            element.getAttribute("data-email") ||
            element.getAttribute("data-address")
        );
        candidates.push({
          element,
          text: candidateText(element),
          priority: explicitSender ? 0 : structuredAddress ? 1 : 2,
          order: order++
        });
      });
    }

    return candidates.sort((first, second) => first.priority - second.priority || first.order - second.order);
  }

  function collectLinkCandidates(scopes) {
    const candidates = [];
    let order = 0;

    for (const scope of scopes) {
      scope.querySelectorAll("a[href]").forEach((element) => {
        if (!(element instanceof HTMLAnchorElement)) {
          return;
        }

        const rawHref = element.getAttribute("href") || "";
        const resolvedHref = element.href || rawHref;
        if (
          !scanPolicy.isScannableLinkTarget(rawHref, resolvedHref) ||
          !isVisibleElement(element)
        ) {
          return;
        }

        const text = scanPolicy.boundedBodyText(
          [
            element.innerText || element.textContent || "",
            ...[...element.querySelectorAll("img")].slice(0, MAX_LINK_IMAGE_LABELS).map(
            (image) => image.getAttribute("alt") || image.getAttribute("title") || ""
          )
          ]
            .join(" ")
            .replace(/\s+/g, " ")
            .trim(),
          MAX_LINK_DISPLAY_CHARACTERS
        );
        candidates.push({
          element,
          rawHref,
          resolvedHref,
          order: order++,
          text,
          detectorRisk: detector.linkSelectionRisk
            ? detector.linkSelectionRisk(
                text,
                scanPolicy.preferredLinkHref(rawHref, resolvedHref),
                state.rules
              )
            : 0
        });
      });
    }

    return scanPolicy.selectLinkCandidates(candidates);
  }

  function textWithoutOwnedUi(element) {
    const chunks = [];
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
    let node = walker.nextNode();

    while (node) {
      let current = node.parentElement;
      let skip = false;
      while (current && current !== element) {
        // Highlight spans wrap original mail text and must remain part of the
        // analysis. Other owned descendants are extension UI, never evidence.
        if (state.ownedElements.has(current) && !current.classList.contains("byebyefishing-highlight")) {
          skip = true;
          break;
        }
        current = current.parentElement;
      }
      if (!skip && node.nodeValue) {
        chunks.push(node.nodeValue);
      }
      node = walker.nextNode();
    }

    const accessibleMediaLabels = [...element.querySelectorAll("img[alt], img[title], [role='img'][aria-label]")]
      .filter((media) => !isOwnedExtensionNode(media))
      .slice(0, 20)
      .map(
        (media) =>
          media.getAttribute("alt") ||
          media.getAttribute("title") ||
          media.getAttribute("aria-label") ||
          ""
      );

    return [...chunks, ...accessibleMediaLabels].join(" ").replace(/\s+/g, " ").trim();
  }

  function collectContentCandidates() {
    const seen = new Set();
    const scopeRecords = new Map();
    let order = 0;

    document.querySelectorAll(MESSAGE_BODY_SELECTOR).forEach((element) => {
      if (!(element instanceof HTMLElement) || seen.has(element) || isOwnedExtensionNode(element)) {
        return;
      }
      seen.add(element);

      if (!isVisibleElement(element)) {
        return;
      }

      const scope = messageScopeFor(element);
      let record = scopeRecords.get(scope);
      if (!record) {
        record = {
          ...messageSelectionMetadata(scope, order),
          scope,
          bodies: []
        };
        scopeRecords.set(scope, record);
      }
      const body = messageSelectionMetadata(element, order++);
      record.bodies.push(body);
      record.isCurrent = record.isCurrent || body.isCurrent;
      record.viewportDistance = Math.min(record.viewportDistance, body.viewportDistance);
    });

    const selectedScopes = scanPolicy.selectMessageCandidates([...scopeRecords.values()]);
    const candidates = [];

    for (const scopeRecord of selectedScopes) {
      const selectedBodies = scanPolicy.selectMessageCandidates(scopeRecord.bodies, {
        limit: MAX_BODIES_PER_MESSAGE
      });
      let remainingSamples = scanPolicy.LIMITS.bodySamplesPerMessage;
      for (const body of selectedBodies) {
        if (remainingSamples <= 0) {
          break;
        }
        const fullText = textWithoutOwnedUi(body.element);
        const samplePlan = scanPolicy.bodyTextSamplePlan(fullText, {
          maxSamples: Math.min(
            remainingSamples,
            scanPolicy.LIMITS.bodySamplesPerBody
          )
        });
        const samples = samplePlan.samples.slice(0, remainingSamples);
        const hasScannableContent = Boolean(
          body.element.querySelector("a[href], img[alt], img[title], [role='img'][aria-label]")
        );
        if (!fullText && !hasScannableContent) {
          continue;
        }
        const subject = subjectTextForScope(scopeRecord.scope);
        samples.forEach((text, index) => {
          candidates.push({
            element: body.element,
            subject: index === 0 ? subject : "",
            text,
            samplingMetrics: index === 0 ? samplePlan.metrics : null
          });
        });
        remainingSamples -= samples.length;
      }
    }

    return candidates;
  }

  function collectMailListSenderCandidates() {
    const seenRows = new Set();
    const seenElements = new Set();
    const candidates = [];

    function addRowCandidate(row) {
      if (!(row instanceof HTMLElement) || seenRows.has(row) || !isVisibleElement(row)) {
        return;
      }
      seenRows.add(row);

      let senderElement = null;
      for (const selector of MAIL_LIST_SENDER_SELECTORS) {
        const element = row.querySelector(selector);
        if (!(element instanceof HTMLElement) || seenElements.has(element) || !isReadableSenderCandidate(element)) {
          continue;
        }

        const text = candidateText(element);
        senderElement = element;
        break;
      }

      if (!senderElement) {
        return;
      }

      seenElements.add(senderElement);
      candidates.push({ element: senderElement, text: candidateText(senderElement) });
    }

    document.querySelectorAll(MAIL_LIST_ROW_SELECTOR).forEach(addRowCandidate);

    const main = document.querySelector("div[role='main'], main");
    if (main instanceof HTMLElement) {
      main.querySelectorAll(MAIL_LIST_SENDER_SELECTOR).forEach((element) => {
        if (!(element instanceof HTMLElement) || seenElements.has(element) || !isReadableSenderCandidate(element)) {
          return;
        }

        const text = candidateText(element);
        const row = element.closest("tr.zA, tr[role='row'], div[role='row']");
        if (!(row instanceof HTMLElement)) {
          return;
        }

        seenElements.add(element);
        seenRows.add(row);
        candidates.push({ element, text });
      });
    }

    return candidates.slice(0, 80);
  }

  function warningRank(result) {
    if (result.severity === "critical") {
      return 4;
    }
    if (result.severity === "high") {
      return 3;
    }
    if (result.severity === "medium") {
      return 2;
    }
    return result.status === "warning" ? 1 : 0;
  }

  function warningTiePriority(result) {
    if (result.context === "hosted-platform-link") {
      return 2;
    }
    if (result.urlDomain) {
      return 1;
    }
    if (result.context === "professional-sender-check") {
      return -1;
    }
    return 0;
  }

  function shouldReplaceGlobalWarning(candidate, current) {
    if (
      !shouldRenderGlobalWarning(candidate) ||
      state.dismissedWarnings.has(warningKey(candidate))
    ) {
      return false;
    }
    if (!current) {
      return true;
    }

    const candidateRank = warningRank(candidate);
    const currentRank = warningRank(current);
    if (candidateRank !== currentRank) {
      return candidateRank > currentRank;
    }

    return warningTiePriority(candidate) > warningTiePriority(current);
  }

  function severityLabel(severity) {
    if (severity === "critical") {
      return "Likely phishing";
    }
    if (severity === "high") {
      return "Strong warning";
    }
    if (severity === "medium") {
      return "Worth checking";
    }
    return "Heads-up";
  }

  function warningTitle(result) {
    if (result.context === "scan-incomplete") {
      return "Only part of this long message was checked";
    }
    if (result.context === "trusted-sender-payment") {
      return "Check this payment request";
    }
    if (result.context === "trusted-sender-content-check") {
      return "Check this known-domain message";
    }
    if (result.context === "trusted-sender-link-check") {
      return "Double-check this link";
    }
    if (result.context === "hosted-platform-link") {
      return "Shared page check";
    }
    if (result.context === "public-hosting-link") {
      return "Shared file or page";
    }
    if (result.context === "shortened-link") {
      return "Hidden link destination";
    }
    if (result.context === "unfamiliar-domain" || result.context === "long-link") {
      return result.urlDomain ? "Quick link check" : "Quick sender check";
    }
    if (result.context === "professional-sender-check") {
      return "Verify this sender";
    }
    if (result.context === "common-tech-tld") {
      return result.urlDomain ? "Quick link check" : "Quick sender check";
    }
    if (result.urlDomain && result.severity === "critical") {
      return "Pause before opening this link";
    }
    if (result.urlDomain && result.severity === "high") {
      return "Check this link first";
    }
    if (result.urlDomain) {
      return "Unusual link";
    }
    if (result.severity === "critical") {
      return "Pause before acting";
    }
    if (result.severity === "high") {
      return "Verify before acting";
    }
    if (result.severity === "medium") {
      return "Verify before acting";
    }
    return "Check before acting";
  }

  function trustedSenderContext(result) {
    if (result.status !== "trusted" || result.context === "known-sender") {
      return null;
    }

    return {
      brandId: result.brandId || "",
      brand: result.brand || "",
      senderDomain: result.senderDomain || ""
    };
  }

  function displaySenderDomain(domain) {
    const normalized = detector.normalizeDomain(domain);
    return normalized ? `${normalized.charAt(0).toUpperCase()}${normalized.slice(1)}` : "";
  }

  function isNumericAddress(value) {
    return /^\d{1,3}(?:\.\d{1,3}){3}$/.test(String(value || "").trim());
  }

  function senderLabel(result) {
    return result.senderEmail || result.senderDomain || "this sender";
  }

  function createInlineEntity(text, tone = "sender") {
    const entity = document.createElement("span");
    entity.className = `byebyefishing-warning__entity byebyefishing-warning__entity--${tone}`;
    entity.textContent = text;
    return entity;
  }

  function senderDomainIsGreenFlagged(senderDomain) {
    const normalized = detector.normalizeDomain(senderDomain);
    if (!normalized || state.greenFlagSenderDomains.size === 0) {
      return false;
    }

    for (const greenFlaggedDomain of state.greenFlagSenderDomains) {
      if (detector.domainMatchesAllowed(normalized, greenFlaggedDomain)) {
        return true;
      }
    }

    return false;
  }

  function withGreenFlagSenderResult(result) {
    const sender = senderIdentityFromResult(result);
    if (
      result.status !== "warning" ||
      result.severity === "high" ||
      result.severity === "critical" ||
      result.brandId ||
      (!senderDomainIsGreenFlagged(result.senderDomain) && !senderIsKnownFromTrustedSite(sender))
    ) {
      return result;
    }

    return {
      ...result,
      status: "trusted",
      severity: "none",
      context: "known-sender",
      allowedDomains: [],
      message: `Sender you know: ${result.senderDomain}.`
    };
  }

  function senderIdentityFromResult(result) {
    const senderEmail = detector.extractEmail(result?.senderEmail || "");
    const senderDomain = detector.normalizeDomain(result?.senderDomain || senderEmail);
    if (!senderDomain) {
      return null;
    }

    return { senderEmail, senderDomain };
  }

  function senderSiteRecordMatches(record, sender, urlDomain) {
    const normalizedUrlDomain = detector.normalizeDomain(urlDomain);
    if (!record || !sender || !normalizedUrlDomain) {
      return false;
    }

    const senderMatches = record.senderEmail
      ? record.senderEmail === sender.senderEmail
      : detector.domainMatchesAllowed(sender.senderDomain, record.senderDomain);
    return senderMatches && detector.domainMatchesAllowed(normalizedUrlDomain, record.urlDomain);
  }

  function senderIsKnownFromTrustedSite(sender) {
    if (!sender) {
      return false;
    }

    return state.trustedSenderSites.some((record) =>
      record.senderEmail
        ? record.senderEmail === sender.senderEmail
        : detector.domainMatchesAllowed(sender.senderDomain, record.senderDomain)
    );
  }

  function withTrustedSenderSiteResult(result, sender) {
    const urlDomain = detector.normalizeDomain(result?.urlDomain);
    const canUseSenderSiteMemory =
      result.context === "hosted-platform-link" ||
      result.context === "public-hosting-link" ||
      result.context === "unfamiliar-domain" ||
      result.context === "common-tech-tld" ||
      (result.context === "generic-domain-risk" && result.severity !== "critical");
    if (
      result.status !== "warning" ||
      result.severity === "high" ||
      result.severity === "critical" ||
      !canUseSenderSiteMemory ||
      result.displayedDomain ||
      !urlDomain ||
      !sender
    ) {
      return result;
    }

    const trustedSite = state.trustedSenderSites.find((record) =>
      senderSiteRecordMatches(record, sender, urlDomain)
    );
    if (!trustedSite) {
      return result;
    }

    return {
      ...result,
      severity: "low",
      context: "trusted-sender-site",
      senderEmail: sender.senderEmail,
      senderDomain: sender.senderDomain,
      message: `${urlDomain} is remembered for ${sender.senderEmail || sender.senderDomain}. Bye Bye Fishing will still warn about unexpected payment, login, code, or personal-information requests.`
    };
  }

  function trustedSenderBrandRule(trustedSender) {
    if (!trustedSender?.brandId) {
      return null;
    }
    return state.rules.find((rule) => rule.id === trustedSender.brandId) || null;
  }

  function linkBelongsToBrand(urlDomain, brandRule) {
    if (!urlDomain || !brandRule) {
      return false;
    }
    const brandDomains = [
      ...(Array.isArray(brandRule.allowedDomains) ? brandRule.allowedDomains : []),
      ...(Array.isArray(brandRule.brandLinkDomains) ? brandRule.brandLinkDomains : [])
    ];
    return brandDomains.some((domain) => detector.domainMatchesAllowed(urlDomain, domain));
  }

  function withTrustedSenderLinkCheckResult(result, trustedSender) {
    const urlDomain = detector.normalizeDomain(result?.urlDomain);
    const sameTrustedBrand =
      result?.brandId &&
      trustedSender?.brandId &&
      result.brandId === trustedSender.brandId;
    const isOwnBrandLink = linkBelongsToBrand(urlDomain, trustedSenderBrandRule(trustedSender));
    const isOrdinaryUnusualLink =
      result?.context === "generic-domain-risk" &&
      result.severity === "medium";
    // A confusing visible text shouldn't keep a high-risk badge on a link that demonstrably
    // points to the verified sender's own brand.
    const ignoreDisplayedDomain = sameTrustedBrand || isOwnBrandLink;
    if (
      result?.status !== "warning" ||
      (!isOrdinaryUnusualLink && !isOwnBrandLink) ||
      (result.displayedDomain && !ignoreDisplayedDomain) ||
      result.severity === "critical" ||
      !urlDomain ||
      !trustedSender
    ) {
      return result;
    }

    const senderName = trustedSender.brand || trustedSender.senderDomain || "this sender";
    const message = `${urlDomain} looks unusual, while the From domain matches the known ${senderName} list. The From address is not authentication, so double-check that you expected this link.`;
    return {
      ...result,
      // A From address can be forged. It may soften an ordinary domain-shape
      // observation, but it must never hide an unknown brand destination.
      severity: "medium",
      context: "trusted-sender-link-check",
      trustedSenderBrand: trustedSender.brand || "",
      trustedSenderDomain: trustedSender.senderDomain || "",
      message
    };
  }

  function canRememberSenderWarning(result) {
    return Boolean(
      !result.brandId &&
        !result.urlDomain &&
        detector.normalizeDomain(result.senderDomain) &&
        (result.context === "professional-sender-check" ||
          result.context === "generic-domain-risk" ||
          result.context === "common-tech-tld")
    );
  }

  async function rememberKnownSenderDomain(senderDomain) {
    const normalized = detector.normalizeDomain(senderDomain);
    if (!normalized) {
      return null;
    }

    const previousDomains = new Set(state.greenFlagSenderDomains);
    state.greenFlagSenderDomains.add(normalized);
    state.skipNextMemoryChangeScan = true;
    try {
      await localStorageSet({
        byebyefishingGreenFlagSenderDomains: [...state.greenFlagSenderDomains].sort()
      });
      return { domain: normalized, previousDomains };
    } catch (error) {
      state.skipNextMemoryChangeScan = false;
      state.greenFlagSenderDomains = previousDomains;
      throw error;
    }
  }

  async function undoKnownSenderDomains(previousDomains) {
    const currentDomains = state.greenFlagSenderDomains;
    state.greenFlagSenderDomains = new Set(previousDomains || []);
    try {
      await localStorageSet({
        byebyefishingGreenFlagSenderDomains: [...state.greenFlagSenderDomains].sort()
      });
    } catch (error) {
      state.greenFlagSenderDomains = currentDomains;
      throw error;
    }
    scheduleScan();
  }

  function ruleForResult(result) {
    if (!result?.brandId) {
      return null;
    }

    return state.rules.find((rule) => rule.id === result.brandId) || null;
  }

  function domainListNameForSenderTrust(rule) {
    return Array.isArray(rule?.senderDomains) ? "senderDomains" : "allowedDomains";
  }

  function canTrustSenderDomain(result) {
    return Boolean(
      result?.status === "warning" &&
        result.severity !== "high" &&
        result.severity !== "critical" &&
        result.brandId &&
        !result.urlDomain &&
        detector.normalizeDomain(result.senderDomain) &&
        ruleForResult(result)
    );
  }

  function canTrustSiteForSender(result) {
    return Boolean(
      result?.status === "warning" &&
        result.severity !== "high" &&
        result.severity !== "critical" &&
        (result.context === "hosted-platform-link" ||
          result.context === "public-hosting-link" ||
          result.context === "unfamiliar-domain" ||
          result.context === "common-tech-tld" ||
          (result.context === "generic-domain-risk" && result.severity !== "critical")) &&
        !result.displayedDomain &&
        detector.normalizeDomain(result.urlDomain) &&
        detector.normalizeDomain(result.senderDomain)
    );
  }

  async function saveRules(rules) {
    const validation = detector.validateRules(rules);
    if (!validation.ok) {
      throw new Error(validation.error || "Trusted-domain rules are invalid.");
    }

    const previousRules = state.rules;
    state.rules = rules;
    state.skipNextRuleChangeScan = true;
    try {
      await localStorageSet({
        byebyefishingRules: rules,
        byebyefishingRulesCustom: true,
        byebyefishingRulesVersion: rulesetVersion
      });
    } catch (error) {
      state.skipNextRuleChangeScan = false;
      state.rules = previousRules;
      throw error;
    }
  }

  async function trustSenderDomainForResult(result) {
    const domain = detector.normalizeDomain(result.senderDomain);
    const rule = ruleForResult(result);
    if (!domain || !rule || !detector.addTrustedDomainToRule) {
      return null;
    }

    const previousRules = state.rules;
    const listName = domainListNameForSenderTrust(rule);
    const nextRules = detector.addTrustedDomainToRule(state.rules, rule.id, domain, listName);
    await saveRules(nextRules);

    return { domain, previousRules };
  }

  async function undoTrustRules(previousRules) {
    if (!previousRules) {
      return;
    }

    await saveRules(previousRules);
    scheduleScan();
  }

  async function trustSiteForSender(result) {
    const sender = senderIdentityFromResult(result);
    const urlDomain = detector.normalizeDomain(result.urlDomain);
    if (!sender || !urlDomain) {
      return null;
    }

    const previousSites = state.trustedSenderSites;
    const nextSites = normalizeTrustedSenderSites([
      ...state.trustedSenderSites,
      {
        senderEmail: sender.senderEmail,
        senderDomain: sender.senderDomain,
        urlDomain
      }
    ]);

    state.trustedSenderSites = nextSites;
    state.skipNextMemoryChangeScan = true;
    try {
      await localStorageSet({
        byebyefishingTrustedSenderSites: nextSites
      });
    } catch (error) {
      state.skipNextMemoryChangeScan = false;
      state.trustedSenderSites = previousSites;
      throw error;
    }

    return { sender, urlDomain, previousSites };
  }

  async function undoTrustedSenderSites(previousSites) {
    const currentSites = state.trustedSenderSites;
    state.trustedSenderSites = normalizeTrustedSenderSites(previousSites);
    try {
      await localStorageSet({
        byebyefishingTrustedSenderSites: state.trustedSenderSites
      });
    } catch (error) {
      state.trustedSenderSites = currentSites;
      throw error;
    }
    scheduleScan();
  }

  function showControlError(controls, message = "Could not save this change. Please try again.") {
    let error = controls.querySelector(".byebyefishing-warning__save-error");
    if (!error) {
      error = document.createElement("span");
      error.className = "byebyefishing-warning__save-error";
      error.setAttribute("role", "alert");
      controls.prepend(error);
    }
    error.textContent = message;
  }

  function showTrustSuccess(controls, message, previousRules) {
    controls.textContent = "";

    const status = document.createElement("span");
    status.className = "byebyefishing-warning__saved";
    status.textContent = message;

    const undo = document.createElement("button");
    undo.type = "button";
    undo.className = "byebyefishing-warning__secondary-action";
    undo.textContent = "Undo";
    undo.addEventListener("click", () => {
      undo.disabled = true;
      undoTrustRules(previousRules).catch(() => {
        undo.disabled = false;
        showControlError(controls, "Undo could not be saved. Please try again.");
      });
    });

    const done = document.createElement("button");
    done.type = "button";
    done.className = "byebyefishing-warning__secondary-action";
    done.textContent = "Done";
    done.addEventListener("click", () => {
      removeGlobalWarning();
      scheduleScan();
    });

    controls.append(status, undo, done);
    undo.focus();
  }

  function showSiteTrustSuccess(controls, message, previousSites) {
    controls.textContent = "";

    const status = document.createElement("span");
    status.className = "byebyefishing-warning__saved";
    status.textContent = message;

    const undo = document.createElement("button");
    undo.type = "button";
    undo.className = "byebyefishing-warning__secondary-action";
    undo.textContent = "Undo";
    undo.addEventListener("click", () => {
      undo.disabled = true;
      undoTrustedSenderSites(previousSites).catch(() => {
        undo.disabled = false;
        showControlError(controls, "Undo could not be saved. Please try again.");
      });
    });

    const done = document.createElement("button");
    done.type = "button";
    done.className = "byebyefishing-warning__secondary-action";
    done.textContent = "Done";
    done.addEventListener("click", () => {
      removeGlobalWarning();
      scheduleScan();
    });

    controls.append(status, undo, done);
    undo.focus();
  }

  function showKnownSenderSuccess(controls, message, previousDomains) {
    controls.textContent = "";

    const status = document.createElement("span");
    status.className = "byebyefishing-warning__saved";
    status.textContent = message;

    const undo = document.createElement("button");
    undo.type = "button";
    undo.className = "byebyefishing-warning__secondary-action";
    undo.textContent = "Undo";
    undo.addEventListener("click", () => {
      undo.disabled = true;
      undoKnownSenderDomains(previousDomains).catch(() => {
        undo.disabled = false;
        showControlError(controls, "Undo could not be saved. Please try again.");
      });
    });

    const done = document.createElement("button");
    done.type = "button";
    done.className = "byebyefishing-warning__secondary-action";
    done.textContent = "Done";
    done.addEventListener("click", () => {
      removeGlobalWarning();
      scheduleScan();
    });

    controls.append(status, undo, done);
    undo.focus();
  }

  function beginWarningConfirmation(controls, trigger) {
    const existing = controls.querySelector(".byebyefishing-warning__confirm");
    if (existing) {
      const previousTrigger = existing.byebyefishingTrigger;
      existing.remove();
      previousTrigger?.setAttribute("aria-expanded", "false");
      previousTrigger?.removeAttribute("aria-controls");
      if (previousTrigger === trigger) {
        trigger.focus();
        return null;
      }
    }

    const confirm = document.createElement("div");
    confirm.className = "byebyefishing-warning__confirm";
    confirm.id = `byebyefishing-warning-confirm-${state.nextWarningConfirmationId++}`;
    confirm.setAttribute("role", "group");
    confirm.setAttribute("aria-label", "Confirm this local exception");
    confirm.byebyefishingTrigger = trigger;
    trigger.setAttribute("aria-expanded", "true");
    trigger.setAttribute("aria-controls", confirm.id);
    return confirm;
  }

  function closeWarningConfirmation(confirm) {
    const trigger = confirm.byebyefishingTrigger;
    confirm.remove();
    trigger?.setAttribute("aria-expanded", "false");
    trigger?.removeAttribute("aria-controls");
    if (trigger?.isConnected) {
      trigger.focus();
    }
  }

  function renderTrustConfirmation(controls, result, trigger) {
    const confirm = beginWarningConfirmation(controls, trigger);
    if (!confirm) return;

    const domain = detector.normalizeDomain(result.senderDomain);

    const copy = document.createElement("p");
    copy.textContent = `Add ${domain} to the known ${result.brand} sender domains only after checking another source. This allows every email address at ${domain} to represent ${result.brand}.`;

    const actions = document.createElement("div");
    actions.className = "byebyefishing-warning__confirm-actions";

    const trust = document.createElement("button");
    trust.type = "button";
    trust.className = "byebyefishing-warning__danger-action";
    trust.textContent = "Add known domain";
    trust.addEventListener("click", () => {
      trust.disabled = true;
      trustSenderDomainForResult(result)
        .then((saved) => {
          if (saved) {
            showTrustSuccess(controls, `Saved. ${saved.domain} is now familiar for ${result.brand}.`, saved.previousRules);
          }
        })
        .catch(() => {
          trust.disabled = false;
          showControlError(controls);
        });
    });

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "byebyefishing-warning__secondary-action";
    cancel.textContent = "Cancel";
    cancel.addEventListener("click", () => closeWarningConfirmation(confirm));

    actions.append(trust, cancel);
    confirm.append(copy, actions);
    controls.append(confirm);
    trust.focus();
  }

  function renderRememberSenderConfirmation(controls, senderDomain, trigger) {
    const confirm = beginWarningConfirmation(controls, trigger);
    if (!confirm) return;

    const domain = detector.normalizeDomain(senderDomain);

    const copy = document.createElement("p");
    copy.textContent = `Remember ${domain} only if you know this organization and expected this message. This applies to every email address at ${domain}. Bye Bye Fishing will still warn about known brands, passwords, payments, codes, and personal information.`;

    const actions = document.createElement("div");
    actions.className = "byebyefishing-warning__confirm-actions";

    const remember = document.createElement("button");
    remember.type = "button";
    remember.className = "byebyefishing-warning__danger-action";
    remember.textContent = "Remember this sender";
    remember.addEventListener("click", () => {
      remember.disabled = true;
      rememberKnownSenderDomain(domain)
        .then((saved) => {
          if (saved) {
            showKnownSenderSuccess(
              controls,
              `Saved. Mail from ${saved.domain} will no longer trigger this sender-only check.`,
              saved.previousDomains
            );
          }
        })
        .catch(() => {
          remember.disabled = false;
          showControlError(controls);
        });
    });

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "byebyefishing-warning__secondary-action";
    cancel.textContent = "Cancel";
    cancel.addEventListener("click", () => closeWarningConfirmation(confirm));

    actions.append(remember, cancel);
    confirm.append(copy, actions);
    controls.append(confirm);
    remember.focus();
  }

  function renderTrustSiteConfirmation(controls, result, trigger) {
    const confirm = beginWarningConfirmation(controls, trigger);
    if (!confirm) return;

    const sender = result.senderEmail || result.senderDomain;
    const urlDomain = detector.normalizeDomain(result.urlDomain);

    const copy = document.createElement("p");
    copy.textContent = `Use this only if you know ${sender} and expected links to ${urlDomain}. Bye Bye Fishing will remember this link only for this sender, and will still warn about passwords, payments, codes, personal information, misleading links, or messages that pretend to be known brands.`;

    const actions = document.createElement("div");
    actions.className = "byebyefishing-warning__confirm-actions";

    const trust = document.createElement("button");
    trust.type = "button";
    trust.className = "byebyefishing-warning__danger-action";
    trust.textContent = "Remember this link";
    trust.addEventListener("click", () => {
      trust.disabled = true;
      trustSiteForSender(result)
        .then((saved) => {
          if (saved) {
            showSiteTrustSuccess(
              controls,
              `Saved. ${saved.urlDomain} is now familiar for ${saved.sender.senderEmail || saved.sender.senderDomain}.`,
              saved.previousSites
            );
          }
        })
        .catch(() => {
          trust.disabled = false;
          showControlError(controls);
        });
    });

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "byebyefishing-warning__secondary-action";
    cancel.textContent = "Cancel";
    cancel.addEventListener("click", () => closeWarningConfirmation(confirm));

    actions.append(trust, cancel);
    confirm.append(copy, actions);
    controls.append(confirm);
    trust.focus();
  }

  function warningSignalText(result) {
    const labels = [...new Set((result.signals || []).map((signal) => signal.label).filter(Boolean))];
    return labels.length > 0 ? `Why it was flagged: ${labels.slice(0, 3).join(" + ")}.` : "";
  }

  function warningDetail(result, allowed) {
    if (result.context === "trusted-sender-payment") {
      return result.senderDomain
        ? `Known sender domain: ${result.senderDomain}. This does not verify who sent the email.`
        : result.brand
          ? `Domain matches the known ${result.brand} list; this does not verify the sender.`
          : "The domain matches your list; this does not verify the sender.";
    }
    if (result.context === "trusted-sender-content-check") {
      return result.senderDomain
        ? `Known sender domain: ${result.senderDomain}. This does not verify who sent the email.`
        : result.brand
          ? `Domain matches the known ${result.brand} list; this does not verify the sender.`
          : "The domain matches your list; this does not verify the sender.";
    }
    if (result.context === "trusted-sender-link-check") {
      return result.urlDomain ? `Destination: ${result.urlDomain}` : "Use it only if you expected this link.";
    }
    if (result.context === "hosted-platform-link") {
      return result.urlDomain ? `Shared page: ${result.urlDomain}` : "Open it only if you expected this page.";
    }
    if (result.context === "public-hosting-link") {
      return result.urlDomain ? `Shared destination: ${result.urlDomain}` : "Anyone can publish at this destination.";
    }
    if (result.context === "shortened-link") {
      return result.urlDomain ? `Short-link service: ${result.urlDomain}` : "The final destination is hidden.";
    }
    if (result.context === "unfamiliar-domain" || result.context === "long-link") {
      return result.reason ? `Observed detail: ${result.reason}.` : "This is a weak signal, not proof of a scam.";
    }
    if (result.context === "professional-sender-check") {
      return result.reason ? `Why: the address ${result.reason}.` : "Check that you recognize the sender.";
    }
    if (result.context === "common-tech-tld") {
      if (result.urlDomain) {
        return `Destination: ${result.urlDomain}`;
      }
      return result.reason ? `Why: the address ${result.reason}.` : "Check that you recognize the sender.";
    }
    if (result.urlDomain) {
      return isNumericAddress(result.urlDomain)
        ? `Destination is a numeric IP address: ${result.urlDomain}`
        : `Destination: ${result.urlDomain}`;
    }

    if (result.severity === "critical") {
      return allowed
        ? `Known domains in your safety list: ${allowed}`
        : "You can use the official app or contact the sender another way.";
    }

    return allowed ? `Known examples: ${allowed}` : "Check that this message matches what you expected.";
  }

  function warningActionText(result) {
    if (result.context === "known-phishing-url") {
      return "Do not open this destination. Contact the sender through a channel you already trust.";
    }
    if (result.context === "scan-incomplete") {
      return "If it asks for a password, payment, or remote access, verify it in the official app or site.";
    }
    if (result.context === "trusted-sender-payment") {
      return "Pay only if this matches something you just did.";
    }
    if (result.context === "trusted-sender-content-check") {
      return "Use your usual app or website if anything feels off.";
    }
    if (result.context === "trusted-sender-link-check") {
      return "Use it only if this destination matches what you expected.";
    }
    if (result.context === "hosted-platform-link") {
      return "Avoid passwords, codes, or payment details on this page.";
    }
    if (result.context === "public-hosting-link") {
      return result.severity === "high"
        ? "Verify the page another way before entering a password, code, or payment detail."
        : "Shared files and pages are common. Open it only if you expected this destination.";
    }
    if (result.context === "shortened-link") {
      return "Ask the sender or preview the destination if you did not expect this short link.";
    }
    if (result.context === "unfamiliar-domain" || result.context === "long-link") {
      return "This detail alone is not proof of danger. Check whether the message and destination are expected.";
    }
    if (result.context === "professional-sender-check") {
      return "Check the sender before replying, opening files, or following links.";
    }
    if (result.context === "common-tech-tld") {
      return result.urlDomain
        ? "Likely fine — open it only if you expected this link, and don't enter passwords or codes unless you're sure."
        : "Likely fine — just confirm you recognize the sender before sharing anything sensitive.";
    }
    if (result.severity === "critical") {
      return "To stay safe, don't use links in the email. Open the official app or website yourself.";
    }
    if (result.severity === "high") {
      return "Check another way before clicking or paying.";
    }
    if (result.urlDomain) {
      return "Don't use this link for login, payment, or personal details. Open the site directly if needed.";
    }
    return "Check another way before acting.";
  }

  function warningVerdict(result) {
    if (result.context === "known-phishing-url") {
      return "This exact link is on the packaged phishing list.";
    }
    if (result.context === "scan-incomplete") {
      return "The local scan reached its safety limit. This does not mean the message is phishing.";
    }
    if (result.context === "trusted-sender-payment") {
      return "The sender looks familiar, but this asks for money or account access.";
    }
    if (result.context === "trusted-sender-content-check") {
      return "The sender domain matches your list, but the message includes safety-sensitive wording.";
    }
    if (result.context === "trusted-sender-link-check") {
      return "The sender domain looks familiar, but this destination is not on the known domain list.";
    }
    if (result.context === "hosted-platform-link") {
      return result.brand
        ? `This page was made with ${result.brand}, where anyone can create a page.`
        : "This page was made with a public website builder.";
    }
    if (result.context === "public-hosting-link") {
      return result.severity === "high"
        ? "This user-published page combines hosting risk with sensitive wording."
        : "This is a user-published file or page, which can be legitimate.";
    }
    if (result.context === "shortened-link") {
      return "This short link hides its final destination.";
    }
    if (result.context === "unfamiliar-domain" || result.context === "long-link") {
      return "Bye Bye Fishing noticed one weak link or domain signal.";
    }
    if (result.context === "professional-sender-check") {
      return result.reason
        ? `This sender address ${result.reason}.`
        : `${senderLabel(result)} needs a quick check.`;
    }
    if (result.context === "common-tech-tld") {
      return result.urlDomain
        ? "This link uses a newer domain extension that's common for tech products."
        : "This sender uses a newer domain extension that's common for tech products.";
    }
    if (result.context === "generic-domain-risk" && result.senderDomain && !result.urlDomain) {
      return result.message && /sensitive wording/i.test(result.message)
        ? "This sender address looks unusual, and the message uses sensitive wording."
        : "This sender address looks unusual.";
    }
    if (result.urlDomain && isNumericAddress(result.urlDomain)) {
      return "This link uses a numeric IP address instead of a normal website name.";
    }
    if (result.urlDomain && result.severity === "critical") {
      return "This link can be used to fake delivery, payment, or login pages.";
    }
    if (result.urlDomain && result.severity === "high") {
      return "This link has a suspicious destination.";
    }
    if (result.urlDomain) {
      return "This link goes somewhere unusual.";
    }
    if (result.brand && result.senderDomain && result.severity === "critical") {
      return `This looks like it may be from ${result.brand}, but email addresses can be faked.`;
    }
    if (result.brand && result.urlDomain && result.severity === "critical") {
      return `This does not look like ${result.brand}'s familiar site.`;
    }
    if (result.severity === "critical") {
      return "This message looks risky.";
    }
    if (result.severity === "high") {
      return "This message has risky signs.";
    }
    return warningTitle(result);
  }

  function appendProfessionalSenderVerdict(verdict, result) {
    if (!result.reason) {
      verdict.textContent = `${senderLabel(result)} needs a quick check.`;
      return;
    }

    const extensionMatch = result.reason.match(/^(uses the uncommon )(\.[a-z0-9-]+ extension)$/i);
    verdict.append("This sender address ");
    if (extensionMatch) {
      verdict.append(extensionMatch[1], createInlineEntity(extensionMatch[2], "reason"), ".");
      return;
    }

    verdict.append(createInlineEntity(result.reason, "reason"), ".");
  }

  function appendWarningContext(message, result, contextText) {
    if (result.context === "professional-sender-check") {
      message.append(" Sender: ", createInlineEntity(senderLabel(result), "sender"), ".");
      return;
    }

    if (result.brand && result.senderDomain) {
      message.append(" It came from ", createInlineEntity(result.senderDomain, "sender"), ".");
      return;
    }

    message.append(contextText.startsWith(" ") ? contextText : ` ${contextText}`);
  }

  function warningContextText(result) {
    if (result.context === "professional-sender-check") {
      return "Sender:";
    }
    if (result.context === "hosted-platform-link") {
      const sender = result.senderEmail || result.senderDomain;
      return sender
        ? ` Open it only if you expected it from ${sender}.`
        : " Open it only if you expected it.";
    }
    if (result.brand && result.senderDomain) {
      return "It came from:";
    }

    const message = (result.message || "")
      .replace(/^Likely phishing:\s*/i, "")
      .replace(/^the\b/, "The")
      .replace(/\s*Do not enter delivery, payment, or login information there\.$/i, "")
      .replace(/\s*Do not click links, pay, or enter personal information\.$/i, "")
      .replace(/\s*Do not click links or enter delivery\/payment information\.$/i, "")
      .replace(/\s*Don't use links in this message or share personal information\.$/i, "")
      .replace(/\s*Don't use links in the message for delivery, payment, or login details\.$/i, "")
      .trim();
    return message;
  }

  function warningKey(result) {
    const signalKey = (result.signals || [])
      .map((signal) => `${signal.id}:${(signal.phrases || []).join(",")}`)
      .join("|");
    return JSON.stringify([
      result.context || "",
      result.brandId || result.brand || "generic",
      result.senderEmail || "",
      result.senderDomain || "",
      result.url || "",
      result.urlDomain || "",
      result.displayedDomain || "",
      // Sender and link results repeat frequently across a mailbox. Include the
      // current message fingerprint so a dismissal never leaks into another mail.
      result.messageScopeKey || result.messageFingerprint || result.fingerprint || "",
      signalKey,
      result.score || 0
    ]);
  }

  function removeGlobalWarning() {
    ownedElementsMatching(".byebyefishing-warning, .byebyefishing-pointer").forEach((node) => node.remove());
    unhighlightAllContentPhrases();
  }

  function warningSignature(result) {
    const allowed = (result.allowedDomains || []).slice(0, 4).join(", ");
    return [
      warningKey(result),
      result.severity || "low",
      result.context || "",
      result.reason || "",
      warningTitle(result),
      result.message || "",
      allowed
    ].join("\n");
  }

  function buildWarningContent(result) {
    const allowed = (result.allowedDomains || []).slice(0, 4).join(", ");

    const content = document.createElement("div");
    content.className = "byebyefishing-warning__content";

    const header = document.createElement("div");
    header.className = "byebyefishing-warning__header";

    const heading = document.createElement("div");
    heading.className = "byebyefishing-warning__heading";

    const eyebrow = document.createElement("span");
    eyebrow.className = "byebyefishing-warning__eyebrow";
    eyebrow.textContent = `Bye Bye Fishing · ${severityLabel(result.severity)}`;

    const title = document.createElement("strong");
    title.textContent = warningTitle(result);
    heading.append(eyebrow, title);
    header.append(heading);

    const message = document.createElement("p");
    message.className = "byebyefishing-warning__message";

    const verdict = document.createElement("strong");
    verdict.className = "byebyefishing-warning__verdict";
    if (result.context === "professional-sender-check") {
      appendProfessionalSenderVerdict(verdict, result);
    } else {
      verdict.textContent = warningVerdict(result);
    }

    const contextText = warningContextText(result);
    if (contextText) {
      const context = document.createElement("span");
      appendWarningContext(context, result, contextText);
      message.append(verdict, context);
    } else {
      message.append(verdict);
    }

    const action = document.createElement("strong");
    action.className = "byebyefishing-warning__action";
    action.textContent = warningActionText(result);

    const detail = document.createElement("span");
    detail.className = "byebyefishing-warning__detail";
    detail.textContent = warningDetail(result, allowed);

    const signalText = warningSignalText(result);
    const evidence = document.createElement("span");
    evidence.className = "byebyefishing-warning__evidence";
    evidence.textContent = signalText;

    const controls = document.createElement("div");
    controls.className = "byebyefishing-warning__controls";
    if (canTrustSiteForSender(result)) {
      const trustSite = document.createElement("button");
      trustSite.type = "button";
      trustSite.className = "byebyefishing-warning__trust-domain";
      trustSite.textContent = "I expected this link from this sender";
      trustSite.title = `Remember ${detector.normalizeDomain(result.urlDomain)} for ${
        result.senderEmail || result.senderDomain
      }`;
      trustSite.setAttribute("aria-expanded", "false");
      trustSite.addEventListener("click", () => renderTrustSiteConfirmation(controls, result, trustSite));
      controls.append(trustSite);
    }

    if (canTrustSenderDomain(result)) {
      const senderDomain = detector.normalizeDomain(result.senderDomain);
      const trustSender = document.createElement("button");
      trustSender.type = "button";
      trustSender.className = "byebyefishing-warning__trust-domain";
      trustSender.textContent = "Add known sender domain";
      trustSender.title = `Add every address at ${displaySenderDomain(senderDomain)} for ${result.brand}`;
      trustSender.setAttribute(
        "aria-label",
        `Add ${displaySenderDomain(senderDomain)} as a known sender domain for ${result.brand}`
      );
      trustSender.setAttribute("aria-expanded", "false");
      trustSender.addEventListener("click", () => renderTrustConfirmation(controls, result, trustSender));
      controls.append(trustSender);
    }

    if (canRememberSenderWarning(result)) {
      const senderDomain = detector.normalizeDomain(result.senderDomain);
      const rememberSender = document.createElement("button");
      rememberSender.type = "button";
      rememberSender.className = "byebyefishing-warning__trust-domain";
      rememberSender.textContent = "Remember this sender domain";
      rememberSender.title = `Remember every address at ${displaySenderDomain(senderDomain)}`;
      rememberSender.setAttribute(
        "aria-label",
        `Remember ${displaySenderDomain(senderDomain)} as a sender you know`
      );
      rememberSender.setAttribute("aria-expanded", "false");
      rememberSender.addEventListener("click", () =>
        renderRememberSenderConfirmation(controls, senderDomain, rememberSender)
      );
      controls.append(rememberSender);
    }

    content.append(header, message, action);
    if (signalText) {
      content.append(evidence);
    }
    content.append(detail);
    if (controls.childElementCount > 0) {
      content.append(controls);
    }
    return content;
  }

  function makeWarningCloseButton(onClose) {
    const close = document.createElement("button");
    close.type = "button";
    close.className = "byebyefishing-warning__close";
    close.setAttribute("aria-label", "Dismiss this check");
    close.title = "Dismiss this check";
    close.textContent = "×";
    close.addEventListener("click", onClose);
    return close;
  }

  function removeInlineWarning() {
    ownedElementsMatching(".byebyefishing-warning--inline").forEach((node) => node.remove());
    unhighlightAllContentPhrases();
  }

  function dismissChosenWarning(key) {
    state.dismissedWarnings.add(key);
    removeGlobalWarning();
  }

  function resolveInlineAnchor(placement) {
    if (!placement) {
      return null;
    }
    if (placement.anchor instanceof HTMLElement && placement.anchor.isConnected) {
      return placement.anchor;
    }
    if (
      placement.anchorKind === "content" &&
      placement.scope instanceof HTMLElement &&
      placement.scope.isConnected
    ) {
      const body = placement.scope.querySelector(MESSAGE_BODY_SELECTOR);
      if (body instanceof HTMLElement && body.isConnected && !isOwnedExtensionNode(body)) {
        return body;
      }
    }
    return null;
  }

  function findExistingInlineCard(anchor, anchorKind) {
    if (anchorKind === "content") {
      const card = Array.from(anchor.children).find(
        (child) => isOwnedExtensionNode(child) && child.classList.contains("byebyefishing-warning--inline")
      );
      return card instanceof HTMLElement ? card : null;
    }

    let node = anchor.nextElementSibling;
    while (
      node instanceof HTMLElement &&
      isOwnedExtensionNode(node) &&
      node.classList.contains("byebyefishing-badge")
    ) {
      node = node.nextElementSibling;
    }
    return node instanceof HTMLElement &&
      isOwnedExtensionNode(node) &&
      node.classList.contains("byebyefishing-warning--inline")
      ? node
      : null;
  }

  function removeRedundantPillFor(anchor, anchorKind, card) {
    const pills = [];
    let node = anchor.nextElementSibling;
    while (node instanceof HTMLElement && node !== card) {
      const next = node.nextElementSibling;
      if (isOwnedExtensionNode(node) && node.classList.contains("byebyefishing-badge")) {
        pills.push(node);
      } else if (anchorKind === "content") {
        break;
      }
      node = next;
    }

    for (const pill of pills) {
      if (state.activeBadge === pill) {
        hideBadgeTooltip();
      }
      pill.remove();
    }
  }

  function renderInlineWarning(result, placement) {
    const key = warningKey(result);
    if (state.dismissedWarnings.has(key)) {
      removeInlineWarning();
      return false;
    }

    const anchor = resolveInlineAnchor(placement);
    if (!anchor) {
      removeInlineWarning();
      return false;
    }

    const signature = warningSignature(result);
    const existingCard = findExistingInlineCard(anchor, placement.anchorKind);
    if (existingCard && existingCard.dataset.byebyefishingSignature === signature) {
      ownedElementsMatching(".byebyefishing-warning--inline").forEach((node) => {
        if (node !== existingCard) {
          node.remove();
        }
      });
      removeRedundantPillFor(anchor, placement.anchorKind, existingCard);
      return true;
    }

    removeInlineWarning();

    const card = ownElement(document.createElement("section"));
    card.className = `byebyefishing-warning byebyefishing-warning--inline byebyefishing-warning--${
      result.severity || "low"
    }`;
    card.setAttribute("role", warningRank(result) >= 3 ? "alert" : "status");
    card.tabIndex = -1;
    card.id = INLINE_WARNING_ID;
    card.dataset.byebyefishingSignature = signature;
    card.dataset.byebyefishingKey = key;
    card.append(buildWarningContent(result), makeWarningCloseButton(() => dismissChosenWarning(key)));

    removeRedundantPillFor(anchor, placement.anchorKind, null);
    if (placement.anchorKind === "content") {
      anchor.insertAdjacentElement("afterbegin", card);
      highlightContentPhrases(anchor, result.signals);
    } else {
      anchor.insertAdjacentElement("afterend", card);
    }
    return true;
  }

  function reconcileInlineWarnings(firstWarning) {
    if (!firstWarning) {
      ownedElementsMatching(".byebyefishing-warning--inline").forEach((node) => node.remove());
      unhighlightAllContentPhrases();
      return;
    }

    const key = warningKey(firstWarning.result);
    let keptCard = null;
    ownedElementsMatching(".byebyefishing-warning--inline").forEach((node) => {
      if (!keptCard && node.dataset.byebyefishingKey === key) {
        keptCard = node;
      } else {
        node.remove();
      }
    });

    const anchorBody =
      keptCard && firstWarning.anchorKind === "content" && keptCard.parentElement instanceof HTMLElement
        ? keptCard.parentElement
        : null;
    ownedElementsMatching("span.byebyefishing-highlight").forEach((mark) => {
      if (!anchorBody || !anchorBody.contains(mark)) {
        unwrapHighlightSpan(mark);
      }
    });
  }

  function renderWarning(result, placement) {
    const key = warningKey(result);
    if (state.dismissedWarnings.has(key)) {
      removeGlobalWarning();
      return;
    }

    const hasInlineCard = renderInlineWarning(result, placement);

    let pointer = ownedElementsMatching(".byebyefishing-pointer")[0] || null;
    const signature = `${warningSignature(result)}\n${hasInlineCard ? "inline" : "no-inline"}`;
    if (pointer?.dataset.byebyefishingSignature === signature) {
      return;
    }

    if (!pointer) {
      pointer = ownElement(document.createElement("aside"));
      pointer.setAttribute("role", "region");
      pointer.setAttribute("aria-label", "Bye Bye Fishing warning shortcut");
      document.documentElement.appendChild(pointer);
    }
    pointer.className = `byebyefishing-pointer byebyefishing-pointer--${result.severity || "low"}`;
    pointer.dataset.byebyefishingSignature = signature;
    pointer.innerHTML = "";

    const jump = document.createElement("button");
    jump.type = "button";
    jump.className = "byebyefishing-pointer__jump";
    jump.textContent = hasInlineCard
      ? `${severityLabel(result.severity)} — review the highlighted check`
      : `${severityLabel(result.severity)} — ${warningTitle(result)}`;
    if (hasInlineCard) {
      jump.addEventListener("click", () => {
        const card = ownedElementsMatching(`#${INLINE_WARNING_ID}`)[0] || null;
        if (!(card instanceof HTMLElement) || !card.isConnected) {
          return;
        }
        const reduceMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
        card.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "center" });
        card.focus({ preventScroll: true });
        card.classList.add("byebyefishing-warning--flash");
        setTimeout(() => card.classList.remove("byebyefishing-warning--flash"), 1200);
      });
    } else {
      jump.disabled = true;
    }

    const close = document.createElement("button");
    close.type = "button";
    close.className = "byebyefishing-pointer__close";
    close.setAttribute("aria-label", "Dismiss this check");
    close.title = "Dismiss this check";
    close.textContent = "×";
    close.addEventListener("click", () => dismissChosenWarning(key));

    pointer.append(jump, close);
  }

  // --- Inline phrase highlighting -----------------------------------------

  // Must stay in sync with detector.js normalizeText: strip accents, lowercase,
  // drop apostrophes, and collapse runs of non-letter/non-number characters to one space.
  function normalizePhraseText(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[\u2019']/g, "")
      .replace(/[^\p{L}\p{N}]+/gu, " ")
      .trim();
  }

  function normalizedCharContribution(char) {
    return char
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[\u2019']/g, "");
  }

  function isPhraseSeparatorChar(char) {
    return /[^\p{L}\p{N}]/u.test(char);
  }

  // Returns the normalized form of `original` plus, for each normalized character,
  // the [start, end) code-unit offsets in `original` it maps back to.
  function buildNormalizedIndex(original) {
    let normalized = "";
    const origStart = [];
    const origEnd = [];
    let inSeparatorRun = false;
    let separatorRunStart = -1;

    for (let i = 0; i < original.length; i += 1) {
      const contribution = normalizedCharContribution(original[i]);
      for (const char of contribution) {
        if (isPhraseSeparatorChar(char)) {
          if (!inSeparatorRun) {
            inSeparatorRun = true;
            separatorRunStart = i;
          }
          continue;
        }
        if (inSeparatorRun) {
          inSeparatorRun = false;
          if (normalized.length > 0) {
            normalized += " ";
            origStart.push(separatorRunStart);
            origEnd.push(i);
          }
        }
        normalized += char;
        origStart.push(i);
        origEnd.push(i + 1);
      }
    }

    return { normalized, origStart, origEnd };
  }

  // Must stay in sync with detector.js isBoundedToken: a single Latin/digit word
  // (normalizePhraseText already lowercases and strips diacritics) only matches on
  // word boundaries, so short tokens like "rib" aren't highlighted inside "contributions".
  function isBoundedHighlightToken(normalized) {
    return /^[a-z0-9]+$/.test(normalized);
  }

  function isWordBoundaryChar(char) {
    return char === undefined || !/[a-z0-9]/.test(char);
  }

  function collectHighlightTargets(signals) {
    if (!Array.isArray(signals)) {
      return [];
    }

    const seen = new Set();
    const targets = [];
    for (const signal of signals) {
      const phrases = Array.isArray(signal?.phrases) ? signal.phrases : [];
      for (const phrase of phrases) {
        const normalized = normalizePhraseText(phrase);
        if (normalized.length >= 2 && !seen.has(normalized)) {
          seen.add(normalized);
          targets.push({ text: normalized, bounded: isBoundedHighlightToken(normalized) });
        }
      }
    }

    return targets.sort((first, second) => second.text.length - first.text.length);
  }

  function isHighlightableTextNode(node) {
    if (!node.nodeValue || !node.nodeValue.trim()) {
      return false;
    }
    const parent = node.parentElement;
    if (!parent) {
      return false;
    }
    if (
      isOwnedExtensionNode(parent) || parent.closest("script, style, noscript")
    ) {
      return false;
    }
    return !parent.isContentEditable;
  }

  function findPhraseRangesInText(original, targets) {
    const { normalized, origStart, origEnd } = buildNormalizedIndex(original);
    if (!normalized) {
      return [];
    }

    const ranges = [];
    for (const target of targets) {
      const text = target.text;
      let from = 0;
      let index = normalized.indexOf(text, from);
      while (index !== -1) {
        const atBoundary =
          !target.bounded ||
          (isWordBoundaryChar(normalized[index - 1]) && isWordBoundaryChar(normalized[index + text.length]));
        if (atBoundary) {
          const start = origStart[index];
          const end = origEnd[index + text.length - 1];
          if (typeof start === "number" && typeof end === "number" && end > start) {
            ranges.push({ start, end });
          }
          from = index + text.length;
        } else {
          from = index + 1;
        }
        index = normalized.indexOf(text, from);
      }
    }

    ranges.sort((first, second) => first.start - second.start || second.end - first.end);

    const merged = [];
    for (const range of ranges) {
      const last = merged[merged.length - 1];
      if (last && range.start < last.end) {
        last.end = Math.max(last.end, range.end);
      } else {
        merged.push({ start: range.start, end: range.end });
      }
    }

    return merged;
  }

  function wrapTextNodeRange(textNode, start, end) {
    const matchNode = textNode.splitText(start);
    matchNode.splitText(end - start);

    const span = ownElement(document.createElement("span"));
    span.className = "byebyefishing-highlight";
    matchNode.parentNode.insertBefore(span, matchNode);
    span.appendChild(matchNode);

    const mark = document.createElement("span");
    mark.className = "byebyefishing-highlight__mark";
    mark.setAttribute("aria-hidden", "true");
    mark.textContent = BADGE_SOURCE_MARK;
    span.appendChild(mark);
  }

  function unwrapHighlightSpan(mark) {
    const parent = mark.parentNode;
    if (!parent) {
      return;
    }
    Array.from(mark.childNodes).forEach((child) => {
      if (child instanceof HTMLElement && child.classList.contains("byebyefishing-highlight__mark")) {
        child.remove();
        return;
      }
      parent.insertBefore(child, mark);
    });
    parent.removeChild(mark);
    if (typeof parent.normalize === "function") {
      parent.normalize();
    }
  }

  function unhighlightAllContentPhrases() {
    ownedElementsMatching("span.byebyefishing-highlight").forEach(unwrapHighlightSpan);
  }

  function unhighlightContentPhrases(scopeEl) {
    if (!(scopeEl instanceof HTMLElement)) {
      return;
    }
    scopeEl
      .querySelectorAll("span.byebyefishing-highlight")
      .forEach((mark) => isOwnedExtensionNode(mark) && unwrapHighlightSpan(mark));
  }

  function highlightContentPhrases(bodyEl, signals) {
    if (!(bodyEl instanceof HTMLElement)) {
      return;
    }
    unhighlightContentPhrases(bodyEl);

    const targets = collectHighlightTargets(signals);
    if (targets.length === 0) {
      return;
    }

    const textNodes = [];
    const walker = document.createTreeWalker(bodyEl, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        return isHighlightableTextNode(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      textNodes.push(node);
    }

    let wrapped = 0;
    for (const node of textNodes) {
      if (wrapped >= MAX_INLINE_HIGHLIGHTS) {
        break;
      }
      const ranges = findPhraseRangesInText(node.nodeValue, targets);
      for (let r = ranges.length - 1; r >= 0; r -= 1) {
        if (wrapped >= MAX_INLINE_HIGHLIGHTS) {
          break;
        }
        wrapTextNodeRange(node, ranges[r].start, ranges[r].end);
        wrapped += 1;
      }
    }
  }

  function badgeInfo(result) {
    if (result.status === "trusted") {
      return { label: "on your list", tone: "trusted" };
    }
    if (result.context === "trusted-sender-content-check" || result.context === "trusted-sender-link-check") {
      return { label: "double check", tone: "risk" };
    }
    if (result.status === "warning" && (result.severity === "critical" || result.severity === "high")) {
      return { label: "high risk", tone: "high-risk" };
    }
    if (result.status === "warning" && result.severity === "medium") {
      return { label: "check", tone: "risk" };
    }
    if (result.status === "warning") {
      return { label: "heads-up", tone: "notice" };
    }
    return null;
  }

  function badgeSignature(result) {
    const info = badgeInfo(result);
    if (!info) {
      return "";
    }
    return [info.tone, info.label, result.message || ""].join("\n");
  }

  function ensureBadgeTooltip() {
    if (state.badgeTooltip?.isConnected) {
      return state.badgeTooltip;
    }

    const tooltip = ownElement(document.createElement("div"));
    tooltip.id = "byebyefishing-badge-tooltip";
    tooltip.className = "byebyefishing-badge-tooltip";
    tooltip.setAttribute("role", "tooltip");
    document.body.append(tooltip);
    state.badgeTooltip = tooltip;
    return tooltip;
  }

  function positionBadgeTooltip(badge, tooltip) {
    const badgeRect = badge.getBoundingClientRect();
    const tooltipRect = tooltip.getBoundingClientRect();
    const spacing = 6;
    const padding = 8;
    const maxLeft = window.innerWidth - tooltipRect.width - padding;
    const centeredLeft = badgeRect.left + badgeRect.width / 2 - tooltipRect.width / 2;
    const left = Math.max(padding, Math.min(centeredLeft, maxLeft));
    let top = badgeRect.bottom + spacing;

    if (top + tooltipRect.height + padding > window.innerHeight) {
      top = Math.max(padding, badgeRect.top - tooltipRect.height - spacing);
    }

    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;
  }

  function showBadgeTooltip(badge) {
    const detail = badge.dataset.byebyefishingDetail || "";
    if (!detail) {
      if (state.activeBadge === badge) {
        hideBadgeTooltip();
      }
      return;
    }

    const tooltip = ensureBadgeTooltip();
    tooltip.textContent = "";
    tooltip.append(document.createTextNode(detail));
    if (badge.dataset.byebyefishingSourceMark === "true") {
      const source = document.createElement("span");
      source.className = "byebyefishing-badge-tooltip__source";
      source.setAttribute("aria-hidden", "true");
      source.textContent = BADGE_SOURCE_MARK;
      tooltip.append(source);
    }
    tooltip.classList.remove("byebyefishing-badge-tooltip--visible");
    positionBadgeTooltip(badge, tooltip);
    tooltip.classList.add("byebyefishing-badge-tooltip--visible");
    badge.setAttribute("aria-describedby", tooltip.id);
    badge.setAttribute("aria-expanded", "true");
    state.activeBadge = badge;
  }

  function hideBadgeTooltip() {
    if (state.activeBadge) {
      state.activeBadge.removeAttribute("aria-describedby");
      state.activeBadge.setAttribute("aria-expanded", "false");
    }
    state.activeBadge = null;
    state.badgeTooltip?.classList.remove("byebyefishing-badge-tooltip--visible");
  }

  function syncBadgeTooltipPosition() {
    if (!state.activeBadge?.isConnected || !state.badgeTooltip?.isConnected) {
      hideBadgeTooltip();
      return;
    }

    positionBadgeTooltip(state.activeBadge, state.badgeTooltip);
  }

  function restoreDismissedWarningFromBadge(badge) {
    const key = badge.dataset.byebyefishingWarningKey || "";
    if (!key || !state.dismissedWarnings.has(key)) {
      return false;
    }
    state.dismissedWarnings.delete(key);
    hideBadgeTooltip();
    scheduleScan();
    return true;
  }

  function bindBadgeTooltip(badge) {
    if (badge.dataset.byebyefishingTooltipBound === "true") {
      return;
    }

    badge.dataset.byebyefishingTooltipBound = "true";
    badge.addEventListener("mouseenter", () => showBadgeTooltip(badge));
    badge.addEventListener("mouseleave", hideBadgeTooltip);
    badge.addEventListener("focus", () => showBadgeTooltip(badge));
    badge.addEventListener("blur", hideBadgeTooltip);
    badge.addEventListener("pointerdown", (event) => {
      event.stopPropagation();
    });
    badge.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (restoreDismissedWarningFromBadge(badge)) {
        return;
      }
      showBadgeTooltip(badge);
    });
    badge.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        hideBadgeTooltip();
        badge.focus();
        return;
      }
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        event.stopPropagation();
        if (restoreDismissedWarningFromBadge(badge)) {
          return;
        }
        showBadgeTooltip(badge);
      }
    });
  }

  function shouldShowBadgeSourceMark(info) {
    return info.tone === "risk" || info.tone === "high-risk";
  }

  function renderBadgeContent(badge, info) {
    badge.textContent = "";
    badge.append(document.createTextNode(info.label));

    if (!shouldShowBadgeSourceMark(info)) {
      return;
    }

    const source = document.createElement("span");
    source.className = "byebyefishing-badge__source";
    source.setAttribute("aria-hidden", "true");
    source.textContent = BADGE_SOURCE_MARK;
    badge.append(source);
  }

  function renderStatusBadge(element, result, seenBadges) {
    if (!state.showTrustedBadges && result.status !== "warning") {
      return;
    }
    if (result.status === "warning" && result.severity === "low" && !state.showInformationalNotices) {
      return;
    }

    const info = badgeInfo(result);
    if (!info) {
      return;
    }
    const warningKeyValue = warningKey(result);
    const isDismissed = result.status === "warning" && state.dismissedWarnings.has(warningKeyValue);
    const signature = `${badgeSignature(result)}\n${isDismissed ? "dismissed" : "active"}`;
    let badge = element.nextElementSibling;
    if (
      !(badge instanceof HTMLElement) ||
      !isOwnedExtensionNode(badge) ||
      !badge.classList.contains("byebyefishing-badge")
    ) {
      badge = ownElement(document.createElement("span"));
      element.insertAdjacentElement("afterend", badge);
    }

    if (badge.dataset.byebyefishingSignature !== signature) {
      badge.className = `byebyefishing-badge byebyefishing-badge--${info.tone}`;
      badge.removeAttribute("title");
      renderBadgeContent(badge, info);
      badge.dataset.byebyefishingDetail = isDismissed
        ? `${result.message || "Warning details hidden."} Activate this badge to show the full warning again.`
        : result.message || "";
      badge.dataset.byebyefishingWarningKey = warningKeyValue;
      badge.dataset.byebyefishingSourceMark = shouldShowBadgeSourceMark(info) ? "true" : "false";
      badge.setAttribute(
        "aria-label",
        result.message
          ? `${info.label}. ${isDismissed ? "Restore" : "Show"} Bye Bye Fishing details.`
          : info.label
      );
      if (result.message) {
        badge.tabIndex = 0;
        badge.setAttribute("role", "button");
        badge.setAttribute("aria-expanded", "false");
      } else {
        badge.removeAttribute("tabindex");
        badge.removeAttribute("role");
        badge.removeAttribute("aria-expanded");
      }
      badge.dataset.byebyefishingSignature = signature;
    }
    bindBadgeTooltip(badge);
    if (state.activeBadge === badge) {
      showBadgeTooltip(badge);
    }
    seenBadges.add(badge);
  }

  function reconcileBadges(seenBadges) {
    ownedElementsMatching(".byebyefishing-badge").forEach((badge) => {
      if (!seenBadges.has(badge)) {
        if (state.activeBadge === badge) {
          hideBadgeTooltip();
        }
        badge.remove();
      }
    });
  }

  function shouldRenderDetailBadge(result) {
    return (
      result.status === "warning" &&
      (result.severity !== "low" || state.showInformationalNotices)
    );
  }

  function shouldRenderGlobalWarning(result) {
    return (
      result.status === "warning" &&
      warningRank(result) >= 2 &&
      result.context !== "trusted-sender-site" &&
      result.context !== "trusted-sender-link-check"
    );
  }

  function withIncompleteScanResult(result, samplingMetrics) {
    if (
      !samplingMetrics ||
      samplingMetrics.highestOmittedRiskScore < 3 ||
      warningRank(result) >= 2
    ) {
      return result;
    }

    return {
      ...result,
      status: "warning",
      severity: "medium",
      context: "scan-incomplete",
      score: Math.max(
        Number(result?.score || 0),
        samplingMetrics.highestOmittedRiskScore
      ),
      message:
        "Some security-sensitive sections of this long message were omitted by the local scan.",
      scanMetrics: samplingMetrics
    };
  }

  function scanMailListBadges(seenBadges) {
    for (const candidate of collectMailListSenderCandidates()) {
      const result = withGreenFlagSenderResult(detector.analyzeSender(candidate.text, state.rules));
      renderStatusBadge(candidate.element, result, seenBadges);
    }
  }

  function scanPage() {
    const seenBadges = new Set();
    const contentCandidates = collectContentCandidates();
    const messageScopes = collectMessageScopes(contentCandidates);

    if (messageScopes.length === 0) {
      scanMailListBadges(seenBadges);
      reconcileBadges(seenBadges);
      removeGlobalWarning();
      return;
    }

    const trustedSenderByScope = new Map();
    const senderByScope = new Map();
    const senderResultByScope = new Map();
    const senderAnchorByScope = new Map();
    const linkResultsByScope = new Map();
    const contentResultByCandidate = new Map();
    const contentTextByCandidate = new Map();
    const contentEntriesByScope = new Map();
    const sampledFingerprintByScope = new Map();
    const incompleteFingerprintPartsByScope = new Map();
    const messageFingerprintByScope = new Map();
    const messageScopeKeyByScope = new Map();
    const badgeTargets = [];
    let firstWarning = null;

    for (const candidate of contentCandidates) {
      const scope = messageScopeFor(candidate.element);
      const contentText = [candidate.subject, candidate.text].filter(Boolean).join("\n");
      const result = detector.analyzeContent(contentText);
      contentTextByCandidate.set(candidate, contentText);
      contentResultByCandidate.set(candidate, result);
      if (result.fingerprint && !sampledFingerprintByScope.has(scope)) {
        sampledFingerprintByScope.set(scope, result.fingerprint);
      }
      if (
        candidate.samplingMetrics?.highestOmittedRiskScore >= 3 &&
        candidate.samplingMetrics.fullTextFingerprint
      ) {
        const parts = incompleteFingerprintPartsByScope.get(scope) || [];
        parts.push(candidate.samplingMetrics.fullTextFingerprint);
        incompleteFingerprintPartsByScope.set(scope, parts);
      }
    }

    for (const scope of messageScopes) {
      const sampledFingerprint = sampledFingerprintByScope.get(scope) || "";
      const incompleteParts = incompleteFingerprintPartsByScope.get(scope) || [];
      const fingerprint = incompleteParts.length > 0
        ? scanPolicy.boundedTextFingerprint(
            [sampledFingerprint, ...incompleteParts].join("\u0000"),
            "message-scope"
          )
        : sampledFingerprint;
      if (fingerprint) {
        messageFingerprintByScope.set(scope, fingerprint);
        messageScopeKeyByScope.set(scope, messageScopeKey(scope, fingerprint));
      }
    }

    for (const scope of messageScopes) {
      const candidate = collectSenderCandidates([scope])[0];
      if (candidate) {
        const result = {
          ...withGreenFlagSenderResult(detector.analyzeSender(candidate.text, state.rules)),
          messageFingerprint: messageFingerprintByScope.get(scope) || "",
          messageScopeKey: messageScopeKeyByScope.get(scope) || messageScopeKey(scope, "")
        };
        const senderIdentity = senderIdentityFromResult(result);
        if (senderIdentity) {
          senderByScope.set(scope, senderIdentity);
        }
        const trustedSender = trustedSenderContext(result);
        if (trustedSender) {
          trustedSenderByScope.set(scope, trustedSender);
        }
        senderResultByScope.set(scope, result);
        senderAnchorByScope.set(scope, candidate.element);
        badgeTargets.push({ element: candidate.element, result });
      }
    }

    for (const scope of messageScopes) {
      for (const candidate of collectLinkCandidates([scope])) {
        const sender = senderByScope.get(scope) || null;
        const trustedSender = trustedSenderByScope.get(scope) || null;
        const analyzed = detector.analyzeLink
          ? detector.analyzeLink(candidate.text, candidate.href, state.rules)
          : detector.analyzeUrl(candidate.href, state.rules);
        const result = withTrustedSenderLinkCheckResult(
          withTrustedSenderSiteResult(
            {
              ...analyzed,
              selectionTruncated: candidate.selectionTruncated === true,
              totalLinkCandidates: candidate.totalLinkCandidates || 0,
              senderEmail: sender?.senderEmail || "",
              senderDomain: sender?.senderDomain || "",
              messageFingerprint: messageFingerprintByScope.get(scope) || "",
              messageScopeKey: messageScopeKeyByScope.get(scope) || messageScopeKey(scope, "")
            },
            sender
          ),
          trustedSender
        );
        const scopeLinks = linkResultsByScope.get(scope) || [];
        scopeLinks.push({ element: candidate.element, result });
        linkResultsByScope.set(scope, scopeLinks);
        if (shouldRenderDetailBadge(result)) {
          badgeTargets.push({ element: candidate.element, result });
        }
      }
    }

    for (const candidate of contentCandidates) {
      const scope = messageScopeFor(candidate.element);
      const sender = senderByScope.get(scope) || null;
      const trustedSender = trustedSenderByScope.get(scope) || null;
      const baseResult = contentResultByCandidate.get(candidate);
      const result = {
        ...withIncompleteScanResult(
          trustedSender
            ? detector.analyzeContent(contentTextByCandidate.get(candidate) || "", { trustedSender })
            : baseResult,
          candidate.samplingMetrics
        ),
        senderEmail: sender?.senderEmail || "",
        senderDomain: sender?.senderDomain || "",
        messageFingerprint:
          messageFingerprintByScope.get(scope) || baseResult?.fingerprint || "",
        messageScopeKey: messageScopeKeyByScope.get(scope) || messageScopeKey(scope, baseResult?.fingerprint)
      };
      const scopeContent = contentEntriesByScope.get(scope) || [];
      scopeContent.push({ element: candidate.element, result });
      contentEntriesByScope.set(scope, scopeContent);
      if (shouldRenderDetailBadge(result)) {
        badgeTargets.push({ element: candidate.element, result });
      }
    }

    for (const scope of messageScopes) {
      const senderResult = senderResultByScope.get(scope) || null;
      const linkEntries = linkResultsByScope.get(scope) || [];
      const contentEntries = contentEntriesByScope.get(scope) || [];
      const contentEntry =
        contentEntries
          .slice()
          .sort(
            (first, second) =>
              warningRank(second.result) - warningRank(first.result) ||
              Number(second.result?.score || 0) - Number(first.result?.score || 0)
          )[0] || null;
      const reconciled = detector.reconcileMessageResults
        ? detector.reconcileMessageResults({
            sender: senderResult,
            links: linkEntries.map((entry) => entry.result),
            content: contentEntry?.result || null
          })
        : {
            top:
              [
                senderResult,
                ...linkEntries.map((entry) => entry.result),
                contentEntry?.result
              ]
                .filter(Boolean)
                .sort((first, second) => warningRank(second) - warningRank(first))[0] || null,
            content: contentEntry?.result || null
          };
      const result = reconciled.top;
      if (!result || !shouldRenderGlobalWarning(result)) {
        continue;
      }

      const matchingLink = linkEntries.find((entry) => entry.result === result);
      const isSenderResult = result === senderResult;
      const anchor = isSenderResult
        ? senderAnchorByScope.get(scope)
        : matchingLink?.element || contentEntry?.element || senderAnchorByScope.get(scope);
      if (
        anchor &&
        shouldReplaceGlobalWarning(result, firstWarning?.result)
      ) {
        firstWarning = {
          result,
          anchor,
          anchorKind: isSenderResult ? "sender" : matchingLink ? "link" : "content",
          scope
        };
      }
    }

    badgeTargets
      .filter((target) => !firstWarning || target.element !== firstWarning.anchor)
      .sort((first, second) => warningRank(second.result) - warningRank(first.result))
      .slice(0, MAX_RENDERED_DETAIL_BADGES)
      .forEach((target) => {
        // The rich inline card stands in for the tiny pill on the chosen element.
        renderStatusBadge(target.element, target.result, seenBadges);
      });

    reconcileBadges(seenBadges);
    if (firstWarning) {
      renderWarning(firstWarning.result, firstWarning);
    } else {
      removeGlobalWarning();
    }
    reconcileInlineWarnings(firstWarning);
  }

  function scheduleScan() {
    clearTimeout(state.scanTimer);
    state.scanTimer = setTimeout(scanPage, 250);
  }

  function isExtensionNode(node) {
    return isOwnedExtensionNode(node);
  }

  function shouldScheduleFromMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return false;
    }
    if (mutation.type === "attributes") {
      return true;
    }

    let sawElement = false;
    let sawText = false;
    const nodeLists = [mutation.addedNodes, mutation.removedNodes];
    for (const nodes of nodeLists) {
      for (const node of nodes) {
        if (node instanceof Element) {
          sawElement = true;
          if (!isExtensionNode(node)) {
            return true;
          }
          continue;
        }
        if (node.textContent && node.textContent.trim()) {
          sawText = true;
        }
      }
    }

    return !sawElement && sawText;
  }

  function shouldScheduleFromMutations(mutations) {
    return mutations.some(shouldScheduleFromMutation);
  }

  async function start() {
    await loadSettings();
    if (!state.privacyConsentGranted) {
      return;
    }
    scanPage();

    const observer = new MutationObserver((mutations) => {
      if (shouldScheduleFromMutations(mutations)) {
        scheduleScan();
      }
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["email", "title", "aria-label", "href"]
    });

    window.addEventListener("resize", syncBadgeTooltipPosition);
    window.addEventListener("scroll", syncBadgeTooltipPosition, true);
    document.addEventListener(
      "pointerdown",
      (event) => {
        if (
          state.activeBadge &&
          event.target !== state.activeBadge &&
          !state.activeBadge.contains(event.target) &&
          !state.badgeTooltip?.contains(event.target)
        ) {
          hideBadgeTooltip();
        }
      },
      true
    );

    extensionApi.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local") {
        return;
      }

      if (changes.byebyefishingRulesCustom) {
        state.rulesCustom = changes.byebyefishingRulesCustom.newValue === true;
      }
      if (changes.byebyefishingRules?.newValue) {
        const validation = detector.validateRules(changes.byebyefishingRules.newValue);
        state.rules = validation.ok
          ? state.rulesCustom
            ? changes.byebyefishingRules.newValue
            : mergeSavedRules(changes.byebyefishingRules.newValue)
          : defaultRules;
      }
      if (changes.byebyefishingTrustedSenderSites) {
        state.trustedSenderSites = normalizeTrustedSenderSites(
          changes.byebyefishingTrustedSenderSites.newValue
        );
      }
      if (changes.byebyefishingShowTrustedBadges) {
        state.showTrustedBadges = changes.byebyefishingShowTrustedBadges.newValue !== false;
      }
      if (changes.byebyefishingShowInformationalNotices) {
        state.showInformationalNotices = changes.byebyefishingShowInformationalNotices.newValue === true;
      }
      if (changes.byebyefishingGreenFlagSenderDomains) {
        state.greenFlagSenderDomains = normalizeGreenFlagSenderDomains(
          changes.byebyefishingGreenFlagSenderDomains.newValue
        );
      }
      if (state.skipNextMemoryChangeScan) {
        state.skipNextMemoryChangeScan = false;
        return;
      }
      if (state.skipNextRuleChangeScan) {
        state.skipNextRuleChangeScan = false;
        return;
      }
      scheduleScan();
    });
  }

  start().catch(() => {
    state.rules = defaultRules;
  });
})(typeof globalThis !== "undefined" ? globalThis : this);
