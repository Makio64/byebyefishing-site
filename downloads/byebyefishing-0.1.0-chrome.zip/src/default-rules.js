(function exposeDefaultRules(global) {
  "use strict";

  const RULESET_VERSION = "2026-05-07.10";

  function rule(category, id, name, aliases, allowedDomains, options = {}) {
    return { category, id, name, aliases, allowedDomains, ...options };
  }

  const rules = [
    rule("developer", "stripe", "Stripe", ["stripe"], [
      "stripe.com",
      "stripe.dev",
      "stripe.events",
      "stripe.global",
      "link.com"
    ]),
    rule("developer", "github", "GitHub", ["github"], [
      "github.com",
      "githubstatus.com"
    ]),
    rule("developer", "gitlab", "GitLab", ["gitlab"], ["gitlab.com"]),
    rule("developer", "bitbucket", "Bitbucket", ["bitbucket"], ["bitbucket.org", "atlassian.com"]),
    rule("developer", "atlassian", "Atlassian", ["atlassian", "jira", "confluence"], [
      "atlassian.com",
      "jira.com",
      "statuspage.io",
      "trello.com"
    ]),
    rule("developer", "npm", "npm", ["npm", "npmjs"], ["npmjs.com"]),
    rule("developer", "pypi", "Python Package Index", ["pypi", "python package index"], [
      "pypi.org",
      "python.org"
    ]),
    rule("developer", "docker", "Docker", ["docker", "docker hub"], [
      "docker.com",
      "docker.io"
    ]),
    rule("developer", "cloudflare", "Cloudflare", ["cloudflare"], [
      "cloudflare.com",
      "cloudflarestatus.com"
    ]),
    rule("developer", "vercel", "Vercel", ["vercel"], ["vercel.com"]),
    rule("developer", "netlify", "Netlify", ["netlify"], ["netlify.com"]),
    rule("developer", "aws", "Amazon Web Services", ["aws", "amazon web services"], [
      "aws.amazon.com",
      "amazonaws.com",
      "amazon.com"
    ]),
    rule("developer", "google-cloud", "Google Cloud", ["google cloud", "gcp", "firebase"], [
      "cloud.google.com",
      "console.cloud.google.com",
      "firebase.google.com",
      "firebaseapp.com"
    ], {
      senderDomains: ["google.com"],
      senderMatchSubdomains: false
    }),
    rule("developer", "azure", "Microsoft Azure", ["azure", "microsoft azure"], [
      "microsoft.com",
      "azure.com"
    ]),
    rule("developer", "digitalocean", "DigitalOcean", ["digitalocean"], ["digitalocean.com"]),
    rule("developer", "heroku", "Heroku", ["heroku"], ["heroku.com", "salesforce.com"]),
    rule("developer", "supabase", "Supabase", ["supabase"], ["supabase.com"]),
    rule("developer", "mongodb", "MongoDB", ["mongodb", "mongo db"], ["mongodb.com"]),
    rule("developer", "planetscale", "PlanetScale", ["planetscale"], ["planetscale.com"]),
    rule("developer", "neon", "Neon", ["neon database", "neon postgres", "neon.tech"], [
      "neon.tech"
    ]),
    rule("developer", "railway", "Railway", ["railway.app", "railway hosting"], [
      "railway.app"
    ]),
    rule("developer", "render", "Render", ["render.com", "render hosting"], ["render.com"]),
    rule("developer", "fly-io", "Fly.io", ["fly.io", "fly app"], ["fly.io"]),
    rule("developer", "twilio", "Twilio", ["twilio"], ["twilio.com", "segment.com"]),
    rule("developer", "sendgrid", "SendGrid", ["sendgrid"], ["sendgrid.com", "twilio.com"]),
    rule("developer", "mailgun", "Mailgun", ["mailgun"], ["mailgun.com"]),
    rule("developer", "postmark", "Postmark", ["postmark"], ["postmarkapp.com"]),
    rule("developer", "resend", "Resend", ["resend.com", "resend email"], ["resend.com"]),
    rule("developer", "mailchimp", "Mailchimp", ["mailchimp"], [
      "mailchimp.com",
      "intuit.com"
    ]),
    rule("developer", "linear", "Linear", ["linear.app", "linear issue"], ["linear.app"]),
    rule("developer", "sentry", "Sentry", ["sentry"], ["sentry.io"]),
    rule("developer", "datadog", "Datadog", ["datadog"], ["datadoghq.com", "datadog.com"]),
    rule("developer", "new-relic", "New Relic", ["new relic", "newrelic"], ["newrelic.com"]),
    rule("developer", "circleci", "CircleCI", ["circleci", "circle ci"], ["circleci.com"]),
    rule("developer", "travis-ci", "Travis CI", ["travis ci", "travis-ci"], ["travis-ci.com"]),
    rule("developer", "buildkite", "Buildkite", ["buildkite"], ["buildkite.com"]),
    rule("developer", "jetbrains", "JetBrains", ["jetbrains"], ["jetbrains.com"]),
    rule("developer", "hashicorp", "HashiCorp", ["hashicorp", "terraform cloud"], [
      "hashicorp.com"
    ]),
    rule("developer", "openai", "OpenAI", ["openai", "chatgpt"], [
      "openai.com",
      "chatgpt.com"
    ]),
    rule("developer", "anthropic", "Anthropic", ["anthropic", "claude"], [
      "anthropic.com",
      "claude.ai"
    ]),

    rule("payments", "paypal", "PayPal", ["paypal"], ["paypal.com", "paypal.fr"]),
    rule("payments", "adyen", "Adyen", ["adyen"], ["adyen.com"]),
    rule("payments", "mollie", "Mollie", ["mollie"], ["mollie.com"]),
    rule("payments", "checkout", "Checkout.com", ["checkout.com", "checkout payments"], [
      "checkout.com"
    ]),
    rule("payments", "paddle", "Paddle", ["paddle payments", "paddle.com"], ["paddle.com"]),
    rule("payments", "lemonsqueezy", "Lemon Squeezy", ["lemon squeezy", "lemonsqueezy"], [
      "lemonsqueezy.com"
    ]),
    rule("payments", "square", "Square", ["square payments", "squareup"], [
      "squareup.com",
      "block.xyz"
    ]),
    rule("payments", "cash-app", "Cash App", ["cash app", "cash.app"], ["cash.app"]),
    rule("payments", "venmo", "Venmo", ["venmo"], ["venmo.com"]),
    rule("payments", "wise", "Wise", ["wise.com", "wise payments", "transferwise"], [
      "wise.com",
      "transferwise.com"
    ]),
    rule("payments", "revolut", "Revolut", ["revolut"], ["revolut.com"]),
    rule("payments", "lydia-sumeria", "Lydia / Sumeria", ["lydia", "sumeria"], [
      "lydia-app.com",
      "sumeria.eu"
    ]),
    rule("payments", "klarna", "Klarna", ["klarna"], [
      "klarna.com",
      "klarna.fr",
      "app.klarna.com",
      "checkout.klarna.com",
      "portal.klarna.com",
      "merchants.klarna.com",
      "investors.klarna.com"
    ], {
      senderDomains: ["klarna.com", "klarna.fr"],
      senderMatchSubdomains: true
    }),
    rule("payments", "afterpay", "Afterpay", ["afterpay"], ["afterpay.com"]),
    rule("payments", "affirm", "Affirm", ["affirm"], ["affirm.com"]),
    rule("payments", "worldline", "Worldline", ["worldline"], ["worldline.com"]),
    rule("payments", "visa", "Visa", ["visa card", "visa.com"], ["visa.com"]),
    rule("payments", "mastercard", "Mastercard", ["mastercard"], ["mastercard.com"]),
    rule("payments", "western-union", "Western Union", ["western union"], [
      "westernunion.com"
    ]),
    rule("payments", "moneygram", "MoneyGram", ["moneygram"], ["moneygram.com"]),
    rule("payments", "zelle", "Zelle", ["zelle"], ["zellepay.com"]),
    rule("payments", "braintree", "Braintree", ["braintree payments"], [
      "braintreepayments.com"
    ]),
    rule("payments", "sumup", "SumUp", ["sumup"], ["sumup.com"]),
    rule("payments", "payoneer", "Payoneer", ["payoneer"], ["payoneer.com"]),
    rule("payments", "airwallex", "Airwallex", ["airwallex"], ["airwallex.com"]),
    rule("payments", "lemonway", "Lemonway", ["lemonway"], ["lemonway.com"]),
    rule("payments", "ideal", "iDEAL", ["ideal payment", "ideal payments"], [
      "ideal.nl"
    ]),

    rule("banks-fr", "la-banque-postale", "La Banque Postale", [
      "la banque postale",
      "banque postale"
    ], ["labanquepostale.fr"]),
    rule("banks-fr", "societe-generale", "Societe Generale", [
      "societe generale",
      "socgen",
      "particuliers sg"
    ], ["societegenerale.fr", "particuliers.sg.fr", "sg.fr"]),
    rule("banks-fr", "bnp-paribas", "BNP Paribas", ["bnp paribas", "bnpparibas"], [
      "bnpparibas.net",
      "mabanque.bnpparibas",
      "bnpparibas.com"
    ]),
    rule("banks-fr", "credit-agricole", "Credit Agricole", ["credit agricole"], [
      "credit-agricole.fr"
    ]),
    rule("banks-fr", "lcl", "LCL", ["lcl"], ["lcl.fr"]),
    rule("banks-fr", "credit-mutuel", "Credit Mutuel", ["credit mutuel"], [
      "creditmutuel.fr",
      "creditmutuel.com"
    ]),
    rule("banks-fr", "cic", "CIC", ["cic banque", "cic.fr"], ["cic.fr", "cic.com"]),
    rule("banks-fr", "caisse-epargne", "Caisse d'Epargne", [
      "caisse epargne",
      "caisse d epargne"
    ], ["caisse-epargne.fr"]),
    rule("banks-fr", "banque-populaire", "Banque Populaire", ["banque populaire"], [
      "banquepopulaire.fr"
    ]),
    rule("banks-fr", "bred", "BRED", ["bred banque", "bred.fr"], ["bred.fr"]),
    rule("banks-fr", "bourso-bank", "BoursoBank", [
      "boursobank",
      "boursorama",
      "boursorama banque"
    ], ["boursobank.com", "boursorama.com", "boursorama-banque.com"]),
    rule("banks-fr", "fortuneo", "Fortuneo", ["fortuneo"], ["fortuneo.fr"]),
    rule("banks-fr", "hello-bank", "Hello bank!", ["hello bank", "hellobank"], [
      "hellobank.fr"
    ]),
    rule("banks-fr", "bforbank", "BforBank", ["bforbank"], ["bforbank.com"]),
    rule("banks-fr", "monabanq", "Monabanq", ["monabanq"], ["monabanq.com"]),
    rule("banks-fr", "axa-banque", "AXA Banque", ["axa banque", "axabanque"], [
      "axa.fr",
      "axa.com",
      "axabanque.fr"
    ]),
    rule("banks-fr", "nickel", "Nickel", ["compte nickel", "nickel.eu"], [
      "nickel.eu",
      "nickel.fr"
    ]),
    rule("banks-fr", "qonto", "Qonto", ["qonto"], ["qonto.com"]),
    rule("banks-fr", "shine", "Shine", ["shine banque", "shine.fr"], ["shine.fr"]),
    rule("banks-fr", "blank", "Blank", ["blank.app", "blank banking"], ["blank.app"]),
    rule("banks-fr", "memo-bank", "Memo Bank", ["memo bank", "memo.bank"], ["memo.bank"]),
    rule("banks-fr", "manager-one", "Manager.one", ["manager.one", "manager one"], [
      "manager.one"
    ]),

    rule("consumer-credit-fr", "cetelem", "Cetelem", ["cetelem"], ["cetelem.fr"]),
    rule("consumer-credit-fr", "cofidis", "Cofidis", ["cofidis"], ["cofidis.fr"]),
    rule("consumer-credit-fr", "floa-bank", "FLOA Bank", ["floa", "floa bank", "floabank"], [
      "floabank.fr"
    ]),
    rule("consumer-credit-fr", "oney", "Oney", ["oney"], ["oney.fr", "oney.com"]),
    rule("consumer-credit-fr", "sofinco", "Sofinco", ["sofinco"], ["sofinco.fr"]),
    rule("consumer-credit-fr", "younited-credit", "Younited Credit", [
      "younited",
      "younited credit"
    ], ["younited-credit.com", "younited.com"]),
    rule("consumer-credit-fr", "franfinance", "Franfinance", ["franfinance"], [
      "franfinance.fr"
    ]),
    rule("consumer-credit-fr", "carrefour-banque", "Carrefour Banque", [
      "carrefour banque"
    ], ["carrefour-banque.fr"]),

    rule("banks-global", "american-express", "American Express", [
      "american express",
      "amex"
    ], ["americanexpress.com", "aexp.com"]),
    rule("banks-global", "jpmorgan-chase", "JPMorgan Chase", [
      "jpmorgan",
      "jpmorgan chase",
      "chase bank"
    ], ["jpmorgan.com", "jpmorganchase.com", "chase.com"]),
    rule("banks-global", "bank-of-america", "Bank of America", [
      "bank of america",
      "bofa"
    ], ["bankofamerica.com", "bofa.com"]),
    rule("banks-global", "citi", "Citi", ["citi bank", "citibank"], [
      "citi.com",
      "citibank.com"
    ]),
    rule("banks-global", "wells-fargo", "Wells Fargo", ["wells fargo"], [
      "wellsfargo.com"
    ]),
    rule("banks-global", "capital-one", "Capital One", ["capital one"], [
      "capitalone.com"
    ]),
    rule("banks-global", "discover", "Discover", ["discover card", "discover bank"], [
      "discover.com"
    ]),
    rule("banks-global", "us-bank", "U.S. Bank", ["us bank", "u s bank"], ["usbank.com"]),
    rule("banks-global", "pnc", "PNC Bank", ["pnc bank"], ["pnc.com"]),
    rule("banks-global", "td-bank", "TD Bank", ["td bank"], ["td.com", "tdbank.com"]),
    rule("banks-global", "hsbc", "HSBC", ["hsbc"], ["hsbc.com", "hsbc.fr", "hsbc.co.uk"]),
    rule("banks-global", "barclays", "Barclays", ["barclays"], [
      "barclays.com",
      "barclays.co.uk"
    ]),
    rule("banks-global", "santander", "Santander", ["santander"], [
      "santander.com",
      "santander.co.uk"
    ]),
    rule("banks-global", "ing", "ING", ["ing bank", "ing direct"], [
      "ing.com",
      "ing.fr",
      "ing.nl"
    ]),
    rule("banks-global", "deutsche-bank", "Deutsche Bank", ["deutsche bank"], [
      "db.com",
      "deutsche-bank.de",
      "deutschebank.com"
    ]),
    rule("banks-global", "ubs", "UBS", ["ubs bank", "ubs.com"], ["ubs.com"]),
    rule("banks-global", "natwest", "NatWest", ["natwest"], ["natwest.com"]),
    rule("banks-global", "lloyds", "Lloyds Bank", ["lloyds bank"], ["lloydsbank.com"]),
    rule("banks-global", "halifax", "Halifax", ["halifax bank"], ["halifax.co.uk"]),
    rule("banks-global", "monzo", "Monzo", ["monzo"], ["monzo.com"]),
    rule("banks-global", "starling", "Starling Bank", ["starling bank"], [
      "starlingbank.com"
    ]),
    rule("banks-global", "n26", "N26", ["n26"], ["n26.com"]),
    rule("banks-global", "bunq", "Bunq", ["bunq"], ["bunq.com"]),
    rule("banks-global", "trade-republic", "Trade Republic", ["trade republic"], [
      "traderepublic.com"
    ]),
    rule("banks-global", "robinhood", "Robinhood", ["robinhood"], ["robinhood.com"]),
    rule("banks-global", "vanguard", "Vanguard", ["vanguard"], ["vanguard.com"]),
    rule("banks-global", "fidelity", "Fidelity", ["fidelity investments"], [
      "fidelity.com"
    ]),
    rule("banks-global", "charles-schwab", "Charles Schwab", ["charles schwab", "schwab"], [
      "schwab.com"
    ]),
    rule("banks-global", "etrade", "E*TRADE", ["etrade", "e trade"], ["etrade.com"]),

    rule("crypto", "coinbase", "Coinbase", ["coinbase"], ["coinbase.com"]),
    rule("crypto", "binance", "Binance", ["binance"], ["binance.com"]),
    rule("crypto", "kraken", "Kraken", ["kraken"], ["kraken.com"]),
    rule("crypto", "crypto-com", "Crypto.com", ["crypto.com", "crypto com"], [
      "crypto.com"
    ]),
    rule("crypto", "ledger", "Ledger", ["ledger wallet", "ledger.com"], ["ledger.com"]),
    rule("crypto", "metamask", "MetaMask", ["metamask"], ["metamask.io"]),
    rule("crypto", "phantom", "Phantom", ["phantom wallet"], ["phantom.app"]),
    rule("crypto", "trust-wallet", "Trust Wallet", ["trust wallet"], [
      "trustwallet.com"
    ]),
    rule("crypto", "exodus", "Exodus", ["exodus wallet"], ["exodus.com"]),
    rule("crypto", "trezor", "Trezor", ["trezor"], ["trezor.io"]),
    rule("crypto", "okx", "OKX", ["okx"], ["okx.com"]),
    rule("crypto", "bybit", "Bybit", ["bybit"], ["bybit.com"]),
    rule("crypto", "kucoin", "KuCoin", ["kucoin"], ["kucoin.com"]),
    rule("crypto", "opensea", "OpenSea", ["opensea", "open sea"], ["opensea.io"]),
    rule("crypto", "uniswap", "Uniswap", ["uniswap"], ["uniswap.org"]),

    rule("government-fr", "impots", "Impots.gouv.fr", [
      "impots",
      "impots.gouv",
      "finances publiques",
      "dgfip"
    ], ["impots.gouv.fr", "dgfip.finances.gouv.fr"]),
    rule("government-fr", "franceconnect", "FranceConnect", ["franceconnect"], [
      "franceconnect.gouv.fr"
    ]),
    rule("government-fr", "service-public", "Service-Public.fr", ["service public"], [
      "service-public.fr"
    ]),
    rule("government-fr", "ameli", "Ameli", ["ameli", "assurance maladie"], [
      "ameli.fr",
      "assurance-maladie.fr"
    ]),
    rule("government-fr", "caf", "CAF", ["caf", "allocations familiales"], ["caf.fr"]),
    rule("government-fr", "ants", "ANTS", ["ants", "agence nationale des titres"], [
      "ants.gouv.fr"
    ]),
    rule("government-fr", "france-travail", "France Travail", [
      "france travail",
      "pole emploi"
    ], ["francetravail.fr", "pole-emploi.fr"]),
    rule("government-fr", "urssaf", "Urssaf", ["urssaf"], ["urssaf.fr"]),
    rule("government-fr", "msa", "MSA", ["msa securite sociale", "msa.fr"], ["msa.fr"]),
    rule("government-fr", "cesu", "Cesu", ["cesu"], ["cesu.urssaf.fr"]),
    rule("government-fr", "pajemploi", "Pajemploi", ["pajemploi"], ["pajemploi.urssaf.fr"]),
    rule("government-fr", "mon-compte-formation", "Mon Compte Formation", [
      "mon compte formation"
    ], ["moncompteformation.gouv.fr"]),
    rule("government-fr", "antai-amendes", "ANTAI / Amendes.gouv.fr", [
      "antai",
      "amendes.gouv",
      "amendes"
    ], ["antai.gouv.fr", "amendes.gouv.fr"]),
    rule("government-fr", "info-retraite", "Info Retraite", ["info retraite"], [
      "info-retraite.fr",
      "lassuranceretraite.fr",
      "agirc-arrco.fr"
    ]),
    rule("government-fr", "demarches-simplifiees", "Demarches Simplifiees", [
      "demarches simplifiees"
    ], ["demarches-simplifiees.fr"]),
    rule("government-fr", "diplomatie", "France Diplomatie", ["france diplomatie"], [
      "diplomatie.gouv.fr"
    ]),
    rule("government-fr", "gouvernement", "Gouvernement.fr", ["gouvernement"], [
      "gouvernement.fr"
    ]),

    rule("government-global", "irs", "IRS", ["irs", "internal revenue service"], [
      "irs.gov"
    ]),
    rule("government-global", "ssa", "Social Security Administration", [
      "social security administration",
      "ssa.gov"
    ], ["ssa.gov"]),
    rule("government-global", "usps-government", "USPS Government Services", [
      "usps government",
      "usps.com"
    ], ["usps.com"]),
    rule("government-global", "gov-uk", "GOV.UK", ["gov.uk", "government uk"], [
      "gov.uk"
    ]),
    rule("government-global", "hmrc", "HMRC", ["hmrc", "hm revenue"], [
      "hmrc.gov.uk",
      "gov.uk"
    ]),
    rule("government-global", "canada-ca", "Government of Canada", [
      "government of canada",
      "canada.ca"
    ], ["canada.ca", "gc.ca"]),
    rule("government-global", "ato", "Australian Taxation Office", [
      "australian taxation office",
      "ato"
    ], ["ato.gov.au"]),
    rule("government-global", "mygov-au", "myGov Australia", ["mygov australia", "mygov"], [
      "my.gov.au",
      "mygov.gov.au"
    ]),
    rule("government-global", "europa", "European Union", ["europa.eu", "european union"], [
      "europa.eu"
    ]),

    rule("telecom-utilities-fr", "orange", "Orange", ["orange"], [
      "orange.fr",
      "orange.com"
    ]),
    rule("telecom-utilities-fr", "free", "Free Mobile / Freebox", [
      "free mobile",
      "freebox"
    ], ["free.fr", "freebox.fr"], {
      senderDomains: [
        "free-mobile.fr",
        "freetelecom.fr",
        "assistance.free.fr",
        "proxad.net"
      ]
    }),
    rule("telecom-utilities-fr", "sfr", "SFR", ["sfr", "red by sfr"], [
      "sfr.fr",
      "red-by-sfr.fr"
    ]),
    rule("telecom-utilities-fr", "bouygues", "Bouygues Telecom", [
      "bouygues telecom",
      "bbox"
    ], ["bouyguestelecom.fr"]),
    rule("telecom-utilities-fr", "edf", "EDF", ["edf"], ["edf.fr"]),
    rule("telecom-utilities-fr", "engie", "Engie", ["engie"], ["engie.fr", "engie.com"]),
    rule("telecom-utilities-fr", "totalenergies", "TotalEnergies", ["totalenergies"], [
      "totalenergies.fr",
      "totalenergies.com"
    ]),
    rule("telecom-utilities-fr", "enedis", "Enedis", ["enedis"], ["enedis.fr"]),
    rule("telecom-utilities-fr", "grdf", "GRDF", ["grdf"], ["grdf.fr"]),
    rule("telecom-utilities-fr", "veolia", "Veolia", ["veolia"], ["veolia.fr", "veolia.com"]),
    rule("telecom-utilities-fr", "suez", "Suez", ["suez"], ["suez.com"]),

    rule("telecom-utilities-global", "verizon", "Verizon", ["verizon"], [
      "verizon.com"
    ]),
    rule("telecom-utilities-global", "att", "AT&T", ["at&t", "att.com"], [
      "att.com"
    ]),
    rule("telecom-utilities-global", "t-mobile", "T-Mobile", ["t-mobile", "tmobile"], [
      "t-mobile.com"
    ]),
    rule("telecom-utilities-global", "vodafone", "Vodafone", ["vodafone"], [
      "vodafone.com"
    ]),
    rule("telecom-utilities-global", "ee", "EE", ["ee mobile", "ee.co.uk"], [
      "ee.co.uk"
    ]),
    rule("telecom-utilities-global", "o2", "O2", ["o2 mobile", "o2.co.uk"], [
      "o2.co.uk"
    ]),
    rule("telecom-utilities-global", "xfinity", "Xfinity", ["xfinity"], [
      "xfinity.com",
      "comcast.com"
    ]),
    rule("telecom-utilities-global", "comcast", "Comcast", ["comcast"], [
      "comcast.com"
    ]),
    rule("telecom-utilities-global", "british-gas", "British Gas", ["british gas"], [
      "britishgas.co.uk"
    ]),
    rule("telecom-utilities-global", "eon", "E.ON", ["eon energy", "e.on"], [
      "eon.com",
      "eonenergy.com"
    ]),

    rule("insurance-fr", "axa", "AXA", ["axa assurance", "axa assurances"], [
      "axa.fr",
      "axa.com"
    ]),
    rule("insurance-fr", "maif", "MAIF", ["maif"], ["maif.fr"]),
    rule("insurance-fr", "macif", "Macif", ["macif"], ["macif.fr"]),
    rule("insurance-fr", "maaf", "MAAF", ["maaf"], ["maaf.fr"]),
    rule("insurance-fr", "matmut", "Matmut", ["matmut"], ["matmut.fr"]),
    rule("insurance-fr", "allianz", "Allianz", ["allianz"], ["allianz.fr", "allianz.com"]),
    rule("insurance-fr", "april", "April", ["april assurance", "april mutuelle"], [
      "april.fr"
    ]),
    rule("insurance-fr", "harmonie-mutuelle", "Harmonie Mutuelle", ["harmonie mutuelle"], [
      "harmonie-mutuelle.fr"
    ]),

    rule("delivery", "laposte", "La Poste", ["la poste", "laposte"], [
      "laposte.fr",
      "laposte.net",
      "labanquepostale.fr"
    ]),
    rule("delivery", "colissimo", "Colissimo", ["colissimo"], [
      "laposte.fr",
      "colissimo.fr"
    ]),
    rule("delivery", "chronopost", "Chronopost", ["chronopost"], ["chronopost.fr"]),
    rule("delivery", "dhl", "DHL", ["dhl"], ["dhl.com", "dhl.fr"]),
    rule("delivery", "ups", "UPS", ["ups"], ["ups.com"]),
    rule("delivery", "fedex", "FedEx", ["fedex"], ["fedex.com"]),
    rule("delivery", "mondial-relay", "Mondial Relay", ["mondial relay"], [
      "mondialrelay.fr"
    ]),
    rule("delivery", "relais-colis", "Relais Colis", ["relais colis"], ["relaiscolis.com"]),
    rule("delivery", "dpd", "DPD", ["dpd"], ["dpd.com", "dpd.fr"]),
    rule("delivery", "gls", "GLS", ["gls delivery", "gls colis", "gls france"], [
      "gls-group.eu",
      "gls-france.com"
    ]),
    rule("delivery", "colis-prive", "Colis Prive", ["colis prive"], ["colisprive.com"]),
    rule("delivery", "usps", "USPS", ["usps"], ["usps.com"]),
    rule("delivery", "royal-mail", "Royal Mail", ["royal mail"], ["royalmail.com"]),
    rule("delivery", "canada-post", "Canada Post", ["canada post", "postes canada"], [
      "canadapost-postescanada.ca"
    ]),
    rule("delivery", "correos", "Correos", ["correos"], ["correos.es"]),
    rule("delivery", "bpost", "bpost", ["bpost"], ["bpost.be"]),
    rule("delivery", "postnl", "PostNL", ["postnl", "post nl"], ["postnl.nl"]),
    rule("delivery", "evri", "Evri", ["evri"], ["evri.com"]),
    rule("delivery", "deliveroo", "Deliveroo", ["deliveroo"], [
      "deliveroo.com",
      "deliveroo.fr"
    ]),
    rule("delivery", "just-eat", "Just Eat", ["just eat", "justeat"], [
      "just-eat.fr",
      "justeat.com"
    ]),
    rule("delivery", "uber-eats", "Uber Eats", ["uber eats", "ubereats"], [
      "ubereats.com",
      "uber.com"
    ]),
    rule("delivery", "doordash", "DoorDash", ["doordash", "door dash"], [
      "doordash.com"
    ]),
    rule("delivery", "instacart", "Instacart", ["instacart"], ["instacart.com"]),
    rule("delivery", "glovo", "Glovo", ["glovo"], ["glovoapp.com"]),
    rule("delivery", "wolt", "Wolt", ["wolt delivery", "wolt.com"], ["wolt.com"]),

    rule("commerce", "amazon", "Amazon", ["amazon", "amzn"], [
      "amazon.com",
      "amazon.fr",
      "amazon.co.uk",
      "amazon.de",
      "amazon.es",
      "amazon.it",
      "amazon.nl",
      "amazon.ca",
      "amazon.com.be",
      "amazon.com.au",
      "amazon.co.jp",
      "amazonpay.com"
    ]),
    rule("commerce", "ebay", "eBay", ["ebay"], ["ebay.com", "ebay.fr"]),
    rule("commerce", "leboncoin", "Leboncoin", ["leboncoin", "le bon coin"], [
      "leboncoin.fr"
    ]),
    rule("commerce", "vinted", "Vinted", ["vinted"], ["vinted.com", "vinted.fr"]),
    rule("commerce", "cdiscount", "Cdiscount", ["cdiscount"], ["cdiscount.com"]),
    rule("commerce", "fnac", "Fnac", ["fnac"], ["fnac.com"]),
    rule("commerce", "darty", "Darty", ["darty"], ["darty.com"]),
    rule("commerce", "rakuten", "Rakuten", ["rakuten"], ["rakuten.com", "rakuten.fr"]),
    rule("commerce", "aliexpress", "AliExpress", ["aliexpress", "ali express"], [
      "aliexpress.com"
    ]),
    rule("commerce", "alibaba", "Alibaba", ["alibaba"], ["alibaba.com"]),
    rule("commerce", "temu", "Temu", ["temu"], ["temu.com"]),
    rule("commerce", "shein", "SHEIN", ["shein"], ["shein.com"]),
    rule("commerce", "etsy", "Etsy", ["etsy"], ["etsy.com"]),
    rule("commerce", "shopify", "Shopify", ["shopify"], ["shopify.com"]),
    rule("site-builders", "squarespace", "Squarespace", ["squarespace"], [
      "squarespace.com",
      "www.squarespace.com",
      "support.squarespace.com",
      "account.squarespace.com",
      "login.squarespace.com",
      "domains.squarespace.com",
      "squarespace.info",
      "squarespace-security.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["squarespace.com", "squarespace.info", "squarespace-security.com"]
    }),
    rule("site-builders", "wix", "Wix", ["wix", "wix.com"], [
      "wix.com",
      "www.wix.com",
      "support.wix.com",
      "manage.wix.com",
      "users.wix.com",
      "editor.wix.com",
      "wixanswers.com",
      "wixsiteverifications.com",
      "wixinvoices.com",
      "wix-domains.com",
      "crm.wix.com",
      "forms.wix.com",
      "wixforms.com",
      "wixsite.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: [
        "wix.com",
        "wixanswers.com",
        "wixsiteverifications.com",
        "wixinvoices.com",
        "wix-domains.com",
        "crm.wix.com",
        "forms.wix.com",
        "wixforms.com",
        "wixemails.com"
      ]
    }),
    rule("site-builders", "webflow", "Webflow", ["webflow"], [
      "webflow.com",
      "www.webflow.com",
      "help.webflow.com",
      "support.webflow.com",
      "status.webflow.com",
      "webflow.io"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["webflow.com"]
    }),
    rule("site-builders", "wordpress-com", "WordPress.com", ["wordpress.com", "wordpress"], [
      "wordpress.com",
      "www.wordpress.com",
      "wordpress.org",
      "wp.com",
      "automattic.com",
      "gravatar.com",
      "akismet.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["wordpress.com", "automattic.com"]
    }),
    rule("site-builders", "weebly", "Weebly", ["weebly"], [
      "weebly.com",
      "www.weebly.com",
      "editor.weebly.com",
      "squareup.com",
      "square.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["weebly.com", "squareup.com", "square.com"]
    }),
    rule("site-builders", "framer", "Framer", ["framer"], [
      "framer.com",
      "www.framer.com",
      "help.framer.com",
      "framer.app",
      "framer.website"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["framer.com"]
    }),
    rule("site-builders", "carrd", "Carrd", ["carrd"], [
      "carrd.co",
      "www.carrd.co"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["carrd.co"]
    }),
    rule("site-builders", "tilda", "Tilda", ["tilda"], [
      "tilda.cc",
      "tilda.ws",
      "tildacdn.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["tilda.cc"]
    }),
    rule("site-builders", "strikingly", "Strikingly", ["strikingly"], [
      "strikingly.com",
      "www.strikingly.com",
      "mystrikingly.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["strikingly.com"]
    }),
    rule("site-builders", "jimdo", "Jimdo", ["jimdo"], [
      "jimdo.com",
      "www.jimdo.com",
      "jimdofree.com",
      "jimdosite.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["jimdo.com"]
    }),
    rule("site-builders", "duda", "Duda", ["duda"], [
      "duda.co",
      "www.duda.co",
      "support.duda.co",
      "my.duda.co",
      "multiscreensite.com"
    ], {
      hostedPlatform: true,
      matchSubdomains: false,
      senderDomains: ["duda.co"]
    }),
    rule("commerce", "zalando", "Zalando", ["zalando"], ["zalando.fr", "zalando.com"]),
    rule("commerce", "carrefour", "Carrefour", ["carrefour"], ["carrefour.fr"]),
    rule("commerce", "auchan", "Auchan", ["auchan"], ["auchan.fr"]),
    rule("commerce", "leclerc", "E.Leclerc", ["e leclerc", "leclerc"], [
      "e.leclerc",
      "e-leclerc.com",
      "leclercdrive.fr"
    ]),
    rule("commerce", "intermarche", "Intermarche", ["intermarche"], [
      "intermarche.com"
    ]),
    rule("commerce", "lidl", "Lidl", ["lidl"], ["lidl.fr", "lidl.com"]),
    rule("commerce", "decathlon", "Decathlon", ["decathlon"], [
      "decathlon.fr",
      "decathlon.com"
    ]),
    rule("commerce", "ikea", "IKEA", ["ikea"], ["ikea.com"]),
    rule("commerce", "leroy-merlin", "Leroy Merlin", ["leroy merlin"], [
      "leroymerlin.fr"
    ]),
    rule("commerce", "castorama", "Castorama", ["castorama"], ["castorama.fr"]),
    rule("commerce", "boulanger", "Boulanger", ["boulanger"], ["boulanger.com"]),
    rule("commerce", "walmart", "Walmart", ["walmart"], ["walmart.com"]),
    rule("commerce", "target", "Target", ["target store", "target.com"], ["target.com"]),
    rule("commerce", "best-buy", "Best Buy / Geek Squad", [
      "best buy",
      "bestbuy",
      "geek squad",
      "geeksquad"
    ], ["bestbuy.com", "geeksquad.com"]),
    rule("commerce", "costco", "Costco", ["costco"], ["costco.com"]),
    rule("commerce", "home-depot", "The Home Depot", ["home depot"], [
      "homedepot.com"
    ]),
    rule("commerce", "lowes", "Lowe's", ["lowes", "lowe s"], ["lowes.com"]),
    rule("commerce", "wayfair", "Wayfair", ["wayfair"], ["wayfair.com"]),
    rule("commerce", "macys", "Macy's", ["macys", "macy s"], ["macys.com"]),
    rule("commerce", "nordstrom", "Nordstrom", ["nordstrom"], ["nordstrom.com"]),
    rule("commerce", "kohls", "Kohl's", ["kohls", "kohl s"], ["kohls.com"]),
    rule("commerce", "chewy", "Chewy", ["chewy.com", "chewy pet"], ["chewy.com"]),
    rule("commerce", "back-market", "Back Market", ["back market"], [
      "backmarket.com",
      "backmarket.fr"
    ]),
    rule("commerce", "manomano", "ManoMano", ["manomano", "mano mano"], [
      "manomano.fr",
      "manomano.com"
    ]),
    rule("commerce", "la-redoute", "La Redoute", ["la redoute"], ["laredoute.fr"]),
    rule("commerce", "veepee", "Veepee", ["veepee", "vente privee"], [
      "veepee.fr",
      "veepee.com"
    ]),
    rule("commerce", "showroomprive", "Showroomprive", ["showroomprive"], [
      "showroomprive.com"
    ]),
    rule("commerce", "sephora", "Sephora", ["sephora"], ["sephora.fr", "sephora.com"]),
    rule("commerce", "nocibe", "Nocibe", ["nocibe"], ["nocibe.fr"]),
    rule("commerce", "hm", "H&M", ["h&m", "h and m", "hm.com"], ["hm.com"]),
    rule("commerce", "zara", "Zara", ["zara"], ["zara.com"]),
    rule("commerce", "nike", "Nike", ["nike"], ["nike.com"]),
    rule("commerce", "adidas", "Adidas", ["adidas"], ["adidas.com"]),
    rule("commerce", "asos", "ASOS", ["asos"], ["asos.com"]),
    rule("commerce", "uniqlo", "UNIQLO", ["uniqlo"], ["uniqlo.com"]),
    rule("commerce", "ldlc", "LDLC", ["ldlc"], ["ldlc.com"]),
    rule("commerce", "materiel-net", "Materiel.net", ["materiel.net", "materiel net"], [
      "materiel.net"
    ]),
    rule("commerce", "rueducommerce", "Rue du Commerce", ["rue du commerce"], [
      "rueducommerce.fr"
    ]),
    rule("commerce", "topachat", "TopAchat", ["topachat", "top achat"], [
      "topachat.com"
    ]),
    rule("commerce", "monoprix", "Monoprix", ["monoprix"], ["monoprix.fr"]),
    rule("commerce", "franprix", "Franprix", ["franprix"], ["franprix.fr"]),
    rule("commerce", "picard", "Picard", ["picard surgeles", "picard surgele"], [
      "picard.fr"
    ]),
    rule("commerce", "mercari", "Mercari", ["mercari"], ["mercari.com"]),
    rule("commerce", "poshmark", "Poshmark", ["poshmark"], ["poshmark.com"]),
    rule("commerce", "depop", "Depop", ["depop"], ["depop.com"]),
    rule("commerce", "wallapop", "Wallapop", ["wallapop"], ["wallapop.com"]),
    rule("commerce", "olx", "OLX", ["olx"], ["olx.com"]),
    rule("commerce", "allegro", "Allegro", ["allegro"], ["allegro.pl"]),
    rule("commerce", "mercado-libre", "Mercado Libre", ["mercado libre", "mercadolibre"], [
      "mercadolibre.com"
    ]),
    rule("commerce", "shopee", "Shopee", ["shopee"], ["shopee.com"]),
    rule("commerce", "lazada", "Lazada", ["lazada"], ["lazada.com"]),
    rule("commerce", "flipkart", "Flipkart", ["flipkart"], ["flipkart.com"]),
    rule("commerce", "myntra", "Myntra", ["myntra"], ["myntra.com"]),
    rule("commerce", "newegg", "Newegg", ["newegg"], ["newegg.com"]),
    rule("commerce", "groupon", "Groupon", ["groupon"], ["groupon.com"]),
    rule("commerce", "groupon-fr", "Groupon France", ["groupon france"], [
      "groupon.fr"
    ]),
    rule("commerce", "qvc", "QVC", ["qvc"], ["qvc.com"]),
    rule("commerce", "publishers-clearing-house", "Publishers Clearing House", [
      "publishers clearing house",
      "pch",
      "pch prize patrol"
    ], ["pch.com"]),
    rule("commerce", "wish", "Wish", ["wish.com", "wish shopping"], ["wish.com"]),

    rule("events", "eventbrite", "Eventbrite", ["eventbrite", "event brite"], [
      "eventbrite.com"
    ]),
    rule("events", "ticketmaster", "Ticketmaster", ["ticketmaster"], [
      "ticketmaster.com",
      "ticketmaster.fr"
    ]),
    rule("events", "live-nation", "Live Nation", ["live nation", "livenation"], [
      "livenation.com",
      "livenation.fr"
    ]),
    rule("events", "weezevent", "Weezevent", ["weezevent"], ["weezevent.com"]),
    rule("events", "billetweb", "Billetweb", ["billetweb"], ["billetweb.fr"]),
    rule("events", "helloasso", "HelloAsso", ["helloasso", "hello asso"], [
      "helloasso.com"
    ]),
    rule("events", "shotgun", "Shotgun", ["shotgun.live", "shotgun tickets"], [
      "shotgun.live"
    ]),
    rule("events", "dice", "DICE", ["dice.fm", "dice tickets"], ["dice.fm"]),
    rule("events", "fever", "Fever", ["feverup", "fever tickets"], [
      "feverup.com",
      "feverup.co"
    ]),
    rule("events", "meetup", "Meetup", ["meetup"], ["meetup.com"]),
    rule("events", "luma", "Luma", ["lu.ma", "luma event"], ["lu.ma"]),
    rule("events", "eventim", "Eventim", ["eventim"], [
      "eventim.com",
      "eventim.fr",
      "eventim.de"
    ]),
    rule("events", "see-tickets", "See Tickets", ["see tickets", "seetickets"], [
      "seetickets.com",
      "seetickets.fr",
      "seetickets.us"
    ]),
    rule("events", "fnac-spectacles", "Fnac Spectacles", [
      "fnac spectacles",
      "france billet"
    ], ["fnacspectacles.com", "francebillet.com"]),
    rule("events", "ticketac", "Ticketac", ["ticketac"], ["ticketac.com"]),
    rule("events", "yurplan", "Yurplan", ["yurplan"], ["yurplan.com"]),
    rule("events", "placeminute", "Placeminute", ["placeminute", "place minute"], [
      "placeminute.com"
    ]),
    rule("events", "assoconnect", "AssoConnect", ["assoconnect", "asso connect"], [
      "assoconnect.com"
    ]),
    rule("events", "resident-advisor", "Resident Advisor", [
      "resident advisor",
      "ra.co"
    ], ["ra.co"]),
    rule("events", "eventzilla", "Eventzilla", ["eventzilla"], ["eventzilla.net"]),
    rule("events", "universe", "Universe", ["universe tickets", "universe.com"], [
      "universe.com"
    ]),
    rule("events", "splash", "Splash", ["splashthat", "splash event"], [
      "splashthat.com"
    ]),
    rule("events", "partiful", "Partiful", ["partiful"], ["partiful.com"]),
    rule("events", "pretix", "Pretix", ["pretix"], ["pretix.eu"]),

    rule("forms", "typeform", "Typeform", ["typeform"], ["typeform.com"]),
    rule("forms", "jotform", "Jotform", ["jotform"], ["jotform.com"]),
    rule("forms", "surveymonkey", "SurveyMonkey", ["surveymonkey", "survey monkey"], [
      "surveymonkey.com"
    ]),
    rule("forms", "qualtrics", "Qualtrics", ["qualtrics"], [
      "qualtrics.com",
      "qualtrics.eu"
    ]),
    rule("forms", "calendly", "Calendly", ["calendly"], ["calendly.com"]),
    rule("forms", "doodle", "Doodle", ["doodle meeting", "doodle.com"], [
      "doodle.com"
    ]),
    rule("forms", "youcanbookme", "YouCanBookMe", ["youcanbook.me", "you can book me"], [
      "youcanbook.me"
    ]),
    rule("forms", "tally", "Tally", ["tally.so", "tally forms"], ["tally.so"]),
    rule("forms", "fillout", "Fillout", ["fillout.com", "fillout forms"], [
      "fillout.com"
    ]),
    rule("forms", "paperform", "Paperform", ["paperform"], ["paperform.co"]),
    rule("forms", "formstack", "Formstack", ["formstack"], ["formstack.com"]),
    rule("forms", "wufoo", "Wufoo", ["wufoo"], ["wufoo.com"]),
    rule("forms", "cognito-forms", "Cognito Forms", ["cognito forms"], [
      "cognitoforms.com"
    ]),
    rule("forms", "slido", "Slido", ["slido"], ["slido.com"]),
    rule("forms", "mentimeter", "Mentimeter", ["mentimeter", "menti.com"], [
      "mentimeter.com",
      "menti.com"
    ]),
    rule("forms", "gofundme", "GoFundMe", ["gofundme", "go fund me"], [
      "gofundme.com"
    ]),
    rule("forms", "donorbox", "Donorbox", ["donorbox"], ["donorbox.org"]),
    rule("forms", "kickstarter", "Kickstarter", ["kickstarter"], ["kickstarter.com"]),
    rule("forms", "indiegogo", "Indiegogo", ["indiegogo"], ["indiegogo.com"]),
    rule("forms", "patreon", "Patreon", ["patreon"], ["patreon.com"]),

    rule("accounting", "indy", "Indy", ["indy", "indy.fr", "indy comptabilite"], [
      "indy.fr"
    ]),
    rule("accounting", "pennylane", "Pennylane", [
      "pennylane",
      "pennylane comptabilite"
    ], [
      "pennylane.com"
    ]),
    rule("accounting", "dougs", "Dougs", ["dougs", "dougs expert comptable"], [
      "dougs.fr"
    ]),
    rule("accounting", "tiime", "Tiime", ["tiime", "tiime comptabilite"], [
      "tiime.fr"
    ]),
    rule("accounting", "abby", "Abby", ["abby", "abby facturation"], ["abby.fr"]),
    rule("accounting", "freebe", "Freebe", ["freebe", "freebe.me"], ["freebe.me"]),
    rule("accounting", "sinao", "Sinao", ["sinao", "sinao comptabilite"], [
      "sinao.fr"
    ]),
    rule("accounting", "dext", "Dext", ["dext", "dext prepare", "receipt bank"], [
      "dext.com"
    ]),
    rule("accounting", "myunisoft", "MyUnisoft", ["myunisoft", "my unisoft"], [
      "myunisoft.fr"
    ]),
    rule("accounting", "fulll", "fulll", ["fulll", "fulll compta"], ["fulll.fr"]),
    rule("accounting", "kanta", "Kanta", ["kanta", "kanta expert comptable"], [
      "kanta.fr"
    ]),
    rule("accounting", "regate-qonto", "Regate by Qonto", [
      "regate",
      "regate by qonto"
    ], [
      "regate.io",
      "web.regate.io",
      "qonto.com",
      "support-regate-fr.qonto.com",
      "changelog.regate.io"
    ]),
    rule("accounting", "xero", "Xero", ["xero accounting", "xero.com"], ["xero.com"]),
    rule("accounting", "quickbooks", "QuickBooks", [
      "quickbooks",
      "intuit quickbooks"
    ], [
      "quickbooks.intuit.com",
      "intuit.com"
    ]),

    rule("hr-finance-ops", "payfit", "PayFit", ["payfit", "payfit payroll"], [
      "payfit.com"
    ]),
    rule("hr-finance-ops", "spendesk", "Spendesk", ["spendesk"], [
      "spendesk.com"
    ]),
    rule("hr-finance-ops", "libeo", "Libeo", ["libeo"], ["libeo.io"]),
    rule("hr-finance-ops", "lucca", "Lucca", ["lucca", "lucca sirh"], ["lucca.fr"]),
    rule("hr-finance-ops", "swile", "Swile", ["swile"], ["swile.co"]),
    rule("hr-finance-ops", "adp", "ADP", ["adp", "adp payroll"], ["adp.com"]),
    rule("hr-finance-ops", "paychex", "Paychex", ["paychex"], ["paychex.com"]),
    rule("hr-finance-ops", "ukg", "UKG", ["ukg", "ukg pro"], ["ukg.com"]),
    rule("hr-finance-ops", "bamboohr", "BambooHR", ["bamboohr", "bamboo hr"], [
      "bamboohr.com"
    ]),

    rule("health-fr", "doctolib", "Doctolib", ["doctolib"], [
      "doctolib.fr",
      "doctolib.de",
      "doctolib.com"
    ]),
    rule("health-fr", "alan", "Alan", ["alan assurance", "alan health", "alan.com"], [
      "alan.com"
    ]),

    rule("travel", "booking", "Booking.com", ["booking.com", "booking"], ["booking.com"]),
    rule("travel", "airbnb", "Airbnb", ["airbnb"], [
      "airbnb.com",
      "airbnb.co.uk",
      "airbnb.fr",
      "airbnb.de",
      "airbnb.es",
      "airbnb.it",
      "airbnb.ca",
      "airbnb.com.au"
    ]),
    rule("travel", "uber", "Uber", ["uber"], ["uber.com"]),
    rule("travel", "bolt", "Bolt", ["bolt ride", "bolt.eu"], ["bolt.eu"]),
    rule("travel", "sncf", "SNCF", ["sncf", "sncf connect", "tgv inoui", "tgvinoui"], [
      "sncf.com",
      "sncf.fr",
      "sncf-connect.com",
      "sncfconnect.com",
      "mail.sncfconnect.com",
      "mail.sncf-connect.com",
      "info.sncf.com",
      "connect.sncf",
      "tgvinoui.sncf",
      "sncf-voyageurs.com",
      "info.sncf-voyageurs.com"
    ], {
      senderDomains: [
        "sncf.com",
        "sncf-connect.com",
        "mail.sncfconnect.com",
        "mail.sncf-connect.com",
        "info.sncf.com",
        "connect.sncf",
        "info.sncf-voyageurs.com"
      ],
      senderMatchSubdomains: false
    }),
    rule("travel", "trainline", "Trainline", ["trainline"], ["thetrainline.com"]),
    rule("travel", "air-france", "Air France", ["air france"], [
      "airfrance.fr",
      "airfrance.com",
      "airfrance-klm.com",
      "airfranceklm.com",
      "account-airfrance.com",
      "connect-passengers.com",
      "email.airfrance.fr",
      "enews-airfrance.com",
      "flyingblue.com",
      "info-airfrance.com",
      "info-flyingblue.com",
      "infos-airfrance.com",
      "service.airfrance.com",
      "service-airfrance.com",
      "ticket-airfrance.com",
      "websupportairfrance.com",
      "xmedia.airfrance.fr"
    ]),
    rule("travel", "transavia", "Transavia", ["transavia"], ["transavia.com"]),
    rule("travel", "accor", "Accor", ["accor", "all accor"], ["accor.com", "all.com"]),
    rule("travel", "ratp", "RATP", ["ratp"], ["ratp.fr"]),
    rule("travel", "navigo", "Ile-de-France Mobilites", [
      "ile de france mobilites",
      "navigo"
    ], ["iledefrance-mobilites.fr"]),
    rule("travel", "expedia", "Expedia", ["expedia"], ["expedia.com", "expedia.fr"]),
    rule("travel", "hotels-com", "Hotels.com", ["hotels.com"], ["hotels.com"]),
    rule("travel", "agoda", "Agoda", ["agoda"], ["agoda.com"]),
    rule("travel", "trip-com", "Trip.com", ["trip.com", "trip travel"], ["trip.com"]),
    rule("travel", "kayak", "Kayak", ["kayak travel", "kayak.com"], ["kayak.com"]),
    rule("travel", "skyscanner", "Skyscanner", ["skyscanner"], ["skyscanner.com"]),
    rule("travel", "vrbo", "Vrbo", ["vrbo"], ["vrbo.com"]),
    rule("travel", "hertz", "Hertz", ["hertz rental", "hertz.com"], ["hertz.com"]),
    rule("travel", "avis", "Avis", ["avis rental", "avis.com"], ["avis.com"]),
    rule("travel", "enterprise", "Enterprise Rent-A-Car", [
      "enterprise rent",
      "enterprise.com"
    ], ["enterprise.com"]),
    rule("travel", "ryanair", "Ryanair", ["ryanair"], ["ryanair.com"]),
    rule("travel", "easyjet", "easyJet", ["easyjet", "easy jet"], ["easyjet.com"]),
    rule("travel", "lufthansa", "Lufthansa", ["lufthansa"], ["lufthansa.com"]),
    rule("travel", "klm", "KLM", ["klm"], ["klm.com"]),
    rule("travel", "british-airways", "British Airways", ["british airways"], [
      "britishairways.com"
    ]),
    rule("travel", "delta", "Delta Air Lines", ["delta air lines", "delta.com"], [
      "delta.com"
    ]),
    rule("travel", "united-airlines", "United Airlines", ["united airlines"], [
      "united.com"
    ]),
    rule("travel", "american-airlines", "American Airlines", ["american airlines"], [
      "aa.com",
      "americanairlines.com"
    ]),
    rule("travel", "emirates", "Emirates", ["emirates"], ["emirates.com"]),
    rule("travel", "qatar-airways", "Qatar Airways", ["qatar airways"], [
      "qatarairways.com"
    ]),

    rule("maps", "waze", "Waze", ["waze"], [
      "waze.com"
    ]),
    rule("maps", "openstreetmap", "OpenStreetMap", ["openstreetmap", "open street map", "osm"], [
      "openstreetmap.org",
      "osm.org"
    ]),
    rule("maps", "here-wego", "HERE WeGo", ["here wego", "here maps"], [
      "here.com"
    ]),
    rule("maps", "mapquest", "MapQuest", ["mapquest"], [
      "mapquest.com"
    ]),
    rule("maps", "tomtom", "TomTom", ["tomtom", "tomtom maps"], [
      "tomtom.com"
    ]),
    rule("maps", "mapbox", "Mapbox", ["mapbox"], [
      "mapbox.com"
    ]),
    rule("maps", "citymapper", "Citymapper", ["citymapper"], [
      "citymapper.com"
    ]),

    rule("big-tech", "microsoft", "Microsoft", ["microsoft", "outlook", "onedrive", "bing", "bing maps"], [
      "microsoft.com",
      "accountprotection.microsoft.com",
      "bing.com",
      "outlook.com",
      "office.com",
      "office365.com",
      "live.com",
      "onedrive.com"
    ]),
    rule("big-tech", "google", "Google", ["google", "gmail", "youtube", "google maps"], [
      "google.com",
      "google.fr",
      "google.co.uk",
      "google.de",
      "google.es",
      "google.it",
      "google.nl",
      "google.be",
      "google.ca",
      "google.com.br",
      "google.co.jp",
      "google.com.au",
      "google.ie",
      "google.pt",
      "google.ch",
      "google.at",
      "google.pl",
      "maps.app.goo.gl",
      "g.co",
      "goo.gle",
      "c.gle",
      "gmail.com",
      "youtube.com",
      "youtu.be",
      "accounts.google.com"
    ]),
    rule("big-tech", "apple", "Apple", ["apple", "icloud", "itunes", "app store", "apple maps"], [
      "apple.com",
      "icloud.com",
      "me.com",
      "itunes.com"
    ]),
    rule("big-tech", "meta", "Meta", ["meta platforms", "meta business"], [
      "meta.com",
      "metamail.com"
    ]),
    rule("big-tech", "facebook", "Facebook / Messenger", ["facebook", "messenger"], [
      "facebook.com",
      "facebookmail.com",
      "messenger.com",
      "m.me"
    ]),
    rule("big-tech", "instagram", "Instagram", ["instagram"], ["instagram.com"]),
    rule("big-tech", "whatsapp", "WhatsApp", ["whatsapp"], ["whatsapp.com"]),
    rule("big-tech", "linkedin", "LinkedIn", ["linkedin", "linked in"], ["linkedin.com"]),
    rule("big-tech", "twitter-x", "X / Twitter", ["twitter", "x.com"], [
      "x.com",
      "e.x.com",
      "twitter.com"
    ], {
      senderDomains: ["x.com", "e.x.com"],
      senderMatchSubdomains: false
    }),
    rule("big-tech", "xai", "xAI / Grok", ["x.ai", "xai", "x ai", "grok"], [
      "x.ai",
      "grok.com",
      "grokipedia.com"
    ], {
      senderDomains: ["x.ai"],
      senderMatchSubdomains: false
    }),
    rule("big-tech", "tiktok", "TikTok", ["tiktok", "tik tok"], ["tiktok.com"]),
    rule("big-tech", "snapchat", "Snapchat", ["snapchat"], ["snapchat.com"]),
    rule("big-tech", "discord", "Discord", ["discord"], ["discord.com"]),
    rule("big-tech", "slack", "Slack", ["slack"], ["slack.com"]),
    rule("big-tech", "zoom", "Zoom", ["zoom"], ["zoom.us"]),
    rule("big-tech", "dropbox", "Dropbox", ["dropbox"], ["dropbox.com"]),
    rule("big-tech", "box", "Box", ["box.com", "box cloud"], ["box.com"]),
    rule("big-tech", "adobe", "Adobe", ["adobe", "creative cloud"], ["adobe.com"]),
    rule("big-tech", "docusign", "DocuSign", ["docusign", "docu sign"], [
      "docusign.com",
      "docusign.net"
    ]),
    rule("big-tech", "dropbox-sign", "Dropbox Sign", ["dropbox sign", "hellosign"], [
      "dropboxsign.com",
      "hellosign.com",
      "dropbox.com"
    ]),
    rule("big-tech", "yousign", "Yousign", ["yousign"], ["yousign.com", "yousign.fr"]),
    rule("big-tech", "notion", "Notion", ["notion"], ["notion.so", "notion.site"], {
      hostedPlatform: true,
      matchSubdomains: false
    }),
    rule("big-tech", "figma", "Figma", ["figma"], ["figma.com"]),
    rule("big-tech", "canva", "Canva", ["canva"], ["canva.com"]),
    rule("big-tech", "miro", "Miro", ["miro board", "miro.com"], ["miro.com"]),
    rule("big-tech", "airtable", "Airtable", ["airtable"], ["airtable.com"]),
    rule("big-tech", "asana", "Asana", ["asana"], ["asana.com"]),
    rule("big-tech", "trello", "Trello", ["trello"], ["trello.com", "atlassian.com"]),
    rule("big-tech", "monday", "monday.com", ["monday.com", "monday work"], [
      "monday.com"
    ]),
    rule("big-tech", "1password", "1Password", ["1password", "one password"], [
      "1password.com"
    ]),
    rule("big-tech", "lastpass", "LastPass", ["lastpass", "last pass"], [
      "lastpass.com"
    ]),
    rule("big-tech", "bitwarden", "Bitwarden", ["bitwarden"], ["bitwarden.com"]),
    rule("big-tech", "okta", "Okta", ["okta"], ["okta.com"]),
    rule("big-tech", "auth0", "Auth0", ["auth0"], ["auth0.com", "okta.com"]),
    rule("big-tech", "yahoo", "Yahoo", ["yahoo"], [
      "yahoo.com",
      "yahoo.fr",
      "yahoo.co.uk",
      "yahoo.de",
      "yahoo.es",
      "yahoo.it",
      "ymail.com",
      "rocketmail.com"
    ]),
    rule("big-tech", "proton", "Proton", ["proton mail", "protonmail", "proton.me"], [
      "proton.me",
      "protonmail.com",
      "pm.me"
    ]),
    rule("big-tech", "fastmail", "Fastmail", ["fastmail"], [
      "fastmail.com",
      "fastmail.fm"
    ]),
    rule("big-tech", "zoho", "Zoho", ["zoho"], [
      "zoho.com",
      "zoho.eu",
      "zohomail.com",
      "zohomail.eu"
    ]),
    rule("mail-providers", "gmx", "GMX", ["gmx", "gmx mail"], [
      "gmx.com",
      "gmx.fr",
      "gmx.net",
      "gmx.de",
      "gmx.at",
      "gmx.ch"
    ]),
    rule("mail-providers", "web-de", "WEB.DE", ["web.de", "web de"], [
      "web.de"
    ]),
    rule("mail-providers", "t-online-mail", "T-Online Mail", [
      "t-online",
      "t online",
      "telekom mail"
    ], ["t-online.de"]),
    rule("mail-providers", "freenet-mail", "Freenet Mail", [
      "freenet mail",
      "freenet.de"
    ], ["freenet.de"]),
    rule("mail-providers", "mailo", "Mailo", ["mailo", "netcourrier"], [
      "mailo.com",
      "mailo.fr",
      "mailo.eu",
      "netcourrier.com"
    ]),
    rule("mail-providers", "tuta", "Tuta", ["tuta", "tutanota", "tuta mail"], [
      "tuta.com",
      "tutanota.com",
      "tutanota.de",
      "tutamail.com"
    ]),
    rule("mail-providers", "mailbox-org", "mailbox.org", [
      "mailbox.org",
      "mailbox org"
    ], ["mailbox.org"]),
    rule("mail-providers", "posteo", "Posteo", ["posteo"], ["posteo.de"]),
    rule("mail-providers", "seznam-email", "Seznam Email", [
      "seznam email",
      "seznam.cz"
    ], ["seznam.cz"]),
    rule("mail-providers", "wp-poczta", "Poczta WP", [
      "poczta wp",
      "wp poczta",
      "wp.pl mail"
    ], ["wp.pl"]),
    rule("mail-providers", "onet-poczta", "Onet Poczta", [
      "onet poczta",
      "poczta onet"
    ], ["onet.pl"]),
    rule("mail-providers", "o2-poczta", "O2 Poczta", [
      "o2 poczta",
      "o2.pl mail"
    ], ["o2.pl"]),
    rule("mail-providers", "interia-poczta", "Interia Poczta", [
      "interia poczta",
      "poczta interia"
    ], ["interia.pl"]),
    rule("mail-providers", "libero-mail", "Libero Mail", [
      "libero mail",
      "libero.it"
    ], ["libero.it"]),
    rule("mail-providers", "virgilio-mail", "Virgilio Mail", [
      "virgilio mail",
      "virgilio.it"
    ], ["virgilio.it"]),
    rule("big-tech", "salesforce", "Salesforce", ["salesforce"], ["salesforce.com"]),
    rule("big-tech", "hubspot", "HubSpot", ["hubspot"], ["hubspot.com"]),
    rule("big-tech", "zendesk", "Zendesk", ["zendesk"], ["zendesk.com"]),
    rule("big-tech", "intercom", "Intercom", ["intercom.com", "intercom support"], [
      "intercom.com"
    ]),
    rule("big-tech", "workday", "Workday", ["workday"], ["workday.com"]),
    rule("big-tech", "servicenow", "ServiceNow", ["servicenow", "service now"], [
      "servicenow.com"
    ]),
    rule("big-tech", "rippling", "Rippling", ["rippling"], ["rippling.com"]),
    rule("big-tech", "deel", "Deel", ["deel.com", "deel payroll"], ["deel.com"]),
    rule("big-tech", "gusto", "Gusto", ["gusto payroll", "gusto.com"], ["gusto.com"]),
    rule("big-tech", "dropbox-transfer", "Dropbox Transfer", ["dropbox transfer"], [
      "dropbox.com"
    ]),

    rule("media-gaming", "netflix", "Netflix", ["netflix"], ["netflix.com"]),
    rule("media-gaming", "spotify", "Spotify", ["spotify"], ["spotify.com"]),
    rule("media-gaming", "disney", "Disney+", ["disney plus", "disney+"], [
      "disneyplus.com",
      "disney.com"
    ]),
    rule("media-gaming", "twitch", "Twitch", ["twitch"], ["twitch.tv"]),
    rule("media-gaming", "steam", "Steam", ["steam", "steam support"], [
      "steampowered.com",
      "steamcommunity.com"
    ]),
    rule("media-gaming", "epic-games", "Epic Games", ["epic games"], [
      "epicgames.com"
    ]),
    rule("media-gaming", "playstation", "PlayStation", ["playstation"], [
      "playstation.com",
      "sony.com"
    ]),
    rule("media-gaming", "xbox", "Xbox", ["xbox"], ["xbox.com", "microsoft.com"]),
    rule("media-gaming", "nintendo", "Nintendo", ["nintendo"], ["nintendo.com"]),
    rule("media-gaming", "hulu", "Hulu", ["hulu"], ["hulu.com"]),
    rule("media-gaming", "max", "Max", ["max.com", "hbo max"], [
      "max.com",
      "hbomax.com"
    ]),
    rule("media-gaming", "paramount-plus", "Paramount+", ["paramount plus"], [
      "paramountplus.com"
    ]),
    rule("media-gaming", "peacock", "Peacock", ["peacock tv", "peacocktv"], [
      "peacocktv.com"
    ]),
    rule("media-gaming", "crunchyroll", "Crunchyroll", ["crunchyroll"], [
      "crunchyroll.com"
    ]),
    rule("media-gaming", "roblox", "Roblox", ["roblox"], ["roblox.com"]),
    rule("media-gaming", "ea", "Electronic Arts", ["electronic arts", "ea.com"], [
      "ea.com"
    ]),
    rule("media-gaming", "ubisoft", "Ubisoft", ["ubisoft"], ["ubisoft.com"]),
    rule("media-gaming", "riot-games", "Riot Games", ["riot games"], [
      "riotgames.com"
    ]),
    rule("media-gaming", "battle-net", "Battle.net", ["battle.net", "blizzard"], [
      "battle.net",
      "blizzard.com"
    ]),
    rule("media-gaming", "minecraft", "Minecraft", ["minecraft"], [
      "minecraft.net",
      "microsoft.com"
    ])
  ];

  global.BYEBYEFISHING_RULESET_VERSION = RULESET_VERSION;
  global.BYEBYEFISHING_DEFAULT_RULES = rules;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = rules;
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
